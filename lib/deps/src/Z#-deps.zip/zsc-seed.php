<?php
// wygenerowane przez zst (cel php) — nie edytuj

// Runtime Z# dla celu php (PHP >= 8.1, bez rozszerzeń). Semantyka zgodna z runtime/native/zs_rt.c:
//  int = int64 (przepełnienie = błąd), float = float, napisy = bajty, tablice uporządkowane z kopiowaniem przy zapisie (natywne w PHP),
//  wyjątki ZExc / ZObj niesione przez ZEx.
error_reporting(E_ALL & ~E_DEPRECATED);
set_error_handler(function ($no, $str) { $GLOBALS['z_lasterr'] = $str; if (!(error_reporting() & $no)) return true; if ($no & (E_WARNING | E_NOTICE | E_USER_WARNING)) { z_die("błąd wewnętrzny PHP: " . $str); } return true; });

final class ZExc { public $kind; public $msg; public $line = 0; function __construct($k, $m) { $this->kind = $k; $this->msg = $m; } }
final class ZObj { public $cls; public $f = []; function __construct($c) { $this->cls = $c; } }
final class ZFn { public $id; public $cap; function __construct($i, $c) { $this->id = $i; $this->cap = $c; } }
final class ZEx extends Exception { public $val; function __construct($v) { parent::__construct("zs"); $this->val = $v; } }
final class Z { static $l = 0; }

function z_raise($e) {
    if ($e instanceof ZExc) { if ($e->line === 0) $e->line = Z::$l; }
    elseif ($e instanceof ZObj) { if (!isset($e->f['line']) || !is_int($e->f['line']) || $e->f['line'] === 0) $e->f['line'] = Z::$l; }
    throw new ZEx($e);
}
function z_die($m) { $e = new ZExc(1, $m); $e->line = Z::$l; throw new ZEx($e); }
function z_throwv($x) { if (!($x instanceof ZExc) && !($x instanceof ZObj)) z_die("throw wymaga obiektu typu Throwable"); z_raise($x); }
function z_excis($x, $kind) { return $x instanceof ZExc && ($kind === 0 || $x->kind === $kind); }
function z_getmessage($x) { if (!($x instanceof ZExc)) z_die("wywołanie metody `getMessage` na wartości typu " . z_tn($x)); return $x->msg; }
function z_last(...$a) { return $a[count($a) - 1]; }

function z_tn($v) {
    if ($v === null) return "null"; if (is_bool($v)) return "bool"; if (is_int($v)) return "int"; if (is_float($v)) return "float";
    if (is_string($v)) return "string"; if (is_array($v)) return "array"; if ($v instanceof ZObj) return $v->cls;
    if ($v instanceof ZFn) return "function"; return "object";
}
function z_isnum($v) { return is_int($v) || is_float($v); }

// ───── tekst ─────
function z_fmtfloat($f) {
    if (is_nan($f)) return "NaN"; if (is_infinite($f)) return $f > 0 ? "Infinity" : "-Infinity";
    if ($f == floor($f) && abs($f) < 1e15) return sprintf("%.1f", $f);
    for ($p = 0; $p < 17; $p++) { $e = sprintf("%.{$p}e", $f); if ((float)$e === $f) break; }
    $e = sprintf("%.{$p}e", $f);
    $neg = $e[0] === '-'; if ($neg) $e = substr($e, 1);
    $pos = strpos($e, 'e'); $mant = substr($e, 0, $pos); $ex = (int)substr($e, $pos + 1);
    $digits = str_replace('.', '', $mant); $nd = strlen($digits); $point = $ex + 1;
    if ($point <= 0) $r = "0." . str_repeat("0", -$point) . $digits;
    elseif ($point >= $nd) $r = $digits . str_repeat("0", $point - $nd);
    else $r = substr($digits, 0, $point) . "." . substr($digits, $point);
    return ($neg ? "-" : "") . $r;
}
function z_dumpstr($s) {
    $o = '"'; $n = strlen($s);
    for ($i = 0; $i < $n; $i++) {
        $c = ord($s[$i]);
        if ($c === 34) $o .= '\\"'; elseif ($c === 92) $o .= '\\\\'; elseif ($c === 10) $o .= '\\n'; elseif ($c === 13) $o .= '\\r';
        elseif ($c === 9) $o .= '\\t'; elseif ($c === 0) $o .= '\\0'; elseif ($c < 0x20 || $c === 0x7f) $o .= '\\u{' . dechex($c) . '}';
        else $o .= $s[$i];
    }
    return $o . '"';
}
function z_text($v, $dump = false) {
    if ($v === null) return "null"; if ($v === true) return "true"; if ($v === false) return "false";
    if (is_int($v)) return (string)$v; if (is_float($v)) return z_fmtfloat($v);
    if (is_string($v)) return $dump ? z_dumpstr($v) : $v;
    if (is_array($v)) {
        $seq = true; $i = 0; foreach ($v as $k => $_) { if ($k !== $i) { $seq = false; break; } $i++; }
        $p = [];
        foreach ($v as $k => $x) $p[] = ($seq ? "" : (is_string($k) ? z_dumpstr($k) : (string)$k) . " => ") . z_text($x, true);
        return "[" . implode(", ", $p) . "]";
    }
    if ($v instanceof ZObj) return "<object " . $v->cls . ">";
    if ($v instanceof ZFn) return "<function>";
    if ($v instanceof ZExc) return $v->kind ? "<object Error>" : "<object Exception>";
    return "<object>";
}
function z_truthy($v) {
    if ($v === null || $v === false) return false; if ($v === true) return true;
    if (is_int($v)) return $v !== 0; if (is_float($v)) return $v != 0.0;
    if (is_string($v)) return !($v === "" || $v === "0"); if (is_array($v)) return count($v) > 0; return true;
}

// ───── UTF-8 ─────
function z_u8len($c) { return $c < 0x80 ? 1 : ($c < 0xE0 ? 2 : ($c < 0xF0 ? 3 : 4)); }
function z_lossy($s) {
    $n = strlen($s); $o = ""; $i = 0;
    while ($i < $n) {
        $c = ord($s[$i]); $need = 0; $lo = 0x80; $hi = 0xBF;
        if ($c < 0x80) { $o .= $s[$i]; $i++; continue; }
        elseif ($c >= 0xC2 && $c <= 0xDF) $need = 1;
        elseif ($c === 0xE0) { $need = 2; $lo = 0xA0; } elseif ($c >= 0xE1 && $c <= 0xEC) $need = 2; elseif ($c === 0xED) { $need = 2; $hi = 0x9F; } elseif ($c >= 0xEE && $c <= 0xEF) $need = 2;
        elseif ($c === 0xF0) { $need = 3; $lo = 0x90; } elseif ($c >= 0xF1 && $c <= 0xF3) $need = 3; elseif ($c === 0xF4) { $need = 3; $hi = 0x8F; }
        else { $o .= "\xEF\xBF\xBD"; $i++; continue; }
        $j = 1; $ok = true;
        for (; $j <= $need; $j++) {
            if ($i + $j >= $n) { $ok = false; break; }
            $d = ord($s[$i + $j]); $l = $j === 1 ? $lo : 0x80; $h = $j === 1 ? $hi : 0xBF;
            if ($d < $l || $d > $h) { $ok = false; break; }
        }
        if ($ok) { $o .= substr($s, $i, $need + 1); $i += $need + 1; } else { $o .= "\xEF\xBF\xBD"; $i += $j; }
    }
    return $o;
}

// ───── tablice ─────
function z_k($k) {
    if (is_int($k)) return $k; if (is_bool($k)) return $k ? 1 : 0;
    if (is_float($k)) { if (is_finite($k) && floor($k) == $k && abs($k) < 9.2e18) return (int)$k; z_die("niepoprawny klucz tablicy typu float"); }
    if (is_string($k)) return $k; // PHP normalizuje napisy-liczby tak samo jak Z# (kanoniczne int64 -> int)
    z_die("niepoprawny klucz tablicy typu " . z_tn($k));
}
function z_aset(&$a, $k, $v) {
    if ($a === null) $a = []; elseif (!is_array($a)) z_die("nie można indeksować wartości typu " . z_tn($a) . " przy zapisie");
    $a[z_k($k)] = $v; return $v;
}
function z_apush(&$a, $v) {
    if ($a === null) $a = []; elseif (!is_array($a)) z_die("nie można indeksować wartości typu " . z_tn($a) . " przy zapisie");
    $a[] = $v; return $v;
}
function z_keytext($k) { return is_string($k) ? z_dumpstr($k) : (string)$k; }
function z_index($a, $k, $quiet = false) {
    if (is_array($a)) {
        $nk = z_k($k);
        if (array_key_exists($nk, $a)) return $a[$nk];
        if ($quiet) return null; z_die("brak klucza " . z_keytext($nk));
    }
    if (is_string($a)) {
        if (!is_int($k)) z_die("indeks tekstu musi być liczbą całkowitą");
        $len = strlen($a); $i = $k < 0 ? $len + $k : $k;
        if ($i < 0 || $i >= $len) { if ($quiet) return null; z_die("indeks $i poza zakresem tekstu (długość $len)"); }
        $c = ord($a[$i]);
        if (($c & 0xC0) === 0x80) { if ($quiet) return null; z_die("indeks $i wskazuje środek znaku UTF-8"); }
        $n = z_u8len($c); if ($i + $n > $len) $n = $len - $i;
        return substr($a, $i, $n);
    }
    if ($a === null) { if ($quiet) return null; z_die("indeksowanie wartości null"); }
    z_die("typ " . z_tn($a) . " nie obsługuje indeksowania");
}
function z_indexopt($a, $k) { return z_index($a, $k, true); }
function z_foreach($v) { if (!is_array($v)) z_die("foreach wymaga tablicy, jest " . z_tn($v)); return $v; }

// ───── porównania i operatory ─────
function z_ident($a, $b) { return $a === $b; }
function z_eq($a, $b) { if (z_isnum($a) && z_isnum($b) && is_int($a) !== is_int($b)) return (float)$a == (float)$b; return $a === $b; }
function z_cmp($a, $b) {
    if (is_int($a) && is_int($b)) return $a <=> $b;
    if (z_isnum($a) && z_isnum($b)) { $x = (float)$a; $y = (float)$b; return $x < $y ? -1 : ($x > $y ? 1 : 0); }
    if (is_string($a) && is_string($b)) { $c = strcmp($a, $b); return $c < 0 ? -1 : ($c > 0 ? 1 : 0); }
    if (is_bool($a) && is_bool($b)) return (int)$a <=> (int)$b;
    z_die("nie można porównać " . z_tn($a) . " z " . z_tn($b));
}
function z_badop($op, $a, $b) { z_die("operacja $op niedostępna dla " . z_tn($a) . " i " . z_tn($b)); }
function z_add($a, $b) {
    if (is_int($a) && is_int($b)) { $r = $a + $b; if (is_float($r)) z_die("przepełnienie liczby całkowitej"); return $r; }
    if (z_isnum($a) && z_isnum($b)) return (float)$a + (float)$b;
    if (is_array($a) && is_array($b)) return $a + $b;
    z_badop("Add", $a, $b);
}
function z_sub($a, $b) {
    if (is_int($a) && is_int($b)) { $r = $a - $b; if (is_float($r)) z_die("przepełnienie liczby całkowitej"); return $r; }
    if (z_isnum($a) && z_isnum($b)) return (float)$a - (float)$b;
    z_badop("Sub", $a, $b);
}
function z_mul($a, $b) {
    if (is_int($a) && is_int($b)) { $r = $a * $b; if (is_float($r)) z_die("przepełnienie liczby całkowitej"); return $r; }
    if (z_isnum($a) && z_isnum($b)) return (float)$a * (float)$b;
    z_badop("Mul", $a, $b);
}
function z_div($a, $b) {
    if (!(z_isnum($a) && z_isnum($b))) z_badop("Div", $a, $b);
    if ((float)$b == 0.0) z_die("dzielenie przez zero");
    if (is_int($a) && is_int($b)) {
        if ($b === -1) { if ($a === PHP_INT_MIN) return (float)$a / -1.0; return -$a; }
        if ($a % $b === 0) return intdiv($a, $b);
    }
    return (float)$a / (float)$b;
}
function z_mod($a, $b) {
    if (is_int($a) && is_int($b)) { if ($b === 0) z_die("modulo przez zero"); if ($b === -1) return 0; return $a % $b; }
    z_badop("Mod", $a, $b);
}
function z_bitand($a, $b) { if (is_int($a) && is_int($b)) return $a & $b; z_badop("BitAnd", $a, $b); }
function z_bitor($a, $b) { if (is_int($a) && is_int($b)) return $a | $b; z_badop("BitOr", $a, $b); }
function z_bitxor($a, $b) { if (is_int($a) && is_int($b)) return $a ^ $b; z_badop("BitXor", $a, $b); }
function z_shl($a, $b) { if (is_int($a) && is_int($b)) return $a << ($b & 63); z_badop("Shl", $a, $b); }
function z_shr($a, $b) { if (is_int($a) && is_int($b)) return $a >> ($b & 63); z_badop("Shr", $a, $b); }
function z_bitnot($a) { if (is_int($a)) return ~$a; z_die("operator jednoargumentowy BitNot niedostępny dla " . z_tn($a)); }
function z_pow($a, $b) {
    if (is_int($a) && is_int($b) && $b >= 0) {
        $r = 1; $base = $a; $e = $b; $ovf = false;
        while ($e > 0) {
            if ($e & 1) { $r = $r * $base; if (is_float($r)) { $ovf = true; break; } }
            $e >>= 1; if ($e > 0) { $base = $base * $base; if (is_float($base)) { $ovf = true; break; } }
        }
        if (!$ovf) return $r;
        return pow((float)$a, (float)$b);
    }
    if (z_isnum($a) && z_isnum($b)) return pow((float)$a, (float)$b);
    z_badop("Pow", $a, $b);
}
function z_concat($a, $b) { return (is_string($a) ? $a : z_text($a)) . (is_string($b) ? $b : z_text($b)); }
function z_neg($a) {
    if (is_int($a)) { if ($a === PHP_INT_MIN) z_die("przepełnienie liczby całkowitej"); return -$a; }
    if (is_float($a)) return -$a;
    z_die("operator jednoargumentowy Neg niedostępny dla " . z_tn($a));
}
function z_chk($v, $type, $what) {
    $ok = false;
    if ($type === "int") $ok = is_int($v);
    elseif ($type === "float") { $ok = is_float($v); if (!$ok && is_int($v)) return (float)$v; }
    elseif ($type === "string") $ok = is_string($v); elseif ($type === "bool") $ok = is_bool($v); elseif ($type === "array") $ok = is_array($v);
    elseif ($v instanceof ZObj || $v instanceof ZExc) $ok = true;
    if ($ok) return $v;
    z_die("$what: oczekiwano $type, otrzymano " . z_tn($v));
}

// ───── wbudowane ─────
function z_ns($v, $f, $n) { if (!is_string($v)) z_die("$f: argument #$n powinien być tekstem, jest " . z_tn($v)); return $v; }
function z_ni($v, $f, $n) { if (!is_int($v)) z_die("$f: argument #$n powinien być liczbą całkowitą, jest " . z_tn($v)); return $v; }
function z_nf($v, $f, $n) { if (!z_isnum($v)) z_die("$f: argument #$n powinien być liczbą, jest " . z_tn($v)); return (float)$v; }
function z_na($v, $f, $n) { if (!is_array($v)) z_die("$f: argument #$n powinien być tablicą, jest " . z_tn($v)); return $v; }
const Z_WS = " \t\n\v\f\r";
function z_b_count($v) { if (is_array($v)) return count($v); if (is_string($v)) return strlen($v); z_die("count: niedostępne dla " . z_tn($v)); }
function z_b_strlen($v) { return strlen(z_ns($v, "strlen", 1)); }
function z_b_typeof($v) { if ($v instanceof ZObj) return $v->cls; if ($v instanceof ZExc) return $v->kind ? "Error" : "Exception"; return z_tn($v); }
function z_b_is_int($v) { return is_int($v); } function z_b_is_float($v) { return is_float($v); } function z_b_is_string($v) { return is_string($v); }
function z_b_is_bool($v) { return is_bool($v); } function z_b_is_array($v) { return is_array($v); } function z_b_is_null($v) { return $v === null; }
function z_b_strval($v) { return z_text($v); } function z_b_boolval($v) { return z_truthy($v); }
function z_b_intval($v) {
    if (is_int($v)) return $v;
    if (is_float($v)) return is_nan($v) ? 0 : ($v >= 9.2233720368547758e18 ? PHP_INT_MAX : ($v <= -9.2233720368547758e18 ? PHP_INT_MIN : (int)$v));
    if (is_bool($v)) return $v ? 1 : 0; if ($v === null) return 0;
    if (is_string($v)) {
        $t = trim($v, Z_WS);
        if (preg_match('/^[+-]?[0-9]+$/D', $t)) {
            $neg = $t[0] === '-'; $d = ltrim(ltrim($t, '+-'), '0'); if ($d === '') return 0;
            $lim = $neg ? '9223372036854775808' : '9223372036854775807';
            if (strlen($d) < 19 || (strlen($d) === 19 && strcmp($d, $lim) <= 0)) return $neg ? -(int)$d : (int)$d;
            return $neg ? PHP_INT_MIN : PHP_INT_MAX;
        }
        if ($t !== "" && preg_match('/^[+-]?([0-9]+\.?[0-9]*([eE][+-]?[0-9]+)?|\.[0-9]+([eE][+-]?[0-9]+)?)$/D', $t)) { $f = (float)$t; return is_nan($f) ? 0 : z_b_intval($f); }
        return 0;
    }
    z_die("intval: nie można przekonwertować " . z_tn($v));
}
function z_b_floatval($v) {
    if (is_int($v)) return (float)$v; if (is_float($v)) return $v;
    if (is_string($v)) { $t = trim($v, Z_WS); return ($t !== "" && preg_match('/^[+-]?([0-9]+\.?[0-9]*([eE][+-]?[0-9]+)?|\.[0-9]+([eE][+-]?[0-9]+)?|inf(inity)?|nan)$/Di', $t)) ? (float)$t : 0.0; }
    return 0.0;
}
function z_b_ord($v) { $s = z_ns($v, "ord", 1); if ($s === "") z_die("ord: pusty tekst"); return ord($s[0]); }
function z_b_chr($v) {
    $n = z_ni($v, "chr", 1);
    if ($n < 0 || $n >= 0x110000 || ($n >= 0xD800 && $n < 0xE000)) return "";
    if ($n < 0x80) return chr($n); if ($n < 0x800) return chr(0xC0 | $n >> 6) . chr(0x80 | ($n & 63));
    if ($n < 0x10000) return chr(0xE0 | $n >> 12) . chr(0x80 | (($n >> 6) & 63)) . chr(0x80 | ($n & 63));
    return chr(0xF0 | $n >> 18) . chr(0x80 | (($n >> 12) & 63)) . chr(0x80 | (($n >> 6) & 63)) . chr(0x80 | ($n & 63));
}
function z_b_trim($v) { return trim(z_ns($v, "trim", 1), Z_WS); }
function z_b_contains($a, $b) { return str_contains(z_ns($a, "contains", 1), z_ns($b, "contains", 2)); }
function z_b_starts_with($a, $b) { return str_starts_with(z_ns($a, "starts_with", 1), z_ns($b, "starts_with", 2)); }
function z_b_ends_with($a, $b) { return str_ends_with(z_ns($a, "ends_with", 1), z_ns($b, "ends_with", 2)); }
function z_b_index_of($a, $b) { $p = strpos(z_ns($a, "index_of", 1), z_ns($b, "index_of", 2)); return $p === false ? -1 : $p; }
function z_b_repeat($a, $b) { $x = z_ns($a, "repeat", 1); $n = z_ni($b, "repeat", 2); return $n <= 0 ? "" : str_repeat($x, $n); }
function z_b_substr($s, $a, $l = null) {
    $x = z_ns($s, "substr", 1); $len = strlen($x); $st = z_ni($a, "substr", 2);
    if ($st < 0) { $st = $len + $st; if ($st < 0) $st = 0; } if ($st > $len) $st = $len;
    if (is_int($l)) { $n = $l >= 0 ? $l : $len - $st + $l; if ($n < 0) $n = 0; } else $n = $len - $st;
    if ($st + $n > $len) $n = $len - $st;
    return z_lossy(substr($x, $st, $n));
}
function z_b_join($a, $sep) { $x = z_na($a, "join", 1); $p = []; foreach ($x as $v) $p[] = z_text($v); return implode(is_string($sep) ? $sep : "", $p); }
function z_b_in_array($n, $arr) { foreach (z_na($arr, "in_array", 2) as $v) if ($v === $n) return true; return false; }
function z_b_range($a, $b) { $x = z_ni($a, "range", 1); $y = z_ni($b, "range", 2); $r = []; if ($x <= $y) { for ($i = $x; ; $i++) { $r[] = $i; if ($i === $y) break; } } else { for ($i = $x; ; $i--) { $r[] = $i; if ($i === $y) break; } } return $r; }
function z_b_keys($a) { return array_keys(z_na($a, "keys", 1)); }
function z_b_values($a) { return array_values(z_na($a, "values", 1)); }
function z_b_has_key($a, $k) { return array_key_exists(z_k($k), z_na($a, "has_key", 1)); }
function z_b_upper($v) { return strtr(z_ns($v, "upper", 1), "abcdefghijklmnopqrstuvwxyz", "ABCDEFGHIJKLMNOPQRSTUVWXYZ"); }
function z_b_lower($v) { return strtr(z_ns($v, "lower", 1), "ABCDEFGHIJKLMNOPQRSTUVWXYZ", "abcdefghijklmnopqrstuvwxyz"); }
function z_b_replace($a, $f, $t) { $s = z_ns($a, "replace", 1); $x = z_ns($f, "replace", 2); $y = z_ns($t, "replace", 3); return $x === "" ? $s : str_replace($x, $y, $s); }
function z_chars($s) { $r = []; $n = strlen($s); for ($i = 0; $i < $n;) { $k = z_u8len(ord($s[$i])); if ($i + $k > $n) $k = $n - $i; $r[] = substr($s, $i, $k); $i += $k; } return $r; }
function z_b_split($a, $sep) { $s = z_ns($a, "split", 1); $x = z_ns($sep, "split", 2); return $x === "" ? z_chars($s) : explode($x, $s); }
function z_b_chars($a) { return z_chars(z_ns($a, "chars", 1)); }
function z_u8count($s) { $n = 0; $l = strlen($s); for ($i = 0; $i < $l; $i++) if ((ord($s[$i]) & 0xC0) !== 0x80) $n++; return $n; }
function z_pad($a, $n, $p, $left, $f) {
    $s = z_ns($a, $f, 1); $w = z_ni($n, $f, 2); if ($w < 0) $w = 0;
    $pc = " "; if (is_string($p) && $p !== "") { $k = z_u8len(ord($p[0])); $pc = substr($p, 0, $k); }
    $l = z_u8count($s); if ($l >= $w) return $a;
    $pad = str_repeat($pc, $w - $l); return $left ? $pad . $s : $s . $pad;
}
function z_b_pad_left($a, $n, $p = null) { return z_pad($a, $n, $p, true, "pad_left"); }
function z_b_pad_right($a, $n, $p = null) { return z_pad($a, $n, $p, false, "pad_right"); }
function z_b_array_slice($a, $s, $l = null) {
    $x = array_values(z_na($a, "array_slice", 1)); $len = count($x); $st = z_ni($s, "array_slice", 2);
    if ($st < 0) { $st = $len + $st; if ($st < 0) $st = 0; } if ($st > $len) $st = $len;
    $n = is_int($l) ? $l : $len; if ($n < 0) $n = 0; $end = $st + $n; if ($end > $len) $end = $len;
    return array_slice($x, $st, $end - $st);
}
function z_b_reverse($a) {
    if (is_string($a)) return implode("", array_reverse(z_chars($a)));
    if (!is_array($a)) z_die("reverse: niedostępne dla " . z_tn($a));
    return array_reverse(array_values($a));
}
function z_b_sort($a) { $x = array_values(z_na($a, "sort", 1)); usort($x, 'z_cmp'); return $x; }
function z_b_push($a, $v) { z_na($a, "push", 1); $a[] = $v; return $a; }
function z_b_dump($v) { echo z_text($v, true), "\n"; return null; }
function z_first($v, $f) { $s = z_ns($v, $f, 1); return $s === "" ? null : ord($s[0]); }
function z_b_is_digit($v) { $c = z_first($v, "is_digit"); return $c !== null && $c >= 48 && $c <= 57; }
function z_b_is_alpha($v) { $c = z_first($v, "is_alpha"); return $c !== null && (($c >= 65 && $c <= 90) || ($c >= 97 && $c <= 122) || $c === 95 || $c >= 0x80); }
function z_b_is_alnum($v) { $c = z_first($v, "is_alnum"); return $c !== null && (($c >= 48 && $c <= 57) || ($c >= 65 && $c <= 90) || ($c >= 97 && $c <= 122) || $c === 95 || $c >= 0x80); }
function z_b_is_space($v) { $c = z_first($v, "is_space"); return $c !== null && ($c === 32 || ($c >= 9 && $c <= 13)); }
function z_b_is_hex_digit($v) { $c = z_first($v, "is_hex_digit"); return $c !== null && (($c >= 48 && $c <= 57) || ($c >= 65 && $c <= 70) || ($c >= 97 && $c <= 102)); }
function z_b_to_hex($v) { return dechex(z_ni($v, "to_hex", 1)); }
function z_b_read_line() {
    $l = fgets(STDIN); if ($l === false) return null;
    $l = substr($l, -1) === "\n" ? substr($l, 0, -1) : $l; return rtrim($l, "\r");
}
function z_b_zs_obj_new($cls) { return new ZObj($cls); }
function z_b_zs_obj_class($o) { return $o instanceof ZObj ? $o->cls : null; }
function z_b_zs_obj_get($o, $name) {
    if (!($o instanceof ZObj)) { if ($o === null) z_die("dostęp do właściwości `$name` wartości null"); z_die("dostęp do właściwości `$name` typu " . z_tn($o)); }
    if (!array_key_exists(z_k($name), $o->f)) z_die("obiekt klasy " . $o->cls . " nie ma właściwości $name");
    return $o->f[z_k($name)];
}
function z_b_zs_obj_take($o, $name) { $v = z_b_zs_obj_get($o, $name); $o->f[z_k($name)] = null; return $v; }
function z_b_zs_obj_set($o, $name, $v) { if (!($o instanceof ZObj)) z_die("zapis właściwości `$name` na wartości typu " . z_tn($o)); $o->f[z_k($name)] = $v; return $v; }
function z_b_zs_obj_put($o, $name, $v) { $o->f[z_k($name)] = $v; return $v; }
function z_b_zs_no_method($o, $name) { if ($o instanceof ZObj) z_die("klasa " . $o->cls . " nie ma metody $name"); z_die("wywołanie metody `$name` na wartości typu " . z_tn($o)); }
function z_b_zs_no_class($name) { z_die("nieznana klasa $name"); }
function z_b_zs_mkfn($id, $cap) { return new ZFn($id, $cap); }
function z_b_zs_fn_id($f) { if ($f instanceof ZFn) return $f->id; if (is_string($f)) return $f; return null; }
function z_b_zs_fn_cap($f) { return $f instanceof ZFn ? $f->cap : null; }
function z_b_is_callable($f) { return $f instanceof ZFn; }
$GLOBALS['z_statics'] = [];
function z_b_zs_sget($name) { return $GLOBALS['z_statics'][z_k($name)] ?? null; }
function z_b_zs_sset($name, $v) { $GLOBALS['z_statics'][z_k($name)] = $v; return $v; }

// ───── moduły ─────
function z_iodie($p, $what = null) { $e = $GLOBALS['z_lasterr'] ?? null; $m = $what ?? ($e ? preg_replace('/^.*: /', '', $e) : "błąd wejścia/wyjścia"); z_die("$p: $m"); }
function z_isfile($p) { return is_file($p); }
function z_withext($base) { foreach ([".zsharp", ".zs"] as $e) if (is_file($base . $e)) return $base . $e; return null; }
function z_manifest_member($toml, $name) {
    $t = @file_get_contents($toml); if ($t === false) return null;
    foreach (explode("\n", $t) as $ln) if (preg_match('/^[ \t]*([A-Za-z0-9_]+)[ \t]*=[ \t]*"([^"]*)"/', $ln, $m) && $m[1] === $name) return $m[2];
    return null;
}
function z_m_System_resolveImport($segs, $dir) {
    if (!is_array($segs)) z_die("System.resolveImport: argument 1 musi być tablicą");
    z_ns($dir, "System.resolveImport", 2); $names = array_map('z_text', array_values($segs)); if (!count($names)) return null;
    if ($names[0] === "Workspace" && count($names) >= 2) {
        $cur = $dir;
        for ($up = 0; $up < 40; $up++) {
            foreach (["", "/Z-Sharp"] as $sub) {
                $mem = z_manifest_member($cur . $sub . "/Z#.toml", $names[1]);
                if ($mem !== null) {
                    $base = $cur . $sub . "/" . $mem;
                    if (is_file($base)) {
                        for ($k = 2; $k < count($names); $k++) { $base = z_withext(dirname($base) . "/" . $names[$k]); if ($base === null) return null; }
                        return $base;
                    }
                }
            }
            $sl = strrpos($cur, "/");
            if ($sl === false || $sl === 0) { if ($cur !== "/" && $cur !== ".") $cur = "."; else break; if ($up > 0 && $cur === ".") break; } else $cur = substr($cur, 0, $sl);
            if ($cur === "." && $up > 0) $cur = getcwd();
        }
        return null;
    }
    if ($names[0] === "Std" && count($names) === 2) {
        $lo = strtolower($names[1]);
        foreach ([getenv("ZS_STD") ? getenv("ZS_STD") . "/$lo.zsharp" : null, getenv("ZS_HOME") ? getenv("ZS_HOME") . "/stdlib/$lo.zsharp" : null] as $p) if ($p && is_file($p)) return $p;
        return null;
    }
    $dirs = [$dir, getcwd()]; if (getenv("ZS_PATH")) foreach (explode(":", getenv("ZS_PATH")) as $t) if ($t !== "") $dirs[] = $t;
    foreach ($dirs as $d) { $r = z_withext($d . "/" . implode("/", $names)); if ($r) return $r; }
    return null;
}
function z_spawn($cmd, $args, $inherit) {
    z_ns($cmd, "Process", 1); $av = array_map('z_text', array_values(z_na($args, "Process", 2)));
    $argv = array_merge([$cmd], $av);
    if ($inherit) {
        fflush(STDOUT); $p = @proc_open($argv, [], $pipes);
        if (!is_resource($p)) return [127, "", "$cmd: No such file or directory\n"];
        $rc = proc_close($p); return [$rc < 0 ? -1 : $rc, "", ""];
    }
    $p = @proc_open($argv, [0 => ["pipe", "r"], 1 => ["pipe", "w"], 2 => ["pipe", "w"]], $pipes);
    if (!is_resource($p)) return [127, "", "$cmd: No such file or directory\n"];
    fclose($pipes[0]); stream_set_blocking($pipes[1], false); stream_set_blocking($pipes[2], false);
    $o = ""; $e = ""; $open = [$pipes[1], $pipes[2]];
    while ($open) {
        $r = $open; $w = null; $x = null; if (@stream_select($r, $w, $x, 1) === false) break;
        foreach ($r as $s) { $d = fread($s, 65536); if ($d === false || ($d === "" && feof($s))) { $open = array_values(array_filter($open, fn($q) => $q !== $s)); continue; } if ($s === $pipes[1]) $o .= $d; else $e .= $d; }
    }
    fclose($pipes[1]); fclose($pipes[2]); $st = proc_get_status($p); $rc = proc_close($p);
    if (isset($st['running']) && !$st['running'] && $st['exitcode'] >= 0) $rc = $st['exitcode'];
    if ($rc === 127 && $e === "") $e = "$cmd: No such file or directory\n";
    return [$rc < 0 ? -1 : $rc, $o, $e];
}
function z_m_Process_run($c, $a) { [$s, $o, $e] = z_spawn($c, $a, false); return ["status" => $s, "stdout" => $o, "stderr" => $e]; }
function z_m_Process_exec($c, $a) { return z_spawn($c, $a, true)[0]; }
function z_m_Math_sqrt($v) { return sqrt(z_nf($v, "Math.sqrt", 1)); }
function z_m_Math_floor($v) { return (int)floor(z_nf($v, "Math.floor", 1)); }
function z_m_Math_ceil($v) { return (int)ceil(z_nf($v, "Math.ceil", 1)); }
function z_m_Math_round($v) { return (int)round(z_nf($v, "Math.round", 1)); }
function z_m_Math_abs($v) { if (is_int($v)) return $v < 0 ? z_neg($v) : $v; if (is_float($v)) return abs($v); z_die("Math.abs: " . z_tn($v)); }
function z_m_Math_pow($a, $b) { return z_pow($a, $b); }
function z_m_Math_min($a, $b) { return z_cmp($a, $b) <= 0 ? $a : $b; }
function z_m_Math_max($a, $b) { return z_cmp($a, $b) <= 0 ? $b : $a; }
function z_m_System_args() { global $argv; return array_values($argv); }
function z_m_System_env($k) { $e = getenv(z_ns($k, "System.env", 1)); return $e === false ? null : $e; }
function z_m_System_os() { return PHP_OS_FAMILY === "Darwin" ? "macos" : strtolower(PHP_OS_FAMILY); }
function z_m_System_architecture() { $m = php_uname("m"); return $m === "x86_64" || $m === "amd64" ? "x86_64" : ($m === "aarch64" || $m === "arm64" ? "aarch64" : "unknown"); }
function z_m_System_time() { return microtime(true); }
function z_m_System_cpuCount() { $n = (int)@shell_exec("nproc 2>/dev/null"); return $n > 0 ? $n : 1; }
function z_m_System_version() { return "0.0.1"; }
function z_m_System_dirname($p) {
    $s = z_ns($p, "System.dirname", 1); $i = strlen($s); while ($i > 1 && $s[$i - 1] === "/") $i--; while ($i > 0 && $s[$i - 1] !== "/") $i--; while ($i > 1 && $s[$i - 1] === "/") $i--;
    if ($i === 0) return "."; if ($i === 1 && $s[0] === "/") return "/"; return substr($s, 0, $i);
}
function z_m_System_setEnv($k, $v) { putenv(z_ns($k, "System.setEnv", 1) . "=" . z_text($v)); return null; }
function z_m_System_unsetEnv($k) { putenv(z_ns($k, "System.unsetEnv", 1)); return null; }
function z_m_System_environ() { $e = getenv(); ksort($e, SORT_STRING); return $e; }
function z_m_System_cwd() { return getcwd(); }
function z_m_System_chdir($p) { if (!@chdir(z_ns($p, "System.chdir", 1))) z_iodie($p); return null; }
function z_m_System_pid() { return getmypid(); }
function z_m_System_hostname() { return gethostname(); }
function z_m_System_bytes($s) { return array_values(unpack("C*", z_ns($s, "System.bytes", 1) . "") ?: []); }
function z_m_System_fromBytes($a) { $s = ""; foreach (z_na($a, "System.fromBytes", 1) as $b) $s .= chr($b & 255); return z_lossy($s); }
function z_m_System_nowNanos() { return (int)(microtime(true) * 1e6) * 1000; }
function z_m_System_monotonic() { static $t0 = null; $n = hrtime(true); if ($t0 === null) $t0 = $n; return $n - $t0 + 1000000000; }
function z_m_System_sleep($ms) { $m = z_ni($ms, "System.sleep", 1); if ($m > 0) usleep($m * 1000); return null; }
function z_m_System_localOffset($t) { return (new DateTime("@" . z_ni($t, "System.localOffset", 1)))->setTimezone(new DateTimeZone(date_default_timezone_get()))->getOffset(); }
function z_m_System_gc() { return null; }
function z_m_System_gcStats() { return []; }
function z_m_File_read($p) { $d = @file_get_contents(z_ns($p, "File.read", 1)); if ($d === false) z_iodie($p); return $d; }
function z_m_File_write($p, $d) { if (@file_put_contents(z_ns($p, "File.write", 1), z_text($d)) === false) z_iodie($p); return null; }
function z_m_File_append($p, $d) { if (@file_put_contents(z_ns($p, "File.append", 1), z_text($d), FILE_APPEND) === false) z_iodie($p); return null; }
function z_m_File_exists($p) { return is_file(z_ns($p, "File.exists", 1)); }
function z_m_File_delete($p) { if (!@unlink(z_ns($p, "File.delete", 1))) z_iodie($p); return null; }
function z_m_File_stat($p) {
    $s = @lstat(z_ns($p, "File.stat", 1)); if ($s === false) return null; $m = $s['mode'] & 0170000;
    return ["kind" => $m === 0120000 ? "link" : ($m === 0040000 ? "dir" : ($m === 0100000 ? "file" : "other")), "size" => $s['size'], "mtime" => $s['mtime'], "mode" => $s['mode'] & 07777];
}
function z_m_File_rename($a, $b) { if (!@rename(z_ns($a, "File.rename", 1), z_ns($b, "File.rename", 2))) z_iodie($a); return null; }
function z_m_File_realpath($p) { $r = realpath(z_ns($p, "File.realpath", 1)); if ($r === false) z_iodie($p, "No such file or directory"); return $r; }
function z_m_File_chmod($p, $m) { if (!@chmod(z_ns($p, "File.chmod", 1), z_ni($m, "File.chmod", 2))) z_iodie($p); return null; }
function z_m_File_symlink($t, $l) { if (!@symlink(z_ns($t, "File.symlink", 1), z_ns($l, "File.symlink", 2))) z_iodie($l); return null; }
function z_m_File_readlink($p) { $r = @readlink(z_ns($p, "File.readlink", 1)); if ($r === false) z_iodie($p); return $r; }
function z_m_Directory_create($p) { z_ns($p, "Directory.create", 1); if (!is_dir($p) && !@mkdir($p, 0777, true) && !is_dir($p)) z_iodie($p); return null; }
function z_m_Directory_exists($p) { return is_dir(z_ns($p, "Directory.exists", 1)); }
function z_m_Directory_list($p) { $l = @scandir(z_ns($p, "Directory.list", 1), SCANDIR_SORT_NONE); if ($l === false) z_iodie($p); $l = array_values(array_filter($l, fn($x) => $x !== "." && $x !== "..")); sort($l, SORT_STRING); return $l; }
function z_m_Directory_remove($p) { if (!@rmdir(z_ns($p, "Directory.remove", 1))) z_iodie($p); return null; }
foreach (["tcpConnect", "tcpListen", "accept", "read", "write", "close", "setTimeout", "udpBind", "sendTo", "recvFrom", "resolve", "localAddr", "peerAddr"] as $__n) { eval("function z_m_Socket_$__n(...\$a) { z_die('Socket.$__n: niedostępne w celu php (użyj celu c / zsc)'); }"); }

function z_echo(...$a) { echo implode(" ", array_map('z_text', $a)), "\n"; return null; }
function z_necho(...$a) { echo implode("", array_map('z_text', $a)); return null; }
function z_eecho(...$a) { fwrite(STDERR, implode(" ", array_map('z_text', $a)) . "\n"); return null; }
function z_exit($c = 0) { exit(is_int($c) ? $c : 0); }
function z_dump($v) { return z_b_dump($v); }
function z_run($top, $main, $callsMain) {
    $rc = 0;
    try { $top(); if ($main !== null && !$callsMain) { $r = $main(); if (is_int($r)) $rc = $r; } }
    catch (ZEx $e) {
        $v = $e->val;
        if ($v instanceof ZObj) { fwrite(STDERR, "Nieobsłużony wyjątek " . $v->cls . ": " . z_text($v->f['message'] ?? null) . " (linia " . (is_int($v->f['line'] ?? null) ? $v->f['line'] : 0) . ")\n"); }
        else fwrite(STDERR, "Nieobsłużony wyjątek " . ($v->kind ? "Error" : "Exception") . ": " . z_text($v->msg) . " (linia " . $v->line . ")\n");
        $rc = 1;
    }
    exit($rc);
}

function f_LexError____construct($v_this, $v_message, $v_line, $v_col) {
  Z::$l = 7;
  f_Exception____construct($v_this, z_concat(z_concat(z_concat(z_concat(z_concat($v_message, ' ('), $v_line), ':'), $v_col), ')'));
  Z::$l = 8;
  z_b_zs_obj_set($v_this, 'lineNo', $v_line);
  Z::$l = 9;
  z_b_zs_obj_set($v_this, 'colNo', $v_col);
  return null;
}
function f_LexError__new($v_message, $v_line, $v_col) {
  $v___o = null;
  Z::$l = 3;
  ($v___o = z_b_zs_obj_new('LexError'));
  Z::$l = 3;
  z_b_zs_obj_set($v___o, 'message', '');
  Z::$l = 3;
  z_b_zs_obj_set($v___o, 'line', 0);
  Z::$l = 3;
  z_b_zs_obj_set($v___o, 'lineNo', null);
  Z::$l = 3;
  z_b_zs_obj_set($v___o, 'colNo', null);
  Z::$l = 3;
  f_LexError____construct($v___o, $v_message, $v_line, $v_col);
  Z::$l = 3;
  return $v___o;
  return null;
}
function f_LexTables__new() {
  $v___o = null;
  Z::$l = 13;
  ($v___o = z_b_zs_obj_new('LexTables'));
  Z::$l = 13;
  return $v___o;
  return null;
}
function f_Lexer____construct($v_this, $v_src, $v_keep) {
  Z::$l = 45;
  z_b_zs_obj_set($v_this, 'src', $v_src);
  Z::$l = 46;
  z_b_zs_obj_set($v_this, 'n', z_b_strlen($v_src));
  Z::$l = 47;
  z_b_zs_obj_set($v_this, 'pos', 0);
  Z::$l = 48;
  z_b_zs_obj_set($v_this, 'line', 1);
  Z::$l = 49;
  z_b_zs_obj_set($v_this, 'col', 1);
  Z::$l = 50;
  z_b_zs_obj_set($v_this, 'out', []);
  Z::$l = 51;
  z_b_zs_obj_set($v_this, 'keep', $v_keep);
  return null;
}
function f_Lexer__peek($v_this, $v_k) {
  Z::$l = 55;
  return (($_t1 = z_indexopt(z_b_zs_obj_get($v_this, 'src'), z_add(z_b_zs_obj_get($v_this, 'pos'), $v_k))) !== null ? $_t1 : '');
  return null;
}
function f_Lexer__bump($v_this) {
  $v_c = null;
  Z::$l = 59;
  ($v_c = z_index(z_b_zs_obj_get($v_this, 'src'), z_b_zs_obj_get($v_this, 'pos')));
  Z::$l = 60;
  z_b_zs_obj_set($v_this, 'pos', z_add(z_b_zs_obj_get($v_this, 'pos'), z_b_strlen($v_c)));
  Z::$l = 61;
  if (z_truthy(($v_c === '
'))) {
    Z::$l = 62;
    z_b_zs_obj_set($v_this, 'line', z_add(z_b_zs_obj_get($v_this, 'line'), 1));
    Z::$l = 63;
    z_b_zs_obj_set($v_this, 'col', 1);
  } else {
    Z::$l = 65;
    z_b_zs_obj_set($v_this, 'col', z_add(z_b_zs_obj_get($v_this, 'col'), 1));
  }
  Z::$l = 67;
  return $v_c;
  return null;
}
function f_Lexer__fail($v_this, $v_msg, $v_line, $v_col) {
  Z::$l = 70;
  z_throwv(f_LexError__new($v_msg, $v_line, $v_col));
  return null;
}
function f_Lexer__emit($v_this, $v_kind, $v_text, $v_start, $v_line, $v_col, $v_value) {
  $v___r1 = null;
  $v___w2 = null;
  Z::$l = 73;
  ($v___r1 = [z_k('kind') => $v_kind, z_k('text') => $v_text, z_k('value') => $v_value, z_k('line') => $v_line, z_k('col') => $v_col, z_k('start') => $v_start, z_k('end') => z_b_zs_obj_get($v_this, 'pos')]);
  Z::$l = 73;
  ($v___w2 = z_b_zs_obj_take($v_this, 'out'));
  Z::$l = 73;
  z_apush($v___w2, $v___r1);
  Z::$l = 73;
  z_b_zs_obj_put($v_this, 'out', $v___w2);
  return null;
}
function f_Lexer__run($v_this) {
  $v_line = null;
  $v_col = null;
  $v_c = null;
  $v_start = null;
  Z::$l = 78;
  if (z_truthy(z_b_starts_with(z_b_zs_obj_get($v_this, 'src'), '#!'))) {
    Z::$l = 79;
    ($v_line = z_b_zs_obj_get($v_this, 'line'));
    Z::$l = 79;
    ($v_col = z_b_zs_obj_get($v_this, 'col'));
    while (true) {
      Z::$l = 80;
      if (!z_truthy((z_truthy((z_cmp(z_b_zs_obj_get($v_this, 'pos'), z_b_zs_obj_get($v_this, 'n')) < 0)) && z_truthy((f_zs_invoke($v_this, 'peek', []) !== '
'))))) break;
      Z::$l = 80;
      f_zs_invoke($v_this, 'bump', []);
    }
    Z::$l = 81;
    f_zs_invoke($v_this, 'emit', ['shebang', z_b_substr(z_b_zs_obj_get($v_this, 'src'), 2, z_sub(z_b_zs_obj_get($v_this, 'pos'), 2)), 0, $v_line, $v_col]);
  }
  while (true) {
    Z::$l = 83;
    if (!z_truthy(true)) break;
    Z::$l = 84;
    f_zs_invoke($v_this, 'skipTrivia', []);
    Z::$l = 85;
    if (z_truthy((z_cmp(z_b_zs_obj_get($v_this, 'pos'), z_b_zs_obj_get($v_this, 'n')) >= 0))) {
      break 1;
    }
    Z::$l = 86;
    ($v_c = f_zs_invoke($v_this, 'peek', []));
    Z::$l = 87;
    ($v_start = z_b_zs_obj_get($v_this, 'pos'));
    Z::$l = 87;
    ($v_line = z_b_zs_obj_get($v_this, 'line'));
    Z::$l = 87;
    ($v_col = z_b_zs_obj_get($v_this, 'col'));
    Z::$l = 88;
    if (z_truthy(($v_c === '$'))) {
      Z::$l = 88;
      f_zs_invoke($v_this, 'variable', [$v_start, $v_line, $v_col]);
    } else {
      Z::$l = 89;
      if (z_truthy((z_truthy(($v_c === '"')) || z_truthy(($v_c === '\''))))) {
        Z::$l = 89;
        f_zs_invoke($v_this, 'string', [$v_c, $v_start, $v_line, $v_col]);
      } else {
        Z::$l = 90;
        if (z_truthy(z_b_is_digit($v_c))) {
          Z::$l = 90;
          f_zs_invoke($v_this, 'number', [$v_start, $v_line, $v_col]);
        } else {
          Z::$l = 91;
          if (z_truthy(z_b_is_alpha($v_c))) {
            Z::$l = 91;
            f_zs_invoke($v_this, 'ident', [$v_start, $v_line, $v_col]);
          } else {
            Z::$l = 92;
            f_zs_invoke($v_this, 'op', [$v_start, $v_line, $v_col]);
          }
        }
      }
    }
  }
  Z::$l = 94;
  f_zs_invoke($v_this, 'emit', ['eof', '', z_b_zs_obj_get($v_this, 'pos'), z_b_zs_obj_get($v_this, 'line'), z_b_zs_obj_get($v_this, 'col')]);
  Z::$l = 95;
  return z_b_zs_obj_get($v_this, 'out');
  return null;
}
function f_Lexer__skipTrivia($v_this) {
  $v_c = null;
  $v_start = null;
  $v_line = null;
  $v_col = null;
  $v_c1 = null;
  $v_e = null;
  $v_alone = null;
  $v_textStart = null;
  $v_text = null;
  while (true) {
    Z::$l = 99;
    if (!z_truthy((z_cmp(z_b_zs_obj_get($v_this, 'pos'), z_b_zs_obj_get($v_this, 'n')) < 0))) break;
    Z::$l = 100;
    ($v_c = f_zs_invoke($v_this, 'peek', []));
    Z::$l = 101;
    if (z_truthy((z_truthy((z_truthy((z_truthy(($v_c === ' ')) || z_truthy(($v_c === '	')))) || z_truthy(($v_c === '')))) || z_truthy(($v_c === '
'))))) {
      Z::$l = 101;
      f_zs_invoke($v_this, 'bump', []);
      continue 1;
    }
    Z::$l = 102;
    if (z_truthy(($v_c !== '#'))) {
      Z::$l = 102;
      return null;
    }
    Z::$l = 103;
    ($v_start = z_b_zs_obj_get($v_this, 'pos'));
    Z::$l = 103;
    ($v_line = z_b_zs_obj_get($v_this, 'line'));
    Z::$l = 103;
    ($v_col = z_b_zs_obj_get($v_this, 'col'));
    Z::$l = 104;
    ($v_c1 = f_zs_invoke($v_this, 'peek', [1]));
    Z::$l = 105;
    if (z_truthy(($v_c1 === '('))) {
      Z::$l = 106;
      f_zs_invoke($v_this, 'bump', []);
      Z::$l = 106;
      f_zs_invoke($v_this, 'bump', []);
      while (true) {
        Z::$l = 107;
        if (!z_truthy(true)) break;
        Z::$l = 108;
        if (z_truthy((z_cmp(z_b_zs_obj_get($v_this, 'pos'), z_b_zs_obj_get($v_this, 'n')) >= 0))) {
          Z::$l = 108;
          f_zs_invoke($v_this, 'fail', ['niezamknięty komentarz #( ... )#', $v_line, $v_col]);
        }
        Z::$l = 109;
        if (z_truthy((z_truthy((f_zs_invoke($v_this, 'peek', []) === ')')) && z_truthy((f_zs_invoke($v_this, 'peek', [1]) === '#'))))) {
          Z::$l = 109;
          f_zs_invoke($v_this, 'bump', []);
          Z::$l = 109;
          f_zs_invoke($v_this, 'bump', []);
          break 1;
        }
        Z::$l = 110;
        f_zs_invoke($v_this, 'bump', []);
      }
      Z::$l = 112;
      if (z_truthy(z_b_zs_obj_get($v_this, 'keep'))) {
        Z::$l = 112;
        f_zs_invoke($v_this, 'emit', ['comment', z_b_substr(z_b_zs_obj_get($v_this, 'src'), $v_start, z_sub(z_b_zs_obj_get($v_this, 'pos'), $v_start)), $v_start, $v_line, $v_col]);
      }
    } else {
      Z::$l = 113;
      if (z_truthy(($v_c1 === '#'))) {
        Z::$l = 114;
        f_zs_invoke($v_this, 'bump', []);
        Z::$l = 114;
        f_zs_invoke($v_this, 'bump', []);
        Z::$l = 115;
        ($v_e = z_b_zs_obj_get($v_this, 'pos'));
        while (true) {
          Z::$l = 116;
          if (!z_truthy((z_truthy((z_cmp($v_e, z_b_zs_obj_get($v_this, 'n')) < 0)) && z_truthy(((($_t2 = z_indexopt(z_b_zs_obj_get($v_this, 'src'), $v_e)) !== null ? $_t2 : '') !== '
'))))) break;
          Z::$l = 116;
          z_last($_t3 = $v_e, $v_e = z_add($_t3, 1), $_t3);
        }
        Z::$l = 117;
        ($v_alone = (z_b_trim(z_b_substr(z_b_zs_obj_get($v_this, 'src'), z_b_zs_obj_get($v_this, 'pos'), z_sub($v_e, z_b_zs_obj_get($v_this, 'pos')))) === ''));
        Z::$l = 118;
        ($v_textStart = z_b_zs_obj_get($v_this, 'pos'));
        Z::$l = 119;
        if (z_truthy($v_alone)) {
          while (true) {
            Z::$l = 120;
            if (!z_truthy(true)) break;
            Z::$l = 121;
            if (z_truthy((z_cmp(z_b_zs_obj_get($v_this, 'pos'), z_b_zs_obj_get($v_this, 'n')) >= 0))) {
              Z::$l = 121;
              f_zs_invoke($v_this, 'fail', ['niezamknięty blok dokumentacyjny ##', $v_line, $v_col]);
            }
            Z::$l = 122;
            if (z_truthy((z_truthy((f_zs_invoke($v_this, 'peek', []) === '#')) && z_truthy((f_zs_invoke($v_this, 'peek', [1]) === '#'))))) {
              break 1;
            }
            Z::$l = 123;
            f_zs_invoke($v_this, 'bump', []);
          }
          Z::$l = 125;
          ($v_text = z_b_substr(z_b_zs_obj_get($v_this, 'src'), $v_textStart, z_sub(z_b_zs_obj_get($v_this, 'pos'), $v_textStart)));
          Z::$l = 126;
          f_zs_invoke($v_this, 'bump', []);
          Z::$l = 126;
          f_zs_invoke($v_this, 'bump', []);
        } else {
          while (true) {
            Z::$l = 128;
            if (!z_truthy((z_cmp(z_b_zs_obj_get($v_this, 'pos'), $v_e) < 0))) break;
            Z::$l = 128;
            f_zs_invoke($v_this, 'bump', []);
          }
          Z::$l = 129;
          ($v_text = z_b_trim(z_b_substr(z_b_zs_obj_get($v_this, 'src'), $v_textStart, z_sub(z_b_zs_obj_get($v_this, 'pos'), $v_textStart))));
        }
        Z::$l = 131;
        f_zs_invoke($v_this, 'emit', ['doc', $v_text, $v_start, $v_line, $v_col, $v_text]);
      } else {
        while (true) {
          Z::$l = 133;
          if (!z_truthy((z_truthy((z_cmp(z_b_zs_obj_get($v_this, 'pos'), z_b_zs_obj_get($v_this, 'n')) < 0)) && z_truthy((f_zs_invoke($v_this, 'peek', []) !== '
'))))) break;
          Z::$l = 133;
          f_zs_invoke($v_this, 'bump', []);
        }
        Z::$l = 134;
        if (z_truthy(z_b_zs_obj_get($v_this, 'keep'))) {
          Z::$l = 134;
          f_zs_invoke($v_this, 'emit', ['comment', z_b_substr(z_b_zs_obj_get($v_this, 'src'), $v_start, z_sub(z_b_zs_obj_get($v_this, 'pos'), $v_start)), $v_start, $v_line, $v_col]);
        }
      }
    }
  }
  return null;
}
function f_Lexer__variable($v_this, $v_start, $v_line, $v_col) {
  $v_s = null;
  $v_name = null;
  Z::$l = 140;
  f_zs_invoke($v_this, 'bump', []);
  Z::$l = 141;
  if (z_truthy(!z_truthy(z_b_is_alpha(f_zs_invoke($v_this, 'peek', []))))) {
    Z::$l = 141;
    f_zs_invoke($v_this, 'fail', ['po `$` oczekiwano nazwy zmiennej', $v_line, $v_col]);
  }
  Z::$l = 142;
  ($v_s = z_b_zs_obj_get($v_this, 'pos'));
  while (true) {
    Z::$l = 143;
    if (!z_truthy(z_b_is_alnum(f_zs_invoke($v_this, 'peek', [])))) break;
    Z::$l = 143;
    f_zs_invoke($v_this, 'bump', []);
  }
  Z::$l = 144;
  ($v_name = z_b_substr(z_b_zs_obj_get($v_this, 'src'), $v_s, z_sub(z_b_zs_obj_get($v_this, 'pos'), $v_s)));
  Z::$l = 145;
  f_zs_invoke($v_this, 'emit', ['var', z_concat('$', $v_name), $v_start, $v_line, $v_col, $v_name]);
  return null;
}
function f_Lexer__ident($v_this, $v_start, $v_line, $v_col) {
  $v_word = null;
  while (true) {
    Z::$l = 149;
    if (!z_truthy(z_b_is_alnum(f_zs_invoke($v_this, 'peek', [])))) break;
    Z::$l = 149;
    f_zs_invoke($v_this, 'bump', []);
  }
  Z::$l = 150;
  ($v_word = z_b_substr(z_b_zs_obj_get($v_this, 'src'), $v_start, z_sub(z_b_zs_obj_get($v_this, 'pos'), $v_start)));
  Z::$l = 151;
  f_zs_invoke($v_this, 'emit', [(z_truthy(z_b_has_key([z_k('func') => true, z_k('fn') => true, z_k('return') => true, z_k('if') => true, z_k('elseif') => true, z_k('else') => true, z_k('switch') => true, z_k('case') => true, z_k('default') => true, z_k('match') => true, z_k('for') => true, z_k('foreach') => true, z_k('while') => true, z_k('do') => true, z_k('break') => true, z_k('continue') => true, z_k('as') => true, z_k('import') => true, z_k('namespace') => true, z_k('extern') => true, z_k('class') => true, z_k('interface') => true, z_k('trait') => true, z_k('extends') => true, z_k('implements') => true, z_k('new') => true, z_k('public') => true, z_k('private') => true, z_k('protected') => true, z_k('static') => true, z_k('abstract') => true, z_k('try') => true, z_k('catch') => true, z_k('finally') => true, z_k('throw') => true, z_k('using') => true, z_k('await') => true, z_k('echo') => true, z_k('true') => true, z_k('false') => true, z_k('null') => true, z_k('and') => true, z_k('or') => true, z_k('xor') => true], $v_word)) ? 'kw' : 'ident'), $v_word, $v_start, $v_line, $v_col, $v_word]);
  return null;
}
function f_Lexer__digitValue($v_this, $v_c) {
  $v_o = null;
  Z::$l = 155;
  if (z_truthy(($v_c === ''))) {
    Z::$l = 155;
    return z_neg(1);
  }
  Z::$l = 156;
  ($v_o = z_b_ord($v_c));
  Z::$l = 157;
  if (z_truthy((z_truthy((z_cmp($v_o, 48) >= 0)) && z_truthy((z_cmp($v_o, 57) <= 0))))) {
    Z::$l = 157;
    return z_sub($v_o, 48);
  }
  Z::$l = 158;
  if (z_truthy((z_truthy((z_cmp($v_o, 97) >= 0)) && z_truthy((z_cmp($v_o, 102) <= 0))))) {
    Z::$l = 158;
    return z_sub($v_o, 87);
  }
  Z::$l = 159;
  if (z_truthy((z_truthy((z_cmp($v_o, 65) >= 0)) && z_truthy((z_cmp($v_o, 70) <= 0))))) {
    Z::$l = 159;
    return z_sub($v_o, 55);
  }
  Z::$l = 160;
  return z_neg(1);
  return null;
}
function f_Lexer__digits($v_this) {
  while (true) {
    Z::$l = 164;
    if (!z_truthy((z_truthy(z_b_is_digit(f_zs_invoke($v_this, 'peek', []))) || z_truthy((f_zs_invoke($v_this, 'peek', []) === '_'))))) break;
    Z::$l = 164;
    f_zs_invoke($v_this, 'bump', []);
  }
  return null;
}
function f_Lexer__number($v_this, $v_start, $v_line, $v_col) {
  $v_p = null;
  $v_radix = null;
  $v_v = null;
  $v_count = null;
  $v_c = null;
  $v_d = null;
  $v_isFloat = null;
  $v_e = null;
  $v_sign = null;
  $v_i = null;
  $v_text = null;
  $v_clean = null;
  Z::$l = 168;
  if (z_truthy((f_zs_invoke($v_this, 'peek', []) === '0'))) {
    Z::$l = 169;
    ($v_p = f_zs_invoke($v_this, 'peek', [1]));
    Z::$l = 170;
    ($v_radix = 0);
    Z::$l = 171;
    if (z_truthy((z_truthy(($v_p === 'x')) || z_truthy(($v_p === 'X'))))) {
      Z::$l = 171;
      ($v_radix = 16);
    } else {
      Z::$l = 172;
      if (z_truthy((z_truthy(($v_p === 'b')) || z_truthy(($v_p === 'B'))))) {
        Z::$l = 172;
        ($v_radix = 2);
      } else {
        Z::$l = 173;
        if (z_truthy((z_truthy(($v_p === 'o')) || z_truthy(($v_p === 'O'))))) {
          Z::$l = 173;
          ($v_radix = 8);
        }
      }
    }
    Z::$l = 174;
    if (z_truthy(($v_radix !== 0))) {
      Z::$l = 175;
      f_zs_invoke($v_this, 'bump', []);
      Z::$l = 175;
      f_zs_invoke($v_this, 'bump', []);
      Z::$l = 176;
      ($v_v = 0);
      Z::$l = 176;
      ($v_count = 0);
      while (true) {
        Z::$l = 177;
        if (!z_truthy(true)) break;
        Z::$l = 178;
        ($v_c = f_zs_invoke($v_this, 'peek', []));
        Z::$l = 179;
        if (z_truthy(($v_c === '_'))) {
          Z::$l = 179;
          f_zs_invoke($v_this, 'bump', []);
          continue 1;
        }
        Z::$l = 180;
        ($v_d = f_zs_invoke($v_this, 'digitValue', [$v_c]));
        Z::$l = 181;
        if (z_truthy((z_truthy((z_cmp($v_d, 0) < 0)) || z_truthy((z_cmp($v_d, $v_radix) >= 0))))) {
          break 1;
        }
        Z::$l = 182;
        ($v_v = z_add(z_mul($v_v, $v_radix), $v_d));
        Z::$l = 182;
        z_last($_t4 = $v_count, $v_count = z_add($_t4, 1), $_t4);
        Z::$l = 183;
        f_zs_invoke($v_this, 'bump', []);
      }
      Z::$l = 185;
      if (z_truthy(($v_count === 0))) {
        Z::$l = 185;
        f_zs_invoke($v_this, 'fail', ['niepoprawny literał całkowity', $v_line, $v_col]);
      }
      Z::$l = 186;
      f_zs_invoke($v_this, 'emit', ['int', z_b_substr(z_b_zs_obj_get($v_this, 'src'), $v_start, z_sub(z_b_zs_obj_get($v_this, 'pos'), $v_start)), $v_start, $v_line, $v_col, $v_v]);
      Z::$l = 187;
      return null;
    }
  }
  Z::$l = 190;
  f_zs_invoke($v_this, 'digits', []);
  Z::$l = 191;
  ($v_isFloat = false);
  Z::$l = 192;
  if (z_truthy((z_truthy((f_zs_invoke($v_this, 'peek', []) === '.')) && z_truthy(z_b_is_digit(f_zs_invoke($v_this, 'peek', [1])))))) {
    Z::$l = 193;
    ($v_isFloat = true);
    Z::$l = 193;
    f_zs_invoke($v_this, 'bump', []);
    Z::$l = 193;
    f_zs_invoke($v_this, 'digits', []);
  }
  Z::$l = 195;
  ($v_e = f_zs_invoke($v_this, 'peek', []));
  Z::$l = 196;
  if (z_truthy((z_truthy(($v_e === 'e')) || z_truthy(($v_e === 'E'))))) {
    Z::$l = 197;
    ($v_sign = (z_truthy((z_truthy((f_zs_invoke($v_this, 'peek', [1]) === '+')) || z_truthy((f_zs_invoke($v_this, 'peek', [1]) === '-')))) ? 1 : 0));
    Z::$l = 198;
    if (z_truthy(z_b_is_digit(f_zs_invoke($v_this, 'peek', [z_add(1, $v_sign)])))) {
      Z::$l = 199;
      ($v_isFloat = true);
      Z::$l = 200;
      ($v_i = 0);
      for (; z_truthy((z_cmp($v_i, $v_sign) <= 0)); z_last($_t5 = $v_i, $v_i = z_add($_t5, 1), $_t5)) {
        Z::$l = 200;
        f_zs_invoke($v_this, 'bump', []);
      }
      Z::$l = 201;
      f_zs_invoke($v_this, 'digits', []);
    }
  }
  Z::$l = 204;
  ($v_text = z_b_substr(z_b_zs_obj_get($v_this, 'src'), $v_start, z_sub(z_b_zs_obj_get($v_this, 'pos'), $v_start)));
  Z::$l = 205;
  ($v_clean = z_b_replace($v_text, '_', ''));
  Z::$l = 206;
  if (z_truthy($v_isFloat)) {
    Z::$l = 206;
    f_zs_invoke($v_this, 'emit', ['float', $v_text, $v_start, $v_line, $v_col, z_b_floatval($v_clean)]);
  } else {
    Z::$l = 207;
    f_zs_invoke($v_this, 'emit', ['int', $v_text, $v_start, $v_line, $v_col, z_b_intval($v_clean)]);
  }
  return null;
}
function f_Lexer__string($v_this, $v_q, $v_start, $v_line, $v_col) {
  $v_buf = null;
  $v_c = null;
  $v_e = null;
  Z::$l = 211;
  f_zs_invoke($v_this, 'bump', []);
  Z::$l = 212;
  ($v_buf = '');
  while (true) {
    Z::$l = 213;
    if (!z_truthy(true)) break;
    Z::$l = 214;
    if (z_truthy((z_cmp(z_b_zs_obj_get($v_this, 'pos'), z_b_zs_obj_get($v_this, 'n')) >= 0))) {
      Z::$l = 214;
      f_zs_invoke($v_this, 'fail', ['niezamknięty literał tekstowy', $v_line, $v_col]);
    }
    Z::$l = 215;
    ($v_c = f_zs_invoke($v_this, 'bump', []));
    Z::$l = 216;
    if (z_truthy(($v_c === $v_q))) {
      break 1;
    }
    Z::$l = 217;
    if (z_truthy(($v_c !== '\\'))) {
      Z::$l = 217;
      ($v_buf = z_concat($v_buf, $v_c));
      continue 1;
    }
    Z::$l = 218;
    if (z_truthy((z_cmp(z_b_zs_obj_get($v_this, 'pos'), z_b_zs_obj_get($v_this, 'n')) >= 0))) {
      Z::$l = 218;
      f_zs_invoke($v_this, 'fail', ['niezamknięty literał tekstowy', $v_line, $v_col]);
    }
    Z::$l = 219;
    ($v_e = f_zs_invoke($v_this, 'bump', []));
    Z::$l = 220;
    if (z_truthy(($v_e === '\\'))) {
      Z::$l = 220;
      ($v_buf = z_concat($v_buf, '\\'));
    } else {
      Z::$l = 221;
      if (z_truthy(($v_e === $v_q))) {
        Z::$l = 221;
        ($v_buf = z_concat($v_buf, $v_q));
      } else {
        Z::$l = 222;
        if (z_truthy((z_truthy(($v_q === '"')) && z_truthy(($v_e === 'n'))))) {
          Z::$l = 222;
          ($v_buf = z_concat($v_buf, '
'));
        } else {
          Z::$l = 223;
          if (z_truthy((z_truthy(($v_q === '"')) && z_truthy(($v_e === 't'))))) {
            Z::$l = 223;
            ($v_buf = z_concat($v_buf, '	'));
          } else {
            Z::$l = 224;
            if (z_truthy((z_truthy(($v_q === '"')) && z_truthy(($v_e === 'r'))))) {
              Z::$l = 224;
              ($v_buf = z_concat($v_buf, ''));
            } else {
              Z::$l = 225;
              if (z_truthy((z_truthy(($v_q === '"')) && z_truthy(($v_e === '0'))))) {
                Z::$l = 225;
                ($v_buf = z_concat($v_buf, z_b_chr(0)));
              } else {
                Z::$l = 226;
                if (z_truthy((z_truthy(($v_q === '"')) && z_truthy(($v_e === '$'))))) {
                  Z::$l = 226;
                  ($v_buf = z_concat($v_buf, '$'));
                } else {
                  Z::$l = 227;
                  ($v_buf = z_concat($v_buf, z_concat('\\', $v_e)));
                }
              }
            }
          }
        }
      }
    }
  }
  Z::$l = 229;
  f_zs_invoke($v_this, 'emit', ['str', z_b_substr(z_b_zs_obj_get($v_this, 'src'), $v_start, z_sub(z_b_zs_obj_get($v_this, 'pos'), $v_start)), $v_start, $v_line, $v_col, $v_buf]);
  return null;
}
function f_Lexer__op($v_this, $v_start, $v_line, $v_col) {
  $v_s3 = null;
  $v_s2 = null;
  $v_s1 = null;
  $v_len = null;
  $v_i = null;
  $v_text = null;
  Z::$l = 233;
  ($v_s3 = z_b_substr(z_b_zs_obj_get($v_this, 'src'), z_b_zs_obj_get($v_this, 'pos'), 3));
  Z::$l = 234;
  ($v_s2 = z_b_substr(z_b_zs_obj_get($v_this, 'src'), z_b_zs_obj_get($v_this, 'pos'), 2));
  Z::$l = 235;
  ($v_s1 = z_b_substr(z_b_zs_obj_get($v_this, 'src'), z_b_zs_obj_get($v_this, 'pos'), 1));
  Z::$l = 236;
  ($v_len = 0);
  Z::$l = 237;
  if (z_truthy(z_b_has_key([z_k('===') => true, z_k('!==') => true, z_k('??=') => true, z_k('...') => true], $v_s3))) {
    Z::$l = 237;
    ($v_len = 3);
  } else {
    Z::$l = 238;
    if (z_truthy(z_b_has_key([z_k('**') => true, z_k('==') => true, z_k('!=') => true, z_k('<=') => true, z_k('>=') => true, z_k('&&') => true, z_k('||') => true, z_k('??') => true, z_k('->') => true, z_k('=>') => true, z_k('++') => true, z_k('--') => true, z_k('+=') => true, z_k('-=') => true, z_k('*=') => true, z_k('/=') => true, z_k('%=') => true, z_k('.=') => true, z_k('<<') => true, z_k('>>') => true], $v_s2))) {
      Z::$l = 238;
      ($v_len = 2);
    } else {
      Z::$l = 239;
      if (z_truthy(z_b_contains('+-*/%.=<>!?:,;(){}[]&|^~', $v_s1))) {
        Z::$l = 239;
        ($v_len = 1);
      }
    }
  }
  Z::$l = 240;
  if (z_truthy(($v_len === 0))) {
    Z::$l = 240;
    f_zs_invoke($v_this, 'fail', [z_concat(z_concat('nieoczekiwany znak `', $v_s1), '`'), $v_line, $v_col]);
  }
  Z::$l = 241;
  ($v_i = 0);
  for (; z_truthy((z_cmp($v_i, $v_len) < 0)); z_last($_t6 = $v_i, $v_i = z_add($_t6, 1), $_t6)) {
    Z::$l = 241;
    f_zs_invoke($v_this, 'bump', []);
  }
  Z::$l = 242;
  ($v_text = z_b_substr(z_b_zs_obj_get($v_this, 'src'), $v_start, $v_len));
  Z::$l = 243;
  f_zs_invoke($v_this, 'emit', ['op', $v_text, $v_start, $v_line, $v_col, $v_text]);
  return null;
}
function f_Lexer__new($v_src, $v_keep) {
  $v___o = null;
  Z::$l = 35;
  ($v___o = z_b_zs_obj_new('Lexer'));
  Z::$l = 35;
  z_b_zs_obj_set($v___o, 'src', null);
  Z::$l = 35;
  z_b_zs_obj_set($v___o, 'n', null);
  Z::$l = 35;
  z_b_zs_obj_set($v___o, 'pos', null);
  Z::$l = 35;
  z_b_zs_obj_set($v___o, 'line', null);
  Z::$l = 35;
  z_b_zs_obj_set($v___o, 'col', null);
  Z::$l = 35;
  z_b_zs_obj_set($v___o, 'out', null);
  Z::$l = 35;
  z_b_zs_obj_set($v___o, 'keep', null);
  Z::$l = 35;
  f_Lexer____construct($v___o, $v_src, $v_keep);
  Z::$l = 35;
  return $v___o;
  return null;
}
function f_ParseError____construct($v_this, $v_message, $v_line, $v_col) {
  Z::$l = 9;
  f_Exception____construct($v_this, z_concat(z_concat(z_concat(z_concat($v_line, ':'), $v_col), ': '), $v_message));
  Z::$l = 10;
  z_b_zs_obj_set($v_this, 'lineNo', $v_line);
  Z::$l = 11;
  z_b_zs_obj_set($v_this, 'colNo', $v_col);
  return null;
}
function f_ParseError__new($v_message, $v_line, $v_col) {
  $v___o = null;
  Z::$l = 5;
  ($v___o = z_b_zs_obj_new('ParseError'));
  Z::$l = 5;
  z_b_zs_obj_set($v___o, 'message', '');
  Z::$l = 5;
  z_b_zs_obj_set($v___o, 'line', 0);
  Z::$l = 5;
  z_b_zs_obj_set($v___o, 'lineNo', null);
  Z::$l = 5;
  z_b_zs_obj_set($v___o, 'colNo', null);
  Z::$l = 5;
  f_ParseError____construct($v___o, $v_message, $v_line, $v_col);
  Z::$l = 5;
  return $v___o;
  return null;
}
function f_Tables__new() {
  $v___o = null;
  Z::$l = 15;
  ($v___o = z_b_zs_obj_new('Tables'));
  Z::$l = 15;
  return $v___o;
  return null;
}
function f_Parser____construct($v_this, $v_toks) {
  Z::$l = 62;
  z_b_zs_obj_set($v_this, 'toks', $v_toks);
  Z::$l = 63;
  z_b_zs_obj_set($v_this, 'pos', 0);
  Z::$l = 64;
  z_b_zs_obj_set($v_this, 'last', z_sub(z_b_count($v_toks), 1));
  return null;
}
function f_Parser__cur($v_this) {
  Z::$l = 68;
  return z_index(z_b_zs_obj_get($v_this, 'toks'), (z_truthy((z_cmp(z_b_zs_obj_get($v_this, 'pos'), z_b_zs_obj_get($v_this, 'last')) < 0)) ? z_b_zs_obj_get($v_this, 'pos') : z_b_zs_obj_get($v_this, 'last')));
  return null;
}
function f_Parser__at($v_this, $v_n) {
  $v_i = null;
  Z::$l = 69;
  ($v_i = z_add(z_b_zs_obj_get($v_this, 'pos'), $v_n));
  Z::$l = 69;
  return z_index(z_b_zs_obj_get($v_this, 'toks'), (z_truthy((z_cmp($v_i, z_b_zs_obj_get($v_this, 'last')) < 0)) ? $v_i : z_b_zs_obj_get($v_this, 'last')));
  return null;
}
function f_Parser__line($v_this) {
  Z::$l = 70;
  return z_index(f_zs_invoke($v_this, 'cur', []), 'line');
  return null;
}
function f_Parser__atEof($v_this) {
  Z::$l = 71;
  return (z_index(f_zs_invoke($v_this, 'cur', []), 'kind') === 'eof');
  return null;
}
function f_Parser__bump($v_this) {
  $v_t = null;
  Z::$l = 72;
  ($v_t = f_zs_invoke($v_this, 'cur', []));
  Z::$l = 72;
  if (z_truthy((z_cmp(z_b_zs_obj_get($v_this, 'pos'), z_b_zs_obj_get($v_this, 'last')) < 0))) {
    Z::$l = 72;
    z_b_zs_obj_set($v_this, 'pos', z_add(z_b_zs_obj_get($v_this, 'pos'), 1));
  }
  Z::$l = 72;
  return $v_t;
  return null;
}
function f_Parser__back($v_this) {
  Z::$l = 73;
  z_b_zs_obj_set($v_this, 'pos', z_sub(z_b_zs_obj_get($v_this, 'pos'), 1));
  return null;
}
function f_Parser__fail($v_this, $v_msg) {
  $v_t = null;
  Z::$l = 74;
  ($v_t = f_zs_invoke($v_this, 'cur', []));
  Z::$l = 74;
  z_throwv(f_ParseError__new($v_msg, z_index($v_t, 'line'), z_index($v_t, 'col')));
  return null;
}
function f_Parser__isOp($v_this, $v_s) {
  $v_t = null;
  Z::$l = 75;
  ($v_t = f_zs_invoke($v_this, 'cur', []));
  Z::$l = 75;
  return (z_truthy((z_index($v_t, 'kind') === 'op')) && z_truthy((z_index($v_t, 'text') === $v_s)));
  return null;
}
function f_Parser__isKw($v_this, $v_s) {
  $v_t = null;
  Z::$l = 76;
  ($v_t = f_zs_invoke($v_this, 'cur', []));
  Z::$l = 76;
  return (z_truthy((z_index($v_t, 'kind') === 'kw')) && z_truthy((z_index($v_t, 'text') === $v_s)));
  return null;
}
function f_Parser__isWord($v_this, $v_s) {
  $v_t = null;
  Z::$l = 77;
  ($v_t = f_zs_invoke($v_this, 'cur', []));
  Z::$l = 77;
  return (z_truthy((z_index($v_t, 'kind') === 'ident')) && z_truthy((z_index($v_t, 'text') === $v_s)));
  return null;
}
function f_Parser__isVar($v_this) {
  Z::$l = 78;
  return (z_index(f_zs_invoke($v_this, 'cur', []), 'kind') === 'var');
  return null;
}
function f_Parser__eatOp($v_this, $v_s) {
  Z::$l = 79;
  if (z_truthy(f_zs_invoke($v_this, 'isOp', [$v_s]))) {
    Z::$l = 79;
    f_zs_invoke($v_this, 'bump', []);
    Z::$l = 79;
    return true;
  }
  Z::$l = 79;
  return false;
  return null;
}
function f_Parser__eatKw($v_this, $v_s) {
  Z::$l = 80;
  if (z_truthy(f_zs_invoke($v_this, 'isKw', [$v_s]))) {
    Z::$l = 80;
    f_zs_invoke($v_this, 'bump', []);
    Z::$l = 80;
    return true;
  }
  Z::$l = 80;
  return false;
  return null;
}
function f_Parser__eatWord($v_this, $v_s) {
  Z::$l = 81;
  if (z_truthy(f_zs_invoke($v_this, 'isWord', [$v_s]))) {
    Z::$l = 81;
    f_zs_invoke($v_this, 'bump', []);
    Z::$l = 81;
    return true;
  }
  Z::$l = 81;
  return false;
  return null;
}
function f_Parser__expectOp($v_this, $v_s) {
  Z::$l = 83;
  if (z_truthy(!z_truthy(f_zs_invoke($v_this, 'eatOp', [$v_s])))) {
    Z::$l = 83;
    f_zs_invoke($v_this, 'fail', [z_concat(z_concat(z_concat(z_concat('oczekiwano `', $v_s), '`, jest `'), z_index(f_zs_invoke($v_this, 'cur', []), 'text')), '`')]);
  }
  return null;
}
function f_Parser__ident($v_this) {
  $v_t = null;
  Z::$l = 86;
  ($v_t = f_zs_invoke($v_this, 'bump', []));
  Z::$l = 87;
  if (z_truthy((z_index($v_t, 'kind') !== 'ident'))) {
    Z::$l = 87;
    f_zs_invoke($v_this, 'back', []);
    Z::$l = 87;
    f_zs_invoke($v_this, 'fail', [z_concat(z_concat('oczekiwano identyfikatora, jest `', z_index(f_zs_invoke($v_this, 'cur', []), 'text')), '`')]);
  }
  Z::$l = 88;
  return z_index($v_t, 'text');
  return null;
}
function f_Parser__varName($v_this) {
  $v_t = null;
  Z::$l = 91;
  ($v_t = f_zs_invoke($v_this, 'bump', []));
  Z::$l = 92;
  if (z_truthy((z_index($v_t, 'kind') !== 'var'))) {
    Z::$l = 92;
    f_zs_invoke($v_this, 'back', []);
    Z::$l = 92;
    f_zs_invoke($v_this, 'fail', ['oczekiwano zmiennej']);
  }
  Z::$l = 93;
  return z_index($v_t, 'value');
  return null;
}
function f_Parser__isFuncKw($v_this) {
  Z::$l = 95;
  return (z_truthy(f_zs_invoke($v_this, 'isKw', ['func'])) || z_truthy(f_zs_invoke($v_this, 'isWord', ['function'])));
  return null;
}
function f_Parser__block($v_this) {
  $v_v = null;
  Z::$l = 99;
  f_zs_invoke($v_this, 'expectOp', ['{']);
  Z::$l = 100;
  ($v_v = []);
  while (true) {
    Z::$l = 101;
    if (!z_truthy(!z_truthy(f_zs_invoke($v_this, 'isOp', ['}'])))) break;
    Z::$l = 102;
    if (z_truthy(f_zs_invoke($v_this, 'atEof', []))) {
      Z::$l = 102;
      f_zs_invoke($v_this, 'fail', ['niezamknięty blok `{`']);
    }
    Z::$l = 103;
    z_apush($v_v, f_zs_invoke($v_this, 'stmt', []));
  }
  Z::$l = 105;
  f_zs_invoke($v_this, 'bump', []);
  Z::$l = 106;
  return $v_v;
  return null;
}
function f_Parser__body($v_this) {
  Z::$l = 110;
  if (z_truthy(f_zs_invoke($v_this, 'isOp', ['{']))) {
    Z::$l = 110;
    return f_zs_invoke($v_this, 'block', []);
  }
  Z::$l = 111;
  return [f_zs_invoke($v_this, 'stmt', [])];
  return null;
}
function f_Parser__parenExpr($v_this) {
  $v_e = null;
  Z::$l = 115;
  f_zs_invoke($v_this, 'expectOp', ['(']);
  Z::$l = 116;
  ($v_e = f_zs_invoke($v_this, 'expr', []));
  Z::$l = 117;
  f_zs_invoke($v_this, 'expectOp', [')']);
  Z::$l = 118;
  return $v_e;
  return null;
}
function f_Parser__path($v_this) {
  $v_v = null;
  Z::$l = 122;
  ($v_v = [f_zs_invoke($v_this, 'ident', [])]);
  while (true) {
    Z::$l = 123;
    if (!z_truthy(f_zs_invoke($v_this, 'eatOp', ['.']))) break;
    Z::$l = 123;
    z_apush($v_v, f_zs_invoke($v_this, 'ident', []));
  }
  Z::$l = 124;
  return $v_v;
  return null;
}
function f_Parser__stmt($v_this) {
  $v_line = null;
  $v_t = null;
  $v_k = null;
  $v_x = null;
  $v_c = null;
  $v_b = null;
  $v_e = null;
  $v_n = null;
  $v_v = null;
  $v_p = null;
  $v_r = null;
  $v_t2 = null;
  Z::$l = 128;
  ($v_line = f_zs_invoke($v_this, 'line', []));
  Z::$l = 129;
  ($v_t = f_zs_invoke($v_this, 'cur', []));
  Z::$l = 130;
  ($v_k = z_index($v_t, 'kind'));
  Z::$l = 131;
  ($v_x = z_index($v_t, 'text'));
  Z::$l = 132;
  if (z_truthy((z_truthy(($v_k === 'op')) && z_truthy(($v_x === '{'))))) {
    Z::$l = 132;
    return f_Workspace_parser__node('Block', $v_line, [f_zs_invoke($v_this, 'block', [])]);
  }
  Z::$l = 133;
  if (z_truthy((z_truthy(($v_k === 'op')) && z_truthy(($v_x === ';'))))) {
    Z::$l = 133;
    f_zs_invoke($v_this, 'bump', []);
    Z::$l = 133;
    return f_Workspace_parser__node('Block', $v_line, [[]]);
  }
  Z::$l = 134;
  if (z_truthy(($v_k === 'kw'))) {
    Z::$l = 135;
    if (z_truthy(($v_x === 'if'))) {
      Z::$l = 135;
      f_zs_invoke($v_this, 'bump', []);
      Z::$l = 135;
      return f_zs_invoke($v_this, 'ifRest', [$v_line]);
    }
    Z::$l = 136;
    if (z_truthy(($v_x === 'while'))) {
      Z::$l = 137;
      f_zs_invoke($v_this, 'bump', []);
      Z::$l = 137;
      ($v_c = f_zs_invoke($v_this, 'parenExpr', []));
      Z::$l = 137;
      ($v_b = f_zs_invoke($v_this, 'body', []));
      Z::$l = 138;
      return f_Workspace_parser__node('While', $v_line, [$v_c, $v_b]);
    }
    Z::$l = 140;
    if (z_truthy(($v_x === 'do'))) {
      Z::$l = 141;
      f_zs_invoke($v_this, 'bump', []);
      Z::$l = 141;
      ($v_b = f_zs_invoke($v_this, 'body', []));
      Z::$l = 142;
      if (z_truthy(!z_truthy(f_zs_invoke($v_this, 'eatKw', ['while'])))) {
        Z::$l = 142;
        f_zs_invoke($v_this, 'fail', ['oczekiwano `while` po `do`']);
      }
      Z::$l = 143;
      ($v_c = f_zs_invoke($v_this, 'parenExpr', []));
      Z::$l = 143;
      f_zs_invoke($v_this, 'eatOp', [';']);
      Z::$l = 144;
      return f_Workspace_parser__node('DoWhile', $v_line, [$v_b, $v_c]);
    }
    Z::$l = 146;
    if (z_truthy(($v_x === 'for'))) {
      Z::$l = 146;
      return f_zs_invoke($v_this, 'forStmt', [$v_line]);
    }
    Z::$l = 147;
    if (z_truthy(($v_x === 'foreach'))) {
      Z::$l = 147;
      return f_zs_invoke($v_this, 'foreachStmt', [$v_line]);
    }
    Z::$l = 148;
    if (z_truthy(($v_x === 'switch'))) {
      Z::$l = 148;
      return f_zs_invoke($v_this, 'switchStmt', [$v_line]);
    }
    Z::$l = 149;
    if (z_truthy(($v_x === 'return'))) {
      Z::$l = 150;
      f_zs_invoke($v_this, 'bump', []);
      Z::$l = 151;
      ($v_e = (z_truthy(f_zs_invoke($v_this, 'isOp', [';'])) ? null : f_zs_invoke($v_this, 'expr', [])));
      Z::$l = 152;
      f_zs_invoke($v_this, 'expectOp', [';']);
      Z::$l = 153;
      return f_Workspace_parser__node('Return', $v_line, [$v_e]);
    }
    Z::$l = 155;
    if (z_truthy((z_truthy(($v_x === 'break')) || z_truthy(($v_x === 'continue'))))) {
      Z::$l = 156;
      f_zs_invoke($v_this, 'bump', []);
      Z::$l = 157;
      ($v_n = 1);
      Z::$l = 158;
      if (z_truthy((z_index(f_zs_invoke($v_this, 'cur', []), 'kind') === 'int'))) {
        Z::$l = 158;
        ($v_n = z_index(f_zs_invoke($v_this, 'bump', []), 'value'));
      }
      Z::$l = 159;
      f_zs_invoke($v_this, 'expectOp', [';']);
      Z::$l = 160;
      return f_Workspace_parser__node((z_truthy(($v_x === 'break')) ? 'Break' : 'Continue'), $v_line, [$v_n]);
    }
    Z::$l = 162;
    if (z_truthy(($v_x === 'throw'))) {
      Z::$l = 162;
      f_zs_invoke($v_this, 'bump', []);
      Z::$l = 162;
      ($v_e = f_zs_invoke($v_this, 'expr', []));
      Z::$l = 162;
      f_zs_invoke($v_this, 'expectOp', [';']);
      Z::$l = 162;
      return f_Workspace_parser__node('Throw', $v_line, [$v_e]);
    }
    Z::$l = 163;
    if (z_truthy(($v_x === 'try'))) {
      Z::$l = 163;
      return f_zs_invoke($v_this, 'tryStmt', [$v_line]);
    }
    Z::$l = 164;
    if (z_truthy(($v_x === 'echo'))) {
      Z::$l = 165;
      f_zs_invoke($v_this, 'bump', []);
      Z::$l = 166;
      ($v_v = [f_zs_invoke($v_this, 'expr', [])]);
      while (true) {
        Z::$l = 167;
        if (!z_truthy(f_zs_invoke($v_this, 'eatOp', [',']))) break;
        Z::$l = 167;
        z_apush($v_v, f_zs_invoke($v_this, 'expr', []));
      }
      Z::$l = 168;
      f_zs_invoke($v_this, 'expectOp', [';']);
      Z::$l = 169;
      return f_Workspace_parser__node('Echo', $v_line, [$v_v]);
    }
    Z::$l = 171;
    if (z_truthy(($v_x === 'import'))) {
      Z::$l = 171;
      f_zs_invoke($v_this, 'bump', []);
      Z::$l = 171;
      ($v_p = f_zs_invoke($v_this, 'path', []));
      Z::$l = 171;
      f_zs_invoke($v_this, 'expectOp', [';']);
      Z::$l = 171;
      return f_Workspace_parser__node('Import', $v_line, [$v_p]);
    }
    Z::$l = 172;
    if (z_truthy(($v_x === 'namespace'))) {
      Z::$l = 172;
      f_zs_invoke($v_this, 'bump', []);
      Z::$l = 172;
      ($v_p = f_zs_invoke($v_this, 'path', []));
      Z::$l = 172;
      f_zs_invoke($v_this, 'expectOp', [';']);
      Z::$l = 172;
      return f_Workspace_parser__node('Namespace', $v_line, [$v_p]);
    }
    Z::$l = 173;
    if (z_truthy(($v_x === 'using'))) {
      Z::$l = 174;
      f_zs_invoke($v_this, 'bump', []);
      Z::$l = 175;
      ($v_r = f_zs_invoke($v_this, 'expr', []));
      Z::$l = 176;
      if (z_truthy(!z_truthy(f_zs_invoke($v_this, 'eatKw', ['as'])))) {
        Z::$l = 176;
        f_zs_invoke($v_this, 'fail', ['oczekiwano `as` w `using`']);
      }
      Z::$l = 177;
      ($v_t2 = f_zs_invoke($v_this, 'bump', []));
      Z::$l = 178;
      if (z_truthy((z_index($v_t2, 'kind') !== 'var'))) {
        Z::$l = 178;
        f_zs_invoke($v_this, 'back', []);
        Z::$l = 178;
        f_zs_invoke($v_this, 'fail', ['oczekiwano zmiennej po `as`']);
      }
      Z::$l = 179;
      ($v_b = f_zs_invoke($v_this, 'block', []));
      Z::$l = 180;
      return f_Workspace_parser__node('Using', $v_line, [$v_r, z_index($v_t2, 'value'), $v_b]);
    }
    Z::$l = 182;
    if (z_truthy(($v_x === 'extern'))) {
      Z::$l = 182;
      return f_zs_invoke($v_this, 'externStmt', [$v_line]);
    }
    Z::$l = 183;
    if (z_truthy((z_truthy((z_truthy(($v_x === 'class')) || z_truthy(($v_x === 'interface')))) || z_truthy(($v_x === 'abstract'))))) {
      Z::$l = 183;
      return f_zs_invoke($v_this, 'classDecl', [$v_line]);
    }
  }
  Z::$l = 185;
  if (z_truthy((z_truthy(f_zs_invoke($v_this, 'isFuncKw', [])) && z_truthy((z_index(f_zs_invoke($v_this, 'at', [1]), 'kind') === 'ident'))))) {
    Z::$l = 186;
    f_zs_invoke($v_this, 'bump', []);
    Z::$l = 187;
    return f_Workspace_parser__node('FuncStmt', $v_line, [f_zs_invoke($v_this, 'funcRest', [true])]);
  }
  Z::$l = 189;
  ($v_e = f_zs_invoke($v_this, 'expr', []));
  Z::$l = 190;
  f_zs_invoke($v_this, 'expectOp', [';']);
  Z::$l = 191;
  return f_Workspace_parser__node('Expr', $v_line, [$v_e]);
  return null;
}
function f_Parser__ifRest($v_this, $v_line) {
  $v_c = null;
  $v_then = null;
  $v_els = null;
  $v_l = null;
  Z::$l = 195;
  ($v_c = f_zs_invoke($v_this, 'parenExpr', []));
  Z::$l = 196;
  ($v_then = f_zs_invoke($v_this, 'body', []));
  Z::$l = 197;
  ($v_els = null);
  Z::$l = 198;
  if (z_truthy(f_zs_invoke($v_this, 'isKw', ['elseif']))) {
    Z::$l = 199;
    ($v_l = f_zs_invoke($v_this, 'line', []));
    Z::$l = 199;
    f_zs_invoke($v_this, 'bump', []);
    Z::$l = 199;
    ($v_els = [f_zs_invoke($v_this, 'ifRest', [$v_l])]);
  } else {
    Z::$l = 200;
    if (z_truthy(f_zs_invoke($v_this, 'isKw', ['else']))) {
      Z::$l = 201;
      f_zs_invoke($v_this, 'bump', []);
      Z::$l = 202;
      if (z_truthy(f_zs_invoke($v_this, 'isKw', ['if']))) {
        Z::$l = 202;
        ($v_l = f_zs_invoke($v_this, 'line', []));
        Z::$l = 202;
        f_zs_invoke($v_this, 'bump', []);
        Z::$l = 202;
        ($v_els = [f_zs_invoke($v_this, 'ifRest', [$v_l])]);
      } else {
        Z::$l = 203;
        ($v_els = f_zs_invoke($v_this, 'body', []));
      }
    }
  }
  Z::$l = 205;
  return f_Workspace_parser__node('If', $v_line, [$v_c, $v_then, $v_els]);
  return null;
}
function f_Parser__exprList($v_this, $v_close) {
  $v_v = null;
  Z::$l = 209;
  ($v_v = []);
  Z::$l = 210;
  if (z_truthy(!z_truthy(f_zs_invoke($v_this, 'isOp', [$v_close])))) {
    Z::$l = 211;
    z_apush($v_v, f_zs_invoke($v_this, 'expr', []));
    while (true) {
      Z::$l = 212;
      if (!z_truthy(f_zs_invoke($v_this, 'eatOp', [',']))) break;
      Z::$l = 212;
      z_apush($v_v, f_zs_invoke($v_this, 'expr', []));
    }
  }
  Z::$l = 214;
  return $v_v;
  return null;
}
function f_Parser__forStmt($v_this, $v_line) {
  $v_init = null;
  $v_cond = null;
  $v_step = null;
  $v_b = null;
  Z::$l = 218;
  f_zs_invoke($v_this, 'bump', []);
  Z::$l = 218;
  f_zs_invoke($v_this, 'expectOp', ['(']);
  Z::$l = 219;
  ($v_init = f_zs_invoke($v_this, 'exprList', [';']));
  Z::$l = 220;
  f_zs_invoke($v_this, 'expectOp', [';']);
  Z::$l = 221;
  ($v_cond = (z_truthy(f_zs_invoke($v_this, 'isOp', [';'])) ? null : f_zs_invoke($v_this, 'expr', [])));
  Z::$l = 222;
  f_zs_invoke($v_this, 'expectOp', [';']);
  Z::$l = 223;
  ($v_step = f_zs_invoke($v_this, 'exprList', [')']));
  Z::$l = 224;
  f_zs_invoke($v_this, 'expectOp', [')']);
  Z::$l = 225;
  ($v_b = f_zs_invoke($v_this, 'body', []));
  Z::$l = 226;
  return f_Workspace_parser__node('For', $v_line, [$v_init, $v_cond, $v_step, $v_b]);
  return null;
}
function f_Parser__foreachStmt($v_this, $v_line) {
  $v_iter = null;
  $v_first = null;
  $v_key = null;
  $v_value = null;
  $v_b = null;
  Z::$l = 230;
  f_zs_invoke($v_this, 'bump', []);
  Z::$l = 230;
  f_zs_invoke($v_this, 'expectOp', ['(']);
  Z::$l = 231;
  ($v_iter = f_zs_invoke($v_this, 'expr', []));
  Z::$l = 232;
  if (z_truthy(!z_truthy(f_zs_invoke($v_this, 'eatKw', ['as'])))) {
    Z::$l = 232;
    f_zs_invoke($v_this, 'fail', ['oczekiwano `as` w foreach']);
  }
  Z::$l = 233;
  ($v_first = f_zs_invoke($v_this, 'varName', []));
  Z::$l = 234;
  ($v_key = null);
  Z::$l = 235;
  ($v_value = $v_first);
  Z::$l = 236;
  if (z_truthy(f_zs_invoke($v_this, 'eatOp', ['=>']))) {
    Z::$l = 236;
    ($v_key = $v_first);
    Z::$l = 236;
    ($v_value = f_zs_invoke($v_this, 'varName', []));
  }
  Z::$l = 237;
  f_zs_invoke($v_this, 'expectOp', [')']);
  Z::$l = 238;
  ($v_b = f_zs_invoke($v_this, 'body', []));
  Z::$l = 239;
  return f_Workspace_parser__node('Foreach', $v_line, [$v_iter, $v_key, $v_value, $v_b]);
  return null;
}
function f_Parser__switchStmt($v_this, $v_line) {
  $v_subject = null;
  $v_cases = null;
  $v_cond = null;
  $v_body = null;
  Z::$l = 243;
  f_zs_invoke($v_this, 'bump', []);
  Z::$l = 244;
  ($v_subject = f_zs_invoke($v_this, 'parenExpr', []));
  Z::$l = 245;
  f_zs_invoke($v_this, 'expectOp', ['{']);
  Z::$l = 246;
  ($v_cases = []);
  while (true) {
    Z::$l = 247;
    if (!z_truthy(!z_truthy(f_zs_invoke($v_this, 'isOp', ['}'])))) break;
    Z::$l = 248;
    ($v_cond = null);
    Z::$l = 249;
    if (z_truthy(f_zs_invoke($v_this, 'eatKw', ['case']))) {
      Z::$l = 249;
      ($v_cond = f_zs_invoke($v_this, 'expr', []));
    } else {
      Z::$l = 250;
      if (z_truthy(f_zs_invoke($v_this, 'eatKw', ['default']))) {
        Z::$l = 250;
        ($v_cond = null);
      } else {
        Z::$l = 251;
        f_zs_invoke($v_this, 'fail', ['oczekiwano `case` lub `default`']);
      }
    }
    Z::$l = 252;
    if (z_truthy(!z_truthy(f_zs_invoke($v_this, 'eatOp', [':'])))) {
      Z::$l = 252;
      f_zs_invoke($v_this, 'expectOp', [';']);
    }
    Z::$l = 253;
    ($v_body = []);
    while (true) {
      Z::$l = 254;
      if (!z_truthy((z_truthy((z_truthy(!z_truthy(f_zs_invoke($v_this, 'isKw', ['case']))) && z_truthy(!z_truthy(f_zs_invoke($v_this, 'isKw', ['default']))))) && z_truthy(!z_truthy(f_zs_invoke($v_this, 'isOp', ['}'])))))) break;
      Z::$l = 255;
      if (z_truthy(f_zs_invoke($v_this, 'atEof', []))) {
        Z::$l = 255;
        f_zs_invoke($v_this, 'fail', ['niezamknięty switch']);
      }
      Z::$l = 256;
      z_apush($v_body, f_zs_invoke($v_this, 'stmt', []));
    }
    Z::$l = 258;
    z_apush($v_cases, f_Workspace_parser__node('Case', 0, [$v_cond, $v_body]));
  }
  Z::$l = 260;
  f_zs_invoke($v_this, 'bump', []);
  Z::$l = 261;
  return f_Workspace_parser__node('Switch', $v_line, [$v_subject, $v_cases]);
  return null;
}
function f_Parser__tryStmt($v_this, $v_line) {
  $v_body = null;
  $v_catches = null;
  $v_types = null;
  $v_var = null;
  $v_b = null;
  $v_finally = null;
  Z::$l = 265;
  f_zs_invoke($v_this, 'bump', []);
  Z::$l = 266;
  ($v_body = f_zs_invoke($v_this, 'block', []));
  Z::$l = 267;
  ($v_catches = []);
  while (true) {
    Z::$l = 268;
    if (!z_truthy(f_zs_invoke($v_this, 'eatKw', ['catch']))) break;
    Z::$l = 269;
    f_zs_invoke($v_this, 'expectOp', ['(']);
    Z::$l = 270;
    ($v_types = [f_zs_invoke($v_this, 'ident', [])]);
    while (true) {
      Z::$l = 271;
      if (!z_truthy(f_zs_invoke($v_this, 'eatOp', ['|']))) break;
      Z::$l = 271;
      z_apush($v_types, f_zs_invoke($v_this, 'ident', []));
    }
    Z::$l = 272;
    ($v_var = null);
    Z::$l = 273;
    if (z_truthy(f_zs_invoke($v_this, 'isVar', []))) {
      Z::$l = 273;
      ($v_var = f_zs_invoke($v_this, 'varName', []));
    }
    Z::$l = 274;
    f_zs_invoke($v_this, 'expectOp', [')']);
    Z::$l = 275;
    ($v_b = f_zs_invoke($v_this, 'block', []));
    Z::$l = 276;
    z_apush($v_catches, f_Workspace_parser__node('Catch', 0, [$v_types, $v_var, $v_b]));
  }
  Z::$l = 278;
  ($v_finally = null);
  Z::$l = 279;
  if (z_truthy(f_zs_invoke($v_this, 'eatKw', ['finally']))) {
    Z::$l = 279;
    ($v_finally = f_zs_invoke($v_this, 'block', []));
  }
  Z::$l = 280;
  if (z_truthy((z_truthy((z_b_count($v_catches) === 0)) && z_truthy(($v_finally === null))))) {
    Z::$l = 280;
    f_zs_invoke($v_this, 'fail', ['try wymaga catch lub finally']);
  }
  Z::$l = 281;
  return f_Workspace_parser__node('Try', $v_line, [$v_body, $v_catches, $v_finally]);
  return null;
}
function f_Parser__externStmt($v_this, $v_line) {
  $v_t = null;
  $v_lib = null;
  $v_items = null;
  $v_name = null;
  $v_params = null;
  $v_ret = null;
  Z::$l = 285;
  f_zs_invoke($v_this, 'bump', []);
  Z::$l = 286;
  ($v_t = f_zs_invoke($v_this, 'bump', []));
  Z::$l = 287;
  if (z_truthy((z_index($v_t, 'kind') !== 'str'))) {
    Z::$l = 287;
    f_zs_invoke($v_this, 'back', []);
    Z::$l = 287;
    f_zs_invoke($v_this, 'fail', ['extern wymaga nazwy biblioteki w cudzysłowie']);
  }
  Z::$l = 288;
  ($v_lib = z_index($v_t, 'value'));
  Z::$l = 289;
  ($v_items = []);
  Z::$l = 290;
  if (z_truthy(f_zs_invoke($v_this, 'eatOp', [';']))) {
    Z::$l = 290;
    return f_Workspace_parser__node('Extern', $v_line, [$v_lib, $v_items]);
  }
  Z::$l = 291;
  f_zs_invoke($v_this, 'expectOp', ['{']);
  while (true) {
    Z::$l = 292;
    if (!z_truthy(!z_truthy(f_zs_invoke($v_this, 'isOp', ['}'])))) break;
    Z::$l = 293;
    if (z_truthy(!z_truthy(f_zs_invoke($v_this, 'isFuncKw', [])))) {
      Z::$l = 293;
      f_zs_invoke($v_this, 'fail', ['w extern oczekiwano `func`']);
    }
    Z::$l = 294;
    f_zs_invoke($v_this, 'bump', []);
    Z::$l = 295;
    ($v_name = f_zs_invoke($v_this, 'ident', []));
    Z::$l = 296;
    ($v_params = f_zs_invoke($v_this, 'params', []));
    Z::$l = 297;
    ($v_ret = (z_truthy(f_zs_invoke($v_this, 'eatOp', [':'])) ? f_zs_invoke($v_this, 'types', []) : []));
    Z::$l = 298;
    f_zs_invoke($v_this, 'expectOp', [';']);
    Z::$l = 299;
    z_apush($v_items, f_Workspace_parser__node('ExternItem', 0, [$v_name, $v_params, $v_ret]));
  }
  Z::$l = 301;
  f_zs_invoke($v_this, 'bump', []);
  Z::$l = 302;
  return f_Workspace_parser__node('Extern', $v_line, [$v_lib, $v_items]);
  return null;
}
function f_Parser__types($v_this) {
  $v_v = null;
  $v_t = null;
  Z::$l = 307;
  ($v_v = []);
  Z::$l = 308;
  if (z_truthy(f_zs_invoke($v_this, 'eatOp', ['?']))) {
    Z::$l = 308;
    z_apush($v_v, 'null');
  }
  while (true) {
    Z::$l = 309;
    if (!z_truthy(true)) break;
    Z::$l = 310;
    ($v_t = f_zs_invoke($v_this, 'bump', []));
    Z::$l = 311;
    if (z_truthy((z_index($v_t, 'kind') === 'ident'))) {
      Z::$l = 311;
      z_apush($v_v, z_index($v_t, 'text'));
    } else {
      Z::$l = 312;
      if (z_truthy((z_truthy((z_index($v_t, 'kind') === 'kw')) && z_truthy((z_index($v_t, 'text') === 'null'))))) {
        Z::$l = 312;
        z_apush($v_v, 'null');
      } else {
        Z::$l = 313;
        if (z_truthy((z_truthy((z_index($v_t, 'kind') === 'kw')) && z_truthy((z_index($v_t, 'text') === 'static'))))) {
          Z::$l = 313;
          z_apush($v_v, 'static');
        } else {
          Z::$l = 314;
          if (z_truthy((z_truthy((z_index($v_t, 'kind') === 'kw')) && z_truthy((z_truthy((z_index($v_t, 'text') === 'fn')) || z_truthy((z_index($v_t, 'text') === 'func'))))))) {
            Z::$l = 314;
            z_apush($v_v, 'function');
          } else {
            Z::$l = 315;
            f_zs_invoke($v_this, 'back', []);
            Z::$l = 315;
            f_zs_invoke($v_this, 'fail', ['oczekiwano nazwy typu']);
          }
        }
      }
    }
    Z::$l = 316;
    if (z_truthy(!z_truthy(f_zs_invoke($v_this, 'eatOp', ['|'])))) {
      break 1;
    }
  }
  Z::$l = 318;
  return $v_v;
  return null;
}
function f_Parser__params($v_this) {
  $v_ps = null;
  $v_types = null;
  $v_variadic = null;
  $v_name = null;
  $v_default = null;
  Z::$l = 322;
  f_zs_invoke($v_this, 'expectOp', ['(']);
  Z::$l = 323;
  ($v_ps = []);
  while (true) {
    Z::$l = 324;
    if (!z_truthy(!z_truthy(f_zs_invoke($v_this, 'isOp', [')'])))) break;
    Z::$l = 325;
    ($v_types = (z_truthy((z_truthy(f_zs_invoke($v_this, 'isVar', [])) || z_truthy(f_zs_invoke($v_this, 'isOp', ['...'])))) ? [] : f_zs_invoke($v_this, 'types', [])));
    Z::$l = 326;
    ($v_variadic = f_zs_invoke($v_this, 'eatOp', ['...']));
    Z::$l = 327;
    ($v_name = f_zs_invoke($v_this, 'varName', []));
    Z::$l = 328;
    ($v_default = (z_truthy(f_zs_invoke($v_this, 'eatOp', ['='])) ? f_zs_invoke($v_this, 'expr', []) : null));
    Z::$l = 329;
    z_apush($v_ps, f_Workspace_parser__node('Param', 0, [$v_name, $v_types, $v_default, $v_variadic]));
    Z::$l = 330;
    if (z_truthy(!z_truthy(f_zs_invoke($v_this, 'eatOp', [','])))) {
      break 1;
    }
  }
  Z::$l = 332;
  f_zs_invoke($v_this, 'expectOp', [')']);
  Z::$l = 333;
  return $v_ps;
  return null;
}
function f_Parser__funcRest($v_this, $v_named) {
  $v_line = null;
  $v_name = null;
  $v_params = null;
  $v_ret = null;
  $v_body = null;
  Z::$l = 337;
  ($v_line = f_zs_invoke($v_this, 'line', []));
  Z::$l = 338;
  ($v_name = (z_truthy($v_named) ? f_zs_invoke($v_this, 'ident', []) : null));
  Z::$l = 339;
  ($v_params = f_zs_invoke($v_this, 'params', []));
  Z::$l = 340;
  ($v_ret = (z_truthy(f_zs_invoke($v_this, 'eatOp', [':'])) ? f_zs_invoke($v_this, 'types', []) : []));
  Z::$l = 341;
  ($v_body = f_zs_invoke($v_this, 'block', []));
  Z::$l = 342;
  return f_Workspace_parser__node('Func', $v_line, [$v_name, $v_params, $v_ret, $v_body, false]);
  return null;
}
function f_Parser__classDecl($v_this, $v_line) {
  $v_isAbstract = null;
  $v_isInterface = null;
  $v_name = null;
  $v_parent = null;
  $v_ifaces = null;
  $v_props = null;
  $v_consts = null;
  $v_methods = null;
  $v_isStatic = null;
  $v_abs = null;
  $v_n = null;
  $v_e = null;
  $v_l = null;
  $v_params = null;
  $v_ret = null;
  $v_isAbs = null;
  $v_mbody = null;
  $v_decl = null;
  $v_default = null;
  Z::$l = 346;
  ($v_isAbstract = f_zs_invoke($v_this, 'eatKw', ['abstract']));
  Z::$l = 347;
  ($v_isInterface = false);
  Z::$l = 348;
  if (z_truthy(f_zs_invoke($v_this, 'eatKw', ['interface']))) {
    Z::$l = 348;
    ($v_isInterface = true);
  } else {
    Z::$l = 349;
    if (z_truthy(!z_truthy(f_zs_invoke($v_this, 'eatKw', ['class'])))) {
      Z::$l = 349;
      f_zs_invoke($v_this, 'fail', ['oczekiwano `class`']);
    }
  }
  Z::$l = 350;
  ($v_name = f_zs_invoke($v_this, 'ident', []));
  Z::$l = 351;
  ($v_parent = null);
  Z::$l = 352;
  ($v_ifaces = []);
  Z::$l = 353;
  if (z_truthy(f_zs_invoke($v_this, 'eatKw', ['extends']))) {
    Z::$l = 354;
    if (z_truthy($v_isInterface)) {
      Z::$l = 355;
      z_apush($v_ifaces, f_zs_invoke($v_this, 'ident', []));
      while (true) {
        Z::$l = 356;
        if (!z_truthy(f_zs_invoke($v_this, 'eatOp', [',']))) break;
        Z::$l = 356;
        z_apush($v_ifaces, f_zs_invoke($v_this, 'ident', []));
      }
    } else {
      Z::$l = 357;
      ($v_parent = f_zs_invoke($v_this, 'ident', []));
    }
  }
  Z::$l = 359;
  if (z_truthy(f_zs_invoke($v_this, 'eatKw', ['implements']))) {
    Z::$l = 360;
    z_apush($v_ifaces, f_zs_invoke($v_this, 'ident', []));
    while (true) {
      Z::$l = 361;
      if (!z_truthy(f_zs_invoke($v_this, 'eatOp', [',']))) break;
      Z::$l = 361;
      z_apush($v_ifaces, f_zs_invoke($v_this, 'ident', []));
    }
  }
  Z::$l = 363;
  f_zs_invoke($v_this, 'expectOp', ['{']);
  Z::$l = 364;
  ($v_props = []);
  Z::$l = 365;
  ($v_consts = []);
  Z::$l = 366;
  ($v_methods = []);
  while (true) {
    Z::$l = 367;
    if (!z_truthy(!z_truthy(f_zs_invoke($v_this, 'isOp', ['}'])))) break;
    Z::$l = 368;
    if (z_truthy(f_zs_invoke($v_this, 'atEof', []))) {
      Z::$l = 368;
      f_zs_invoke($v_this, 'fail', ['niezamknięta klasa']);
    }
    Z::$l = 369;
    ($v_isStatic = false);
    Z::$l = 370;
    ($v_abs = false);
    while (true) {
      Z::$l = 371;
      if (!z_truthy(true)) break;
      Z::$l = 372;
      if (z_truthy((z_truthy((z_truthy((z_truthy(f_zs_invoke($v_this, 'eatKw', ['public'])) || z_truthy(f_zs_invoke($v_this, 'eatKw', ['private'])))) || z_truthy(f_zs_invoke($v_this, 'eatKw', ['protected'])))) || z_truthy(f_zs_invoke($v_this, 'eatWord', ['final']))))) {
      } else {
        Z::$l = 373;
        if (z_truthy(f_zs_invoke($v_this, 'eatKw', ['static']))) {
          Z::$l = 373;
          ($v_isStatic = true);
        } else {
          Z::$l = 374;
          if (z_truthy(f_zs_invoke($v_this, 'eatKw', ['abstract']))) {
            Z::$l = 374;
            ($v_abs = true);
          } else {
            break 1;
          }
        }
      }
    }
    Z::$l = 377;
    if (z_truthy(f_zs_invoke($v_this, 'eatWord', ['const']))) {
      Z::$l = 378;
      ($v_n = f_zs_invoke($v_this, 'ident', []));
      Z::$l = 378;
      f_zs_invoke($v_this, 'expectOp', ['=']);
      Z::$l = 378;
      ($v_e = f_zs_invoke($v_this, 'expr', []));
      Z::$l = 378;
      f_zs_invoke($v_this, 'expectOp', [';']);
      Z::$l = 379;
      z_apush($v_consts, f_Workspace_parser__node('Const', 0, [$v_n, $v_e]));
    } else {
      Z::$l = 380;
      if (z_truthy(f_zs_invoke($v_this, 'isFuncKw', []))) {
        Z::$l = 381;
        f_zs_invoke($v_this, 'bump', []);
        Z::$l = 382;
        ($v_l = f_zs_invoke($v_this, 'line', []));
        Z::$l = 383;
        ($v_n = f_zs_invoke($v_this, 'ident', []));
        Z::$l = 384;
        ($v_params = f_zs_invoke($v_this, 'params', []));
        Z::$l = 385;
        ($v_ret = (z_truthy(f_zs_invoke($v_this, 'eatOp', [':'])) ? f_zs_invoke($v_this, 'types', []) : []));
        Z::$l = 386;
        ($v_isAbs = false);
        Z::$l = 387;
        ($v_mbody = []);
        Z::$l = 388;
        if (z_truthy(f_zs_invoke($v_this, 'eatOp', [';']))) {
          Z::$l = 388;
          ($v_isAbs = true);
        } else {
          Z::$l = 388;
          ($v_mbody = f_zs_invoke($v_this, 'block', []));
        }
        Z::$l = 389;
        ($v_decl = f_Workspace_parser__node('Func', $v_l, [$v_n, $v_params, $v_ret, $v_mbody, false]));
        Z::$l = 390;
        z_apush($v_methods, f_Workspace_parser__node('Method', 0, [$v_decl, $v_isStatic, (z_truthy($v_abs) || z_truthy($v_isAbs))]));
      } else {
        Z::$l = 392;
        if (z_truthy(!z_truthy(f_zs_invoke($v_this, 'isVar', [])))) {
          Z::$l = 392;
          f_zs_invoke($v_this, 'types', []);
        }
        Z::$l = 393;
        ($v_n = f_zs_invoke($v_this, 'varName', []));
        Z::$l = 394;
        ($v_default = (z_truthy(f_zs_invoke($v_this, 'eatOp', ['='])) ? f_zs_invoke($v_this, 'expr', []) : null));
        Z::$l = 395;
        f_zs_invoke($v_this, 'expectOp', [';']);
        Z::$l = 396;
        z_apush($v_props, f_Workspace_parser__node('Prop', 0, [$v_n, $v_default, $v_isStatic]));
      }
    }
  }
  Z::$l = 399;
  f_zs_invoke($v_this, 'bump', []);
  Z::$l = 400;
  return f_Workspace_parser__node('ClassStmt', $v_line, [f_Workspace_parser__node('Class', $v_line, [$v_name, $v_parent, $v_ifaces, $v_isInterface, $v_isAbstract, $v_props, $v_consts, $v_methods])]);
  return null;
}
function f_Parser__expr($v_this) {
  Z::$l = 404;
  return f_zs_invoke($v_this, 'exprBp', [0]);
  return null;
}
function f_Parser__checkLvalue($v_this, $v_e) {
  $v_k = null;
  Z::$l = 407;
  ($v_k = z_index($v_e, 0));
  Z::$l = 408;
  if (z_truthy((z_truthy((z_truthy((z_truthy(($v_k === ':Var')) || z_truthy(($v_k === ':Index')))) || z_truthy(($v_k === ':Prop')))) || z_truthy(($v_k === ':Dot'))))) {
    Z::$l = 408;
    return null;
  }
  Z::$l = 409;
  f_zs_invoke($v_this, 'fail', ['lewa strona przypisania nie jest l-wartością']);
  return null;
}
function f_Parser__exprBp($v_this, $v_min) {
  $v_lhs = null;
  $v_line = null;
  $v_t = null;
  $v_ent = null;
  $v_lbp = null;
  $v_rbp = null;
  $v_kind = null;
  $v_r = null;
  $v_then = null;
  $v_els = null;
  $v_n = null;
  Z::$l = 413;
  ($v_lhs = f_zs_invoke($v_this, 'unary', []));
  while (true) {
    Z::$l = 414;
    if (!z_truthy(true)) break;
    Z::$l = 415;
    ($v_line = f_zs_invoke($v_this, 'line', []));
    Z::$l = 416;
    ($v_t = f_zs_invoke($v_this, 'cur', []));
    Z::$l = 417;
    ($v_ent = null);
    Z::$l = 418;
    if (z_truthy((z_index($v_t, 'kind') === 'op'))) {
      Z::$l = 418;
      ($v_ent = (($_t7 = z_indexopt([z_k('=') => [5, 5, 'assign', null], z_k('+=') => [5, 5, 'assignop', 'Add'], z_k('-=') => [5, 5, 'assignop', 'Sub'], z_k('*=') => [5, 5, 'assignop', 'Mul'], z_k('/=') => [5, 5, 'assignop', 'Div'], z_k('%=') => [5, 5, 'assignop', 'Mod'], z_k('.=') => [5, 5, 'assignop', 'Concat'], z_k('??=') => [5, 5, 'assignop', 'Coalesce'], z_k('?') => [6, 7, 'ternary', null], z_k('??') => [8, 8, 'bin', 'Coalesce'], z_k('||') => [9, 10, 'bin', 'Or'], z_k('&&') => [10, 11, 'bin', 'And'], z_k('|') => [11, 12, 'bin', 'BitOr'], z_k('^') => [12, 13, 'bin', 'BitXor'], z_k('&') => [13, 14, 'bin', 'BitAnd'], z_k('==') => [14, 15, 'bin', 'Eq'], z_k('!=') => [14, 15, 'bin', 'NotEq'], z_k('===') => [14, 15, 'bin', 'Identical'], z_k('!==') => [14, 15, 'bin', 'NotIdentical'], z_k('<') => [15, 16, 'bin', 'Lt'], z_k('>') => [15, 16, 'bin', 'Gt'], z_k('<=') => [15, 16, 'bin', 'Le'], z_k('>=') => [15, 16, 'bin', 'Ge'], z_k('.') => [16, 17, 'bin', 'Concat'], z_k('<<') => [17, 18, 'bin', 'Shl'], z_k('>>') => [17, 18, 'bin', 'Shr'], z_k('+') => [18, 19, 'bin', 'Add'], z_k('-') => [18, 19, 'bin', 'Sub'], z_k('*') => [19, 20, 'bin', 'Mul'], z_k('/') => [19, 20, 'bin', 'Div'], z_k('%') => [19, 20, 'bin', 'Mod'], z_k('**') => [23, 22, 'bin', 'Pow']], z_index($v_t, 'text'))) !== null ? $_t7 : null));
    } else {
      Z::$l = 419;
      if (z_truthy((z_index($v_t, 'kind') === 'kw'))) {
        Z::$l = 419;
        ($v_ent = (($_t8 = z_indexopt([z_k('or') => [1, 2, 'bin', 'Or'], z_k('xor') => [2, 3, 'bin', 'Xor'], z_k('and') => [3, 4, 'bin', 'And']], z_index($v_t, 'text'))) !== null ? $_t8 : null));
      } else {
        Z::$l = 420;
        if (z_truthy((z_truthy((z_index($v_t, 'kind') === 'ident')) && z_truthy((z_index($v_t, 'text') === 'instanceof'))))) {
          Z::$l = 420;
          ($v_ent = [16, 17, 'instanceof', null]);
        }
      }
    }
    Z::$l = 421;
    if (z_truthy(($v_ent === null))) {
      break 1;
    }
    Z::$l = 422;
    ($v_lbp = z_index($v_ent, 0));
    Z::$l = 423;
    ($v_rbp = z_index($v_ent, 1));
    Z::$l = 424;
    ($v_kind = z_index($v_ent, 2));
    Z::$l = 425;
    if (z_truthy((z_cmp($v_lbp, $v_min) < 0))) {
      break 1;
    }
    Z::$l = 426;
    f_zs_invoke($v_this, 'bump', []);
    Z::$l = 427;
    if (z_truthy(($v_kind === 'bin'))) {
      Z::$l = 428;
      ($v_r = f_zs_invoke($v_this, 'exprBp', [$v_rbp]));
      Z::$l = 429;
      ($v_lhs = f_Workspace_parser__node('Binary', $v_line, [z_index($v_ent, 3), $v_lhs, $v_r]));
    } else {
      Z::$l = 430;
      if (z_truthy(($v_kind === 'assign'))) {
        Z::$l = 431;
        f_zs_invoke($v_this, 'checkLvalue', [$v_lhs]);
        Z::$l = 432;
        ($v_r = f_zs_invoke($v_this, 'exprBp', [$v_rbp]));
        Z::$l = 433;
        ($v_lhs = f_Workspace_parser__node('Assign', $v_line, [$v_lhs, $v_r]));
      } else {
        Z::$l = 434;
        if (z_truthy(($v_kind === 'assignop'))) {
          Z::$l = 435;
          f_zs_invoke($v_this, 'checkLvalue', [$v_lhs]);
          Z::$l = 436;
          ($v_r = f_zs_invoke($v_this, 'exprBp', [$v_rbp]));
          Z::$l = 437;
          ($v_lhs = f_Workspace_parser__node('AssignOp', $v_line, [z_index($v_ent, 3), $v_lhs, $v_r]));
        } else {
          Z::$l = 438;
          if (z_truthy(($v_kind === 'ternary'))) {
            Z::$l = 439;
            ($v_then = (z_truthy(f_zs_invoke($v_this, 'isOp', [':'])) ? null : f_zs_invoke($v_this, 'exprBp', [0])));
            Z::$l = 440;
            f_zs_invoke($v_this, 'expectOp', [':']);
            Z::$l = 441;
            ($v_els = f_zs_invoke($v_this, 'exprBp', [$v_rbp]));
            Z::$l = 442;
            ($v_lhs = f_Workspace_parser__node('Ternary', $v_line, [$v_lhs, $v_then, $v_els]));
          } else {
            Z::$l = 444;
            ($v_n = f_zs_invoke($v_this, 'ident', []));
            Z::$l = 445;
            ($v_lhs = f_Workspace_parser__node('InstanceOf', $v_line, [$v_lhs, $v_n]));
          }
        }
      }
    }
  }
  Z::$l = 448;
  return $v_lhs;
  return null;
}
function f_Parser__unary($v_this) {
  $v_line = null;
  $v_t = null;
  $v_x = null;
  $v_e = null;
  $v_name = null;
  Z::$l = 452;
  ($v_line = f_zs_invoke($v_this, 'line', []));
  Z::$l = 453;
  ($v_t = f_zs_invoke($v_this, 'cur', []));
  Z::$l = 454;
  if (z_truthy((z_index($v_t, 'kind') === 'op'))) {
    Z::$l = 455;
    ($v_x = z_index($v_t, 'text'));
    Z::$l = 456;
    if (z_truthy((z_truthy((z_truthy((z_truthy(($v_x === '!')) || z_truthy(($v_x === '-')))) || z_truthy(($v_x === '+')))) || z_truthy(($v_x === '~'))))) {
      Z::$l = 457;
      f_zs_invoke($v_this, 'bump', []);
      Z::$l = 458;
      ($v_e = f_zs_invoke($v_this, 'exprBp', [21]));
      Z::$l = 459;
      ($v_name = (z_truthy(($v_x === '!')) ? 'Not' : (z_truthy(($v_x === '-')) ? 'Neg' : (z_truthy(($v_x === '+')) ? 'Plus' : 'BitNot'))));
      Z::$l = 460;
      return f_Workspace_parser__node('Unary', $v_line, [$v_name, $v_e]);
    }
    Z::$l = 462;
    if (z_truthy((z_truthy(($v_x === '++')) || z_truthy(($v_x === '--'))))) {
      Z::$l = 463;
      f_zs_invoke($v_this, 'bump', []);
      Z::$l = 464;
      ($v_e = f_zs_invoke($v_this, 'unary', []));
      Z::$l = 465;
      f_zs_invoke($v_this, 'checkLvalue', [$v_e]);
      Z::$l = 466;
      return f_Workspace_parser__node('IncDec', $v_line, [$v_e, ($v_x === '++'), true]);
    }
  }
  Z::$l = 469;
  if (z_truthy((z_truthy((z_index($v_t, 'kind') === 'kw')) && z_truthy((z_index($v_t, 'text') === 'await'))))) {
    Z::$l = 470;
    f_zs_invoke($v_this, 'bump', []);
    Z::$l = 471;
    ($v_e = f_zs_invoke($v_this, 'unary', []));
    Z::$l = 472;
    return f_Workspace_parser__node('Await', $v_line, [$v_e]);
  }
  Z::$l = 474;
  return f_zs_invoke($v_this, 'postfix', []);
  return null;
}
function f_Parser__args($v_this) {
  $v_v = null;
  $v_spread = null;
  $v_name = null;
  Z::$l = 478;
  f_zs_invoke($v_this, 'expectOp', ['(']);
  Z::$l = 479;
  ($v_v = []);
  while (true) {
    Z::$l = 480;
    if (!z_truthy(!z_truthy(f_zs_invoke($v_this, 'isOp', [')'])))) break;
    Z::$l = 481;
    ($v_spread = f_zs_invoke($v_this, 'eatOp', ['...']));
    Z::$l = 482;
    ($v_name = null);
    Z::$l = 483;
    if (z_truthy((z_truthy((z_truthy((z_index(f_zs_invoke($v_this, 'cur', []), 'kind') === 'ident')) && z_truthy((z_index(f_zs_invoke($v_this, 'at', [1]), 'kind') === 'op')))) && z_truthy((z_index(f_zs_invoke($v_this, 'at', [1]), 'text') === ':'))))) {
      Z::$l = 484;
      ($v_name = f_zs_invoke($v_this, 'ident', []));
      Z::$l = 485;
      f_zs_invoke($v_this, 'bump', []);
    }
    Z::$l = 487;
    z_apush($v_v, f_Workspace_parser__node('Arg', 0, [$v_name, f_zs_invoke($v_this, 'expr', []), $v_spread]));
    Z::$l = 488;
    if (z_truthy(!z_truthy(f_zs_invoke($v_this, 'eatOp', [','])))) {
      break 1;
    }
  }
  Z::$l = 490;
  f_zs_invoke($v_this, 'expectOp', [')']);
  Z::$l = 491;
  return $v_v;
  return null;
}
function f_Parser__postfix($v_this) {
  $v_e = null;
  $v_line = null;
  $v_t = null;
  $v_x = null;
  $v_a = null;
  $v_idx = null;
  $v_n = null;
  Z::$l = 495;
  ($v_e = f_zs_invoke($v_this, 'primary', []));
  while (true) {
    Z::$l = 496;
    if (!z_truthy(true)) break;
    Z::$l = 497;
    ($v_line = f_zs_invoke($v_this, 'line', []));
    Z::$l = 498;
    ($v_t = f_zs_invoke($v_this, 'cur', []));
    Z::$l = 499;
    if (z_truthy((z_index($v_t, 'kind') !== 'op'))) {
      break 1;
    }
    Z::$l = 500;
    ($v_x = z_index($v_t, 'text'));
    Z::$l = 501;
    if (z_truthy(($v_x === '('))) {
      Z::$l = 502;
      ($v_a = f_zs_invoke($v_this, 'args', []));
      Z::$l = 503;
      ($v_e = f_Workspace_parser__node('Call', $v_line, [$v_e, $v_a]));
    } else {
      Z::$l = 504;
      if (z_truthy(($v_x === '['))) {
        Z::$l = 505;
        f_zs_invoke($v_this, 'bump', []);
        Z::$l = 506;
        ($v_idx = (z_truthy(f_zs_invoke($v_this, 'isOp', [']'])) ? null : f_zs_invoke($v_this, 'expr', [])));
        Z::$l = 507;
        f_zs_invoke($v_this, 'expectOp', [']']);
        Z::$l = 508;
        ($v_e = f_Workspace_parser__node('Index', $v_line, [$v_e, $v_idx]));
      } else {
        Z::$l = 509;
        if (z_truthy(($v_x === '->'))) {
          Z::$l = 510;
          f_zs_invoke($v_this, 'bump', []);
          Z::$l = 511;
          ($v_n = f_zs_invoke($v_this, 'ident', []));
          Z::$l = 512;
          ($v_e = f_Workspace_parser__node('Prop', $v_line, [$v_e, $v_n]));
        } else {
          Z::$l = 513;
          if (z_truthy((z_truthy((z_truthy(($v_x === '.')) && z_truthy(f_Workspace_parser__isNamePath($v_e)))) && z_truthy((z_index(f_zs_invoke($v_this, 'at', [1]), 'kind') === 'ident'))))) {
            Z::$l = 514;
            f_zs_invoke($v_this, 'bump', []);
            Z::$l = 515;
            ($v_n = f_zs_invoke($v_this, 'ident', []));
            Z::$l = 516;
            ($v_e = f_Workspace_parser__node('Dot', $v_line, [$v_e, $v_n]));
          } else {
            Z::$l = 517;
            if (z_truthy((z_truthy(($v_x === '++')) || z_truthy(($v_x === '--'))))) {
              Z::$l = 518;
              f_zs_invoke($v_this, 'bump', []);
              Z::$l = 519;
              f_zs_invoke($v_this, 'checkLvalue', [$v_e]);
              Z::$l = 520;
              ($v_e = f_Workspace_parser__node('IncDec', $v_line, [$v_e, ($v_x === '++'), false]));
            } else {
              break 1;
            }
          }
        }
      }
    }
  }
  Z::$l = 523;
  return $v_e;
  return null;
}
function f_Parser__primary($v_this) {
  $v_line = null;
  $v_t = null;
  $v_k = null;
  $v_x = null;
  $v_n = null;
  $v_a = null;
  $v_params = null;
  $v_ret = null;
  $v_body = null;
  $v_d = null;
  $v_e = null;
  $v_items = null;
  $v_sl = null;
  $v_first = null;
  $v_v = null;
  Z::$l = 527;
  ($v_line = f_zs_invoke($v_this, 'line', []));
  Z::$l = 528;
  ($v_t = f_zs_invoke($v_this, 'bump', []));
  Z::$l = 529;
  ($v_k = z_index($v_t, 'kind'));
  Z::$l = 530;
  ($v_x = z_index($v_t, 'text'));
  Z::$l = 531;
  if (z_truthy(($v_k === 'int'))) {
    Z::$l = 531;
    return f_Workspace_parser__node('Int', $v_line, [z_index($v_t, 'value')]);
  }
  Z::$l = 532;
  if (z_truthy(($v_k === 'float'))) {
    Z::$l = 532;
    return f_Workspace_parser__node('Float', $v_line, [z_index($v_t, 'value')]);
  }
  Z::$l = 533;
  if (z_truthy(($v_k === 'str'))) {
    Z::$l = 533;
    return f_Workspace_parser__node('Str', $v_line, [z_index($v_t, 'value')]);
  }
  Z::$l = 534;
  if (z_truthy(($v_k === 'var'))) {
    Z::$l = 534;
    return f_Workspace_parser__node('Var', $v_line, [z_index($v_t, 'value')]);
  }
  Z::$l = 535;
  if (z_truthy(($v_k === 'kw'))) {
    Z::$l = 536;
    if (z_truthy(($v_x === 'true'))) {
      Z::$l = 536;
      return f_Workspace_parser__node('Bool', $v_line, [true]);
    }
    Z::$l = 537;
    if (z_truthy(($v_x === 'false'))) {
      Z::$l = 537;
      return f_Workspace_parser__node('Bool', $v_line, [false]);
    }
    Z::$l = 538;
    if (z_truthy(($v_x === 'null'))) {
      Z::$l = 538;
      return f_Workspace_parser__node('Null', $v_line, []);
    }
    Z::$l = 539;
    if (z_truthy(($v_x === 'static'))) {
      Z::$l = 539;
      return f_Workspace_parser__node('Name', $v_line, ['static']);
    }
    Z::$l = 540;
    if (z_truthy(($v_x === 'new'))) {
      Z::$l = 541;
      ($v_n = f_zs_invoke($v_this, 'ident', []));
      Z::$l = 542;
      ($v_a = (z_truthy(f_zs_invoke($v_this, 'isOp', ['('])) ? f_zs_invoke($v_this, 'args', []) : []));
      Z::$l = 543;
      return f_Workspace_parser__node('New', $v_line, [$v_n, $v_a]);
    }
    Z::$l = 545;
    if (z_truthy(($v_x === 'match'))) {
      Z::$l = 545;
      return f_zs_invoke($v_this, 'matchExpr', [$v_line]);
    }
    Z::$l = 546;
    if (z_truthy(($v_x === 'fn'))) {
      Z::$l = 547;
      ($v_params = f_zs_invoke($v_this, 'params', []));
      Z::$l = 548;
      ($v_ret = (z_truthy(f_zs_invoke($v_this, 'eatOp', [':'])) ? f_zs_invoke($v_this, 'types', []) : []));
      Z::$l = 549;
      f_zs_invoke($v_this, 'expectOp', ['=>']);
      Z::$l = 550;
      ($v_body = f_zs_invoke($v_this, 'exprBp', [5]));
      Z::$l = 551;
      ($v_d = f_Workspace_parser__node('Func', $v_line, [null, $v_params, $v_ret, [f_Workspace_parser__node('Return', z_index($v_body, 1), [$v_body])], true]));
      Z::$l = 552;
      return f_Workspace_parser__node('Closure', $v_line, [$v_d]);
    }
    Z::$l = 554;
    if (z_truthy(($v_x === 'func'))) {
      Z::$l = 554;
      return f_Workspace_parser__node('Closure', $v_line, [f_zs_invoke($v_this, 'funcRest', [false])]);
    }
  }
  Z::$l = 556;
  if (z_truthy(($v_k === 'ident'))) {
    Z::$l = 557;
    if (z_truthy((z_truthy(($v_x === 'function')) && z_truthy(f_zs_invoke($v_this, 'isOp', ['(']))))) {
      Z::$l = 557;
      return f_Workspace_parser__node('Closure', $v_line, [f_zs_invoke($v_this, 'funcRest', [false])]);
    }
    Z::$l = 558;
    return f_Workspace_parser__node('Name', $v_line, [$v_x]);
  }
  Z::$l = 560;
  if (z_truthy((z_truthy(($v_k === 'op')) && z_truthy(($v_x === '('))))) {
    Z::$l = 561;
    ($v_e = f_zs_invoke($v_this, 'expr', []));
    Z::$l = 562;
    f_zs_invoke($v_this, 'expectOp', [')']);
    Z::$l = 563;
    return $v_e;
  }
  Z::$l = 565;
  if (z_truthy((z_truthy(($v_k === 'op')) && z_truthy(($v_x === '['))))) {
    Z::$l = 566;
    ($v_items = []);
    while (true) {
      Z::$l = 567;
      if (!z_truthy(!z_truthy(f_zs_invoke($v_this, 'isOp', [']'])))) break;
      Z::$l = 568;
      if (z_truthy(f_zs_invoke($v_this, 'isOp', ['...']))) {
        Z::$l = 569;
        ($v_sl = f_zs_invoke($v_this, 'line', []));
        Z::$l = 570;
        f_zs_invoke($v_this, 'bump', []);
        Z::$l = 571;
        z_apush($v_items, f_Workspace_parser__node('Item', 0, [null, f_Workspace_parser__node('Spread', $v_sl, [f_zs_invoke($v_this, 'expr', [])])]));
        Z::$l = 572;
        if (z_truthy(!z_truthy(f_zs_invoke($v_this, 'eatOp', [','])))) {
          break 1;
        }
        continue 1;
      }
      Z::$l = 575;
      ($v_first = f_zs_invoke($v_this, 'expr', []));
      Z::$l = 576;
      if (z_truthy(f_zs_invoke($v_this, 'eatOp', ['=>']))) {
        Z::$l = 576;
        ($v_v = f_zs_invoke($v_this, 'expr', []));
        Z::$l = 576;
        z_apush($v_items, f_Workspace_parser__node('Item', 0, [$v_first, $v_v]));
      } else {
        Z::$l = 577;
        z_apush($v_items, f_Workspace_parser__node('Item', 0, [null, $v_first]));
      }
      Z::$l = 578;
      if (z_truthy(!z_truthy(f_zs_invoke($v_this, 'eatOp', [','])))) {
        break 1;
      }
    }
    Z::$l = 580;
    f_zs_invoke($v_this, 'expectOp', [']']);
    Z::$l = 581;
    return f_Workspace_parser__node('Array', $v_line, [$v_items]);
  }
  Z::$l = 583;
  f_zs_invoke($v_this, 'back', []);
  Z::$l = 584;
  f_zs_invoke($v_this, 'fail', [z_concat(z_concat('nieoczekiwany token w wyrażeniu: `', $v_x), '`')]);
  return null;
}
function f_Parser__matchExpr($v_this, $v_line) {
  $v_subj = null;
  $v_arms = null;
  $v_conds = null;
  $v_body = null;
  Z::$l = 588;
  ($v_subj = f_zs_invoke($v_this, 'parenExpr', []));
  Z::$l = 589;
  f_zs_invoke($v_this, 'expectOp', ['{']);
  Z::$l = 590;
  ($v_arms = []);
  while (true) {
    Z::$l = 591;
    if (!z_truthy(!z_truthy(f_zs_invoke($v_this, 'isOp', ['}'])))) break;
    Z::$l = 592;
    ($v_conds = null);
    Z::$l = 593;
    if (z_truthy(!z_truthy(f_zs_invoke($v_this, 'eatKw', ['default'])))) {
      Z::$l = 594;
      ($v_conds = [f_zs_invoke($v_this, 'expr', [])]);
      while (true) {
        Z::$l = 595;
        if (!z_truthy(f_zs_invoke($v_this, 'eatOp', [',']))) break;
        Z::$l = 596;
        if (z_truthy(f_zs_invoke($v_this, 'isOp', ['=>']))) {
          break 1;
        }
        Z::$l = 597;
        z_apush($v_conds, f_zs_invoke($v_this, 'expr', []));
      }
    }
    Z::$l = 600;
    f_zs_invoke($v_this, 'expectOp', ['=>']);
    Z::$l = 601;
    ($v_body = f_zs_invoke($v_this, 'expr', []));
    Z::$l = 602;
    z_apush($v_arms, f_Workspace_parser__node('Arm', 0, [$v_conds, $v_body]));
    Z::$l = 603;
    if (z_truthy(!z_truthy(f_zs_invoke($v_this, 'eatOp', [','])))) {
      break 1;
    }
  }
  Z::$l = 605;
  f_zs_invoke($v_this, 'expectOp', ['}']);
  Z::$l = 606;
  return f_Workspace_parser__node('Match', $v_line, [$v_subj, $v_arms]);
  return null;
}
function f_Parser__new($v_toks) {
  $v___o = null;
  Z::$l = 56;
  ($v___o = z_b_zs_obj_new('Parser'));
  Z::$l = 56;
  z_b_zs_obj_set($v___o, 'toks', null);
  Z::$l = 56;
  z_b_zs_obj_set($v___o, 'pos', null);
  Z::$l = 56;
  z_b_zs_obj_set($v___o, 'last', null);
  Z::$l = 56;
  f_Parser____construct($v___o, $v_toks);
  Z::$l = 56;
  return $v___o;
  return null;
}
function f_ZbcTables__new() {
  $v___o = null;
  Z::$l = 5;
  ($v___o = z_b_zs_obj_new('ZbcTables'));
  Z::$l = 5;
  return $v___o;
  return null;
}
function f_Bundler____construct($v_this) {
  Z::$l = 14;
  z_b_zs_obj_set($v_this, 'mods', []);
  Z::$l = 15;
  z_b_zs_obj_set($v_this, 'files', []);
  return null;
}
function f_Bundler__scan($v_this, $v_stmts, $v_dir) {
  $v_s = null;
  $v_path = null;
  $v_key = null;
  $v_file = null;
  $v___k3 = null;
  $v___r4 = null;
  $v___w5 = null;
  $v___k6 = null;
  $v___r7 = null;
  $v___w8 = null;
  $v_ast = null;
  $v___k9 = null;
  $v___r10 = null;
  $v___w11 = null;
  Z::$l = 19;
  foreach (z_foreach($v_stmts) as $_k37 => $_v37) {
    $v_s = $_v37;
    Z::$l = 20;
    if (z_truthy((z_index($v_s, 0) !== ':Import'))) {
      continue 1;
    }
    Z::$l = 21;
    ($v_path = z_index($v_s, 2));
    Z::$l = 22;
    if (z_truthy(z_b_in_array(z_index($v_path, 0), ['System', 'Math', 'File', 'Directory', 'Process', 'Task']))) {
      continue 1;
    }
    Z::$l = 23;
    ($v_key = z_b_join($v_path, '.'));
    Z::$l = 24;
    ($v_file = z_m_System_resolveImport($v_path, $v_dir));
    Z::$l = 25;
    if (z_truthy(($v_file === null))) {
      Z::$l = 25;
      z_raise(new ZExc(0, z_concat(z_concat(z_concat(z_concat('nie znaleziono modułu ', $v_key), ' (import w '), $v_dir), ')')));
    }
    Z::$l = 26;
    if (z_truthy(z_b_has_key(z_b_zs_obj_get($v_this, 'mods'), $v_key))) {
      Z::$l = 27;
      if (z_truthy((z_index(z_b_zs_obj_get($v_this, 'files'), $v_key) !== $v_file))) {
        Z::$l = 28;
        z_raise(new ZExc(0, z_concat(z_concat(z_concat(z_concat(z_concat('niejednoznaczny import `', $v_key), '`: '), z_index(z_b_zs_obj_get($v_this, 'files'), $v_key)), ' oraz '), $v_file)));
      }
      continue 1;
    }
    Z::$l = 32;
    ($v___k3 = $v_key);
    Z::$l = 32;
    ($v___r4 = $v_file);
    Z::$l = 32;
    ($v___w5 = z_b_zs_obj_take($v_this, 'files'));
    Z::$l = 32;
    z_aset($v___w5, $v___k3, $v___r4);
    Z::$l = 32;
    z_b_zs_obj_put($v_this, 'files', $v___w5);
    Z::$l = 33;
    ($v___k6 = $v_key);
    Z::$l = 33;
    ($v___r7 = []);
    Z::$l = 33;
    ($v___w8 = z_b_zs_obj_take($v_this, 'mods'));
    Z::$l = 33;
    z_aset($v___w8, $v___k6, $v___r7);
    Z::$l = 33;
    z_b_zs_obj_put($v_this, 'mods', $v___w8);
    Z::$l = 34;
    ($v_ast = f_Workspace_parser__parse(z_m_File_read($v_file)));
    Z::$l = 35;
    ($v___k9 = $v_key);
    Z::$l = 35;
    ($v___r10 = $v_ast);
    Z::$l = 35;
    ($v___w11 = z_b_zs_obj_take($v_this, 'mods'));
    Z::$l = 35;
    z_aset($v___w11, $v___k9, $v___r10);
    Z::$l = 35;
    z_b_zs_obj_put($v_this, 'mods', $v___w11);
    Z::$l = 36;
    f_zs_invoke($v_this, 'scan', [$v_ast, z_m_System_dirname($v_file)]);
  }
  return null;
}
function f_Bundler__new() {
  $v___o = null;
  Z::$l = 9;
  ($v___o = z_b_zs_obj_new('Bundler'));
  Z::$l = 9;
  z_b_zs_obj_set($v___o, 'mods', null);
  Z::$l = 9;
  z_b_zs_obj_set($v___o, 'files', null);
  Z::$l = 9;
  f_Bundler____construct($v___o);
  Z::$l = 9;
  return $v___o;
  return null;
}
function f_SemaTables__new() {
  $v___o = null;
  Z::$l = 5;
  ($v___o = z_b_zs_obj_new('SemaTables'));
  Z::$l = 5;
  return $v___o;
  return null;
}
function f_SemaScope____construct($v_this, $v_name, $v_line, $v_isClosure) {
  Z::$l = 31;
  z_b_zs_obj_set($v_this, 'name', $v_name);
  Z::$l = 32;
  z_b_zs_obj_set($v_this, 'line', $v_line);
  Z::$l = 33;
  z_b_zs_obj_set($v_this, 'assigned', []);
  Z::$l = 34;
  z_b_zs_obj_set($v_this, 'reads', []);
  Z::$l = 35;
  z_b_zs_obj_set($v_this, 'sites', []);
  Z::$l = 36;
  z_b_zs_obj_set($v_this, 'level', []);
  Z::$l = 37;
  z_b_zs_obj_set($v_this, 'edges', []);
  Z::$l = 38;
  z_b_zs_obj_set($v_this, 'children', []);
  Z::$l = 39;
  z_b_zs_obj_set($v_this, 'isClosure', $v_isClosure);
  return null;
}
function f_SemaScope__raise($v_this, $v_v, $v_lv) {
  $v_cur = null;
  $v___k12 = null;
  $v___r13 = null;
  $v___w14 = null;
  Z::$l = 43;
  ($v_cur = (($_t9 = z_indexopt(z_b_zs_obj_get($v_this, 'level'), $v_v)) !== null ? $_t9 : 0));
  Z::$l = 44;
  if (z_truthy((z_cmp($v_lv, $v_cur) > 0))) {
    Z::$l = 44;
    ($v___k12 = $v_v);
    Z::$l = 44;
    ($v___r13 = $v_lv);
    Z::$l = 44;
    ($v___w14 = z_b_zs_obj_take($v_this, 'level'));
    Z::$l = 44;
    z_aset($v___w14, $v___k12, $v___r13);
    Z::$l = 44;
    z_b_zs_obj_put($v_this, 'level', $v___w14);
  }
  return null;
}
function f_SemaScope__new($v_name, $v_line, $v_isClosure) {
  $v___o = null;
  Z::$l = 19;
  ($v___o = z_b_zs_obj_new('SemaScope'));
  Z::$l = 19;
  z_b_zs_obj_set($v___o, 'name', null);
  Z::$l = 19;
  z_b_zs_obj_set($v___o, 'line', null);
  Z::$l = 19;
  z_b_zs_obj_set($v___o, 'assigned', null);
  Z::$l = 19;
  z_b_zs_obj_set($v___o, 'reads', null);
  Z::$l = 19;
  z_b_zs_obj_set($v___o, 'sites', null);
  Z::$l = 19;
  z_b_zs_obj_set($v___o, 'level', null);
  Z::$l = 19;
  z_b_zs_obj_set($v___o, 'edges', null);
  Z::$l = 19;
  z_b_zs_obj_set($v___o, 'children', null);
  Z::$l = 19;
  z_b_zs_obj_set($v___o, 'isClosure', null);
  Z::$l = 19;
  f_SemaScope____construct($v___o, $v_name, $v_line, $v_isClosure);
  Z::$l = 19;
  return $v___o;
  return null;
}
function f_Analyzer____construct($v_this) {
  Z::$l = 53;
  z_b_zs_obj_set($v_this, 'warnings', []);
  Z::$l = 54;
  z_b_zs_obj_set($v_this, 'functions', []);
  return null;
}
function f_Analyzer__baseVar($v_this, $v_e) {
  while (true) {
    Z::$l = 58;
    if (!z_truthy((z_truthy((z_index($v_e, 0) === ':Index')) || z_truthy((z_index($v_e, 0) === ':Prop'))))) break;
    Z::$l = 58;
    ($v_e = z_index($v_e, 2));
  }
  Z::$l = 59;
  return (z_truthy((z_index($v_e, 0) === ':Var')) ? z_index($v_e, 2) : null);
  return null;
}
function f_Analyzer__allocKind($v_this, $v_e) {
  Z::$l = 63;
  if (z_truthy((z_index($v_e, 0) === ':Array'))) {
    Z::$l = 63;
    return 'array';
  }
  Z::$l = 64;
  if (z_truthy((z_index($v_e, 0) === ':New'))) {
    Z::$l = 64;
    return z_concat('object ', z_index($v_e, 2));
  }
  Z::$l = 65;
  if (z_truthy((z_index($v_e, 0) === ':Closure'))) {
    Z::$l = 65;
    return 'closure';
  }
  Z::$l = 66;
  return null;
  return null;
}
function f_Analyzer__valueVars($v_this, $v_e) {
  $v_out = null;
  $v_it = null;
  $v_x = null;
  Z::$l = 71;
  ($v_out = []);
  Z::$l = 72;
  if (z_truthy((z_index($v_e, 0) === ':Var'))) {
    Z::$l = 72;
    z_apush($v_out, z_index($v_e, 2));
  } else {
    Z::$l = 73;
    if (z_truthy((z_index($v_e, 0) === ':Array'))) {
      Z::$l = 74;
      foreach (z_foreach(z_index($v_e, 2)) as $_k39 => $_v39) {
        $v_it = $_v39;
        Z::$l = 74;
        foreach (z_foreach(f_zs_invoke($v_this, 'valueVars', [z_index($v_it, 3)])) as $_k40 => $_v40) {
          $v_x = $_v40;
          Z::$l = 74;
          z_apush($v_out, $v_x);
        }
      }
    } else {
      Z::$l = 75;
      if (z_truthy((z_index($v_e, 0) === ':Spread'))) {
        Z::$l = 76;
        foreach (z_foreach(f_zs_invoke($v_this, 'valueVars', [z_index($v_e, 2)])) as $_k41 => $_v41) {
          $v_x = $_v41;
          Z::$l = 76;
          z_apush($v_out, $v_x);
        }
      } else {
        Z::$l = 77;
        if (z_truthy((z_index($v_e, 0) === ':Ternary'))) {
          Z::$l = 78;
          if (z_truthy((z_index($v_e, 3) !== null))) {
            Z::$l = 78;
            foreach (z_foreach(f_zs_invoke($v_this, 'valueVars', [z_index($v_e, 3)])) as $_k42 => $_v42) {
              $v_x = $_v42;
              Z::$l = 78;
              z_apush($v_out, $v_x);
            }
          }
          Z::$l = 79;
          foreach (z_foreach(f_zs_invoke($v_this, 'valueVars', [z_index($v_e, 4)])) as $_k43 => $_v43) {
            $v_x = $_v43;
            Z::$l = 79;
            z_apush($v_out, $v_x);
          }
        } else {
          Z::$l = 80;
          if (z_truthy((z_truthy((z_index($v_e, 0) === ':Binary')) && z_truthy((z_index($v_e, 2) === 'Coalesce'))))) {
            Z::$l = 81;
            foreach (z_foreach(f_zs_invoke($v_this, 'valueVars', [z_index($v_e, 3)])) as $_k44 => $_v44) {
              $v_x = $_v44;
              Z::$l = 81;
              z_apush($v_out, $v_x);
            }
            Z::$l = 82;
            foreach (z_foreach(f_zs_invoke($v_this, 'valueVars', [z_index($v_e, 4)])) as $_k45 => $_v45) {
              $v_x = $_v45;
              Z::$l = 82;
              z_apush($v_out, $v_x);
            }
          }
        }
      }
    }
  }
  Z::$l = 84;
  return $v_out;
  return null;
}
function f_Analyzer__visitAny($v_this, $v_x, $v_sc, $v_prefix) {
  $v_y = null;
  Z::$l = 88;
  if (z_truthy(f_Workspace_parser__isNode($v_x))) {
    Z::$l = 88;
    f_zs_invoke($v_this, 'visit', [$v_x, $v_sc, $v_prefix]);
  } else {
    Z::$l = 89;
    if (z_truthy(z_b_is_array($v_x))) {
      Z::$l = 89;
      foreach (z_foreach($v_x) as $_k46 => $_v46) {
        $v_y = $_v46;
        Z::$l = 89;
        f_zs_invoke($v_this, 'visitAny', [$v_y, $v_sc, $v_prefix]);
      }
    }
  }
  return null;
}
function f_Analyzer__visitChildren($v_this, $v_n, $v_sc, $v_prefix) {
  $v_i = null;
  Z::$l = 93;
  ($v_i = 2);
  for (; z_truthy((z_cmp($v_i, z_b_count($v_n)) < 0)); z_last($_t10 = $v_i, $v_i = z_add($_t10, 1), $_t10)) {
    Z::$l = 93;
    f_zs_invoke($v_this, 'visitAny', [z_index($v_n, $v_i), $v_sc, $v_prefix]);
  }
  return null;
}
function f_Analyzer__visit($v_this, $v_n, $v_sc, $v_prefix) {
  $v_k = null;
  $v___r15 = null;
  $v___w16 = null;
  $v_lhs = null;
  $v_rhs = null;
  $v_name = null;
  $v___k17 = null;
  $v___r18 = null;
  $v___w19 = null;
  $v_ak = null;
  $v___r20 = null;
  $v___w21 = null;
  $v_v = null;
  $v___r22 = null;
  $v___w23 = null;
  $v___r24 = null;
  $v___w25 = null;
  $v___r26 = null;
  $v___w27 = null;
  $v_b = null;
  $v___k28 = null;
  $v___r29 = null;
  $v___w30 = null;
  $v___r31 = null;
  $v___w32 = null;
  $v___r33 = null;
  $v___w34 = null;
  $v_e = null;
  $v_t = null;
  $v___k35 = null;
  $v___r36 = null;
  $v___w37 = null;
  $v___r38 = null;
  $v___w39 = null;
  $v___r40 = null;
  $v___w41 = null;
  $v___k42 = null;
  $v___r43 = null;
  $v___w44 = null;
  $v_callee = null;
  $v_args = null;
  $v_pure = null;
  $v_c = null;
  $v_a = null;
  $v___k45 = null;
  $v___r46 = null;
  $v___w47 = null;
  $v___k48 = null;
  $v___r49 = null;
  $v___w50 = null;
  $v___k51 = null;
  $v___r52 = null;
  $v___w53 = null;
  $v___k54 = null;
  $v___r55 = null;
  $v___w56 = null;
  $v_m = null;
  Z::$l = 97;
  ($v_k = z_index($v_n, 0));
  Z::$l = 98;
  if (z_truthy(($v_k === ':Var'))) {
    Z::$l = 98;
    ($v___r15 = [z_index($v_n, 2), z_index($v_n, 1)]);
    Z::$l = 98;
    ($v___w16 = z_b_zs_obj_take($v_sc, 'reads'));
    Z::$l = 98;
    z_apush($v___w16, $v___r15);
    Z::$l = 98;
    z_b_zs_obj_put($v_sc, 'reads', $v___w16);
    Z::$l = 98;
    return null;
  }
  Z::$l = 99;
  if (z_truthy(($v_k === ':Assign'))) {
    Z::$l = 100;
    ($v_lhs = z_index($v_n, 2));
    Z::$l = 101;
    ($v_rhs = z_index($v_n, 3));
    Z::$l = 102;
    if (z_truthy((z_index($v_lhs, 0) === ':Var'))) {
      Z::$l = 103;
      ($v_name = z_index($v_lhs, 2));
      Z::$l = 104;
      ($v___k17 = $v_name);
      Z::$l = 104;
      ($v___r18 = true);
      Z::$l = 104;
      ($v___w19 = z_b_zs_obj_take($v_sc, 'assigned'));
      Z::$l = 104;
      z_aset($v___w19, $v___k17, $v___r18);
      Z::$l = 104;
      z_b_zs_obj_put($v_sc, 'assigned', $v___w19);
      Z::$l = 105;
      ($v_ak = f_zs_invoke($v_this, 'allocKind', [$v_rhs]));
      Z::$l = 106;
      if (z_truthy(($v_ak !== null))) {
        Z::$l = 106;
        ($v___r20 = [$v_name, $v_ak, z_index($v_n, 1)]);
        Z::$l = 106;
        ($v___w21 = z_b_zs_obj_take($v_sc, 'sites'));
        Z::$l = 106;
        z_apush($v___w21, $v___r20);
        Z::$l = 106;
        z_b_zs_obj_put($v_sc, 'sites', $v___w21);
      }
      Z::$l = 107;
      foreach (z_foreach(f_zs_invoke($v_this, 'valueVars', [$v_rhs])) as $_k48 => $_v48) {
        $v_v = $_v48;
        Z::$l = 108;
        if (z_truthy((z_index($v_rhs, 0) === ':Var'))) {
          Z::$l = 108;
          ($v___r22 = [$v_v, $v_name]);
          Z::$l = 108;
          ($v___w23 = z_b_zs_obj_take($v_sc, 'edges'));
          Z::$l = 108;
          z_apush($v___w23, $v___r22);
          Z::$l = 108;
          z_b_zs_obj_put($v_sc, 'edges', $v___w23);
          Z::$l = 108;
          ($v___r24 = [$v_name, $v_v]);
          Z::$l = 108;
          ($v___w25 = z_b_zs_obj_take($v_sc, 'edges'));
          Z::$l = 108;
          z_apush($v___w25, $v___r24);
          Z::$l = 108;
          z_b_zs_obj_put($v_sc, 'edges', $v___w25);
        } else {
          Z::$l = 109;
          ($v___r26 = [$v_v, $v_name]);
          Z::$l = 109;
          ($v___w27 = z_b_zs_obj_take($v_sc, 'edges'));
          Z::$l = 109;
          z_apush($v___w27, $v___r26);
          Z::$l = 109;
          z_b_zs_obj_put($v_sc, 'edges', $v___w27);
        }
      }
    } else {
      Z::$l = 112;
      ($v_b = f_zs_invoke($v_this, 'baseVar', [$v_lhs]));
      Z::$l = 113;
      if (z_truthy(($v_b !== null))) {
        Z::$l = 114;
        if (z_truthy((z_index($v_lhs, 0) === ':Index'))) {
          Z::$l = 114;
          ($v___k28 = $v_b);
          Z::$l = 114;
          ($v___r29 = true);
          Z::$l = 114;
          ($v___w30 = z_b_zs_obj_take($v_sc, 'assigned'));
          Z::$l = 114;
          z_aset($v___w30, $v___k28, $v___r29);
          Z::$l = 114;
          z_b_zs_obj_put($v_sc, 'assigned', $v___w30);
        } else {
          Z::$l = 115;
          ($v___r31 = [$v_b, z_index($v_n, 1)]);
          Z::$l = 115;
          ($v___w32 = z_b_zs_obj_take($v_sc, 'reads'));
          Z::$l = 115;
          z_apush($v___w32, $v___r31);
          Z::$l = 115;
          z_b_zs_obj_put($v_sc, 'reads', $v___w32);
        }
        Z::$l = 116;
        foreach (z_foreach(f_zs_invoke($v_this, 'valueVars', [$v_rhs])) as $_k49 => $_v49) {
          $v_v = $_v49;
          Z::$l = 116;
          ($v___r33 = [$v_v, $v_b]);
          Z::$l = 116;
          ($v___w34 = z_b_zs_obj_take($v_sc, 'edges'));
          Z::$l = 116;
          z_apush($v___w34, $v___r33);
          Z::$l = 116;
          z_b_zs_obj_put($v_sc, 'edges', $v___w34);
        }
      }
      Z::$l = 119;
      ($v_e = $v_lhs);
      while (true) {
        Z::$l = 120;
        if (!z_truthy((z_truthy((z_index($v_e, 0) === ':Index')) || z_truthy((z_index($v_e, 0) === ':Prop'))))) break;
        Z::$l = 121;
        if (z_truthy((z_truthy((z_index($v_e, 0) === ':Index')) && z_truthy((z_index($v_e, 3) !== null))))) {
          Z::$l = 121;
          f_zs_invoke($v_this, 'visit', [z_index($v_e, 3), $v_sc, $v_prefix]);
        }
        Z::$l = 122;
        ($v_e = z_index($v_e, 2));
      }
      Z::$l = 124;
      if (z_truthy((z_index($v_e, 0) !== ':Var'))) {
        Z::$l = 124;
        f_zs_invoke($v_this, 'visit', [$v_e, $v_sc, $v_prefix]);
      }
    }
    Z::$l = 126;
    f_zs_invoke($v_this, 'visit', [$v_rhs, $v_sc, $v_prefix]);
    Z::$l = 127;
    return null;
  }
  Z::$l = 129;
  if (z_truthy((z_truthy(($v_k === ':AssignOp')) || z_truthy(($v_k === ':IncDec'))))) {
    Z::$l = 130;
    ($v_t = (z_truthy(($v_k === ':AssignOp')) ? z_index($v_n, 3) : z_index($v_n, 2)));
    Z::$l = 131;
    ($v_b = f_zs_invoke($v_this, 'baseVar', [$v_t]));
    Z::$l = 132;
    if (z_truthy(($v_b !== null))) {
      Z::$l = 132;
      ($v___k35 = $v_b);
      Z::$l = 132;
      ($v___r36 = true);
      Z::$l = 132;
      ($v___w37 = z_b_zs_obj_take($v_sc, 'assigned'));
      Z::$l = 132;
      z_aset($v___w37, $v___k35, $v___r36);
      Z::$l = 132;
      z_b_zs_obj_put($v_sc, 'assigned', $v___w37);
      Z::$l = 132;
      ($v___r38 = [$v_b, z_index($v_n, 1)]);
      Z::$l = 132;
      ($v___w39 = z_b_zs_obj_take($v_sc, 'reads'));
      Z::$l = 132;
      z_apush($v___w39, $v___r38);
      Z::$l = 132;
      z_b_zs_obj_put($v_sc, 'reads', $v___w39);
    }
    Z::$l = 133;
    if (z_truthy(($v_k === ':AssignOp'))) {
      Z::$l = 133;
      f_zs_invoke($v_this, 'visit', [z_index($v_n, 4), $v_sc, $v_prefix]);
    }
    Z::$l = 134;
    return null;
  }
  Z::$l = 136;
  if (z_truthy(($v_k === ':Return'))) {
    Z::$l = 137;
    if (z_truthy((z_index($v_n, 2) !== null))) {
      Z::$l = 138;
      ($v_ak = f_zs_invoke($v_this, 'allocKind', [z_index($v_n, 2)]));
      Z::$l = 139;
      if (z_truthy(($v_ak !== null))) {
        Z::$l = 139;
        ($v___r40 = ['<return>', $v_ak, z_index($v_n, 1)]);
        Z::$l = 139;
        ($v___w41 = z_b_zs_obj_take($v_sc, 'sites'));
        Z::$l = 139;
        z_apush($v___w41, $v___r40);
        Z::$l = 139;
        z_b_zs_obj_put($v_sc, 'sites', $v___w41);
        Z::$l = 139;
        ($v___k42 = '<return>');
        Z::$l = 139;
        ($v___r43 = 1);
        Z::$l = 139;
        ($v___w44 = z_b_zs_obj_take($v_sc, 'level'));
        Z::$l = 139;
        z_aset($v___w44, $v___k42, $v___r43);
        Z::$l = 139;
        z_b_zs_obj_put($v_sc, 'level', $v___w44);
      }
      Z::$l = 140;
      foreach (z_foreach(f_zs_invoke($v_this, 'valueVars', [z_index($v_n, 2)])) as $_k51 => $_v51) {
        $v_v = $_v51;
        Z::$l = 140;
        f_zs_invoke($v_sc, 'raise', [$v_v, 1]);
      }
      Z::$l = 141;
      f_zs_invoke($v_this, 'visit', [z_index($v_n, 2), $v_sc, $v_prefix]);
    }
    Z::$l = 143;
    return null;
  }
  Z::$l = 145;
  if (z_truthy(($v_k === ':Throw'))) {
    Z::$l = 146;
    foreach (z_foreach(f_zs_invoke($v_this, 'valueVars', [z_index($v_n, 2)])) as $_k52 => $_v52) {
      $v_v = $_v52;
      Z::$l = 146;
      f_zs_invoke($v_sc, 'raise', [$v_v, 2]);
    }
    Z::$l = 147;
    f_zs_invoke($v_this, 'visit', [z_index($v_n, 2), $v_sc, $v_prefix]);
    Z::$l = 148;
    return null;
  }
  Z::$l = 150;
  if (z_truthy((z_truthy(($v_k === ':Call')) || z_truthy(($v_k === ':New'))))) {
    Z::$l = 151;
    ($v_callee = (z_truthy(($v_k === ':Call')) ? z_index($v_n, 2) : null));
    Z::$l = 152;
    ($v_args = (z_truthy(($v_k === ':Call')) ? z_index($v_n, 3) : z_index($v_n, 3)));
    Z::$l = 153;
    ($v_pure = false);
    Z::$l = 154;
    if (z_truthy((z_truthy(($v_callee !== null)) && z_truthy((z_index($v_callee, 0) === ':Name'))))) {
      Z::$l = 154;
      ($v_pure = z_b_has_key([z_k('necho') => true, z_k('eecho') => true, z_k('count') => true, z_k('strlen') => true, z_k('has_key') => true, z_k('keys') => true, z_k('join') => true, z_k('in_array') => true, z_k('index_of') => true, z_k('starts_with') => true, z_k('ends_with') => true, z_k('trim') => true, z_k('substr') => true, z_k('intval') => true, z_k('typeof') => true, z_k('is_int') => true, z_k('is_float') => true, z_k('is_string') => true, z_k('is_bool') => true, z_k('is_array') => true, z_k('is_null') => true, z_k('is_object') => true, z_k('is_callable') => true, z_k('replace') => true, z_k('pad_left') => true, z_k('pad_right') => true, z_k('ord') => true, z_k('chr') => true, z_k('floatval') => true], z_index($v_callee, 2)));
    }
    Z::$l = 155;
    if (z_truthy(($v_callee !== null))) {
      Z::$l = 156;
      if (z_truthy((z_index($v_callee, 0) === ':Name'))) {
      } else {
        Z::$l = 157;
        if (z_truthy((z_index($v_callee, 0) === ':Dot'))) {
          Z::$l = 157;
          ($v_c = $v_callee);
          while (true) {
            Z::$l = 157;
            if (!z_truthy((z_index($v_c, 0) === ':Dot'))) break;
            Z::$l = 157;
            ($v_c = z_index($v_c, 2));
          }
          Z::$l = 157;
          if (z_truthy((z_index($v_c, 0) !== ':Name'))) {
            Z::$l = 157;
            f_zs_invoke($v_this, 'visit', [$v_c, $v_sc, $v_prefix]);
          }
        } else {
          Z::$l = 158;
          f_zs_invoke($v_this, 'visit', [$v_callee, $v_sc, $v_prefix]);
        }
      }
    }
    Z::$l = 160;
    foreach (z_foreach($v_args) as $_k54 => $_v54) {
      $v_a = $_v54;
      Z::$l = 161;
      if (z_truthy(!z_truthy($v_pure))) {
        Z::$l = 161;
        foreach (z_foreach(f_zs_invoke($v_this, 'valueVars', [z_index($v_a, 3)])) as $_k55 => $_v55) {
          $v_v = $_v55;
          Z::$l = 161;
          f_zs_invoke($v_sc, 'raise', [$v_v, 2]);
        }
      }
      Z::$l = 162;
      f_zs_invoke($v_this, 'visit', [z_index($v_a, 3), $v_sc, $v_prefix]);
    }
    Z::$l = 164;
    return null;
  }
  Z::$l = 166;
  if (z_truthy(($v_k === ':Foreach'))) {
    Z::$l = 167;
    f_zs_invoke($v_this, 'visit', [z_index($v_n, 2), $v_sc, $v_prefix]);
    Z::$l = 168;
    if (z_truthy((z_index($v_n, 3) !== null))) {
      Z::$l = 168;
      ($v___k45 = z_index($v_n, 3));
      Z::$l = 168;
      ($v___r46 = true);
      Z::$l = 168;
      ($v___w47 = z_b_zs_obj_take($v_sc, 'assigned'));
      Z::$l = 168;
      z_aset($v___w47, $v___k45, $v___r46);
      Z::$l = 168;
      z_b_zs_obj_put($v_sc, 'assigned', $v___w47);
    }
    Z::$l = 169;
    ($v___k48 = z_index($v_n, 4));
    Z::$l = 169;
    ($v___r49 = true);
    Z::$l = 169;
    ($v___w50 = z_b_zs_obj_take($v_sc, 'assigned'));
    Z::$l = 169;
    z_aset($v___w50, $v___k48, $v___r49);
    Z::$l = 169;
    z_b_zs_obj_put($v_sc, 'assigned', $v___w50);
    Z::$l = 170;
    f_zs_invoke($v_this, 'visitAny', [z_index($v_n, 5), $v_sc, $v_prefix]);
    Z::$l = 171;
    return null;
  }
  Z::$l = 173;
  if (z_truthy(($v_k === ':Try'))) {
    Z::$l = 174;
    f_zs_invoke($v_this, 'visitAny', [z_index($v_n, 2), $v_sc, $v_prefix]);
    Z::$l = 175;
    foreach (z_foreach(z_index($v_n, 3)) as $_k56 => $_v56) {
      $v_c = $_v56;
      Z::$l = 176;
      if (z_truthy((z_index($v_c, 3) !== null))) {
        Z::$l = 176;
        ($v___k51 = z_index($v_c, 3));
        Z::$l = 176;
        ($v___r52 = true);
        Z::$l = 176;
        ($v___w53 = z_b_zs_obj_take($v_sc, 'assigned'));
        Z::$l = 176;
        z_aset($v___w53, $v___k51, $v___r52);
        Z::$l = 176;
        z_b_zs_obj_put($v_sc, 'assigned', $v___w53);
      }
      Z::$l = 177;
      f_zs_invoke($v_this, 'visitAny', [z_index($v_c, 4), $v_sc, $v_prefix]);
    }
    Z::$l = 179;
    if (z_truthy((z_index($v_n, 4) !== null))) {
      Z::$l = 179;
      f_zs_invoke($v_this, 'visitAny', [z_index($v_n, 4), $v_sc, $v_prefix]);
    }
    Z::$l = 180;
    return null;
  }
  Z::$l = 182;
  if (z_truthy(($v_k === ':Using'))) {
    Z::$l = 183;
    f_zs_invoke($v_this, 'visit', [z_index($v_n, 2), $v_sc, $v_prefix]);
    Z::$l = 184;
    ($v___k54 = z_index($v_n, 3));
    Z::$l = 184;
    ($v___r55 = true);
    Z::$l = 184;
    ($v___w56 = z_b_zs_obj_take($v_sc, 'assigned'));
    Z::$l = 184;
    z_aset($v___w56, $v___k54, $v___r55);
    Z::$l = 184;
    z_b_zs_obj_put($v_sc, 'assigned', $v___w56);
    Z::$l = 185;
    f_zs_invoke($v_this, 'visitAny', [z_index($v_n, 4), $v_sc, $v_prefix]);
    Z::$l = 186;
    return null;
  }
  Z::$l = 188;
  if (z_truthy(($v_k === ':FuncStmt'))) {
    Z::$l = 188;
    f_zs_invoke($v_this, 'fnScope', [z_index($v_n, 2), $v_prefix, false, null]);
    Z::$l = 188;
    return null;
  }
  Z::$l = 189;
  if (z_truthy(($v_k === ':Closure'))) {
    Z::$l = 189;
    f_zs_invoke($v_this, 'fnScope', [z_index($v_n, 2), $v_prefix, true, $v_sc]);
    Z::$l = 189;
    return null;
  }
  Z::$l = 190;
  if (z_truthy(($v_k === ':ClassStmt'))) {
    Z::$l = 191;
    ($v_c = z_index($v_n, 2));
    Z::$l = 192;
    foreach (z_foreach(z_index($v_c, 9)) as $_k57 => $_v57) {
      $v_m = $_v57;
      Z::$l = 192;
      f_zs_invoke($v_this, 'fnScope', [z_index($v_m, 2), z_index($v_c, 2), false, null]);
    }
    Z::$l = 193;
    return null;
  }
  Z::$l = 195;
  f_zs_invoke($v_this, 'visitChildren', [$v_n, $v_sc, $v_prefix]);
  return null;
}
function f_Analyzer__fnScope($v_this, $v_decl, $v_prefix, $v_isClosure, $v_parent) {
  $v_name = null;
  $v_label = null;
  $v_sc = null;
  $v_p = null;
  $v___k57 = null;
  $v___r58 = null;
  $v___w59 = null;
  $v___k60 = null;
  $v___r61 = null;
  $v___w62 = null;
  $v_free = null;
  $v_r = null;
  $v___r63 = null;
  $v___w64 = null;
  Z::$l = 200;
  ($v_name = z_index($v_decl, 2));
  Z::$l = 201;
  ($v_label = (z_truthy($v_isClosure) ? '{closure}' : (z_truthy((z_truthy(($v_prefix !== '')) && z_truthy(($v_name !== null)))) ? z_concat(z_concat($v_prefix, '.'), $v_name) : (($_t11 = $v_name) !== null ? $_t11 : '{anon}'))));
  Z::$l = 202;
  ($v_sc = f_SemaScope__new($v_label, z_index($v_decl, 1), $v_isClosure));
  Z::$l = 203;
  foreach (z_foreach(z_index($v_decl, 3)) as $_k58 => $_v58) {
    $v_p = $_v58;
    Z::$l = 203;
    ($v___k57 = z_index($v_p, 2));
    Z::$l = 203;
    ($v___r58 = true);
    Z::$l = 203;
    ($v___w59 = z_b_zs_obj_take($v_sc, 'assigned'));
    Z::$l = 203;
    z_aset($v___w59, $v___k57, $v___r58);
    Z::$l = 203;
    z_b_zs_obj_put($v_sc, 'assigned', $v___w59);
  }
  Z::$l = 204;
  ($v___k60 = 'this');
  Z::$l = 204;
  ($v___r61 = true);
  Z::$l = 204;
  ($v___w62 = z_b_zs_obj_take($v_sc, 'assigned'));
  Z::$l = 204;
  z_aset($v___w62, $v___k60, $v___r61);
  Z::$l = 204;
  z_b_zs_obj_put($v_sc, 'assigned', $v___w62);
  Z::$l = 205;
  f_zs_invoke($v_this, 'visitAny', [z_index($v_decl, 5), $v_sc, $v_prefix]);
  Z::$l = 206;
  if (z_truthy($v_isClosure)) {
    Z::$l = 207;
    ($v_free = []);
    Z::$l = 208;
    foreach (z_foreach(z_b_zs_obj_get($v_sc, 'reads')) as $_k59 => $_v59) {
      $v_r = $_v59;
      Z::$l = 208;
      if (z_truthy(!z_truthy(z_b_has_key(z_b_zs_obj_get($v_sc, 'assigned'), z_index($v_r, 0))))) {
        Z::$l = 208;
        z_apush($v_free, $v_r);
      }
    }
    Z::$l = 209;
    ($v___r63 = [$v_free, z_index($v_decl, 1)]);
    Z::$l = 209;
    ($v___w64 = z_b_zs_obj_take($v_parent, 'children'));
    Z::$l = 209;
    z_apush($v___w64, $v___r63);
    Z::$l = 209;
    z_b_zs_obj_put($v_parent, 'children', $v___w64);
    Z::$l = 210;
    f_zs_invoke($v_this, 'finish', [$v_sc, false]);
  } else {
    Z::$l = 212;
    f_zs_invoke($v_this, 'finish', [$v_sc, true]);
  }
  return null;
}
function f_Analyzer__resolveChildren($v_this, $v_sc) {
  $v_ch = null;
  $v_r = null;
  $v___r65 = null;
  $v___w66 = null;
  $v___r67 = null;
  $v___w68 = null;
  Z::$l = 218;
  foreach (z_foreach(z_b_zs_obj_get($v_sc, 'children')) as $_k60 => $_v60) {
    $v_ch = $_v60;
    Z::$l = 219;
    foreach (z_foreach(z_index($v_ch, 0)) as $_k61 => $_v61) {
      $v_r = $_v61;
      Z::$l = 220;
      if (z_truthy(z_b_has_key(z_b_zs_obj_get($v_sc, 'assigned'), z_index($v_r, 0)))) {
        Z::$l = 220;
        f_zs_invoke($v_sc, 'raise', [z_index($v_r, 0), 2]);
      } else {
        Z::$l = 221;
        if (z_truthy(z_b_zs_obj_get($v_sc, 'isClosure'))) {
          Z::$l = 221;
          ($v___r65 = $v_r);
          Z::$l = 221;
          ($v___w66 = z_b_zs_obj_take($v_sc, 'reads'));
          Z::$l = 221;
          z_apush($v___w66, $v___r65);
          Z::$l = 221;
          z_b_zs_obj_put($v_sc, 'reads', $v___w66);
        } else {
          Z::$l = 222;
          ($v___r67 = [z_index($v_r, 1), z_concat(z_concat('zmienna $', z_index($v_r, 0)), ' w domknięciu nie jest przypisana w otaczającej funkcji')]);
          Z::$l = 222;
          ($v___w68 = z_b_zs_obj_take($v_this, 'warnings'));
          Z::$l = 222;
          z_apush($v___w68, $v___r67);
          Z::$l = 222;
          z_b_zs_obj_put($v_this, 'warnings', $v___w68);
        }
      }
    }
  }
  return null;
}
function f_Analyzer__finish($v_this, $v_sc, $v_report) {
  $v_r = null;
  $v___r69 = null;
  $v___w70 = null;
  $v_changed = null;
  $v_guard = null;
  $v_e = null;
  $v_a = null;
  $v_b = null;
  $v___k71 = null;
  $v___r72 = null;
  $v___w73 = null;
  $v_sites = null;
  $v_s = null;
  $v_lv = null;
  $v___r74 = null;
  $v___w75 = null;
  Z::$l = 228;
  f_zs_invoke($v_this, 'resolveChildren', [$v_sc]);
  Z::$l = 229;
  if (z_truthy($v_report)) {
    Z::$l = 230;
    foreach (z_foreach(z_b_zs_obj_get($v_sc, 'reads')) as $_k62 => $_v62) {
      $v_r = $_v62;
      Z::$l = 231;
      if (z_truthy(!z_truthy(z_b_has_key(z_b_zs_obj_get($v_sc, 'assigned'), z_index($v_r, 0))))) {
        Z::$l = 232;
        ($v___r69 = [z_index($v_r, 1), z_concat(z_concat(z_concat('zmienna $', z_index($v_r, 0)), ' jest czytana, ale nigdy nie przypisana w '), z_b_zs_obj_get($v_sc, 'name'))]);
        Z::$l = 232;
        ($v___w70 = z_b_zs_obj_take($v_this, 'warnings'));
        Z::$l = 232;
        z_apush($v___w70, $v___r69);
        Z::$l = 232;
        z_b_zs_obj_put($v_this, 'warnings', $v___w70);
      }
    }
  }
  Z::$l = 237;
  ($v_changed = true);
  Z::$l = 238;
  ($v_guard = 0);
  while (true) {
    Z::$l = 239;
    if (!z_truthy((z_truthy($v_changed) && z_truthy((z_cmp($v_guard, 64) < 0))))) break;
    Z::$l = 240;
    ($v_changed = false);
    Z::$l = 241;
    z_last($_t12 = $v_guard, $v_guard = z_add($_t12, 1), $_t12);
    Z::$l = 242;
    foreach (z_foreach(z_b_zs_obj_get($v_sc, 'edges')) as $_k64 => $_v64) {
      $v_e = $_v64;
      Z::$l = 243;
      ($v_a = (($_t13 = z_indexopt(z_b_zs_obj_get($v_sc, 'level'), z_index($v_e, 0))) !== null ? $_t13 : 0));
      Z::$l = 244;
      ($v_b = (($_t14 = z_indexopt(z_b_zs_obj_get($v_sc, 'level'), z_index($v_e, 1))) !== null ? $_t14 : 0));
      Z::$l = 245;
      if (z_truthy((z_cmp($v_b, $v_a) > 0))) {
        Z::$l = 245;
        ($v___k71 = z_index($v_e, 0));
        Z::$l = 245;
        ($v___r72 = $v_b);
        Z::$l = 245;
        ($v___w73 = z_b_zs_obj_take($v_sc, 'level'));
        Z::$l = 245;
        z_aset($v___w73, $v___k71, $v___r72);
        Z::$l = 245;
        z_b_zs_obj_put($v_sc, 'level', $v___w73);
        Z::$l = 245;
        ($v_changed = true);
      }
    }
  }
  Z::$l = 248;
  ($v_sites = []);
  Z::$l = 249;
  foreach (z_foreach(z_b_zs_obj_get($v_sc, 'sites')) as $_k65 => $_v65) {
    $v_s = $_v65;
    Z::$l = 250;
    ($v_lv = (($_t15 = z_indexopt(z_b_zs_obj_get($v_sc, 'level'), z_index($v_s, 0))) !== null ? $_t15 : 0));
    Z::$l = 251;
    z_apush($v_sites, [z_k('var') => z_index($v_s, 0), z_k('kind') => z_index($v_s, 1), z_k('line') => z_index($v_s, 2), z_k('escape') => z_index(['No', 'Caller', 'Unknown'], $v_lv), z_k('zamm') => z_index(['Frame', 'Frame + przeniesienie przy return', 'Persistent'], $v_lv)]);
  }
  Z::$l = 253;
  if (z_truthy((z_truthy((z_cmp(z_b_count($v_sites), 0) > 0)) || z_truthy(!z_truthy(z_b_zs_obj_get($v_sc, 'isClosure')))))) {
    Z::$l = 254;
    ($v___r74 = [z_k('name') => z_b_zs_obj_get($v_sc, 'name'), z_k('line') => z_b_zs_obj_get($v_sc, 'line'), z_k('sites') => $v_sites]);
    Z::$l = 254;
    ($v___w75 = z_b_zs_obj_take($v_this, 'functions'));
    Z::$l = 254;
    z_apush($v___w75, $v___r74);
    Z::$l = 254;
    z_b_zs_obj_put($v_this, 'functions', $v___w75);
  }
  return null;
}
function f_Analyzer__new() {
  $v___o = null;
  Z::$l = 48;
  ($v___o = z_b_zs_obj_new('Analyzer'));
  Z::$l = 48;
  z_b_zs_obj_set($v___o, 'warnings', null);
  Z::$l = 48;
  z_b_zs_obj_set($v___o, 'functions', null);
  Z::$l = 48;
  f_Analyzer____construct($v___o);
  Z::$l = 48;
  return $v___o;
  return null;
}
function f_IrTables__new() {
  $v___o = null;
  Z::$l = 12;
  ($v___o = z_b_zs_obj_new('IrTables'));
  Z::$l = 12;
  return $v___o;
  return null;
}
function f_Lowerer____construct($v_this) {
  Z::$l = 50;
  z_b_zs_obj_set($v_this, 'funcs', []);
  Z::$l = 51;
  z_b_zs_obj_set($v_this, 'order', []);
  Z::$l = 52;
  z_b_zs_obj_set($v_this, 'errors', []);
  return null;
}
function f_Lowerer__err($v_this, $v_line, $v_code, $v_msg) {
  $v___r76 = null;
  $v___w77 = null;
  Z::$l = 55;
  ($v___r76 = [$v_line, $v_code, $v_msg]);
  Z::$l = 55;
  ($v___w77 = z_b_zs_obj_take($v_this, 'errors'));
  Z::$l = 55;
  z_apush($v___w77, $v___r76);
  Z::$l = 55;
  z_b_zs_obj_put($v_this, 'errors', $v___w77);
  return null;
}
function f_Lowerer__addLocal($v_this, $v_locals, $v_name) {
  Z::$l = 59;
  if (z_truthy(!z_truthy(z_b_in_array($v_name, $v_locals)))) {
    Z::$l = 59;
    z_apush($v_locals, $v_name);
  }
  Z::$l = 60;
  return $v_locals;
  return null;
}
function f_Lowerer__collectExpr($v_this, $v_e, $v_locals) {
  $v_k = null;
  $v_i = null;
  Z::$l = 64;
  if (z_truthy(!z_truthy(f_Workspace_parser__isNode($v_e)))) {
    Z::$l = 64;
    return $v_locals;
  }
  Z::$l = 65;
  ($v_k = z_index($v_e, 0));
  Z::$l = 66;
  if (z_truthy(($v_k === ':Assign'))) {
    Z::$l = 66;
    ($v_locals = f_zs_invoke($v_this, 'collectTarget', [z_index($v_e, 2), $v_locals]));
  } else {
    Z::$l = 67;
    if (z_truthy(($v_k === ':AssignOp'))) {
      Z::$l = 67;
      ($v_locals = f_zs_invoke($v_this, 'collectTarget', [z_index($v_e, 3), $v_locals]));
    } else {
      Z::$l = 68;
      if (z_truthy(($v_k === ':IncDec'))) {
        Z::$l = 68;
        ($v_locals = f_zs_invoke($v_this, 'collectTarget', [z_index($v_e, 2), $v_locals]));
      }
    }
  }
  Z::$l = 69;
  ($v_i = 2);
  for (; z_truthy((z_cmp($v_i, z_b_count($v_e)) < 0)); z_last($_t16 = $v_i, $v_i = z_add($_t16, 1), $_t16)) {
    Z::$l = 69;
    ($v_locals = f_zs_invoke($v_this, 'collectAny', [z_index($v_e, $v_i), $v_locals]));
  }
  Z::$l = 70;
  return $v_locals;
  return null;
}
function f_Lowerer__collectTarget($v_this, $v_t, $v_locals) {
  while (true) {
    Z::$l = 74;
    if (!z_truthy((z_truthy((z_index($v_t, 0) === ':Index')) || z_truthy((z_index($v_t, 0) === ':Prop'))))) break;
    Z::$l = 74;
    ($v_t = z_index($v_t, 2));
  }
  Z::$l = 75;
  if (z_truthy((z_index($v_t, 0) === ':Var'))) {
    Z::$l = 75;
    ($v_locals = f_zs_invoke($v_this, 'addLocal', [$v_locals, z_index($v_t, 2)]));
  }
  Z::$l = 76;
  return $v_locals;
  return null;
}
function f_Lowerer__collectAny($v_this, $v_x, $v_locals) {
  $v_y = null;
  Z::$l = 80;
  if (z_truthy(f_Workspace_parser__isNode($v_x))) {
    Z::$l = 81;
    if (z_truthy((z_truthy((z_index($v_x, 0) === ':Catch')) && z_truthy((z_index($v_x, 3) !== null))))) {
      Z::$l = 81;
      ($v_locals = f_zs_invoke($v_this, 'addLocal', [$v_locals, z_index($v_x, 3)]));
    }
    Z::$l = 82;
    if (z_truthy((z_index($v_x, 0) === ':Foreach'))) {
      Z::$l = 83;
      if (z_truthy((z_index($v_x, 3) !== null))) {
        Z::$l = 83;
        ($v_locals = f_zs_invoke($v_this, 'addLocal', [$v_locals, z_index($v_x, 3)]));
      }
      Z::$l = 84;
      ($v_locals = f_zs_invoke($v_this, 'addLocal', [$v_locals, z_index($v_x, 4)]));
    }
    Z::$l = 86;
    return f_zs_invoke($v_this, 'collectExpr', [$v_x, $v_locals]);
  }
  Z::$l = 88;
  if (z_truthy(z_b_is_array($v_x))) {
    Z::$l = 88;
    foreach (z_foreach($v_x) as $_k68 => $_v68) {
      $v_y = $_v68;
      Z::$l = 88;
      ($v_locals = f_zs_invoke($v_this, 'collectAny', [$v_y, $v_locals]));
    }
  }
  Z::$l = 89;
  return $v_locals;
  return null;
}
function f_Lowerer__checkStmts($v_this, $v_list, $v_depth) {
  $v_s = null;
  Z::$l = 93;
  foreach (z_foreach($v_list) as $_k69 => $_v69) {
    $v_s = $_v69;
    Z::$l = 93;
    f_zs_invoke($v_this, 'checkStmt', [$v_s, $v_depth]);
  }
  return null;
}
function f_Lowerer__checkStmt($v_this, $v_s, $v_depth) {
  $v_k = null;
  $v_line = null;
  $v_e = null;
  $v_c = null;
  $v_t = null;
  $v_x = null;
  Z::$l = 96;
  ($v_k = z_index($v_s, 0));
  Z::$l = 97;
  ($v_line = z_index($v_s, 1));
  Z::$l = 98;
  if (z_truthy(($v_k === ':Expr'))) {
    Z::$l = 98;
    f_zs_invoke($v_this, 'checkExpr', [z_index($v_s, 2)]);
  } else {
    Z::$l = 99;
    if (z_truthy(($v_k === ':Echo'))) {
      Z::$l = 99;
      foreach (z_foreach(z_index($v_s, 2)) as $_k70 => $_v70) {
        $v_e = $_v70;
        Z::$l = 99;
        f_zs_invoke($v_this, 'checkExpr', [$v_e]);
      }
    } else {
      Z::$l = 100;
      if (z_truthy(($v_k === ':Block'))) {
        Z::$l = 100;
        f_zs_invoke($v_this, 'checkStmts', [z_index($v_s, 2), $v_depth]);
      } else {
        Z::$l = 101;
        if (z_truthy(($v_k === ':If'))) {
          Z::$l = 102;
          f_zs_invoke($v_this, 'checkExpr', [z_index($v_s, 2)]);
          Z::$l = 103;
          f_zs_invoke($v_this, 'checkStmts', [z_index($v_s, 3), $v_depth]);
          Z::$l = 104;
          if (z_truthy((z_index($v_s, 4) !== null))) {
            Z::$l = 104;
            f_zs_invoke($v_this, 'checkStmts', [z_index($v_s, 4), $v_depth]);
          }
        } else {
          Z::$l = 106;
          if (z_truthy(($v_k === ':While'))) {
            Z::$l = 106;
            f_zs_invoke($v_this, 'checkExpr', [z_index($v_s, 2)]);
            Z::$l = 106;
            f_zs_invoke($v_this, 'checkStmts', [z_index($v_s, 3), $v_depth]);
          } else {
            Z::$l = 107;
            if (z_truthy(($v_k === ':DoWhile'))) {
              Z::$l = 107;
              f_zs_invoke($v_this, 'checkStmts', [z_index($v_s, 2), $v_depth]);
              Z::$l = 107;
              f_zs_invoke($v_this, 'checkExpr', [z_index($v_s, 3)]);
            } else {
              Z::$l = 108;
              if (z_truthy(($v_k === ':For'))) {
                Z::$l = 109;
                foreach (z_foreach(z_index($v_s, 2)) as $_k71 => $_v71) {
                  $v_e = $_v71;
                  Z::$l = 109;
                  f_zs_invoke($v_this, 'checkExpr', [$v_e]);
                }
                Z::$l = 110;
                if (z_truthy((z_index($v_s, 3) !== null))) {
                  Z::$l = 110;
                  f_zs_invoke($v_this, 'checkExpr', [z_index($v_s, 3)]);
                }
                Z::$l = 111;
                foreach (z_foreach(z_index($v_s, 4)) as $_k72 => $_v72) {
                  $v_e = $_v72;
                  Z::$l = 111;
                  f_zs_invoke($v_this, 'checkExpr', [$v_e]);
                }
                Z::$l = 112;
                f_zs_invoke($v_this, 'checkStmts', [z_index($v_s, 5), $v_depth]);
              } else {
                Z::$l = 114;
                if (z_truthy(($v_k === ':Foreach'))) {
                  Z::$l = 114;
                  f_zs_invoke($v_this, 'checkExpr', [z_index($v_s, 2)]);
                  Z::$l = 114;
                  f_zs_invoke($v_this, 'checkStmts', [z_index($v_s, 5), $v_depth]);
                } else {
                  Z::$l = 115;
                  if (z_truthy(($v_k === ':Switch'))) {
                    Z::$l = 116;
                    f_zs_invoke($v_this, 'checkExpr', [z_index($v_s, 2)]);
                    Z::$l = 117;
                    foreach (z_foreach(z_index($v_s, 3)) as $_k73 => $_v73) {
                      $v_c = $_v73;
                      Z::$l = 118;
                      if (z_truthy((z_index($v_c, 2) !== null))) {
                        Z::$l = 118;
                        f_zs_invoke($v_this, 'checkExpr', [z_index($v_c, 2)]);
                      }
                      Z::$l = 119;
                      f_zs_invoke($v_this, 'checkStmts', [z_index($v_c, 3), $v_depth]);
                    }
                  } else {
                    Z::$l = 122;
                    if (z_truthy(($v_k === ':Return'))) {
                      Z::$l = 122;
                      if (z_truthy((z_index($v_s, 2) !== null))) {
                        Z::$l = 122;
                        f_zs_invoke($v_this, 'checkExpr', [z_index($v_s, 2)]);
                      }
                    } else {
                      Z::$l = 123;
                      if (z_truthy((z_truthy(($v_k === ':Break')) || z_truthy(($v_k === ':Continue'))))) {
                      } else {
                        Z::$l = 124;
                        if (z_truthy(($v_k === ':Try'))) {
                          Z::$l = 125;
                          f_zs_invoke($v_this, 'checkStmts', [z_index($v_s, 2), $v_depth]);
                          Z::$l = 126;
                          foreach (z_foreach(z_index($v_s, 3)) as $_k74 => $_v74) {
                            $v_c = $_v74;
                            Z::$l = 127;
                            foreach (z_foreach(z_index($v_c, 2)) as $_k75 => $_v75) {
                              $v_t = $_v75;
                              Z::$l = 128;
                              if (z_truthy(!z_truthy(z_b_in_array($v_t, ['Exception', 'Error', 'Throwable'])))) {
                                Z::$l = 128;
                                f_zs_invoke($v_this, 'err', [$v_line, 'E0107', z_concat(z_concat('klasa wyjątku `', $v_t), '` niedostępna w backendzie natywnym 0.0.1 (obsługiwane: Exception, Error, Throwable)')]);
                              }
                            }
                            Z::$l = 130;
                            f_zs_invoke($v_this, 'checkStmts', [z_index($v_c, 4), $v_depth]);
                          }
                          Z::$l = 132;
                          if (z_truthy((z_index($v_s, 4) !== null))) {
                            Z::$l = 132;
                            f_zs_invoke($v_this, 'checkStmts', [z_index($v_s, 4), $v_depth]);
                          }
                        } else {
                          Z::$l = 134;
                          if (z_truthy(($v_k === ':Throw'))) {
                            Z::$l = 135;
                            ($v_x = z_index($v_s, 2));
                            Z::$l = 136;
                            if (z_truthy((z_index($v_x, 0) === ':New'))) {
                              Z::$l = 136;
                              f_zs_invoke($v_this, 'checkNew', [$v_x]);
                            } else {
                              Z::$l = 137;
                              if (z_truthy((z_index($v_x, 0) === ':Var'))) {
                              } else {
                                Z::$l = 138;
                                f_zs_invoke($v_this, 'checkExpr', [$v_x]);
                              }
                            }
                          } else {
                            Z::$l = 140;
                            if (z_truthy(($v_k === ':FuncStmt'))) {
                              Z::$l = 140;
                              f_zs_invoke($v_this, 'err', [$v_line, 'E0101', 'funkcje zagnieżdżone nie są obsługiwane (deklaruj funkcje na najwyższym poziomie)']);
                            } else {
                              Z::$l = 141;
                              f_zs_invoke($v_this, 'err', [$v_line, 'E0101', z_concat(z_concat('instrukcja ', z_b_substr($v_k, 1)), ' niedostępna w backendzie natywnym 0.0.1')]);
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
  return null;
}
function f_Lowerer__checkNew($v_this, $v_x) {
  $v_a = null;
  Z::$l = 145;
  if (z_truthy(!z_truthy(z_b_in_array(z_index($v_x, 2), ['Exception', 'Error'])))) {
    Z::$l = 145;
    f_zs_invoke($v_this, 'err', [z_index($v_x, 1), 'E0107', z_concat(z_concat('new ', z_index($v_x, 2)), ': tylko Exception i Error w backendzie natywnym 0.0.1')]);
  }
  Z::$l = 146;
  if (z_truthy((z_cmp(z_b_count(z_index($v_x, 3)), 1) > 0))) {
    Z::$l = 146;
    f_zs_invoke($v_this, 'err', [z_index($v_x, 1), 'E0104', z_concat(z_concat('new ', z_index($v_x, 2)), ': oczekiwano co najwyżej 1 argumentu')]);
  }
  Z::$l = 147;
  foreach (z_foreach(z_index($v_x, 3)) as $_k76 => $_v76) {
    $v_a = $_v76;
    Z::$l = 147;
    f_zs_invoke($v_this, 'checkExpr', [z_index($v_a, 3)]);
  }
  return null;
}
function f_Lowerer__containsTry($v_this, $v_x) {
  $v_i = null;
  $v_y = null;
  Z::$l = 151;
  if (z_truthy(f_Workspace_parser__isNode($v_x))) {
    Z::$l = 152;
    if (z_truthy((z_index($v_x, 0) === ':Try'))) {
      Z::$l = 152;
      return true;
    }
    Z::$l = 153;
    if (z_truthy((z_index($v_x, 0) === ':FuncStmt'))) {
      Z::$l = 153;
      return false;
    }
    Z::$l = 154;
    ($v_i = 2);
    for (; z_truthy((z_cmp($v_i, z_b_count($v_x)) < 0)); z_last($_t17 = $v_i, $v_i = z_add($_t17, 1), $_t17)) {
      Z::$l = 154;
      if (z_truthy(f_zs_invoke($v_this, 'containsTry', [z_index($v_x, $v_i)]))) {
        Z::$l = 154;
        return true;
      }
    }
    Z::$l = 155;
    return false;
  }
  Z::$l = 157;
  if (z_truthy(z_b_is_array($v_x))) {
    Z::$l = 157;
    foreach (z_foreach($v_x) as $_k78 => $_v78) {
      $v_y = $_v78;
      Z::$l = 157;
      if (z_truthy(f_zs_invoke($v_this, 'containsTry', [$v_y]))) {
        Z::$l = 157;
        return true;
      }
    }
  }
  Z::$l = 158;
  return false;
  return null;
}
function f_Lowerer__calleeName($v_this, $v_c) {
  Z::$l = 162;
  if (z_truthy((z_index($v_c, 0) === ':Name'))) {
    Z::$l = 162;
    return z_index($v_c, 2);
  }
  Z::$l = 163;
  return null;
  return null;
}
function f_Lowerer__checkExpr($v_this, $v_e) {
  $v_k = null;
  $v_line = null;
  $v_it = null;
  $v_op = null;
  Z::$l = 167;
  if (z_truthy(!z_truthy(f_Workspace_parser__isNode($v_e)))) {
    Z::$l = 167;
    return null;
  }
  Z::$l = 168;
  ($v_k = z_index($v_e, 0));
  Z::$l = 169;
  ($v_line = z_index($v_e, 1));
  Z::$l = 170;
  if (z_truthy((z_truthy((z_truthy((z_truthy((z_truthy((z_truthy(($v_k === ':Null')) || z_truthy(($v_k === ':Bool')))) || z_truthy(($v_k === ':Int')))) || z_truthy(($v_k === ':Float')))) || z_truthy(($v_k === ':Str')))) || z_truthy(($v_k === ':Var'))))) {
    Z::$l = 170;
    return null;
  }
  Z::$l = 171;
  if (z_truthy(($v_k === ':Array'))) {
    Z::$l = 172;
    foreach (z_foreach(z_index($v_e, 2)) as $_k79 => $_v79) {
      $v_it = $_v79;
      Z::$l = 173;
      if (z_truthy((z_index($v_it, 2) !== null))) {
        Z::$l = 173;
        f_zs_invoke($v_this, 'checkExpr', [z_index($v_it, 2)]);
      }
      Z::$l = 174;
      f_zs_invoke($v_this, 'checkExpr', [z_index($v_it, 3)]);
    }
    Z::$l = 176;
    return null;
  }
  Z::$l = 178;
  if (z_truthy(($v_k === ':Index'))) {
    Z::$l = 179;
    f_zs_invoke($v_this, 'checkExpr', [z_index($v_e, 2)]);
    Z::$l = 180;
    if (z_truthy((z_index($v_e, 3) !== null))) {
      Z::$l = 180;
      f_zs_invoke($v_this, 'checkExpr', [z_index($v_e, 3)]);
    }
    Z::$l = 181;
    return null;
  }
  Z::$l = 183;
  if (z_truthy(($v_k === ':Unary'))) {
    Z::$l = 184;
    f_zs_invoke($v_this, 'checkExpr', [z_index($v_e, 3)]);
    Z::$l = 185;
    return null;
  }
  Z::$l = 187;
  if (z_truthy(($v_k === ':Binary'))) {
    Z::$l = 188;
    ($v_op = z_index($v_e, 2));
    Z::$l = 189;
    f_zs_invoke($v_this, 'checkExpr', [z_index($v_e, 3)]);
    Z::$l = 190;
    f_zs_invoke($v_this, 'checkExpr', [z_index($v_e, 4)]);
    Z::$l = 191;
    return null;
  }
  Z::$l = 193;
  if (z_truthy(($v_k === ':Assign'))) {
    Z::$l = 193;
    f_zs_invoke($v_this, 'checkLvalue', [z_index($v_e, 2)]);
    Z::$l = 193;
    f_zs_invoke($v_this, 'checkExpr', [z_index($v_e, 3)]);
    Z::$l = 193;
    return null;
  }
  Z::$l = 194;
  if (z_truthy(($v_k === ':AssignOp'))) {
    Z::$l = 194;
    f_zs_invoke($v_this, 'checkLvalue', [z_index($v_e, 3)]);
    Z::$l = 194;
    f_zs_invoke($v_this, 'checkExpr', [z_index($v_e, 4)]);
    Z::$l = 194;
    return null;
  }
  Z::$l = 195;
  if (z_truthy(($v_k === ':IncDec'))) {
    Z::$l = 195;
    f_zs_invoke($v_this, 'checkLvalue', [z_index($v_e, 2)]);
    Z::$l = 195;
    return null;
  }
  Z::$l = 196;
  if (z_truthy(($v_k === ':Ternary'))) {
    Z::$l = 197;
    f_zs_invoke($v_this, 'checkExpr', [z_index($v_e, 2)]);
    Z::$l = 198;
    if (z_truthy((z_index($v_e, 3) !== null))) {
      Z::$l = 198;
      f_zs_invoke($v_this, 'checkExpr', [z_index($v_e, 3)]);
    }
    Z::$l = 199;
    f_zs_invoke($v_this, 'checkExpr', [z_index($v_e, 4)]);
    Z::$l = 200;
    return null;
  }
  Z::$l = 202;
  if (z_truthy(($v_k === ':Call'))) {
    Z::$l = 202;
    f_zs_invoke($v_this, 'checkCall', [$v_e]);
    Z::$l = 202;
    return null;
  }
  Z::$l = 203;
  if (z_truthy(($v_k === ':New'))) {
    Z::$l = 203;
    f_zs_invoke($v_this, 'checkNew', [$v_e]);
    Z::$l = 203;
    return null;
  }
  Z::$l = 204;
  f_zs_invoke($v_this, 'err', [$v_line, 'E0102', z_concat(z_concat('wyrażenie ', z_b_substr($v_k, 1)), ' niedostępne w backendzie natywnym 0.0.1')]);
  return null;
}
function f_Lowerer__checkLvalue($v_this, $v_t) {
  Z::$l = 208;
  if (z_truthy((z_index($v_t, 0) === ':Var'))) {
    Z::$l = 208;
    return null;
  }
  Z::$l = 209;
  if (z_truthy((z_index($v_t, 0) === ':Index'))) {
    Z::$l = 209;
    f_zs_invoke($v_this, 'checkExpr', [z_index($v_t, 2)]);
    Z::$l = 209;
    if (z_truthy((z_index($v_t, 3) !== null))) {
      Z::$l = 209;
      f_zs_invoke($v_this, 'checkExpr', [z_index($v_t, 3)]);
    }
    Z::$l = 209;
    return null;
  }
  Z::$l = 210;
  f_zs_invoke($v_this, 'err', [z_index($v_t, 1), 'E0102', z_concat(z_concat('przypisanie do ', z_b_substr(z_index($v_t, 0), 1)), ' niedostępne w backendzie natywnym 0.0.1')]);
  return null;
}
function f_Lowerer__checkCall($v_this, $v_e) {
  $v_line = null;
  $v_callee = null;
  $v_args = null;
  $v_a = null;
  $v_n = null;
  $v_name = null;
  $v_f = null;
  $v_min = null;
  $v_p = null;
  $v_ar = null;
  $v_m = null;
  Z::$l = 214;
  ($v_line = z_index($v_e, 1));
  Z::$l = 215;
  ($v_callee = z_index($v_e, 2));
  Z::$l = 216;
  ($v_args = z_index($v_e, 3));
  Z::$l = 217;
  foreach (z_foreach($v_args) as $_k80 => $_v80) {
    $v_a = $_v80;
    Z::$l = 218;
    if (z_truthy((z_index($v_a, 2) !== null))) {
      Z::$l = 218;
      f_zs_invoke($v_this, 'err', [$v_line, 'E0104', 'argumenty nazwane niedostępne w backendzie natywnym 0.0.1']);
    }
    Z::$l = 219;
    if (z_truthy(z_index($v_a, 4))) {
      Z::$l = 219;
      f_zs_invoke($v_this, 'err', [$v_line, 'E0104', 'operator ... (spread) niedostępny w backendzie natywnym 0.0.1']);
    }
    Z::$l = 220;
    f_zs_invoke($v_this, 'checkExpr', [z_index($v_a, 3)]);
  }
  Z::$l = 222;
  ($v_n = z_b_count($v_args));
  Z::$l = 223;
  if (z_truthy((z_index($v_callee, 0) === ':Prop'))) {
    Z::$l = 224;
    if (z_truthy((z_truthy((z_index($v_callee, 3) === 'getMessage')) && z_truthy(($v_n === 0))))) {
      Z::$l = 224;
      f_zs_invoke($v_this, 'checkExpr', [z_index($v_callee, 2)]);
      Z::$l = 224;
      return null;
    }
    Z::$l = 225;
    f_zs_invoke($v_this, 'err', [$v_line, 'E0102', z_concat(z_concat('metoda `', z_index($v_callee, 3)), '` niedostępna w backendzie natywnym 0.0.1 (obsługiwane: getMessage na wyjątku)')]);
    Z::$l = 226;
    return null;
  }
  Z::$l = 228;
  ($v_name = f_zs_invoke($v_this, 'calleeName', [$v_callee]));
  Z::$l = 229;
  if (z_truthy(($v_name !== null))) {
    Z::$l = 230;
    if (z_truthy(z_b_has_key(z_b_zs_obj_get($v_this, 'funcs'), $v_name))) {
      Z::$l = 231;
      ($v_f = z_index(z_b_zs_obj_get($v_this, 'funcs'), $v_name));
      Z::$l = 232;
      ($v_min = 0);
      Z::$l = 233;
      foreach (z_foreach(z_index($v_f, 'params')) as $_k81 => $_v81) {
        $v_p = $_v81;
        Z::$l = 233;
        if (z_truthy((z_index($v_p, 4) === null))) {
          Z::$l = 233;
          z_last($_t18 = $v_min, $v_min = z_add($_t18, 1), $_t18);
        }
      }
      Z::$l = 234;
      if (z_truthy((z_truthy((z_cmp($v_n, $v_min) < 0)) || z_truthy((z_cmp($v_n, z_b_count(z_index($v_f, 'params'))) > 0))))) {
        Z::$l = 235;
        f_zs_invoke($v_this, 'err', [$v_line, 'E0104', z_concat(z_concat(z_concat(z_concat(z_concat('funkcja ', $v_name), ' oczekuje '), (z_truthy(($v_min === z_b_count(z_index($v_f, 'params')))) ? $v_min : z_concat(z_concat($v_min, '..'), z_b_count(z_index($v_f, 'params'))))), ' argumentów, podano '), $v_n)]);
      }
    } else {
      Z::$l = 237;
      if (z_truthy(z_b_has_key([z_k('count') => [1, 1], z_k('strlen') => [1, 1], z_k('typeof') => [1, 1], z_k('is_int') => [1, 1], z_k('is_float') => [1, 1], z_k('is_string') => [1, 1], z_k('is_bool') => [1, 1], z_k('is_array') => [1, 1], z_k('is_null') => [1, 1], z_k('strval') => [1, 1], z_k('boolval') => [1, 1], z_k('intval') => [1, 1], z_k('floatval') => [1, 1], z_k('ord') => [1, 1], z_k('chr') => [1, 1], z_k('contains') => [2, 2], z_k('starts_with') => [2, 2], z_k('ends_with') => [2, 2], z_k('index_of') => [2, 2], z_k('repeat') => [2, 2], z_k('substr') => [2, 3], z_k('trim') => [1, 1], z_k('join') => [2, 2], z_k('in_array') => [2, 2], z_k('range') => [2, 2], z_k('keys') => [1, 1], z_k('values') => [1, 1], z_k('has_key') => [2, 2], z_k('upper') => [1, 1], z_k('lower') => [1, 1], z_k('replace') => [3, 3], z_k('split') => [2, 2], z_k('chars') => [1, 1], z_k('pad_left') => [2, 3], z_k('pad_right') => [2, 3], z_k('to_hex') => [1, 1], z_k('is_digit') => [1, 1], z_k('is_alpha') => [1, 1], z_k('is_alnum') => [1, 1], z_k('is_space') => [1, 1], z_k('is_hex_digit') => [1, 1], z_k('array_slice') => [2, 3], z_k('reverse') => [1, 1], z_k('sort') => [1, 1], z_k('push') => [2, z_neg(1)], z_k('dump') => [1, z_neg(1)], z_k('read_line') => [0, 0], z_k('zs_obj_new') => [1, 1], z_k('zs_obj_class') => [1, 1], z_k('zs_obj_get') => [2, 2], z_k('zs_obj_take') => [2, 2], z_k('zs_obj_set') => [3, 3], z_k('zs_obj_put') => [3, 3], z_k('zs_no_method') => [2, 2], z_k('zs_no_class') => [1, 1], z_k('zs_mkfn') => [2, 2], z_k('zs_fn_id') => [1, 1], z_k('zs_fn_cap') => [1, 1], z_k('is_callable') => [1, 1], z_k('zs_sget') => [1, 1], z_k('zs_sset') => [2, 2], z_k('necho') => [1, z_neg(1)], z_k('eecho') => [0, z_neg(1)], z_k('exit') => [0, 1]], $v_name))) {
        Z::$l = 238;
        ($v_ar = z_index([z_k('count') => [1, 1], z_k('strlen') => [1, 1], z_k('typeof') => [1, 1], z_k('is_int') => [1, 1], z_k('is_float') => [1, 1], z_k('is_string') => [1, 1], z_k('is_bool') => [1, 1], z_k('is_array') => [1, 1], z_k('is_null') => [1, 1], z_k('strval') => [1, 1], z_k('boolval') => [1, 1], z_k('intval') => [1, 1], z_k('floatval') => [1, 1], z_k('ord') => [1, 1], z_k('chr') => [1, 1], z_k('contains') => [2, 2], z_k('starts_with') => [2, 2], z_k('ends_with') => [2, 2], z_k('index_of') => [2, 2], z_k('repeat') => [2, 2], z_k('substr') => [2, 3], z_k('trim') => [1, 1], z_k('join') => [2, 2], z_k('in_array') => [2, 2], z_k('range') => [2, 2], z_k('keys') => [1, 1], z_k('values') => [1, 1], z_k('has_key') => [2, 2], z_k('upper') => [1, 1], z_k('lower') => [1, 1], z_k('replace') => [3, 3], z_k('split') => [2, 2], z_k('chars') => [1, 1], z_k('pad_left') => [2, 3], z_k('pad_right') => [2, 3], z_k('to_hex') => [1, 1], z_k('is_digit') => [1, 1], z_k('is_alpha') => [1, 1], z_k('is_alnum') => [1, 1], z_k('is_space') => [1, 1], z_k('is_hex_digit') => [1, 1], z_k('array_slice') => [2, 3], z_k('reverse') => [1, 1], z_k('sort') => [1, 1], z_k('push') => [2, z_neg(1)], z_k('dump') => [1, z_neg(1)], z_k('read_line') => [0, 0], z_k('zs_obj_new') => [1, 1], z_k('zs_obj_class') => [1, 1], z_k('zs_obj_get') => [2, 2], z_k('zs_obj_take') => [2, 2], z_k('zs_obj_set') => [3, 3], z_k('zs_obj_put') => [3, 3], z_k('zs_no_method') => [2, 2], z_k('zs_no_class') => [1, 1], z_k('zs_mkfn') => [2, 2], z_k('zs_fn_id') => [1, 1], z_k('zs_fn_cap') => [1, 1], z_k('is_callable') => [1, 1], z_k('zs_sget') => [1, 1], z_k('zs_sset') => [2, 2], z_k('necho') => [1, z_neg(1)], z_k('eecho') => [0, z_neg(1)], z_k('exit') => [0, 1]], $v_name));
        Z::$l = 239;
        if (z_truthy((z_truthy((z_cmp($v_n, z_index($v_ar, 0)) < 0)) || z_truthy((z_truthy((z_cmp(z_index($v_ar, 1), 0) >= 0)) && z_truthy((z_cmp($v_n, z_index($v_ar, 1)) > 0))))))) {
          Z::$l = 239;
          f_zs_invoke($v_this, 'err', [$v_line, 'E0104', z_concat(z_concat(z_concat(z_concat('funkcja wbudowana ', $v_name), ': zła liczba argumentów ('), $v_n), ')')]);
        }
      } else {
        Z::$l = 241;
        f_zs_invoke($v_this, 'err', [$v_line, 'E0103', z_concat(z_concat('nieznana funkcja `', $v_name), '` (backend natywny 0.0.1 obsługuje funkcje użytkownika i podzbiór wbudowanych)')]);
      }
    }
    Z::$l = 243;
    return null;
  }
  Z::$l = 245;
  if (z_truthy((z_truthy((z_index($v_callee, 0) === ':Dot')) && z_truthy((z_index(z_index($v_callee, 2), 0) === ':Name'))))) {
    Z::$l = 246;
    ($v_m = z_index(z_index($v_callee, 2), 2));
    Z::$l = 247;
    ($v_f = z_index($v_callee, 3));
    Z::$l = 248;
    if (z_truthy((z_truthy(($v_m === 'Math')) && z_truthy(z_b_has_key([z_k('sqrt') => 1, z_k('floor') => 1, z_k('ceil') => 1, z_k('round') => 1, z_k('abs') => 1, z_k('min') => 2, z_k('max') => 2, z_k('pow') => 2], $v_f))))) {
      Z::$l = 249;
      if (z_truthy(($v_n !== z_index([z_k('sqrt') => 1, z_k('floor') => 1, z_k('ceil') => 1, z_k('round') => 1, z_k('abs') => 1, z_k('min') => 2, z_k('max') => 2, z_k('pow') => 2], $v_f)))) {
        Z::$l = 249;
        f_zs_invoke($v_this, 'err', [$v_line, 'E0104', z_concat(z_concat('Math.', $v_f), ': zła liczba argumentów')]);
      }
      Z::$l = 250;
      return null;
    }
    Z::$l = 252;
    if (z_truthy((z_truthy(z_b_has_key([z_k('System') => [z_k('args') => 0, z_k('env') => 1, z_k('os') => 0, z_k('architecture') => 0, z_k('time') => 0, z_k('cpuCount') => 0, z_k('dirname') => 1, z_k('resolveImport') => 2, z_k('version') => 0, z_k('exit') => z_neg(1), z_k('setEnv') => 2, z_k('unsetEnv') => 1, z_k('environ') => 0, z_k('cwd') => 0, z_k('chdir') => 1, z_k('pid') => 0, z_k('hostname') => 0, z_k('bytes') => 1, z_k('fromBytes') => 1, z_k('nowNanos') => 0, z_k('monotonic') => 0, z_k('sleep') => 1, z_k('localOffset') => 1, z_k('gc') => 0, z_k('gcStats') => 0], z_k('File') => [z_k('read') => 1, z_k('write') => 2, z_k('append') => 2, z_k('exists') => 1, z_k('delete') => 1, z_k('stat') => 1, z_k('rename') => 2, z_k('realpath') => 1, z_k('chmod') => 2, z_k('symlink') => 2, z_k('readlink') => 1], z_k('Directory') => [z_k('create') => 1, z_k('exists') => 1, z_k('list') => 1, z_k('remove') => 1], z_k('Process') => [z_k('run') => z_neg(1), z_k('exec') => z_neg(1)], z_k('Socket') => [z_k('tcpConnect') => 3, z_k('tcpListen') => 2, z_k('accept') => 1, z_k('read') => 2, z_k('write') => 2, z_k('close') => 1, z_k('setTimeout') => 2, z_k('udpBind') => 2, z_k('sendTo') => 4, z_k('recvFrom') => 2, z_k('resolve') => 1, z_k('localAddr') => 1, z_k('peerAddr') => 1]], $v_m)) && z_truthy(z_b_has_key(z_index([z_k('System') => [z_k('args') => 0, z_k('env') => 1, z_k('os') => 0, z_k('architecture') => 0, z_k('time') => 0, z_k('cpuCount') => 0, z_k('dirname') => 1, z_k('resolveImport') => 2, z_k('version') => 0, z_k('exit') => z_neg(1), z_k('setEnv') => 2, z_k('unsetEnv') => 1, z_k('environ') => 0, z_k('cwd') => 0, z_k('chdir') => 1, z_k('pid') => 0, z_k('hostname') => 0, z_k('bytes') => 1, z_k('fromBytes') => 1, z_k('nowNanos') => 0, z_k('monotonic') => 0, z_k('sleep') => 1, z_k('localOffset') => 1, z_k('gc') => 0, z_k('gcStats') => 0], z_k('File') => [z_k('read') => 1, z_k('write') => 2, z_k('append') => 2, z_k('exists') => 1, z_k('delete') => 1, z_k('stat') => 1, z_k('rename') => 2, z_k('realpath') => 1, z_k('chmod') => 2, z_k('symlink') => 2, z_k('readlink') => 1], z_k('Directory') => [z_k('create') => 1, z_k('exists') => 1, z_k('list') => 1, z_k('remove') => 1], z_k('Process') => [z_k('run') => z_neg(1), z_k('exec') => z_neg(1)], z_k('Socket') => [z_k('tcpConnect') => 3, z_k('tcpListen') => 2, z_k('accept') => 1, z_k('read') => 2, z_k('write') => 2, z_k('close') => 1, z_k('setTimeout') => 2, z_k('udpBind') => 2, z_k('sendTo') => 4, z_k('recvFrom') => 2, z_k('resolve') => 1, z_k('localAddr') => 1, z_k('peerAddr') => 1]], $v_m), $v_f))))) {
      Z::$l = 253;
      ($v_ar = z_index(z_index([z_k('System') => [z_k('args') => 0, z_k('env') => 1, z_k('os') => 0, z_k('architecture') => 0, z_k('time') => 0, z_k('cpuCount') => 0, z_k('dirname') => 1, z_k('resolveImport') => 2, z_k('version') => 0, z_k('exit') => z_neg(1), z_k('setEnv') => 2, z_k('unsetEnv') => 1, z_k('environ') => 0, z_k('cwd') => 0, z_k('chdir') => 1, z_k('pid') => 0, z_k('hostname') => 0, z_k('bytes') => 1, z_k('fromBytes') => 1, z_k('nowNanos') => 0, z_k('monotonic') => 0, z_k('sleep') => 1, z_k('localOffset') => 1, z_k('gc') => 0, z_k('gcStats') => 0], z_k('File') => [z_k('read') => 1, z_k('write') => 2, z_k('append') => 2, z_k('exists') => 1, z_k('delete') => 1, z_k('stat') => 1, z_k('rename') => 2, z_k('realpath') => 1, z_k('chmod') => 2, z_k('symlink') => 2, z_k('readlink') => 1], z_k('Directory') => [z_k('create') => 1, z_k('exists') => 1, z_k('list') => 1, z_k('remove') => 1], z_k('Process') => [z_k('run') => z_neg(1), z_k('exec') => z_neg(1)], z_k('Socket') => [z_k('tcpConnect') => 3, z_k('tcpListen') => 2, z_k('accept') => 1, z_k('read') => 2, z_k('write') => 2, z_k('close') => 1, z_k('setTimeout') => 2, z_k('udpBind') => 2, z_k('sendTo') => 4, z_k('recvFrom') => 2, z_k('resolve') => 1, z_k('localAddr') => 1, z_k('peerAddr') => 1]], $v_m), $v_f));
      Z::$l = 254;
      if (z_truthy((z_truthy((z_cmp($v_ar, 0) >= 0)) && z_truthy(($v_n !== $v_ar))))) {
        Z::$l = 254;
        f_zs_invoke($v_this, 'err', [$v_line, 'E0104', z_concat(z_concat(z_concat(z_concat(z_concat($v_m, '.'), $v_f), ': zła liczba argumentów ('), $v_n), ')')]);
      }
      Z::$l = 255;
      return null;
    }
    Z::$l = 257;
    f_zs_invoke($v_this, 'err', [$v_line, 'E0103', z_concat(z_concat(z_concat(z_concat('funkcja ', $v_m), '.'), $v_f), ' niedostępna w backendzie natywnym 0.0.1')]);
    Z::$l = 258;
    return null;
  }
  Z::$l = 260;
  f_zs_invoke($v_this, 'err', [$v_line, 'E0102', 'wywołanie wartości niedostępne w backendzie natywnym 0.0.1']);
  return null;
}
function f_Lowerer__topCallsMain($v_this, $v_x) {
  $v_i = null;
  $v_y = null;
  Z::$l = 264;
  if (z_truthy(f_Workspace_parser__isNode($v_x))) {
    Z::$l = 265;
    if (z_truthy((z_truthy((z_truthy((z_index($v_x, 0) === ':Call')) && z_truthy((z_index(z_index($v_x, 2), 0) === ':Name')))) && z_truthy((z_index(z_index($v_x, 2), 2) === 'main'))))) {
      Z::$l = 265;
      return true;
    }
    Z::$l = 266;
    if (z_truthy((z_index($v_x, 0) === ':FuncStmt'))) {
      Z::$l = 266;
      return false;
    }
    Z::$l = 267;
    ($v_i = 2);
    for (; z_truthy((z_cmp($v_i, z_b_count($v_x)) < 0)); z_last($_t19 = $v_i, $v_i = z_add($_t19, 1), $_t19)) {
      Z::$l = 267;
      if (z_truthy(f_zs_invoke($v_this, 'topCallsMain', [z_index($v_x, $v_i)]))) {
        Z::$l = 267;
        return true;
      }
    }
    Z::$l = 268;
    return false;
  }
  Z::$l = 270;
  if (z_truthy(z_b_is_array($v_x))) {
    Z::$l = 270;
    foreach (z_foreach($v_x) as $_k83 => $_v83) {
      $v_y = $_v83;
      Z::$l = 270;
      if (z_truthy(f_zs_invoke($v_this, 'topCallsMain', [$v_y]))) {
        Z::$l = 270;
        return true;
      }
    }
  }
  Z::$l = 271;
  return false;
  return null;
}
function f_Lowerer__new() {
  $v___o = null;
  Z::$l = 44;
  ($v___o = z_b_zs_obj_new('Lowerer'));
  Z::$l = 44;
  z_b_zs_obj_set($v___o, 'funcs', null);
  Z::$l = 44;
  z_b_zs_obj_set($v___o, 'order', null);
  Z::$l = 44;
  z_b_zs_obj_set($v___o, 'errors', null);
  Z::$l = 44;
  f_Lowerer____construct($v___o);
  Z::$l = 44;
  return $v___o;
  return null;
}
function f_Lifter__err($v_this, $v_line, $v_m) {
  $v___r78 = null;
  $v___w79 = null;
  Z::$l = 62;
  ($v___r78 = [$v_line, 'E0104', $v_m]);
  Z::$l = 62;
  ($v___w79 = z_b_zs_obj_take($v_this, 'errors'));
  Z::$l = 62;
  z_apush($v___w79, $v___r78);
  Z::$l = 62;
  z_b_zs_obj_put($v_this, 'errors', $v___w79);
  return null;
}
function f_Lifter__scan($v_this, $v_x) {
  $v_k = null;
  $v___k80 = null;
  $v___r81 = null;
  $v___w82 = null;
  $v_n = null;
  $v___k83 = null;
  $v___r84 = null;
  $v___w85 = null;
  $v___k86 = null;
  $v___r87 = null;
  $v___w88 = null;
  $v___k89 = null;
  $v___r90 = null;
  $v___w91 = null;
  $v___k92 = null;
  $v___r93 = null;
  $v___w94 = null;
  $v_v = null;
  Z::$l = 66;
  if (z_truthy(!z_truthy(z_b_is_array($v_x)))) {
    Z::$l = 66;
    return null;
  }
  Z::$l = 67;
  if (z_truthy(f_Workspace_parser__isNode($v_x))) {
    Z::$l = 68;
    ($v_k = z_index($v_x, 0));
    Z::$l = 69;
    if (z_truthy(($v_k === ':Var'))) {
      Z::$l = 69;
      ($v___k80 = z_index($v_x, 2));
      Z::$l = 69;
      ($v___r81 = true);
      Z::$l = 69;
      ($v___w82 = z_b_zs_obj_take($v_this, 'acc'));
      Z::$l = 69;
      z_aset($v___w82, $v___k80, $v___r81);
      Z::$l = 69;
      z_b_zs_obj_put($v_this, 'acc', $v___w82);
      Z::$l = 69;
      return null;
    }
    Z::$l = 70;
    if (z_truthy(($v_k === ':Closure'))) {
      Z::$l = 70;
      foreach (z_foreach(f_zs_invoke($v_this, 'freeOf', [z_index($v_x, 2)])) as $_k84 => $_v84) {
        $v_n = $_v84;
        Z::$l = 70;
        ($v___k83 = $v_n);
        Z::$l = 70;
        ($v___r84 = true);
        Z::$l = 70;
        ($v___w85 = z_b_zs_obj_take($v_this, 'acc'));
        Z::$l = 70;
        z_aset($v___w85, $v___k83, $v___r84);
        Z::$l = 70;
        z_b_zs_obj_put($v_this, 'acc', $v___w85);
      }
      Z::$l = 70;
      return null;
    }
    Z::$l = 71;
    if (z_truthy(($v_k === ':Foreach'))) {
      Z::$l = 72;
      if (z_truthy((z_index($v_x, 3) !== null))) {
        Z::$l = 72;
        ($v___k86 = z_index($v_x, 3));
        Z::$l = 72;
        ($v___r87 = true);
        Z::$l = 72;
        ($v___w88 = z_b_zs_obj_take($v_this, 'acc'));
        Z::$l = 72;
        z_aset($v___w88, $v___k86, $v___r87);
        Z::$l = 72;
        z_b_zs_obj_put($v_this, 'acc', $v___w88);
      }
      Z::$l = 73;
      if (z_truthy((z_index($v_x, 4) !== null))) {
        Z::$l = 73;
        ($v___k89 = z_index($v_x, 4));
        Z::$l = 73;
        ($v___r90 = true);
        Z::$l = 73;
        ($v___w91 = z_b_zs_obj_take($v_this, 'acc'));
        Z::$l = 73;
        z_aset($v___w91, $v___k89, $v___r90);
        Z::$l = 73;
        z_b_zs_obj_put($v_this, 'acc', $v___w91);
      }
    }
    Z::$l = 75;
    if (z_truthy((z_truthy(($v_k === ':Catch')) && z_truthy((z_index($v_x, 3) !== null))))) {
      Z::$l = 75;
      ($v___k92 = z_index($v_x, 3));
      Z::$l = 75;
      ($v___r93 = true);
      Z::$l = 75;
      ($v___w94 = z_b_zs_obj_take($v_this, 'acc'));
      Z::$l = 75;
      z_aset($v___w94, $v___k92, $v___r93);
      Z::$l = 75;
      z_b_zs_obj_put($v_this, 'acc', $v___w94);
    }
  }
  Z::$l = 77;
  foreach (z_foreach($v_x) as $_k85 => $_v85) {
    $v_v = $_v85;
    Z::$l = 77;
    f_zs_invoke($v_this, 'scan', [$v_v]);
  }
  return null;
}
function f_Lifter__names($v_this, $v_x) {
  $v_save = null;
  $v_r = null;
  Z::$l = 81;
  ($v_save = z_b_zs_obj_get($v_this, 'acc'));
  Z::$l = 82;
  z_b_zs_obj_set($v_this, 'acc', []);
  Z::$l = 83;
  f_zs_invoke($v_this, 'scan', [$v_x]);
  Z::$l = 84;
  ($v_r = z_b_zs_obj_get($v_this, 'acc'));
  Z::$l = 85;
  z_b_zs_obj_set($v_this, 'acc', $v_save);
  Z::$l = 86;
  return $v_r;
  return null;
}
function f_Lifter__freeOf($v_this, $v_f) {
  $v_r = null;
  $v_n = null;
  $v_t = null;
  $v_pn = null;
  $v_p = null;
  $v_out = null;
  Z::$l = 91;
  ($v_r = f_zs_invoke($v_this, 'names', [z_index($v_f, 5)]));
  Z::$l = 92;
  foreach (z_foreach(f_zs_invoke($v_this, 'names', [z_index($v_f, 3)])) as $_k86 => $_v86) {
    $v_t = $_v86;
    $v_n = $_k86;
    Z::$l = 92;
    z_aset($v_r, $v_n, true);
  }
  Z::$l = 93;
  ($v_pn = []);
  Z::$l = 94;
  foreach (z_foreach(z_index($v_f, 3)) as $_k87 => $_v87) {
    $v_p = $_v87;
    Z::$l = 94;
    z_aset($v_pn, z_index($v_p, 2), true);
  }
  Z::$l = 95;
  ($v_out = []);
  Z::$l = 96;
  foreach (z_foreach($v_r) as $_k88 => $_v88) {
    $v_t = $_v88;
    $v_n = $_k88;
    Z::$l = 96;
    if (z_truthy(!z_truthy(z_b_has_key($v_pn, $v_n)))) {
      Z::$l = 96;
      z_apush($v_out, $v_n);
    }
  }
  Z::$l = 97;
  return $v_out;
  return null;
}
function f_Lifter__lift($v_this, $v_x, $v_vis) {
  $v_f = null;
  $v_line = null;
  $v_cap = null;
  $v_n = null;
  $v_id = null;
  $v_vis2 = null;
  $v_p = null;
  $v_body = null;
  $v_s = null;
  $v_ps = null;
  $v_own = null;
  $v___k95 = null;
  $v___r96 = null;
  $v___w97 = null;
  $v___r98 = null;
  $v___w99 = null;
  $v_items = null;
  Z::$l = 101;
  ($v_f = z_index($v_x, 2));
  Z::$l = 102;
  ($v_line = z_index($v_x, 1));
  Z::$l = 103;
  ($v_cap = []);
  Z::$l = 104;
  foreach (z_foreach(f_zs_invoke($v_this, 'freeOf', [$v_f])) as $_k89 => $_v89) {
    $v_n = $_v89;
    Z::$l = 104;
    if (z_truthy(z_b_has_key($v_vis, $v_n))) {
      Z::$l = 104;
      z_apush($v_cap, $v_n);
    }
  }
  Z::$l = 105;
  ($v_id = z_b_zs_obj_get($v_this, 'n'));
  Z::$l = 106;
  z_b_zs_obj_set($v_this, 'n', z_add(z_b_zs_obj_get($v_this, 'n'), 1));
  Z::$l = 107;
  ($v_vis2 = f_zs_invoke($v_this, 'names', [z_index($v_f, 5)]));
  Z::$l = 108;
  foreach (z_foreach(z_index($v_f, 3)) as $_k90 => $_v90) {
    $v_p = $_v90;
    Z::$l = 108;
    z_aset($v_vis2, z_index($v_p, 2), true);
  }
  Z::$l = 109;
  foreach (z_foreach($v_cap) as $_k91 => $_v91) {
    $v_n = $_v91;
    Z::$l = 109;
    z_aset($v_vis2, $v_n, true);
  }
  Z::$l = 110;
  ($v_body = []);
  Z::$l = 111;
  foreach (z_foreach($v_cap) as $_k92 => $_v92) {
    $v_n = $_v92;
    Z::$l = 112;
    z_apush($v_body, [':Expr', $v_line, [':Assign', $v_line, f_Workspace_closures__var($v_line, $v_n), [':Index', $v_line, f_Workspace_closures__var($v_line, '__cap'), f_Workspace_closures__str($v_line, $v_n)]]]);
  }
  Z::$l = 114;
  foreach (z_foreach(z_index($v_f, 5)) as $_k93 => $_v93) {
    $v_s = $_v93;
    Z::$l = 114;
    z_apush($v_body, f_zs_invoke($v_this, 'rw', [$v_s, $v_vis2]));
  }
  Z::$l = 115;
  ($v_ps = [f_Workspace_closures__param('__cap')]);
  Z::$l = 116;
  ($v_own = []);
  Z::$l = 117;
  foreach (z_foreach(z_index($v_f, 3)) as $_k94 => $_v94) {
    $v_p = $_v94;
    Z::$l = 118;
    if (z_truthy((z_index($v_p, 4) !== null))) {
      Z::$l = 118;
      z_aset($v_p, 4, f_zs_invoke($v_this, 'rw', [z_index($v_p, 4), $v_vis2]));
    }
    Z::$l = 119;
    z_apush($v_ps, $v_p);
    Z::$l = 120;
    z_apush($v_own, $v_p);
  }
  Z::$l = 122;
  ($v___k95 = $v_id);
  Z::$l = 122;
  ($v___r96 = $v_own);
  Z::$l = 122;
  ($v___w97 = z_b_zs_obj_take($v_this, 'lams'));
  Z::$l = 122;
  z_aset($v___w97, $v___k95, $v___r96);
  Z::$l = 122;
  z_b_zs_obj_put($v_this, 'lams', $v___w97);
  Z::$l = 123;
  ($v___r98 = [':FuncStmt', $v_line, [':Func', $v_line, z_concat('__lam', $v_id), $v_ps, z_index($v_f, 4), $v_body, false]]);
  Z::$l = 123;
  ($v___w99 = z_b_zs_obj_take($v_this, 'out'));
  Z::$l = 123;
  z_apush($v___w99, $v___r98);
  Z::$l = 123;
  z_b_zs_obj_put($v_this, 'out', $v___w99);
  Z::$l = 124;
  ($v_items = []);
  Z::$l = 125;
  foreach (z_foreach($v_cap) as $_k95 => $_v95) {
    $v_n = $_v95;
    Z::$l = 125;
    z_apush($v_items, [':Item', 0, f_Workspace_closures__str($v_line, $v_n), f_Workspace_closures__var($v_line, $v_n)]);
  }
  Z::$l = 126;
  return f_Workspace_closures__call($v_line, 'zs_mkfn', [f_Workspace_closures__intl($v_line, $v_id), [':Array', $v_line, $v_items]]);
  return null;
}
function f_Lifter__rw($v_this, $v_x, $v_vis) {
  $v_o = null;
  $v_k = null;
  $v_v = null;
  $v___k100 = null;
  $v___r101 = null;
  $v___w102 = null;
  $v_i = null;
  Z::$l = 130;
  if (z_truthy(!z_truthy(z_b_is_array($v_x)))) {
    Z::$l = 130;
    return $v_x;
  }
  Z::$l = 131;
  if (z_truthy(!z_truthy(f_Workspace_parser__isNode($v_x)))) {
    Z::$l = 132;
    ($v_o = []);
    Z::$l = 133;
    foreach (z_foreach($v_x) as $_k96 => $_v96) {
      $v_v = $_v96;
      $v_k = $_k96;
      Z::$l = 133;
      z_aset($v_o, $v_k, f_zs_invoke($v_this, 'rw', [$v_v, $v_vis]));
    }
    Z::$l = 134;
    return $v_o;
  }
  Z::$l = 136;
  ($v_k = z_index($v_x, 0));
  Z::$l = 137;
  if (z_truthy(($v_k === ':Closure'))) {
    Z::$l = 137;
    return f_zs_invoke($v_this, 'lift', [$v_x, $v_vis]);
  }
  Z::$l = 138;
  if (z_truthy(($v_k === ':Call'))) {
    Z::$l = 138;
    return f_zs_invoke($v_this, 'rwCall', [$v_x, $v_vis]);
  }
  Z::$l = 139;
  if (z_truthy((z_truthy(($v_k === ':Str')) && z_truthy(z_b_has_key(z_b_zs_obj_get($v_this, 'fnp'), z_index($v_x, 2)))))) {
    Z::$l = 139;
    ($v___k100 = z_index($v_x, 2));
    Z::$l = 139;
    ($v___r101 = true);
    Z::$l = 139;
    ($v___w102 = z_b_zs_obj_take($v_this, 'named'));
    Z::$l = 139;
    z_aset($v___w102, $v___k100, $v___r101);
    Z::$l = 139;
    z_b_zs_obj_put($v_this, 'named', $v___w102);
  }
  Z::$l = 140;
  ($v_o = []);
  Z::$l = 141;
  foreach (z_foreach($v_x) as $_k97 => $_v97) {
    $v_v = $_v97;
    $v_i = $_k97;
    Z::$l = 141;
    z_aset($v_o, $v_i, (z_truthy((z_cmp($v_i, 2) < 0)) ? $v_v : f_zs_invoke($v_this, 'rw', [$v_v, $v_vis])));
  }
  Z::$l = 142;
  return $v_o;
  return null;
}
function f_Lifter__argsArray($v_this, $v_line, $v_args, $v_vis) {
  $v_cur = null;
  $v_items = null;
  $v_a = null;
  $v_v = null;
  $v_seg = null;
  Z::$l = 147;
  ($v_cur = null);
  Z::$l = 148;
  ($v_items = []);
  Z::$l = 149;
  foreach (z_foreach($v_args) as $_k98 => $_v98) {
    $v_a = $_v98;
    Z::$l = 150;
    ($v_v = f_zs_invoke($v_this, 'rw', [z_index($v_a, 3), $v_vis]));
    Z::$l = 151;
    if (z_truthy(z_index($v_a, 4))) {
      Z::$l = 152;
      ($v_seg = [':Array', $v_line, $v_items]);
      Z::$l = 153;
      ($v_cur = (z_truthy(($v_cur === null)) ? $v_seg : f_Workspace_closures__call($v_line, 'zs_spread', [$v_cur, $v_seg])));
      Z::$l = 154;
      ($v_cur = f_Workspace_closures__call($v_line, 'zs_spread', [$v_cur, $v_v]));
      Z::$l = 155;
      ($v_items = []);
      Z::$l = 156;
      z_b_zs_obj_set($v_this, 'usesSpread', true);
    } else {
      Z::$l = 157;
      if (z_truthy((z_index($v_a, 2) !== null))) {
        Z::$l = 158;
        z_apush($v_items, [':Item', 0, f_Workspace_closures__str($v_line, z_index($v_a, 2)), $v_v]);
      } else {
        Z::$l = 160;
        z_apush($v_items, [':Item', 0, null, $v_v]);
      }
    }
  }
  Z::$l = 163;
  if (z_truthy(($v_cur === null))) {
    Z::$l = 163;
    return [':Array', $v_line, $v_items];
  }
  Z::$l = 164;
  if (z_truthy((z_cmp(z_b_count($v_items), 0) > 0))) {
    Z::$l = 164;
    ($v_cur = f_Workspace_closures__call($v_line, 'zs_spread', [$v_cur, [':Array', $v_line, $v_items]]));
  }
  Z::$l = 165;
  return $v_cur;
  return null;
}
function f_Lifter__rwCall($v_this, $v_x, $v_vis) {
  $v_line = null;
  $v_callee = null;
  $v_args = null;
  $v_spread = null;
  $v_namedArg = null;
  $v_a = null;
  $v_kind = null;
  $v_n = null;
  $v___k103 = null;
  $v___r104 = null;
  $v___w105 = null;
  Z::$l = 169;
  ($v_line = z_index($v_x, 1));
  Z::$l = 170;
  ($v_callee = z_index($v_x, 2));
  Z::$l = 171;
  ($v_args = z_index($v_x, 3));
  Z::$l = 172;
  ($v_spread = false);
  Z::$l = 173;
  ($v_namedArg = false);
  Z::$l = 174;
  foreach (z_foreach($v_args) as $_k99 => $_v99) {
    $v_a = $_v99;
    Z::$l = 174;
    if (z_truthy(z_index($v_a, 4))) {
      Z::$l = 174;
      ($v_spread = true);
    }
    Z::$l = 174;
    if (z_truthy((z_index($v_a, 2) !== null))) {
      Z::$l = 174;
      ($v_namedArg = true);
    }
  }
  Z::$l = 175;
  ($v_kind = z_index($v_callee, 0));
  Z::$l = 176;
  if (z_truthy(($v_kind === ':Name'))) {
    Z::$l = 177;
    ($v_n = z_index($v_callee, 2));
    Z::$l = 178;
    if (z_truthy((z_truthy(z_b_has_key(z_b_zs_obj_get($v_this, 'fnp'), $v_n)) && z_truthy((z_truthy($v_spread) || z_truthy($v_namedArg)))))) {
      Z::$l = 179;
      if (z_truthy($v_spread)) {
        Z::$l = 180;
        ($v___k103 = $v_n);
        Z::$l = 180;
        ($v___r104 = true);
        Z::$l = 180;
        ($v___w105 = z_b_zs_obj_take($v_this, 'named'));
        Z::$l = 180;
        z_aset($v___w105, $v___k103, $v___r104);
        Z::$l = 180;
        z_b_zs_obj_put($v_this, 'named', $v___w105);
        Z::$l = 181;
        z_b_zs_obj_set($v_this, 'dyn', true);
        Z::$l = 182;
        return f_Workspace_closures__call($v_line, 'zs_call', [f_Workspace_closures__str($v_line, $v_n), f_zs_invoke($v_this, 'argsArray', [$v_line, $v_args, $v_vis])]);
      }
      Z::$l = 184;
      return f_zs_invoke($v_this, 'reorder', [$v_x, $v_vis]);
    }
    Z::$l = 186;
    if (z_truthy((z_truthy($v_spread) || z_truthy($v_namedArg)))) {
      Z::$l = 187;
      f_zs_invoke($v_this, 'err', [$v_line, z_concat(z_concat('argumenty nazwane i rozwinięcie ... niedostępne dla funkcji wbudowanych (', $v_n), ')')]);
    }
    Z::$l = 189;
    if (z_truthy((z_truthy((z_truthy(($v_n === 'zs_spread')) || z_truthy(($v_n === 'zs_arg_missing')))) || z_truthy(($v_n === 'zs_call'))))) {
      Z::$l = 189;
      z_b_zs_obj_set($v_this, 'sawHelper', true);
    }
    Z::$l = 190;
    return f_zs_invoke($v_this, 'plain', [$v_x, $v_vis]);
  }
  Z::$l = 192;
  if (z_truthy((z_truthy(($v_kind === ':Dot')) || z_truthy(($v_kind === ':Prop'))))) {
    Z::$l = 193;
    if (z_truthy((z_truthy($v_spread) || z_truthy($v_namedArg)))) {
      Z::$l = 193;
      f_zs_invoke($v_this, 'err', [$v_line, 'argumenty nazwane i rozwinięcie ... niedostępne dla wywołań modułów wbudowanych']);
    }
    Z::$l = 194;
    return f_zs_invoke($v_this, 'plain', [$v_x, $v_vis]);
  }
  Z::$l = 197;
  z_b_zs_obj_set($v_this, 'dyn', true);
  Z::$l = 198;
  return f_Workspace_closures__call($v_line, 'zs_call', [f_zs_invoke($v_this, 'rw', [$v_callee, $v_vis]), f_zs_invoke($v_this, 'argsArray', [$v_line, $v_args, $v_vis])]);
  return null;
}
function f_Lifter__plain($v_this, $v_x, $v_vis) {
  $v_o = null;
  $v_a = null;
  Z::$l = 202;
  ($v_o = [':Call', z_index($v_x, 1), f_zs_invoke($v_this, 'rw', [z_index($v_x, 2), $v_vis]), []]);
  Z::$l = 203;
  foreach (z_foreach(z_index($v_x, 3)) as $_k100 => $_v100) {
    $v_a = $_v100;
    Z::$l = 203;
    z_aset($v_a, 3, f_zs_invoke($v_this, 'rw', [z_index($v_a, 3), $v_vis]));
    Z::$l = 203;
    z_apush($v_o[z_k(3)], $v_a);
  }
  Z::$l = 204;
  return $v_o;
  return null;
}
function f_Lifter__reorder($v_this, $v_x, $v_vis) {
  $v_line = null;
  $v_n = null;
  $v_ps = null;
  $v_slots = null;
  $v_pos = null;
  $v_maxi = null;
  $v_a = null;
  $v_v = null;
  $v_j = null;
  $v_i = null;
  $v_out = null;
  $v_pn = null;
  Z::$l = 209;
  ($v_line = z_index($v_x, 1));
  Z::$l = 210;
  ($v_n = z_index(z_index($v_x, 2), 2));
  Z::$l = 211;
  ($v_ps = z_index(z_b_zs_obj_get($v_this, 'fnp'), $v_n));
  Z::$l = 212;
  ($v_slots = []);
  Z::$l = 213;
  ($v_pos = 0);
  Z::$l = 214;
  ($v_maxi = z_neg(1));
  Z::$l = 215;
  foreach (z_foreach(z_index($v_x, 3)) as $_k101 => $_v101) {
    $v_a = $_v101;
    Z::$l = 216;
    ($v_v = f_zs_invoke($v_this, 'rw', [z_index($v_a, 3), $v_vis]));
    Z::$l = 217;
    if (z_truthy((z_index($v_a, 2) === null))) {
      Z::$l = 218;
      z_aset($v_slots, $v_pos, $v_v);
      Z::$l = 219;
      if (z_truthy((z_cmp($v_pos, $v_maxi) > 0))) {
        Z::$l = 219;
        ($v_maxi = $v_pos);
      }
      Z::$l = 220;
      z_last($_t20 = $v_pos, $v_pos = z_add($_t20, 1), $_t20);
      continue 1;
    }
    Z::$l = 223;
    ($v_j = z_neg(1));
    Z::$l = 224;
    ($v_i = 0);
    for (; z_truthy((z_cmp($v_i, z_b_count($v_ps)) < 0)); z_last($_t21 = $v_i, $v_i = z_add($_t21, 1), $_t21)) {
      Z::$l = 224;
      if (z_truthy((z_truthy((z_index(z_index($v_ps, $v_i), 2) === z_index($v_a, 2))) && z_truthy(!z_truthy(z_index(z_index($v_ps, $v_i), 5)))))) {
        Z::$l = 224;
        ($v_j = $v_i);
      }
    }
    Z::$l = 225;
    if (z_truthy((z_cmp($v_j, 0) < 0))) {
      Z::$l = 225;
      f_zs_invoke($v_this, 'err', [$v_line, z_concat(z_concat(z_concat($v_n, ': nieznany argument nazwany `'), z_index($v_a, 2)), '`')]);
      Z::$l = 225;
      return $v_x;
    }
    Z::$l = 226;
    if (z_truthy(z_b_has_key($v_slots, $v_j))) {
      Z::$l = 226;
      f_zs_invoke($v_this, 'err', [$v_line, z_concat(z_concat(z_concat($v_n, ': argument `'), z_index($v_a, 2)), '` podany dwukrotnie')]);
      Z::$l = 226;
      return $v_x;
    }
    Z::$l = 227;
    z_aset($v_slots, $v_j, $v_v);
    Z::$l = 228;
    if (z_truthy((z_cmp($v_j, $v_maxi) > 0))) {
      Z::$l = 228;
      ($v_maxi = $v_j);
    }
  }
  Z::$l = 230;
  ($v_out = []);
  Z::$l = 231;
  ($v_i = 0);
  for (; z_truthy((z_cmp($v_i, $v_maxi) <= 0)); z_last($_t22 = $v_i, $v_i = z_add($_t22, 1), $_t22)) {
    Z::$l = 232;
    if (z_truthy(z_b_has_key($v_slots, $v_i))) {
      Z::$l = 232;
      z_apush($v_out, f_Workspace_closures__arg(z_index($v_slots, $v_i)));
      continue 1;
    }
    Z::$l = 233;
    if (z_truthy((z_truthy((z_cmp($v_i, z_b_count($v_ps)) < 0)) && z_truthy((z_index(z_index($v_ps, $v_i), 4) !== null))))) {
      Z::$l = 233;
      z_apush($v_out, f_Workspace_closures__arg(f_zs_invoke($v_this, 'rw', [z_index(z_index($v_ps, $v_i), 4), $v_vis])));
      continue 1;
    }
    Z::$l = 234;
    ($v_pn = (z_truthy((z_cmp($v_i, z_b_count($v_ps)) < 0)) ? z_index(z_index($v_ps, $v_i), 2) : '?'));
    Z::$l = 235;
    f_zs_invoke($v_this, 'err', [$v_line, z_concat(z_concat($v_n, ': brak argumentu $'), $v_pn)]);
    Z::$l = 236;
    return $v_x;
  }
  Z::$l = 238;
  return [':Call', $v_line, z_index($v_x, 2), $v_out];
  return null;
}
function f_Lifter__helpers($v_this) {
  $v_line = null;
  $v_out = null;
  $v_src = null;
  $v_s = null;
  Z::$l = 242;
  ($v_line = 0);
  Z::$l = 243;
  ($v_out = []);
  Z::$l = 244;
  if (z_truthy((z_truthy((z_truthy((z_cmp(z_b_zs_obj_get($v_this, 'n'), 0) > 0)) || z_truthy(z_b_zs_obj_get($v_this, 'dyn')))) || z_truthy((z_cmp(z_b_count(z_b_zs_obj_get($v_this, 'named')), 0) > 0))))) {
    Z::$l = 244;
    z_apush($v_out, f_zs_invoke($v_this, 'dispatcher', []));
  }
  Z::$l = 245;
  ($v_src = z_concat(z_concat('func zs_arg_missing($f, $p) { throw new Error($f . ": brak argumentu $" . $p); } ', 'func zs_not_callable($f) { throw new Error("wartość typu " . typeof($f) . " nie jest wywoływalna"); } '), 'func zs_spread($a, $b) { foreach ($b as $k => $v) { if (is_int($k)) { $a[] = $v; } else { $a[$k] = $v; } } return $a; }'));
  Z::$l = 248;
  foreach (z_foreach(f_Workspace_parser__parse($v_src)) as $_k104 => $_v104) {
    $v_s = $_v104;
    Z::$l = 248;
    z_apush($v_out, $v_s);
  }
  Z::$l = 249;
  return $v_out;
  return null;
}
function f_Lifter__dispatcher($v_this) {
  $v_line = null;
  $v_body = null;
  $v_id = null;
  $v_ps = null;
  $v_args = null;
  $v_fname = null;
  $v_t = null;
  Z::$l = 253;
  ($v_line = 0);
  Z::$l = 254;
  ($v_body = []);
  Z::$l = 255;
  z_apush($v_body, [':Expr', $v_line, [':Assign', $v_line, f_Workspace_closures__var($v_line, 'id'), f_Workspace_closures__call($v_line, 'zs_fn_id', [f_Workspace_closures__var($v_line, 'f')])]]);
  Z::$l = 256;
  z_apush($v_body, [':Expr', $v_line, [':Assign', $v_line, f_Workspace_closures__var($v_line, 'cap'), f_Workspace_closures__call($v_line, 'zs_fn_cap', [f_Workspace_closures__var($v_line, 'f')])]]);
  Z::$l = 257;
  foreach (z_foreach(z_b_zs_obj_get($v_this, 'lams')) as $_k105 => $_v105) {
    $v_ps = $_v105;
    $v_id = $_k105;
    Z::$l = 258;
    ($v_args = f_Workspace_closures__prepend(f_Workspace_closures__arg(f_Workspace_closures__var($v_line, 'cap')), f_Workspace_closures__bindArgs($v_line, $v_ps, 'args', '{closure}')));
    Z::$l = 259;
    z_apush($v_body, [':If', $v_line, [':Binary', $v_line, 'Identical', f_Workspace_closures__var($v_line, 'id'), f_Workspace_closures__intl($v_line, $v_id)], [[':Return', $v_line, [':Call', $v_line, f_Workspace_closures__nm($v_line, z_concat('__lam', $v_id)), $v_args]]], null]);
  }
  Z::$l = 262;
  foreach (z_foreach(z_b_zs_obj_get($v_this, 'named')) as $_k106 => $_v106) {
    $v_t = $_v106;
    $v_fname = $_k106;
    Z::$l = 263;
    z_apush($v_body, [':If', $v_line, [':Binary', $v_line, 'Identical', f_Workspace_closures__var($v_line, 'id'), f_Workspace_closures__str($v_line, $v_fname)], [[':Return', $v_line, [':Call', $v_line, f_Workspace_closures__nm($v_line, $v_fname), f_Workspace_closures__bindArgs($v_line, z_index(z_b_zs_obj_get($v_this, 'fnp'), $v_fname), 'args', $v_fname)]]], null]);
  }
  Z::$l = 266;
  z_apush($v_body, [':Return', $v_line, f_Workspace_closures__call($v_line, 'zs_not_callable', [f_Workspace_closures__var($v_line, 'f')])]);
  Z::$l = 267;
  return [':FuncStmt', $v_line, [':Func', $v_line, 'zs_call', [f_Workspace_closures__param('f'), f_Workspace_closures__param('args')], [], $v_body, false]];
  return null;
}
function f_Lifter__new() {
  $v___o = null;
  Z::$l = 50;
  ($v___o = z_b_zs_obj_new('Lifter'));
  Z::$l = 50;
  z_b_zs_obj_set($v___o, 'n', 0);
  Z::$l = 50;
  z_b_zs_obj_set($v___o, 'out', []);
  Z::$l = 50;
  z_b_zs_obj_set($v___o, 'lams', []);
  Z::$l = 50;
  z_b_zs_obj_set($v___o, 'fnp', []);
  Z::$l = 50;
  z_b_zs_obj_set($v___o, 'named', []);
  Z::$l = 50;
  z_b_zs_obj_set($v___o, 'dyn', false);
  Z::$l = 50;
  z_b_zs_obj_set($v___o, 'usesSpread', false);
  Z::$l = 50;
  z_b_zs_obj_set($v___o, 'sawHelper', false);
  Z::$l = 50;
  z_b_zs_obj_set($v___o, 'errors', []);
  Z::$l = 50;
  z_b_zs_obj_set($v___o, 'acc', []);
  Z::$l = 50;
  return $v___o;
  return null;
}
function f_Cls__new() {
  $v___o = null;
  Z::$l = 20;
  ($v___o = z_b_zs_obj_new('Cls'));
  Z::$l = 20;
  z_b_zs_obj_set($v___o, 'name', null);
  Z::$l = 20;
  z_b_zs_obj_set($v___o, 'parent', null);
  Z::$l = 20;
  z_b_zs_obj_set($v___o, 'ifaces', null);
  Z::$l = 20;
  z_b_zs_obj_set($v___o, 'line', null);
  Z::$l = 20;
  z_b_zs_obj_set($v___o, 'props', []);
  Z::$l = 20;
  z_b_zs_obj_set($v___o, 'consts', []);
  Z::$l = 20;
  z_b_zs_obj_set($v___o, 'methods', []);
  Z::$l = 20;
  return $v___o;
  return null;
}
function f_Desugar__err($v_this, $v_line, $v_msg) {
  $v___r106 = null;
  $v___w107 = null;
  Z::$l = 38;
  ($v___r106 = [$v_line, 'E0108', $v_msg]);
  Z::$l = 38;
  ($v___w107 = z_b_zs_obj_take($v_this, 'errors'));
  Z::$l = 38;
  z_apush($v___w107, $v___r106);
  Z::$l = 38;
  z_b_zs_obj_put($v_this, 'errors', $v___w107);
  return null;
}
function f_Desugar__node($v_this, $v_k, $v_line, $v_a, $v_b, $v_c, $v_d) {
  Z::$l = 40;
  return [z_concat(':', $v_k), $v_line, $v_a, $v_b, $v_c, $v_d];
  return null;
}
function f_Desugar__nm($v_this, $v_line, $v_n) {
  Z::$l = 41;
  return [':Name', $v_line, $v_n];
  return null;
}
function f_Desugar__mkstr($v_this, $v_line, $v_s) {
  Z::$l = 42;
  return [':Str', $v_line, $v_s];
  return null;
}
function f_Desugar__mkvar($v_this, $v_line, $v_n) {
  Z::$l = 43;
  return [':Var', $v_line, $v_n];
  return null;
}
function f_Desugar__call($v_this, $v_line, $v_fn, $v_args) {
  $v_as = null;
  $v_a = null;
  Z::$l = 45;
  ($v_as = []);
  Z::$l = 46;
  foreach (z_foreach($v_args) as $_k107 => $_v107) {
    $v_a = $_v107;
    Z::$l = 46;
    z_apush($v_as, [':Arg', 0, null, $v_a, false]);
  }
  Z::$l = 47;
  return [':Call', $v_line, f_zs_invoke($v_this, 'nm', [$v_line, $v_fn]), $v_as];
  return null;
}
function f_Desugar__fresh($v_this, $v_p) {
  Z::$l = 49;
  z_b_zs_obj_set($v_this, 'tmp', z_add(z_b_zs_obj_get($v_this, 'tmp'), 1));
  Z::$l = 49;
  return z_concat(z_concat('__', $v_p), z_b_zs_obj_get($v_this, 'tmp'));
  return null;
}
function f_Desugar__collect($v_this, $v_ast) {
  $v_s = null;
  $v_c = null;
  $v_k = null;
  $v_p = null;
  $v___k108 = null;
  $v___r109 = null;
  $v___w110 = null;
  $v_cn = null;
  $v___k111 = null;
  $v___r112 = null;
  $v___w113 = null;
  $v_m = null;
  $v___k114 = null;
  $v___r115 = null;
  $v___w116 = null;
  $v___k117 = null;
  $v___r118 = null;
  $v___w119 = null;
  Z::$l = 53;
  foreach (z_foreach($v_ast) as $_k108 => $_v108) {
    $v_s = $_v108;
    Z::$l = 54;
    if (z_truthy((z_index($v_s, 0) !== ':ClassStmt'))) {
      continue 1;
    }
    Z::$l = 55;
    ($v_c = z_index($v_s, 2));
    Z::$l = 56;
    ($v_k = f_Cls__new());
    Z::$l = 57;
    z_b_zs_obj_set($v_k, 'name', z_index($v_c, 2));
    Z::$l = 57;
    z_b_zs_obj_set($v_k, 'parent', z_index($v_c, 3));
    Z::$l = 57;
    z_b_zs_obj_set($v_k, 'ifaces', z_index($v_c, 4));
    Z::$l = 57;
    z_b_zs_obj_set($v_k, 'line', z_index($v_s, 1));
    Z::$l = 58;
    foreach (z_foreach(z_index($v_c, 7)) as $_k109 => $_v109) {
      $v_p = $_v109;
      Z::$l = 58;
      ($v___k108 = z_index($v_p, 2));
      Z::$l = 58;
      ($v___r109 = [z_k('default') => z_index($v_p, 3), z_k('static') => z_index($v_p, 4)]);
      Z::$l = 58;
      ($v___w110 = z_b_zs_obj_take($v_k, 'props'));
      Z::$l = 58;
      z_aset($v___w110, $v___k108, $v___r109);
      Z::$l = 58;
      z_b_zs_obj_put($v_k, 'props', $v___w110);
    }
    Z::$l = 59;
    foreach (z_foreach(z_index($v_c, 8)) as $_k110 => $_v110) {
      $v_cn = $_v110;
      Z::$l = 59;
      ($v___k111 = z_index($v_cn, 2));
      Z::$l = 59;
      ($v___r112 = z_index($v_cn, 3));
      Z::$l = 59;
      ($v___w113 = z_b_zs_obj_take($v_k, 'consts'));
      Z::$l = 59;
      z_aset($v___w113, $v___k111, $v___r112);
      Z::$l = 59;
      z_b_zs_obj_put($v_k, 'consts', $v___w113);
    }
    Z::$l = 60;
    foreach (z_foreach(z_index($v_c, 9)) as $_k111 => $_v111) {
      $v_m = $_v111;
      Z::$l = 60;
      ($v___k114 = z_index(z_index($v_m, 2), 2));
      Z::$l = 60;
      ($v___r115 = [z_k('decl') => z_index($v_m, 2), z_k('static') => z_index($v_m, 3), z_k('abstract') => z_index($v_m, 4)]);
      Z::$l = 60;
      ($v___w116 = z_b_zs_obj_take($v_k, 'methods'));
      Z::$l = 60;
      z_aset($v___w116, $v___k114, $v___r115);
      Z::$l = 60;
      z_b_zs_obj_put($v_k, 'methods', $v___w116);
    }
    Z::$l = 61;
    if (z_truthy(z_b_has_key(z_b_zs_obj_get($v_this, 'classes'), z_b_zs_obj_get($v_k, 'name')))) {
      Z::$l = 61;
      f_zs_invoke($v_this, 'err', [z_index($v_s, 1), z_concat(z_concat('klasa ', z_b_zs_obj_get($v_k, 'name')), ' zdefiniowana wielokrotnie')]);
    }
    Z::$l = 62;
    ($v___k117 = z_b_zs_obj_get($v_k, 'name'));
    Z::$l = 62;
    ($v___r118 = $v_k);
    Z::$l = 62;
    ($v___w119 = z_b_zs_obj_take($v_this, 'classes'));
    Z::$l = 62;
    z_aset($v___w119, $v___k117, $v___r118);
    Z::$l = 62;
    z_b_zs_obj_put($v_this, 'classes', $v___w119);
  }
  return null;
}
function f_Desugar__chain($v_this, $v_name) {
  $v_out = null;
  $v_n = null;
  Z::$l = 67;
  ($v_out = []);
  Z::$l = 68;
  ($v_n = $v_name);
  while (true) {
    Z::$l = 69;
    if (!z_truthy((z_truthy((z_truthy(($v_n !== null)) && z_truthy(z_b_has_key(z_b_zs_obj_get($v_this, 'classes'), $v_n)))) && z_truthy((z_cmp(z_b_count($v_out), 64) < 0))))) break;
    Z::$l = 69;
    z_apush($v_out, $v_n);
    Z::$l = 69;
    ($v_n = z_b_zs_obj_get(z_index(z_b_zs_obj_get($v_this, 'classes'), $v_n), 'parent'));
  }
  Z::$l = 70;
  return $v_out;
  return null;
}
function f_Desugar__owner($v_this, $v_cls, $v_m) {
  $v_n = null;
  Z::$l = 75;
  foreach (z_foreach(f_zs_invoke($v_this, 'chain', [$v_cls])) as $_k113 => $_v113) {
    $v_n = $_v113;
    Z::$l = 76;
    if (z_truthy((z_truthy(z_b_has_key(z_b_zs_obj_get(z_index(z_b_zs_obj_get($v_this, 'classes'), $v_n), 'methods'), $v_m)) && z_truthy(!z_truthy(z_index(z_index(z_b_zs_obj_get(z_index(z_b_zs_obj_get($v_this, 'classes'), $v_n), 'methods'), $v_m), 'abstract')))))) {
      Z::$l = 76;
      return $v_n;
    }
  }
  Z::$l = 78;
  return null;
  return null;
}
function f_Desugar__allProps($v_this, $v_cls) {
  $v_names = null;
  $v_out = null;
  $v_n = null;
  $v_p = null;
  $v_d = null;
  Z::$l = 82;
  ($v_names = f_Workspace_classes__array_reverse_names(f_zs_invoke($v_this, 'chain', [$v_cls])));
  Z::$l = 83;
  ($v_out = []);
  Z::$l = 84;
  foreach (z_foreach($v_names) as $_k114 => $_v114) {
    $v_n = $_v114;
    Z::$l = 85;
    foreach (z_foreach(z_b_zs_obj_get(z_index(z_b_zs_obj_get($v_this, 'classes'), $v_n), 'props')) as $_k115 => $_v115) {
      $v_d = $_v115;
      $v_p = $_k115;
      Z::$l = 86;
      if (z_truthy(z_index($v_d, 'static'))) {
        continue 1;
      }
      Z::$l = 87;
      if (z_truthy(!z_truthy(z_b_has_key($v_out, $v_p)))) {
        Z::$l = 87;
        z_aset($v_out, $v_p, [z_k('default') => z_index($v_d, 'default'), z_k('cls') => $v_n]);
      } else {
        Z::$l = 88;
        z_aset($v_out, $v_p, [z_k('default') => (($_t23 = z_indexopt($v_d, 'default')) !== null ? $_t23 : z_index(z_index($v_out, $v_p), 'default')), z_k('cls') => $v_n]);
      }
    }
  }
  Z::$l = 91;
  return $v_out;
  return null;
}
function f_Desugar__isaNames($v_this, $v_cls) {
  $v_out = null;
  $v_stack = null;
  $v_n = null;
  $v_c = null;
  $v_i = null;
  Z::$l = 95;
  ($v_out = []);
  Z::$l = 96;
  ($v_stack = [$v_cls]);
  while (true) {
    Z::$l = 97;
    if (!z_truthy((z_cmp(z_b_count($v_stack), 0) > 0))) break;
    Z::$l = 98;
    ($v_n = z_index($v_stack, z_sub(z_b_count($v_stack), 1)));
    Z::$l = 99;
    ($v_stack = z_b_array_slice($v_stack, 0, z_sub(z_b_count($v_stack), 1)));
    Z::$l = 100;
    if (z_truthy(z_b_in_array($v_n, $v_out))) {
      continue 1;
    }
    Z::$l = 101;
    z_apush($v_out, $v_n);
    Z::$l = 102;
    if (z_truthy(($v_n === 'Exception'))) {
      Z::$l = 102;
      z_apush($v_out, 'Throwable');
    }
    Z::$l = 103;
    if (z_truthy(z_b_has_key(z_b_zs_obj_get($v_this, 'classes'), $v_n))) {
      Z::$l = 104;
      ($v_c = z_index(z_b_zs_obj_get($v_this, 'classes'), $v_n));
      Z::$l = 105;
      if (z_truthy((z_b_zs_obj_get($v_c, 'parent') !== null))) {
        Z::$l = 105;
        z_apush($v_stack, z_b_zs_obj_get($v_c, 'parent'));
      }
      Z::$l = 106;
      foreach (z_foreach(z_b_zs_obj_get($v_c, 'ifaces')) as $_k117 => $_v117) {
        $v_i = $_v117;
        Z::$l = 106;
        z_apush($v_stack, $v_i);
      }
    }
  }
  Z::$l = 109;
  return $v_out;
  return null;
}
function f_Desugar__rwList($v_this, $v_xs) {
  $v_o = null;
  $v_x = null;
  $v_r = null;
  $v_y = null;
  Z::$l = 114;
  ($v_o = []);
  Z::$l = 115;
  foreach (z_foreach($v_xs) as $_k118 => $_v118) {
    $v_x = $_v118;
    Z::$l = 116;
    if (z_truthy((z_truthy(f_Workspace_parser__isNode($v_x)) && z_truthy((z_index($v_x, 0) === ':Expr'))))) {
      Z::$l = 117;
      ($v_r = f_zs_invoke($v_this, 'stmtExpr', [$v_x]));
      Z::$l = 118;
      if (z_truthy(($v_r !== null))) {
        Z::$l = 118;
        foreach (z_foreach($v_r) as $_k119 => $_v119) {
          $v_y = $_v119;
          Z::$l = 118;
          z_apush($v_o, $v_y);
        }
        continue 1;
      }
    }
    Z::$l = 120;
    z_apush($v_o, f_zs_invoke($v_this, 'rw', [$v_x]));
  }
  Z::$l = 122;
  return $v_o;
  return null;
}
function f_Desugar__rw($v_this, $v_x) {
  $v_o = null;
  $v_k = null;
  $v_v = null;
  $v_line = null;
  $v_r = null;
  $v_cn = null;
  $v_sn = null;
  $v_t = null;
  $v_i = null;
  Z::$l = 126;
  if (z_truthy(!z_truthy(z_b_is_array($v_x)))) {
    Z::$l = 126;
    return $v_x;
  }
  Z::$l = 127;
  if (z_truthy(!z_truthy(f_Workspace_parser__isNode($v_x)))) {
    Z::$l = 128;
    ($v_o = []);
    Z::$l = 129;
    foreach (z_foreach($v_x) as $_k120 => $_v120) {
      $v_v = $_v120;
      $v_k = $_k120;
      Z::$l = 130;
      if (z_truthy((z_truthy((z_truthy(z_b_is_array($v_v)) && z_truthy((z_cmp(z_b_count($v_v), 0) > 0)))) && z_truthy(f_Workspace_parser__isNode((($_t24 = z_indexopt($v_v, 0)) !== null ? $_t24 : null)))))) {
        Z::$l = 130;
        z_aset($v_o, $v_k, f_zs_invoke($v_this, 'rwList', [$v_v]));
      } else {
        Z::$l = 131;
        z_aset($v_o, $v_k, f_zs_invoke($v_this, 'rw', [$v_v]));
      }
    }
    Z::$l = 133;
    return $v_o;
  }
  Z::$l = 135;
  ($v_k = z_index($v_x, 0));
  Z::$l = 136;
  ($v_line = z_index($v_x, 1));
  Z::$l = 137;
  if (z_truthy(($v_k === ':Expr'))) {
    Z::$l = 138;
    ($v_r = f_zs_invoke($v_this, 'stmtExpr', [$v_x]));
    Z::$l = 139;
    if (z_truthy(($v_r !== null))) {
      Z::$l = 139;
      return (z_truthy((z_b_count($v_r) === 1)) ? z_index($v_r, 0) : [':Block', $v_line, $v_r]);
    }
  }
  Z::$l = 141;
  if (z_truthy((z_truthy((z_truthy(($v_k === ':Try')) && z_truthy(z_b_zs_obj_get($v_this, 'excMode')))) && z_truthy((z_cmp(z_b_count(z_index($v_x, 3)), 0) > 0))))) {
    Z::$l = 141;
    return f_zs_invoke($v_this, 'rwTry', [$v_x]);
  }
  Z::$l = 142;
  if (z_truthy(($v_k === ':New'))) {
    Z::$l = 142;
    return f_zs_invoke($v_this, 'rwNew', [$v_x]);
  }
  Z::$l = 143;
  if (z_truthy(($v_k === ':InstanceOf'))) {
    Z::$l = 143;
    return f_zs_invoke($v_this, 'call', [$v_line, 'zs_isa', [f_zs_invoke($v_this, 'rw', [z_index($v_x, 2)]), f_zs_invoke($v_this, 'mkstr', [$v_line, z_index($v_x, 3)])]]);
  }
  Z::$l = 144;
  if (z_truthy(($v_k === ':Prop'))) {
    Z::$l = 144;
    return f_zs_invoke($v_this, 'call', [$v_line, 'zs_obj_get', [f_zs_invoke($v_this, 'rw', [z_index($v_x, 2)]), f_zs_invoke($v_this, 'mkstr', [$v_line, z_index($v_x, 3)])]]);
  }
  Z::$l = 145;
  if (z_truthy(($v_k === ':Dot'))) {
    Z::$l = 146;
    if (z_truthy((z_index(z_index($v_x, 2), 0) === ':Name'))) {
      Z::$l = 147;
      ($v_cn = f_zs_invoke($v_this, 'clsName', [z_index(z_index($v_x, 2), 2)]));
      Z::$l = 148;
      if (z_truthy(($v_cn !== null))) {
        Z::$l = 149;
        ($v_v = f_zs_invoke($v_this, 'constOf', [$v_cn, z_index($v_x, 3)]));
        Z::$l = 150;
        if (z_truthy(($v_v !== null))) {
          Z::$l = 150;
          return f_zs_invoke($v_this, 'rw', [$v_v]);
        }
        Z::$l = 151;
        ($v_sn = f_zs_invoke($v_this, 'staticName', [$v_cn, z_index($v_x, 3)]));
        Z::$l = 152;
        if (z_truthy(($v_sn !== null))) {
          Z::$l = 152;
          return f_zs_invoke($v_this, 'call', [$v_line, 'zs_sget', [f_zs_invoke($v_this, 'mkstr', [$v_line, $v_sn])]]);
        }
        Z::$l = 153;
        f_zs_invoke($v_this, 'err', [$v_line, z_concat(z_concat(z_concat('brak stałej lub statycznego pola ', $v_cn), '.'), z_index($v_x, 3))]);
      }
    }
    Z::$l = 156;
    return [':Dot', $v_line, f_zs_invoke($v_this, 'rw', [z_index($v_x, 2)]), z_index($v_x, 3)];
  }
  Z::$l = 158;
  if (z_truthy((z_truthy(($v_k === ':Assign')) && z_truthy((f_zs_invoke($v_this, 'staticTarget', [z_index($v_x, 2)]) !== null))))) {
    Z::$l = 159;
    return f_zs_invoke($v_this, 'call', [$v_line, 'zs_sset', [f_zs_invoke($v_this, 'mkstr', [$v_line, f_zs_invoke($v_this, 'staticTarget', [z_index($v_x, 2)])]), f_zs_invoke($v_this, 'rw', [z_index($v_x, 3)])]]);
  }
  Z::$l = 161;
  if (z_truthy((z_truthy((z_truthy(($v_k === ':AssignOp')) && z_truthy((z_index($v_x, 2) !== 'Coalesce')))) && z_truthy((f_zs_invoke($v_this, 'staticTarget', [z_index($v_x, 3)]) !== null))))) {
    Z::$l = 162;
    ($v_sn = f_zs_invoke($v_this, 'mkstr', [$v_line, f_zs_invoke($v_this, 'staticTarget', [z_index($v_x, 3)])]));
    Z::$l = 163;
    return f_zs_invoke($v_this, 'call', [$v_line, 'zs_sset', [$v_sn, [':Binary', $v_line, z_index($v_x, 2), f_zs_invoke($v_this, 'call', [$v_line, 'zs_sget', [$v_sn]]), f_zs_invoke($v_this, 'rw', [z_index($v_x, 4)])]]]);
  }
  Z::$l = 165;
  if (z_truthy((z_truthy(($v_k === ':IncDec')) && z_truthy((f_zs_invoke($v_this, 'staticTarget', [z_index($v_x, 2)]) !== null))))) {
    Z::$l = 166;
    ($v_sn = f_zs_invoke($v_this, 'mkstr', [$v_line, f_zs_invoke($v_this, 'staticTarget', [z_index($v_x, 2)])]));
    Z::$l = 167;
    return f_zs_invoke($v_this, 'call', [$v_line, 'zs_sset', [$v_sn, [':Binary', $v_line, (z_truthy(z_index($v_x, 3)) ? 'Add' : 'Sub'), f_zs_invoke($v_this, 'call', [$v_line, 'zs_sget', [$v_sn]]), [':Int', $v_line, 1]]]]);
  }
  Z::$l = 169;
  if (z_truthy((z_truthy(($v_k === ':Assign')) && z_truthy((z_index(z_index($v_x, 2), 0) === ':Prop'))))) {
    Z::$l = 170;
    ($v_t = z_index($v_x, 2));
    Z::$l = 171;
    return f_zs_invoke($v_this, 'call', [$v_line, 'zs_obj_set', [f_zs_invoke($v_this, 'rw', [z_index($v_t, 2)]), f_zs_invoke($v_this, 'mkstr', [$v_line, z_index($v_t, 3)]), f_zs_invoke($v_this, 'rw', [z_index($v_x, 3)])]]);
  }
  Z::$l = 173;
  if (z_truthy((z_truthy((z_truthy(($v_k === ':AssignOp')) && z_truthy((z_index(z_index($v_x, 3), 0) === ':Prop')))) && z_truthy((z_index($v_x, 2) !== 'Coalesce'))))) {
    Z::$l = 174;
    ($v_t = z_index($v_x, 3));
    Z::$l = 175;
    return f_zs_invoke($v_this, 'propModify', [$v_line, $v_t, z_index($v_x, 2), f_zs_invoke($v_this, 'rw', [z_index($v_x, 4)])]);
  }
  Z::$l = 177;
  if (z_truthy((z_truthy(($v_k === ':IncDec')) && z_truthy((z_index(z_index($v_x, 2), 0) === ':Prop'))))) {
    Z::$l = 178;
    return f_zs_invoke($v_this, 'propModify', [$v_line, z_index($v_x, 2), (z_truthy(z_index($v_x, 3)) ? 'Add' : 'Sub'), [':Int', $v_line, 1]]);
  }
  Z::$l = 180;
  if (z_truthy(($v_k === ':Call'))) {
    Z::$l = 180;
    return f_zs_invoke($v_this, 'rwCall', [$v_x]);
  }
  Z::$l = 181;
  ($v_o = []);
  Z::$l = 182;
  foreach (z_foreach($v_x) as $_k121 => $_v121) {
    $v_v = $_v121;
    $v_i = $_k121;
    Z::$l = 183;
    if (z_truthy((z_cmp($v_i, 2) < 0))) {
      Z::$l = 183;
      z_aset($v_o, $v_i, $v_v);
      continue 1;
    }
    Z::$l = 184;
    if (z_truthy((z_truthy((z_truthy(z_b_is_array($v_v)) && z_truthy((z_cmp(z_b_count($v_v), 0) > 0)))) && z_truthy(f_Workspace_parser__isNode((($_t25 = z_indexopt($v_v, 0)) !== null ? $_t25 : null)))))) {
      Z::$l = 184;
      z_aset($v_o, $v_i, f_zs_invoke($v_this, 'rwList', [$v_v]));
    } else {
      Z::$l = 185;
      z_aset($v_o, $v_i, f_zs_invoke($v_this, 'rw', [$v_v]));
    }
  }
  Z::$l = 187;
  return $v_o;
  return null;
}
function f_Desugar__baseOk($v_this, $v_b) {
  Z::$l = 190;
  return (z_index($v_b, 0) === ':Var');
  return null;
}
function f_Desugar__propModify($v_this, $v_line, $v_t, $v_op, $v_rhs) {
  $v_base = null;
  $v_get = null;
  Z::$l = 193;
  ($v_base = z_index($v_t, 2));
  Z::$l = 194;
  if (z_truthy(!z_truthy(f_zs_invoke($v_this, 'baseOk', [$v_base])))) {
    Z::$l = 194;
    f_zs_invoke($v_this, 'err', [$v_line, 'modyfikacja właściwości wymaga zmiennej jako obiektu (np. $this->x += 1)']);
    Z::$l = 194;
    return [':Null', $v_line];
  }
  Z::$l = 195;
  ($v_get = f_zs_invoke($v_this, 'call', [$v_line, 'zs_obj_get', [$v_base, f_zs_invoke($v_this, 'mkstr', [$v_line, z_index($v_t, 3)])]]));
  Z::$l = 196;
  return f_zs_invoke($v_this, 'call', [$v_line, 'zs_obj_set', [$v_base, f_zs_invoke($v_this, 'mkstr', [$v_line, z_index($v_t, 3)]), [':Binary', $v_line, $v_op, $v_get, $v_rhs]]]);
  return null;
}
function f_Desugar__staticName($v_this, $v_cn, $v_p) {
  $v_n = null;
  $v_d = null;
  Z::$l = 201;
  foreach (z_foreach(f_zs_invoke($v_this, 'chain', [$v_cn])) as $_k122 => $_v122) {
    $v_n = $_v122;
    Z::$l = 202;
    ($v_d = z_b_zs_obj_get(z_index(z_b_zs_obj_get($v_this, 'classes'), $v_n), 'props'));
    Z::$l = 203;
    if (z_truthy((z_truthy(z_b_has_key($v_d, $v_p)) && z_truthy(z_index(z_index($v_d, $v_p), 'static'))))) {
      Z::$l = 203;
      return z_concat(z_concat($v_n, '::'), $v_p);
    }
  }
  Z::$l = 205;
  return null;
  return null;
}
function f_Desugar__staticTarget($v_this, $v_t) {
  $v_cn = null;
  Z::$l = 209;
  if (z_truthy((z_truthy((z_truthy(!z_truthy(z_b_is_array($v_t))) || z_truthy((z_index($v_t, 0) !== ':Dot')))) || z_truthy((z_index(z_index($v_t, 2), 0) !== ':Name'))))) {
    Z::$l = 209;
    return null;
  }
  Z::$l = 210;
  ($v_cn = f_zs_invoke($v_this, 'clsName', [z_index(z_index($v_t, 2), 2)]));
  Z::$l = 211;
  if (z_truthy(($v_cn === null))) {
    Z::$l = 211;
    return null;
  }
  Z::$l = 212;
  return f_zs_invoke($v_this, 'staticName', [$v_cn, z_index($v_t, 3)]);
  return null;
}
function f_Desugar__clsName($v_this, $v_n) {
  Z::$l = 216;
  if (z_truthy((z_truthy(($v_n === 'static')) || z_truthy(($v_n === 'self'))))) {
    Z::$l = 216;
    return (z_truthy((z_b_zs_obj_get($v_this, 'cur') !== null)) ? z_b_zs_obj_get(z_b_zs_obj_get($v_this, 'cur'), 'name') : null);
  }
  Z::$l = 217;
  return (z_truthy(z_b_has_key(z_b_zs_obj_get($v_this, 'classes'), $v_n)) ? $v_n : null);
  return null;
}
function f_Desugar__constOf($v_this, $v_cn, $v_k) {
  $v_n = null;
  Z::$l = 221;
  foreach (z_foreach(f_zs_invoke($v_this, 'chain', [$v_cn])) as $_k123 => $_v123) {
    $v_n = $_v123;
    Z::$l = 222;
    if (z_truthy(z_b_has_key(z_b_zs_obj_get(z_index(z_b_zs_obj_get($v_this, 'classes'), $v_n), 'consts'), $v_k))) {
      Z::$l = 222;
      return z_index(z_b_zs_obj_get(z_index(z_b_zs_obj_get($v_this, 'classes'), $v_n), 'consts'), $v_k);
    }
  }
  Z::$l = 224;
  return null;
  return null;
}
function f_Desugar__rwNew($v_this, $v_x) {
  $v_line = null;
  $v_args = null;
  $v_a = null;
  Z::$l = 228;
  ($v_line = z_index($v_x, 1));
  Z::$l = 229;
  ($v_args = []);
  Z::$l = 230;
  foreach (z_foreach(z_index($v_x, 3)) as $_k124 => $_v124) {
    $v_a = $_v124;
    Z::$l = 230;
    z_aset($v_a, 3, f_zs_invoke($v_this, 'rw', [z_index($v_a, 3)]));
    Z::$l = 230;
    z_apush($v_args, $v_a);
  }
  Z::$l = 231;
  if (z_truthy(z_b_in_array(z_index($v_x, 2), ['Exception', 'Error']))) {
    Z::$l = 231;
    return [':New', $v_line, z_index($v_x, 2), $v_args];
  }
  Z::$l = 232;
  if (z_truthy(!z_truthy(z_b_has_key(z_b_zs_obj_get($v_this, 'classes'), z_index($v_x, 2))))) {
    Z::$l = 233;
    return f_zs_invoke($v_this, 'call', [$v_line, 'zs_no_class', [f_zs_invoke($v_this, 'mkstr', [$v_line, z_index($v_x, 2)])]]);
  }
  Z::$l = 235;
  return [':Call', $v_line, f_zs_invoke($v_this, 'nm', [$v_line, z_concat(z_index($v_x, 2), '__new')]), $v_args];
  return null;
}
function f_Desugar__rwCall($v_this, $v_x) {
  $v_line = null;
  $v_callee = null;
  $v_args = null;
  $v_a = null;
  $v_m = null;
  $v_special = null;
  $v___k120 = null;
  $v___r121 = null;
  $v___w122 = null;
  $v_cur = null;
  $v_its = null;
  $v_seg = null;
  $v_arr = null;
  $v_items = null;
  $v_n = null;
  $v_o = null;
  $v_as = null;
  $v_cn = null;
  Z::$l = 239;
  ($v_line = z_index($v_x, 1));
  Z::$l = 240;
  ($v_callee = z_index($v_x, 2));
  Z::$l = 241;
  ($v_args = []);
  Z::$l = 242;
  foreach (z_foreach(z_index($v_x, 3)) as $_k125 => $_v125) {
    $v_a = $_v125;
    Z::$l = 242;
    z_aset($v_a, 3, f_zs_invoke($v_this, 'rw', [z_index($v_a, 3)]));
    Z::$l = 242;
    z_apush($v_args, $v_a);
  }
  Z::$l = 243;
  if (z_truthy((z_index($v_callee, 0) === ':Prop'))) {
    Z::$l = 244;
    ($v_m = z_index($v_callee, 3));
    Z::$l = 245;
    if (z_truthy((z_truthy((z_truthy(($v_m === 'getMessage')) && z_truthy((z_b_count($v_args) === 0)))) && z_truthy(!z_truthy(f_zs_invoke($v_this, 'anyMethod', ['getMessage'])))))) {
      Z::$l = 246;
      return [':Call', $v_line, [':Prop', z_index($v_callee, 1), f_zs_invoke($v_this, 'rw', [z_index($v_callee, 2)]), $v_m], $v_args];
    }
    Z::$l = 248;
    ($v_special = false);
    Z::$l = 249;
    foreach (z_foreach($v_args) as $_k126 => $_v126) {
      $v_a = $_v126;
      Z::$l = 249;
      if (z_truthy((z_truthy(z_index($v_a, 4)) || z_truthy((z_index($v_a, 2) !== null))))) {
        Z::$l = 249;
        ($v_special = true);
      }
    }
    Z::$l = 250;
    if (z_truthy($v_special)) {
      Z::$l = 251;
      ($v___k120 = $v_m);
      Z::$l = 251;
      ($v___r121 = true);
      Z::$l = 251;
      ($v___w122 = z_b_zs_obj_take($v_this, 'nuse'));
      Z::$l = 251;
      z_aset($v___w122, $v___k120, $v___r121);
      Z::$l = 251;
      z_b_zs_obj_put($v_this, 'nuse', $v___w122);
      Z::$l = 252;
      ($v_cur = null);
      Z::$l = 253;
      ($v_its = []);
      Z::$l = 254;
      foreach (z_foreach($v_args) as $_k127 => $_v127) {
        $v_a = $_v127;
        Z::$l = 255;
        if (z_truthy(z_index($v_a, 4))) {
          Z::$l = 256;
          ($v_seg = [':Array', $v_line, $v_its]);
          Z::$l = 257;
          ($v_cur = (z_truthy(($v_cur === null)) ? $v_seg : f_zs_invoke($v_this, 'call', [$v_line, 'zs_spread', [$v_cur, $v_seg]])));
          Z::$l = 258;
          ($v_cur = f_zs_invoke($v_this, 'call', [$v_line, 'zs_spread', [$v_cur, z_index($v_a, 3)]]));
          Z::$l = 259;
          ($v_its = []);
        } else {
          Z::$l = 260;
          if (z_truthy((z_index($v_a, 2) !== null))) {
            Z::$l = 260;
            z_apush($v_its, [':Item', 0, f_zs_invoke($v_this, 'mkstr', [$v_line, z_index($v_a, 2)]), z_index($v_a, 3)]);
          } else {
            Z::$l = 261;
            z_apush($v_its, [':Item', 0, null, z_index($v_a, 3)]);
          }
        }
      }
      Z::$l = 263;
      if (z_truthy(($v_cur === null))) {
        Z::$l = 263;
        ($v_cur = [':Array', $v_line, $v_its]);
      } else {
        Z::$l = 264;
        if (z_truthy((z_cmp(z_b_count($v_its), 0) > 0))) {
          Z::$l = 264;
          ($v_cur = f_zs_invoke($v_this, 'call', [$v_line, 'zs_spread', [$v_cur, [':Array', $v_line, $v_its]]]));
        }
      }
      Z::$l = 265;
      return f_zs_invoke($v_this, 'call', [$v_line, 'zs_invoke_n', [f_zs_invoke($v_this, 'rw', [z_index($v_callee, 2)]), f_zs_invoke($v_this, 'mkstr', [$v_line, $v_m]), $v_cur]]);
    }
    Z::$l = 267;
    ($v_arr = [':Array', $v_line, []]);
    Z::$l = 268;
    ($v_items = []);
    Z::$l = 269;
    foreach (z_foreach($v_args) as $_k128 => $_v128) {
      $v_a = $_v128;
      Z::$l = 269;
      z_apush($v_items, [':Item', 0, null, z_index($v_a, 3), false]);
    }
    Z::$l = 270;
    z_aset($v_arr, 2, $v_items);
    Z::$l = 271;
    return f_zs_invoke($v_this, 'call', [$v_line, 'zs_invoke', [f_zs_invoke($v_this, 'rw', [z_index($v_callee, 2)]), f_zs_invoke($v_this, 'mkstr', [$v_line, $v_m]), $v_arr]]);
  }
  Z::$l = 273;
  if (z_truthy((z_truthy((z_index($v_callee, 0) === ':Dot')) && z_truthy((z_index(z_index($v_callee, 2), 0) === ':Name'))))) {
    Z::$l = 274;
    ($v_n = z_index(z_index($v_callee, 2), 2));
    Z::$l = 275;
    ($v_m = z_index($v_callee, 3));
    Z::$l = 276;
    if (z_truthy(($v_n === 'parent'))) {
      Z::$l = 277;
      if (z_truthy((z_truthy((z_b_zs_obj_get($v_this, 'cur') === null)) || z_truthy((z_b_zs_obj_get(z_b_zs_obj_get($v_this, 'cur'), 'parent') === null))))) {
        Z::$l = 277;
        f_zs_invoke($v_this, 'err', [$v_line, 'parent poza klasą z rodzicem']);
        Z::$l = 277;
        return $v_x;
      }
      Z::$l = 278;
      ($v_o = f_zs_invoke($v_this, 'owner', [z_b_zs_obj_get(z_b_zs_obj_get($v_this, 'cur'), 'parent'), $v_m]));
      Z::$l = 279;
      if (z_truthy(($v_o === null))) {
        Z::$l = 279;
        f_zs_invoke($v_this, 'err', [$v_line, z_concat(z_concat(z_concat('klasa ', z_b_zs_obj_get(z_b_zs_obj_get($v_this, 'cur'), 'parent')), ' nie ma metody '), $v_m)]);
        Z::$l = 279;
        return $v_x;
      }
      Z::$l = 280;
      ($v_as = $v_args);
      Z::$l = 281;
      if (z_truthy(!z_truthy(z_index(z_index(z_b_zs_obj_get(z_index(z_b_zs_obj_get($v_this, 'classes'), $v_o), 'methods'), $v_m), 'static')))) {
        Z::$l = 281;
        ($v_as = f_Workspace_classes__prepend([':Arg', 0, null, f_zs_invoke($v_this, 'mkvar', [$v_line, 'this']), false], $v_as));
      }
      Z::$l = 282;
      return [':Call', $v_line, f_zs_invoke($v_this, 'nm', [$v_line, z_concat(z_concat($v_o, '__'), $v_m)]), $v_as];
    }
    Z::$l = 284;
    ($v_cn = f_zs_invoke($v_this, 'clsName', [$v_n]));
    Z::$l = 285;
    if (z_truthy(($v_cn !== null))) {
      Z::$l = 286;
      ($v_o = f_zs_invoke($v_this, 'owner', [$v_cn, $v_m]));
      Z::$l = 287;
      if (z_truthy((z_truthy(($v_o === null)) || z_truthy(!z_truthy(z_index(z_index(z_b_zs_obj_get(z_index(z_b_zs_obj_get($v_this, 'classes'), $v_o), 'methods'), $v_m), 'static')))))) {
        Z::$l = 287;
        f_zs_invoke($v_this, 'err', [$v_line, z_concat(z_concat(z_concat('brak metody statycznej ', $v_cn), '.'), $v_m)]);
        Z::$l = 287;
        return $v_x;
      }
      Z::$l = 288;
      return [':Call', $v_line, f_zs_invoke($v_this, 'nm', [$v_line, z_concat(z_concat($v_o, '__'), $v_m)]), $v_args];
    }
  }
  Z::$l = 291;
  return [':Call', $v_line, f_zs_invoke($v_this, 'rw', [$v_callee]), $v_args];
  return null;
}
function f_Desugar__rwTry($v_this, $v_x) {
  $v_line = null;
  $v_ex = null;
  $v_chain = null;
  $v_i = null;
  $v_c = null;
  $v_cond = null;
  $v_t = null;
  $v_one = null;
  $v_then = null;
  $v_s = null;
  $v_fin = null;
  Z::$l = 295;
  ($v_line = z_index($v_x, 1));
  Z::$l = 296;
  ($v_ex = f_zs_invoke($v_this, 'fresh', ['ex']));
  Z::$l = 297;
  ($v_chain = [[':Throw', $v_line, f_zs_invoke($v_this, 'mkvar', [$v_line, $v_ex])]]);
  Z::$l = 298;
  ($v_i = z_sub(z_b_count(z_index($v_x, 3)), 1));
  for (; z_truthy((z_cmp($v_i, 0) >= 0)); z_last($_t26 = $v_i, $v_i = z_sub($_t26, 1), $_t26)) {
    Z::$l = 299;
    ($v_c = z_index(z_index($v_x, 3), $v_i));
    Z::$l = 300;
    ($v_cond = null);
    Z::$l = 301;
    foreach (z_foreach(z_index($v_c, 2)) as $_k130 => $_v130) {
      $v_t = $_v130;
      Z::$l = 302;
      ($v_one = (z_truthy(($v_t === 'Throwable')) ? [':Bool', $v_line, true] : f_zs_invoke($v_this, 'call', [$v_line, 'zs_isa', [f_zs_invoke($v_this, 'mkvar', [$v_line, $v_ex]), f_zs_invoke($v_this, 'mkstr', [$v_line, $v_t])]])));
      Z::$l = 303;
      ($v_cond = (z_truthy(($v_cond === null)) ? $v_one : [':Binary', $v_line, 'Or', $v_cond, $v_one]));
    }
    Z::$l = 305;
    ($v_then = []);
    Z::$l = 306;
    if (z_truthy((z_index($v_c, 3) !== null))) {
      Z::$l = 306;
      z_apush($v_then, [':Expr', $v_line, [':Assign', $v_line, f_zs_invoke($v_this, 'mkvar', [$v_line, z_index($v_c, 3)]), f_zs_invoke($v_this, 'mkvar', [$v_line, $v_ex])]]);
    }
    Z::$l = 307;
    foreach (z_foreach(f_zs_invoke($v_this, 'rwList', [z_index($v_c, 4)])) as $_k131 => $_v131) {
      $v_s = $_v131;
      Z::$l = 307;
      z_apush($v_then, $v_s);
    }
    Z::$l = 308;
    ($v_chain = [[':If', $v_line, $v_cond, $v_then, $v_chain]]);
  }
  Z::$l = 310;
  ($v_fin = (z_truthy((z_index($v_x, 4) === null)) ? null : f_zs_invoke($v_this, 'rwList', [z_index($v_x, 4)])));
  Z::$l = 311;
  return [':Try', $v_line, f_zs_invoke($v_this, 'rwList', [z_index($v_x, 2)]), [[':Catch', 0, ['Throwable'], $v_ex, $v_chain]], $v_fin];
  return null;
}
function f_Desugar__anyMethod($v_this, $v_m) {
  $v_c = null;
  Z::$l = 315;
  foreach (z_foreach(z_b_zs_obj_get($v_this, 'classes')) as $_k132 => $_v132) {
    $v_c = $_v132;
    Z::$l = 315;
    if (z_truthy(z_b_has_key(z_b_zs_obj_get($v_c, 'methods'), $v_m))) {
      Z::$l = 315;
      return true;
    }
  }
  Z::$l = 316;
  return false;
  return null;
}
function f_Desugar__stmtExpr($v_this, $v_s) {
  $v_e = null;
  $v_line = null;
  $v_target = null;
  $v_kind = null;
  $v_keys = null;
  $v_t = null;
  $v_sname = null;
  $v_out = null;
  $v_base = null;
  $v_bv = null;
  $v_ks = null;
  $v_key = null;
  $v_kv = null;
  $v_rv = null;
  $v_rhs = null;
  $v_w = null;
  $v_tgt = null;
  $v_kk = null;
  $v_ne = null;
  Z::$l = 321;
  ($v_e = z_index($v_s, 2));
  Z::$l = 322;
  ($v_line = z_index($v_s, 1));
  Z::$l = 323;
  ($v_target = null);
  Z::$l = 323;
  ($v_kind = null);
  Z::$l = 324;
  if (z_truthy((z_index($v_e, 0) === ':Assign'))) {
    Z::$l = 324;
    ($v_target = z_index($v_e, 2));
    Z::$l = 324;
    ($v_kind = 'assign');
  } else {
    Z::$l = 325;
    if (z_truthy((z_index($v_e, 0) === ':AssignOp'))) {
      Z::$l = 325;
      ($v_target = z_index($v_e, 3));
      Z::$l = 325;
      ($v_kind = 'op');
    } else {
      Z::$l = 326;
      if (z_truthy((z_index($v_e, 0) === ':IncDec'))) {
        Z::$l = 326;
        ($v_target = z_index($v_e, 2));
        Z::$l = 326;
        ($v_kind = 'incdec');
      }
    }
  }
  Z::$l = 327;
  if (z_truthy((z_truthy(($v_target === null)) || z_truthy((z_index($v_target, 0) !== ':Index'))))) {
    Z::$l = 327;
    return null;
  }
  Z::$l = 328;
  ($v_keys = []);
  Z::$l = 329;
  ($v_t = $v_target);
  while (true) {
    Z::$l = 330;
    if (!z_truthy((z_index($v_t, 0) === ':Index'))) break;
    Z::$l = 330;
    z_apush($v_keys, z_index($v_t, 3));
    Z::$l = 330;
    ($v_t = z_index($v_t, 2));
  }
  Z::$l = 331;
  ($v_sname = f_zs_invoke($v_this, 'staticTarget', [$v_t]));
  Z::$l = 332;
  if (z_truthy((z_truthy((z_index($v_t, 0) !== ':Prop')) && z_truthy(($v_sname === null))))) {
    Z::$l = 332;
    return null;
  }
  Z::$l = 334;
  ($v_keys = f_Workspace_classes__array_reverse_names($v_keys));
  Z::$l = 335;
  ($v_out = []);
  Z::$l = 336;
  ($v_base = (z_truthy(($v_sname !== null)) ? [':Null', $v_line] : f_zs_invoke($v_this, 'rw', [z_index($v_t, 2)])));
  Z::$l = 337;
  if (z_truthy((z_truthy(($v_sname === null)) && z_truthy((z_index($v_base, 0) !== ':Var'))))) {
    Z::$l = 338;
    ($v_bv = f_zs_invoke($v_this, 'fresh', ['o']));
    Z::$l = 339;
    z_apush($v_out, [':Expr', $v_line, [':Assign', $v_line, f_zs_invoke($v_this, 'mkvar', [$v_line, $v_bv]), $v_base]]);
    Z::$l = 340;
    ($v_base = f_zs_invoke($v_this, 'mkvar', [$v_line, $v_bv]));
  }
  Z::$l = 342;
  ($v_ks = []);
  Z::$l = 343;
  foreach (z_foreach($v_keys) as $_k134 => $_v134) {
    $v_key = $_v134;
    Z::$l = 344;
    if (z_truthy(($v_key === null))) {
      Z::$l = 344;
      z_apush($v_ks, null);
      continue 1;
    }
    Z::$l = 345;
    ($v_kv = f_zs_invoke($v_this, 'fresh', ['k']));
    Z::$l = 346;
    z_apush($v_out, [':Expr', $v_line, [':Assign', $v_line, f_zs_invoke($v_this, 'mkvar', [$v_line, $v_kv]), f_zs_invoke($v_this, 'rw', [$v_key])]]);
    Z::$l = 347;
    z_apush($v_ks, f_zs_invoke($v_this, 'mkvar', [$v_line, $v_kv]));
  }
  Z::$l = 349;
  ($v_rv = null);
  Z::$l = 350;
  if (z_truthy((z_truthy(($v_kind === 'assign')) || z_truthy(($v_kind === 'op'))))) {
    Z::$l = 351;
    ($v_rv = f_zs_invoke($v_this, 'fresh', ['r']));
    Z::$l = 352;
    ($v_rhs = (z_truthy(($v_kind === 'assign')) ? z_index($v_e, 3) : z_index($v_e, 4)));
    Z::$l = 353;
    z_apush($v_out, [':Expr', $v_line, [':Assign', $v_line, f_zs_invoke($v_this, 'mkvar', [$v_line, $v_rv]), f_zs_invoke($v_this, 'rw', [$v_rhs])]]);
  }
  Z::$l = 355;
  ($v_w = f_zs_invoke($v_this, 'fresh', ['w']));
  Z::$l = 356;
  z_apush($v_out, [':Expr', $v_line, [':Assign', $v_line, f_zs_invoke($v_this, 'mkvar', [$v_line, $v_w]), (z_truthy(($v_sname !== null)) ? f_zs_invoke($v_this, 'call', [$v_line, 'zs_sget', [f_zs_invoke($v_this, 'mkstr', [$v_line, $v_sname])]]) : f_zs_invoke($v_this, 'call', [$v_line, 'zs_obj_take', [$v_base, f_zs_invoke($v_this, 'mkstr', [$v_line, z_index($v_t, 3)])]]))]]);
  Z::$l = 357;
  ($v_tgt = f_zs_invoke($v_this, 'mkvar', [$v_line, $v_w]));
  Z::$l = 358;
  foreach (z_foreach($v_ks) as $_k135 => $_v135) {
    $v_kk = $_v135;
    Z::$l = 358;
    ($v_tgt = [':Index', $v_line, $v_tgt, $v_kk]);
  }
  Z::$l = 359;
  if (z_truthy(($v_kind === 'assign'))) {
    Z::$l = 359;
    ($v_ne = [':Assign', $v_line, $v_tgt, f_zs_invoke($v_this, 'mkvar', [$v_line, $v_rv])]);
  } else {
    Z::$l = 360;
    if (z_truthy(($v_kind === 'op'))) {
      Z::$l = 360;
      ($v_ne = [':AssignOp', $v_line, z_index($v_e, 2), $v_tgt, f_zs_invoke($v_this, 'mkvar', [$v_line, $v_rv])]);
    } else {
      Z::$l = 361;
      ($v_ne = [':IncDec', $v_line, $v_tgt, z_index($v_e, 3), z_index($v_e, 4)]);
    }
  }
  Z::$l = 362;
  z_apush($v_out, [':Expr', $v_line, $v_ne]);
  Z::$l = 363;
  if (z_truthy(($v_sname !== null))) {
    Z::$l = 363;
    z_apush($v_out, [':Expr', $v_line, f_zs_invoke($v_this, 'call', [$v_line, 'zs_sset', [f_zs_invoke($v_this, 'mkstr', [$v_line, $v_sname]), f_zs_invoke($v_this, 'mkvar', [$v_line, $v_w])]])]);
  } else {
    Z::$l = 364;
    z_apush($v_out, [':Expr', $v_line, f_zs_invoke($v_this, 'call', [$v_line, 'zs_obj_put', [$v_base, f_zs_invoke($v_this, 'mkstr', [$v_line, z_index($v_t, 3)]), f_zs_invoke($v_this, 'mkvar', [$v_line, $v_w])]])]);
  }
  Z::$l = 365;
  return $v_out;
  return null;
}
function f_Desugar__funcStmt($v_this, $v_line, $v_name, $v_params, $v_body) {
  Z::$l = 370;
  return [':FuncStmt', $v_line, [':Func', $v_line, $v_name, $v_params, [], $v_body, false]];
  return null;
}
function f_Desugar__param($v_this, $v_name, $v_default) {
  Z::$l = 373;
  return [':Param', 0, $v_name, [], $v_default, false];
  return null;
}
function f_Desugar__genClass($v_this, $v_k) {
  $v_m = null;
  $v_d = null;
  $v_f = null;
  $v_params = null;
  $v_body = null;
  $v___r123 = null;
  $v___w124 = null;
  $v_line = null;
  $v_ctorOwner = null;
  $v_p = null;
  $v_dv = null;
  $v_args = null;
  $v___r125 = null;
  $v___w126 = null;
  Z::$l = 376;
  z_b_zs_obj_set($v_this, 'cur', $v_k);
  Z::$l = 378;
  foreach (z_foreach(z_b_zs_obj_get($v_k, 'methods')) as $_k136 => $_v136) {
    $v_d = $_v136;
    $v_m = $_k136;
    Z::$l = 379;
    if (z_truthy(z_index($v_d, 'abstract'))) {
      continue 1;
    }
    Z::$l = 380;
    ($v_f = z_index($v_d, 'decl'));
    Z::$l = 381;
    ($v_params = z_index($v_f, 3));
    Z::$l = 382;
    if (z_truthy(!z_truthy(z_index($v_d, 'static')))) {
      Z::$l = 382;
      ($v_params = f_Workspace_classes__prepend(f_zs_invoke($v_this, 'param', ['this']), $v_params));
    }
    Z::$l = 383;
    z_b_zs_obj_set($v_this, 'curStatic', z_index($v_d, 'static'));
    Z::$l = 384;
    ($v_body = f_zs_invoke($v_this, 'rwList', [z_index($v_f, 5)]));
    Z::$l = 385;
    ($v___r123 = [':FuncStmt', z_index($v_f, 1), [':Func', z_index($v_f, 1), z_concat(z_concat(z_b_zs_obj_get($v_k, 'name'), '__'), $v_m), $v_params, z_index($v_f, 4), $v_body, false]]);
    Z::$l = 385;
    ($v___w124 = z_b_zs_obj_take($v_this, 'extra'));
    Z::$l = 385;
    z_apush($v___w124, $v___r123);
    Z::$l = 385;
    z_b_zs_obj_put($v_this, 'extra', $v___w124);
  }
  Z::$l = 388;
  ($v_line = z_b_zs_obj_get($v_k, 'line'));
  Z::$l = 389;
  ($v_ctorOwner = f_zs_invoke($v_this, 'owner', [z_b_zs_obj_get($v_k, 'name'), '__construct']));
  Z::$l = 390;
  ($v_params = []);
  Z::$l = 391;
  if (z_truthy(($v_ctorOwner !== null))) {
    Z::$l = 391;
    ($v_params = z_index(z_index(z_index(z_b_zs_obj_get(z_index(z_b_zs_obj_get($v_this, 'classes'), $v_ctorOwner), 'methods'), '__construct'), 'decl'), 3));
  }
  Z::$l = 392;
  ($v_body = []);
  Z::$l = 393;
  z_apush($v_body, [':Expr', $v_line, [':Assign', $v_line, f_zs_invoke($v_this, 'mkvar', [$v_line, '__o']), f_zs_invoke($v_this, 'call', [$v_line, 'zs_obj_new', [f_zs_invoke($v_this, 'mkstr', [$v_line, z_b_zs_obj_get($v_k, 'name')])]])]]);
  Z::$l = 394;
  foreach (z_foreach(f_zs_invoke($v_this, 'allProps', [z_b_zs_obj_get($v_k, 'name')])) as $_k137 => $_v137) {
    $v_d = $_v137;
    $v_p = $_k137;
    Z::$l = 395;
    z_b_zs_obj_set($v_this, 'cur', z_index(z_b_zs_obj_get($v_this, 'classes'), z_index($v_d, 'cls')));
    Z::$l = 396;
    ($v_dv = (z_truthy((z_index($v_d, 'default') === null)) ? [':Null', $v_line] : f_zs_invoke($v_this, 'rw', [z_index($v_d, 'default')])));
    Z::$l = 397;
    z_apush($v_body, [':Expr', $v_line, f_zs_invoke($v_this, 'call', [$v_line, 'zs_obj_set', [f_zs_invoke($v_this, 'mkvar', [$v_line, '__o']), f_zs_invoke($v_this, 'mkstr', [$v_line, $v_p]), $v_dv]])]);
  }
  Z::$l = 399;
  z_b_zs_obj_set($v_this, 'cur', $v_k);
  Z::$l = 400;
  if (z_truthy(($v_ctorOwner !== null))) {
    Z::$l = 401;
    ($v_args = [f_zs_invoke($v_this, 'mkvar', [$v_line, '__o'])]);
    Z::$l = 402;
    foreach (z_foreach($v_params) as $_k138 => $_v138) {
      $v_p = $_v138;
      Z::$l = 402;
      z_apush($v_args, f_zs_invoke($v_this, 'mkvar', [$v_line, z_index($v_p, 2)]));
    }
    Z::$l = 403;
    z_apush($v_body, [':Expr', $v_line, f_zs_invoke($v_this, 'call', [$v_line, z_concat($v_ctorOwner, '____construct'), $v_args])]);
  }
  Z::$l = 405;
  z_apush($v_body, [':Return', $v_line, f_zs_invoke($v_this, 'mkvar', [$v_line, '__o'])]);
  Z::$l = 406;
  ($v___r125 = f_zs_invoke($v_this, 'funcStmt', [$v_line, z_concat(z_b_zs_obj_get($v_k, 'name'), '__new'), $v_params, $v_body]));
  Z::$l = 406;
  ($v___w126 = z_b_zs_obj_take($v_this, 'extra'));
  Z::$l = 406;
  z_apush($v___w126, $v___r125);
  Z::$l = 406;
  z_b_zs_obj_put($v_this, 'extra', $v___w126);
  return null;
}
function f_Desugar__wrapper($v_this, $v_owner, $v_m) {
  $v_f = null;
  $v_line = null;
  $v_ps = null;
  $v_np = null;
  $v_min = null;
  $v_p = null;
  $v_body = null;
  $v_cnt = null;
  $v_isVar = null;
  $v_n = null;
  $v_cargs = null;
  $v_i = null;
  $v_msg = null;
  $v_act = null;
  $v_sl = null;
  $v_call = null;
  $v_cmp = null;
  Z::$l = 411;
  ($v_f = z_index(z_index(z_b_zs_obj_get(z_index(z_b_zs_obj_get($v_this, 'classes'), $v_owner), 'methods'), $v_m), 'decl'));
  Z::$l = 412;
  ($v_line = z_index($v_f, 1));
  Z::$l = 413;
  ($v_ps = z_index($v_f, 3));
  Z::$l = 414;
  ($v_np = z_b_count($v_ps));
  Z::$l = 415;
  ($v_min = 0);
  Z::$l = 416;
  foreach (z_foreach($v_ps) as $_k139 => $_v139) {
    $v_p = $_v139;
    Z::$l = 416;
    if (z_truthy((z_index($v_p, 4) === null))) {
      Z::$l = 416;
      z_last($_t27 = $v_min, $v_min = z_add($_t27, 1), $_t27);
    }
  }
  Z::$l = 417;
  ($v_body = []);
  Z::$l = 418;
  ($v_cnt = f_zs_invoke($v_this, 'call', [$v_line, 'count', [f_zs_invoke($v_this, 'mkvar', [$v_line, 'args'])]]));
  Z::$l = 419;
  ($v_isVar = (z_truthy((z_cmp($v_np, 0) > 0)) && z_truthy(z_index(z_index($v_ps, z_sub($v_np, 1)), 5))));
  Z::$l = 420;
  if (z_truthy($v_isVar)) {
    Z::$l = 420;
    ($v_np = z_sub($v_np, 1));
  }
  Z::$l = 421;
  ($v_n = 0);
  for (; z_truthy((z_cmp($v_n, $v_np) <= 0)); z_last($_t28 = $v_n, $v_n = z_add($_t28, 1), $_t28)) {
    Z::$l = 422;
    ($v_cargs = [f_zs_invoke($v_this, 'mkvar', [$v_line, 'this'])]);
    Z::$l = 423;
    ($v_i = 0);
    for (; z_truthy((z_cmp($v_i, $v_n) < 0)); z_last($_t29 = $v_i, $v_i = z_add($_t29, 1), $_t29)) {
      Z::$l = 423;
      z_apush($v_cargs, [':Index', $v_line, f_zs_invoke($v_this, 'mkvar', [$v_line, 'args']), [':Int', $v_line, $v_i]]);
    }
    Z::$l = 424;
    if (z_truthy((z_cmp($v_n, $v_min) < 0))) {
      Z::$l = 425;
      ($v_msg = z_concat(z_concat($v_m, ': brak argumentu $'), z_index(z_index($v_ps, $v_n), 2)));
      Z::$l = 426;
      ($v_act = [':Throw', $v_line, [':New', $v_line, 'Error', [[':Arg', 0, null, f_zs_invoke($v_this, 'mkstr', [$v_line, $v_msg]), false]]]]);
    } else {
      Z::$l = 428;
      ($v_act = [':Return', $v_line, f_zs_invoke($v_this, 'call', [$v_line, z_concat(z_concat($v_owner, '__'), $v_m), $v_cargs])]);
    }
    Z::$l = 430;
    if (z_truthy((z_truthy($v_isVar) && z_truthy(($v_n === $v_np))))) {
      Z::$l = 431;
      ($v_sl = f_zs_invoke($v_this, 'call', [$v_line, 'array_slice', [f_zs_invoke($v_this, 'mkvar', [$v_line, 'args']), [':Int', $v_line, $v_np]]]));
      Z::$l = 432;
      ($v_call = f_zs_invoke($v_this, 'call', [$v_line, z_concat(z_concat($v_owner, '__'), $v_m), $v_cargs]));
      Z::$l = 433;
      z_apush($v_call[z_k(3)], [':Arg', 0, null, $v_sl, true]);
      Z::$l = 434;
      ($v_act = [':Return', $v_line, $v_call]);
    }
    Z::$l = 436;
    ($v_cmp = (z_truthy(($v_n === $v_np)) ? [':Binary', $v_line, 'Ge', $v_cnt, [':Int', $v_line, $v_n]] : [':Binary', $v_line, 'Identical', $v_cnt, [':Int', $v_line, $v_n]]));
    Z::$l = 437;
    z_apush($v_body, [':If', $v_line, $v_cmp, [$v_act], null]);
  }
  Z::$l = 439;
  z_apush($v_body, [':Return', $v_line, [':Null', $v_line]]);
  Z::$l = 440;
  return f_zs_invoke($v_this, 'funcStmt', [$v_line, z_concat(z_concat(z_concat($v_owner, '__'), $v_m), '__w'), [f_zs_invoke($v_this, 'param', ['this']), f_zs_invoke($v_this, 'param', ['args'])], $v_body]);
  return null;
}
function f_Desugar__wrapperN($v_this, $v_owner, $v_m) {
  $v_f = null;
  $v_line = null;
  $v_args = null;
  $v_body = null;
  Z::$l = 444;
  ($v_f = z_index(z_index(z_b_zs_obj_get(z_index(z_b_zs_obj_get($v_this, 'classes'), $v_owner), 'methods'), $v_m), 'decl'));
  Z::$l = 445;
  ($v_line = z_index($v_f, 1));
  Z::$l = 446;
  ($v_args = f_Workspace_classes__prepend([':Arg', 0, null, f_zs_invoke($v_this, 'mkvar', [$v_line, 'this']), false], f_Workspace_closures__bindArgs($v_line, z_index($v_f, 3), 'args', $v_m)));
  Z::$l = 447;
  ($v_body = [[':Return', $v_line, [':Call', $v_line, f_zs_invoke($v_this, 'nm', [$v_line, z_concat(z_concat($v_owner, '__'), $v_m)]), $v_args]]]);
  Z::$l = 448;
  return f_zs_invoke($v_this, 'funcStmt', [$v_line, z_concat(z_concat(z_concat($v_owner, '__'), $v_m), '__wn'), [f_zs_invoke($v_this, 'param', ['this']), f_zs_invoke($v_this, 'param', ['args'])], $v_body]);
  return null;
}
function f_Desugar__genDispatchN($v_this) {
  $v_line = null;
  $v_body = null;
  $v_wrapped = null;
  $v_cn = null;
  $v_k = null;
  $v_stmts = null;
  $v_seen = null;
  $v_n = null;
  $v_m = null;
  $v_d = null;
  $v_wn = null;
  $v___r127 = null;
  $v___w128 = null;
  $v___r129 = null;
  $v___w130 = null;
  Z::$l = 452;
  ($v_line = 0);
  Z::$l = 453;
  ($v_body = []);
  Z::$l = 454;
  z_apush($v_body, [':Expr', $v_line, [':Assign', $v_line, f_zs_invoke($v_this, 'mkvar', [$v_line, 'c']), f_zs_invoke($v_this, 'call', [$v_line, 'zs_obj_class', [f_zs_invoke($v_this, 'mkvar', [$v_line, 'o'])]])]]);
  Z::$l = 455;
  ($v_wrapped = []);
  Z::$l = 456;
  foreach (z_foreach(z_b_zs_obj_get($v_this, 'classes')) as $_k142 => $_v142) {
    $v_k = $_v142;
    $v_cn = $_k142;
    Z::$l = 457;
    ($v_stmts = []);
    Z::$l = 458;
    ($v_seen = []);
    Z::$l = 459;
    foreach (z_foreach(f_zs_invoke($v_this, 'chain', [$v_cn])) as $_k143 => $_v143) {
      $v_n = $_v143;
      Z::$l = 460;
      foreach (z_foreach(z_b_zs_obj_get(z_index(z_b_zs_obj_get($v_this, 'classes'), $v_n), 'methods')) as $_k144 => $_v144) {
        $v_d = $_v144;
        $v_m = $_k144;
        Z::$l = 461;
        if (z_truthy((z_truthy((z_truthy((z_truthy((z_truthy(z_index($v_d, 'abstract')) || z_truthy(z_index($v_d, 'static')))) || z_truthy(($v_m === '__construct')))) || z_truthy(z_b_has_key($v_seen, $v_m)))) || z_truthy(!z_truthy(z_b_has_key(z_b_zs_obj_get($v_this, 'nuse'), $v_m)))))) {
          continue 1;
        }
        Z::$l = 462;
        z_aset($v_seen, $v_m, true);
        Z::$l = 463;
        ($v_wn = z_concat(z_concat(z_concat($v_n, '__'), $v_m), '__wn'));
        Z::$l = 464;
        if (z_truthy(!z_truthy(z_b_has_key($v_wrapped, $v_wn)))) {
          Z::$l = 464;
          z_aset($v_wrapped, $v_wn, true);
          Z::$l = 464;
          ($v___r127 = f_zs_invoke($v_this, 'wrapperN', [$v_n, $v_m]));
          Z::$l = 464;
          ($v___w128 = z_b_zs_obj_take($v_this, 'extra'));
          Z::$l = 464;
          z_apush($v___w128, $v___r127);
          Z::$l = 464;
          z_b_zs_obj_put($v_this, 'extra', $v___w128);
        }
        Z::$l = 465;
        z_apush($v_stmts, [':If', $v_line, [':Binary', $v_line, 'Identical', f_zs_invoke($v_this, 'mkvar', [$v_line, 'name']), f_zs_invoke($v_this, 'mkstr', [$v_line, $v_m])], [[':Return', $v_line, f_zs_invoke($v_this, 'call', [$v_line, $v_wn, [f_zs_invoke($v_this, 'mkvar', [$v_line, 'o']), f_zs_invoke($v_this, 'mkvar', [$v_line, 'args'])]])]], null]);
      }
    }
    Z::$l = 469;
    if (z_truthy((z_cmp(z_b_count($v_stmts), 0) > 0))) {
      Z::$l = 470;
      z_apush($v_body, [':If', $v_line, [':Binary', $v_line, 'Identical', f_zs_invoke($v_this, 'mkvar', [$v_line, 'c']), f_zs_invoke($v_this, 'mkstr', [$v_line, $v_cn])], $v_stmts, null]);
    }
  }
  Z::$l = 473;
  z_apush($v_body, [':Return', $v_line, f_zs_invoke($v_this, 'call', [$v_line, 'zs_no_method', [f_zs_invoke($v_this, 'mkvar', [$v_line, 'o']), f_zs_invoke($v_this, 'mkvar', [$v_line, 'name'])]])]);
  Z::$l = 474;
  ($v___r129 = f_zs_invoke($v_this, 'funcStmt', [$v_line, 'zs_invoke_n', [f_zs_invoke($v_this, 'param', ['o']), f_zs_invoke($v_this, 'param', ['name']), f_zs_invoke($v_this, 'param', ['args'])], $v_body]));
  Z::$l = 474;
  ($v___w130 = z_b_zs_obj_take($v_this, 'extra'));
  Z::$l = 474;
  z_apush($v___w130, $v___r129);
  Z::$l = 474;
  z_b_zs_obj_put($v_this, 'extra', $v___w130);
  return null;
}
function f_Desugar__genDispatch($v_this) {
  $v_line = null;
  $v_body = null;
  $v_wrapped = null;
  $v_cn = null;
  $v_k = null;
  $v_stmts = null;
  $v_seen = null;
  $v_n = null;
  $v_m = null;
  $v_d = null;
  $v_wn = null;
  $v___r131 = null;
  $v___w132 = null;
  $v___r133 = null;
  $v___w134 = null;
  $v_b = null;
  $v_or = null;
  $v_t = null;
  $v___r135 = null;
  $v___w136 = null;
  Z::$l = 478;
  if (z_truthy((z_cmp(z_b_count(z_b_zs_obj_get($v_this, 'nuse')), 0) > 0))) {
    Z::$l = 478;
    f_zs_invoke($v_this, 'genDispatchN', []);
  }
  Z::$l = 479;
  ($v_line = 0);
  Z::$l = 480;
  ($v_body = []);
  Z::$l = 481;
  z_apush($v_body, [':Expr', $v_line, [':Assign', $v_line, f_zs_invoke($v_this, 'mkvar', [$v_line, 'c']), f_zs_invoke($v_this, 'call', [$v_line, 'zs_obj_class', [f_zs_invoke($v_this, 'mkvar', [$v_line, 'o'])]])]]);
  Z::$l = 482;
  z_apush($v_body, [':If', $v_line, [':Binary', $v_line, 'Identical', f_zs_invoke($v_this, 'mkvar', [$v_line, 'c']), [':Null', $v_line]], [[':If', $v_line, [':Binary', $v_line, 'Identical', f_zs_invoke($v_this, 'mkvar', [$v_line, 'name']), f_zs_invoke($v_this, 'mkstr', [$v_line, 'getMessage'])], [[':Return', $v_line, [':Call', $v_line, [':Prop', $v_line, f_zs_invoke($v_this, 'mkvar', [$v_line, 'o']), 'getMessage'], []]]], null]], null]);
  Z::$l = 485;
  ($v_wrapped = []);
  Z::$l = 486;
  foreach (z_foreach(z_b_zs_obj_get($v_this, 'classes')) as $_k145 => $_v145) {
    $v_k = $_v145;
    $v_cn = $_k145;
    Z::$l = 487;
    ($v_stmts = []);
    Z::$l = 488;
    ($v_seen = []);
    Z::$l = 489;
    foreach (z_foreach(f_zs_invoke($v_this, 'chain', [$v_cn])) as $_k146 => $_v146) {
      $v_n = $_v146;
      Z::$l = 490;
      foreach (z_foreach(z_b_zs_obj_get(z_index(z_b_zs_obj_get($v_this, 'classes'), $v_n), 'methods')) as $_k147 => $_v147) {
        $v_d = $_v147;
        $v_m = $_k147;
        Z::$l = 491;
        if (z_truthy((z_truthy((z_truthy((z_truthy(z_index($v_d, 'abstract')) || z_truthy(z_index($v_d, 'static')))) || z_truthy(($v_m === '__construct')))) || z_truthy(z_b_has_key($v_seen, $v_m))))) {
          continue 1;
        }
        Z::$l = 492;
        z_aset($v_seen, $v_m, true);
        Z::$l = 493;
        ($v_wn = z_concat(z_concat(z_concat($v_n, '__'), $v_m), '__w'));
        Z::$l = 494;
        if (z_truthy(!z_truthy(z_b_has_key($v_wrapped, $v_wn)))) {
          Z::$l = 494;
          z_aset($v_wrapped, $v_wn, true);
          Z::$l = 494;
          ($v___r131 = f_zs_invoke($v_this, 'wrapper', [$v_n, $v_m]));
          Z::$l = 494;
          ($v___w132 = z_b_zs_obj_take($v_this, 'extra'));
          Z::$l = 494;
          z_apush($v___w132, $v___r131);
          Z::$l = 494;
          z_b_zs_obj_put($v_this, 'extra', $v___w132);
        }
        Z::$l = 495;
        z_apush($v_stmts, [':If', $v_line, [':Binary', $v_line, 'Identical', f_zs_invoke($v_this, 'mkvar', [$v_line, 'name']), f_zs_invoke($v_this, 'mkstr', [$v_line, $v_m])], [[':Return', $v_line, f_zs_invoke($v_this, 'call', [$v_line, $v_wn, [f_zs_invoke($v_this, 'mkvar', [$v_line, 'o']), f_zs_invoke($v_this, 'mkvar', [$v_line, 'args'])]])]], null]);
      }
    }
    Z::$l = 499;
    if (z_truthy((z_cmp(z_b_count($v_stmts), 0) > 0))) {
      Z::$l = 500;
      z_apush($v_body, [':If', $v_line, [':Binary', $v_line, 'Identical', f_zs_invoke($v_this, 'mkvar', [$v_line, 'c']), f_zs_invoke($v_this, 'mkstr', [$v_line, $v_cn])], $v_stmts, null]);
    }
  }
  Z::$l = 503;
  z_apush($v_body, [':Return', $v_line, f_zs_invoke($v_this, 'call', [$v_line, 'zs_no_method', [f_zs_invoke($v_this, 'mkvar', [$v_line, 'o']), f_zs_invoke($v_this, 'mkvar', [$v_line, 'name'])]])]);
  Z::$l = 504;
  ($v___r133 = f_zs_invoke($v_this, 'funcStmt', [$v_line, 'zs_invoke', [f_zs_invoke($v_this, 'param', ['o']), f_zs_invoke($v_this, 'param', ['name']), f_zs_invoke($v_this, 'param', ['args'])], $v_body]));
  Z::$l = 504;
  ($v___w134 = z_b_zs_obj_take($v_this, 'extra'));
  Z::$l = 504;
  z_apush($v___w134, $v___r133);
  Z::$l = 504;
  z_b_zs_obj_put($v_this, 'extra', $v___w134);
  Z::$l = 506;
  ($v_b = []);
  Z::$l = 507;
  z_apush($v_b, [':Expr', $v_line, [':Assign', $v_line, f_zs_invoke($v_this, 'mkvar', [$v_line, 'c']), f_zs_invoke($v_this, 'call', [$v_line, 'zs_obj_class', [f_zs_invoke($v_this, 'mkvar', [$v_line, 'o'])]])]]);
  Z::$l = 508;
  z_apush($v_b, [':If', $v_line, [':Binary', $v_line, 'Identical', f_zs_invoke($v_this, 'mkvar', [$v_line, 'c']), [':Null', $v_line]], [[':Expr', $v_line, [':Assign', $v_line, f_zs_invoke($v_this, 'mkvar', [$v_line, 't']), f_zs_invoke($v_this, 'call', [$v_line, 'typeof', [f_zs_invoke($v_this, 'mkvar', [$v_line, 'o'])]])]], [':Return', $v_line, [':Binary', $v_line, 'Or', [':Binary', $v_line, 'Identical', f_zs_invoke($v_this, 'mkvar', [$v_line, 't']), f_zs_invoke($v_this, 'mkvar', [$v_line, 'k'])], [':Binary', $v_line, 'Or', [':Binary', $v_line, 'And', [':Binary', $v_line, 'Identical', f_zs_invoke($v_this, 'mkvar', [$v_line, 'k']), f_zs_invoke($v_this, 'mkstr', [$v_line, 'Exception'])], [':Binary', $v_line, 'Identical', f_zs_invoke($v_this, 'mkvar', [$v_line, 't']), f_zs_invoke($v_this, 'mkstr', [$v_line, 'Error'])]], [':Binary', $v_line, 'And', [':Binary', $v_line, 'Identical', f_zs_invoke($v_this, 'mkvar', [$v_line, 'k']), f_zs_invoke($v_this, 'mkstr', [$v_line, 'Throwable'])], [':Binary', $v_line, 'Or', [':Binary', $v_line, 'Identical', f_zs_invoke($v_this, 'mkvar', [$v_line, 't']), f_zs_invoke($v_this, 'mkstr', [$v_line, 'Exception'])], [':Binary', $v_line, 'Identical', f_zs_invoke($v_this, 'mkvar', [$v_line, 't']), f_zs_invoke($v_this, 'mkstr', [$v_line, 'Error'])]]]]]]], null]);
  Z::$l = 515;
  foreach (z_foreach(z_b_zs_obj_get($v_this, 'classes')) as $_k148 => $_v148) {
    $v_k = $_v148;
    $v_cn = $_k148;
    Z::$l = 516;
    ($v_or = null);
    Z::$l = 517;
    foreach (z_foreach(f_zs_invoke($v_this, 'isaNames', [$v_cn])) as $_k149 => $_v149) {
      $v_n = $_v149;
      Z::$l = 518;
      ($v_t = [':Binary', $v_line, 'Identical', f_zs_invoke($v_this, 'mkvar', [$v_line, 'k']), f_zs_invoke($v_this, 'mkstr', [$v_line, $v_n])]);
      Z::$l = 519;
      ($v_or = (z_truthy(($v_or === null)) ? $v_t : [':Binary', $v_line, 'Or', $v_or, $v_t]));
    }
    Z::$l = 521;
    z_apush($v_b, [':If', $v_line, [':Binary', $v_line, 'Identical', f_zs_invoke($v_this, 'mkvar', [$v_line, 'c']), f_zs_invoke($v_this, 'mkstr', [$v_line, $v_cn])], [[':Return', $v_line, $v_or]], null]);
  }
  Z::$l = 523;
  z_apush($v_b, [':Return', $v_line, [':Bool', $v_line, false]]);
  Z::$l = 524;
  ($v___r135 = f_zs_invoke($v_this, 'funcStmt', [$v_line, 'zs_isa', [f_zs_invoke($v_this, 'param', ['o']), f_zs_invoke($v_this, 'param', ['k'])], $v_b]));
  Z::$l = 524;
  ($v___w136 = z_b_zs_obj_take($v_this, 'extra'));
  Z::$l = 524;
  z_apush($v___w136, $v___r135);
  Z::$l = 524;
  z_b_zs_obj_put($v_this, 'extra', $v___w136);
  return null;
}
function f_Desugar__new() {
  $v___o = null;
  Z::$l = 27;
  ($v___o = z_b_zs_obj_new('Desugar'));
  Z::$l = 27;
  z_b_zs_obj_set($v___o, 'classes', []);
  Z::$l = 27;
  z_b_zs_obj_set($v___o, 'errors', []);
  Z::$l = 27;
  z_b_zs_obj_set($v___o, 'tmp', 0);
  Z::$l = 27;
  z_b_zs_obj_set($v___o, 'cur', null);
  Z::$l = 27;
  z_b_zs_obj_set($v___o, 'curStatic', false);
  Z::$l = 27;
  z_b_zs_obj_set($v___o, 'dispatch', []);
  Z::$l = 27;
  z_b_zs_obj_set($v___o, 'extra', []);
  Z::$l = 27;
  z_b_zs_obj_set($v___o, 'nuse', []);
  Z::$l = 27;
  z_b_zs_obj_set($v___o, 'excMode', false);
  Z::$l = 27;
  return $v___o;
  return null;
}
function f_Linker__err($v_this, $v_file, $v_line, $v_code, $v_msg) {
  $v___r137 = null;
  $v___w138 = null;
  Z::$l = 25;
  ($v___r137 = [$v_line, $v_code, $v_msg, $v_file]);
  Z::$l = 25;
  ($v___w138 = z_b_zs_obj_take($v_this, 'errors'));
  Z::$l = 25;
  z_apush($v___w138, $v___r137);
  Z::$l = 25;
  z_b_zs_obj_put($v_this, 'errors', $v___w138);
  return null;
}
function f_Linker__prefixOf($v_this, $v_path) {
  Z::$l = 27;
  return z_b_join($v_path, '_');
  return null;
}
function f_Linker__dirOf($v_this, $v_file) {
  $v_d = null;
  Z::$l = 30;
  ($v_d = z_m_System_dirname($v_file));
  Z::$l = 31;
  return (z_truthy((z_truthy(($v_d === null)) || z_truthy(($v_d === '')))) ? '.' : $v_d);
  return null;
}
function f_Linker__rw($v_this, $v_x, $v_self, $v_funcs, $v_aliases) {
  $v_callee = null;
  $v_m = null;
  $v_args = null;
  $v_a = null;
  $v_o = null;
  $v_k = null;
  $v_v = null;
  Z::$l = 36;
  if (z_truthy(!z_truthy(z_b_is_array($v_x)))) {
    Z::$l = 36;
    return $v_x;
  }
  Z::$l = 37;
  if (z_truthy((z_truthy(f_Workspace_parser__isNode($v_x)) && z_truthy((z_index($v_x, 0) === ':Call'))))) {
    Z::$l = 38;
    ($v_callee = z_index($v_x, 2));
    Z::$l = 39;
    if (z_truthy((z_truthy((z_truthy((z_index($v_callee, 0) === ':Name')) && z_truthy(($v_self !== null)))) && z_truthy(z_b_has_key($v_funcs, z_index($v_callee, 2)))))) {
      Z::$l = 40;
      z_aset($v_callee, 2, z_concat(z_concat($v_self, '__'), z_index($v_callee, 2)));
      Z::$l = 41;
      z_aset($v_x, 2, $v_callee);
    } else {
      Z::$l = 42;
      if (z_truthy((z_truthy((z_truthy((z_index($v_callee, 0) === ':Dot')) && z_truthy((z_index(z_index($v_callee, 2), 0) === ':Name')))) && z_truthy(z_b_has_key($v_aliases, z_index(z_index($v_callee, 2), 2)))))) {
        Z::$l = 43;
        ($v_m = z_index($v_aliases, z_index(z_index($v_callee, 2), 2)));
        Z::$l = 44;
        z_aset($v_x, 2, [':Name', z_index($v_callee, 1), z_concat(z_concat(z_index($v_m, 'prefix'), '__'), z_index($v_callee, 3))]);
      }
    }
    Z::$l = 46;
    ($v_args = []);
    Z::$l = 47;
    foreach (z_foreach(z_index($v_x, 3)) as $_k150 => $_v150) {
      $v_a = $_v150;
      Z::$l = 47;
      z_apush($v_args, f_zs_invoke($v_this, 'rw', [$v_a, $v_self, $v_funcs, $v_aliases]));
    }
    Z::$l = 48;
    z_aset($v_x, 3, $v_args);
    Z::$l = 49;
    if (z_truthy((z_index(z_index($v_x, 2), 0) !== ':Dot'))) {
      Z::$l = 49;
      z_aset($v_x, 2, f_zs_invoke($v_this, 'rw', [z_index($v_x, 2), $v_self, $v_funcs, $v_aliases]));
    }
    Z::$l = 50;
    return $v_x;
  }
  Z::$l = 52;
  if (z_truthy((z_truthy((z_truthy((z_truthy((z_truthy(f_Workspace_parser__isNode($v_x)) && z_truthy((z_index($v_x, 0) === ':Dot')))) && z_truthy((z_index(z_index($v_x, 2), 0) === ':Name')))) && z_truthy((z_index(z_index($v_x, 2), 2) === 'System')))) && z_truthy((z_index($v_x, 3) === 'version'))))) {
    Z::$l = 53;
    return [':Call', z_index($v_x, 1), $v_x, []];
  }
  Z::$l = 55;
  ($v_o = []);
  Z::$l = 56;
  foreach (z_foreach($v_x) as $_k151 => $_v151) {
    $v_v = $_v151;
    $v_k = $_k151;
    Z::$l = 56;
    z_aset($v_o, $v_k, f_zs_invoke($v_this, 'rw', [$v_v, $v_self, $v_funcs, $v_aliases]));
  }
  Z::$l = 57;
  return $v_o;
  return null;
}
function f_Linker__loadModule($v_this, $v_file, $v_path, $v_fromFile, $v_line) {
  $v___k139 = null;
  $v___r140 = null;
  $v___w141 = null;
  $v_ast = null;
  $v___ex142 = null;
  $v_e = null;
  $v___k143 = null;
  $v___r144 = null;
  $v___w145 = null;
  $v_prefix = null;
  $v_funcs = null;
  $v_s = null;
  $v_aliases = null;
  $v_stmts = null;
  $v_k = null;
  $v_f = null;
  $v___k146 = null;
  $v___r147 = null;
  $v___w148 = null;
  $v_m = null;
  $v___k149 = null;
  $v___r150 = null;
  $v___w151 = null;
  $v___r152 = null;
  $v___w153 = null;
  Z::$l = 62;
  if (z_truthy(z_b_has_key(z_b_zs_obj_get($v_this, 'loaded'), $v_file))) {
    Z::$l = 62;
    return z_index(z_b_zs_obj_get($v_this, 'loaded'), $v_file);
  }
  Z::$l = 63;
  if (z_truthy((($_t30 = z_indexopt(z_b_zs_obj_get($v_this, 'active'), $v_file)) !== null ? $_t30 : false))) {
    Z::$l = 63;
    f_zs_invoke($v_this, 'err', [$v_fromFile, $v_line, 'E0106', z_concat('cykliczny import ', z_b_join($v_path, '.'))]);
    Z::$l = 63;
    return null;
  }
  Z::$l = 64;
  ($v___k139 = $v_file);
  Z::$l = 64;
  ($v___r140 = true);
  Z::$l = 64;
  ($v___w141 = z_b_zs_obj_take($v_this, 'active'));
  Z::$l = 64;
  z_aset($v___w141, $v___k139, $v___r140);
  Z::$l = 64;
  z_b_zs_obj_put($v_this, 'active', $v___w141);
  try {
    Z::$l = 65;
    ($v_ast = f_Workspace_parser__parse(z_m_File_read($v_file)));
  } catch (ZEx $_ex152) {
    $_e152 = $_ex152->val;
    if (true) {
      $v___ex142 = $_e152;
      Z::$l = 65;
      if (z_truthy(f_zs_isa($v___ex142, 'Exception'))) {
        Z::$l = 65;
        ($v_e = $v___ex142);
        Z::$l = 66;
        f_zs_invoke($v_this, 'err', [$v_file, 0, 'E0106', z_concat('błąd składni modułu: ', f_zs_invoke($v_e, 'getMessage', []))]);
        Z::$l = 66;
        ($v___k143 = $v_file);
        Z::$l = 66;
        ($v___r144 = false);
        Z::$l = 66;
        ($v___w145 = z_b_zs_obj_take($v_this, 'active'));
        Z::$l = 66;
        z_aset($v___w145, $v___k143, $v___r144);
        Z::$l = 66;
        z_b_zs_obj_put($v_this, 'active', $v___w145);
        Z::$l = 66;
        return null;
      } else {
        Z::$l = 65;
        z_throwv($v___ex142);
      }
    }
    else throw $_ex152;
  }
  Z::$l = 67;
  ($v_prefix = f_zs_invoke($v_this, 'prefixOf', [$v_path]));
  Z::$l = 68;
  ($v_funcs = []);
  Z::$l = 69;
  foreach (z_foreach($v_ast) as $_k153 => $_v153) {
    $v_s = $_v153;
    Z::$l = 69;
    if (z_truthy((z_index($v_s, 0) === ':FuncStmt'))) {
      Z::$l = 69;
      z_aset($v_funcs, z_index(z_index($v_s, 2), 2), true);
    }
  }
  Z::$l = 70;
  ($v_aliases = f_zs_invoke($v_this, 'collectImports', [$v_ast, $v_file]));
  Z::$l = 71;
  ($v_stmts = []);
  Z::$l = 72;
  foreach (z_foreach($v_ast) as $_k154 => $_v154) {
    $v_s = $_v154;
    Z::$l = 73;
    ($v_k = z_index($v_s, 0));
    Z::$l = 74;
    if (z_truthy(($v_k === ':FuncStmt'))) {
      Z::$l = 75;
      ($v_f = z_index($v_s, 2));
      Z::$l = 76;
      z_aset($v_f, 2, z_concat(z_concat($v_prefix, '__'), z_index($v_f, 2)));
      Z::$l = 77;
      z_aset($v_f, 5, f_zs_invoke($v_this, 'rw', [z_index($v_f, 5), $v_prefix, $v_funcs, $v_aliases]));
      Z::$l = 78;
      z_aset($v_s, 2, $v_f);
      Z::$l = 79;
      z_apush($v_stmts, $v_s);
    } else {
      Z::$l = 80;
      if (z_truthy(($v_k === ':ClassStmt'))) {
        Z::$l = 81;
        z_apush($v_stmts, f_zs_invoke($v_this, 'rw', [$v_s, $v_prefix, $v_funcs, $v_aliases]));
      } else {
        Z::$l = 82;
        if (z_truthy((z_truthy(($v_k !== ':Import')) && z_truthy(($v_k !== ':Namespace'))))) {
          Z::$l = 83;
          f_zs_invoke($v_this, 'err', [$v_file, z_index($v_s, 1), 'E0106', z_concat(z_concat('moduł natywny może zawierać tylko funkcje, klasy, import i namespace (instrukcja ', z_b_substr($v_k, 1)), ')')]);
        }
      }
    }
  }
  Z::$l = 86;
  ($v___k146 = $v_file);
  Z::$l = 86;
  ($v___r147 = false);
  Z::$l = 86;
  ($v___w148 = z_b_zs_obj_take($v_this, 'active'));
  Z::$l = 86;
  z_aset($v___w148, $v___k146, $v___r147);
  Z::$l = 86;
  z_b_zs_obj_put($v_this, 'active', $v___w148);
  Z::$l = 87;
  ($v_m = [z_k('prefix') => $v_prefix, z_k('funcs') => $v_funcs]);
  Z::$l = 88;
  ($v___k149 = $v_file);
  Z::$l = 88;
  ($v___r150 = $v_m);
  Z::$l = 88;
  ($v___w151 = z_b_zs_obj_take($v_this, 'loaded'));
  Z::$l = 88;
  z_aset($v___w151, $v___k149, $v___r150);
  Z::$l = 88;
  z_b_zs_obj_put($v_this, 'loaded', $v___w151);
  Z::$l = 89;
  foreach (z_foreach($v_stmts) as $_k155 => $_v155) {
    $v_s = $_v155;
    Z::$l = 89;
    ($v___r152 = $v_s);
    Z::$l = 89;
    ($v___w153 = z_b_zs_obj_take($v_this, 'out'));
    Z::$l = 89;
    z_apush($v___w153, $v___r152);
    Z::$l = 89;
    z_b_zs_obj_put($v_this, 'out', $v___w153);
  }
  Z::$l = 90;
  return $v_m;
  return null;
}
function f_Linker__collectImports($v_this, $v_ast, $v_file) {
  $v_aliases = null;
  $v_s = null;
  $v_path = null;
  $v_f = null;
  $v_m = null;
  Z::$l = 95;
  ($v_aliases = []);
  Z::$l = 96;
  foreach (z_foreach($v_ast) as $_k156 => $_v156) {
    $v_s = $_v156;
    Z::$l = 97;
    if (z_truthy((z_index($v_s, 0) !== ':Import'))) {
      continue 1;
    }
    Z::$l = 98;
    ($v_path = z_index($v_s, 2));
    Z::$l = 99;
    if (z_truthy(z_b_in_array(z_index($v_path, 0), f_Workspace_link__builtin_modules()))) {
      continue 1;
    }
    Z::$l = 100;
    ($v_f = z_m_System_resolveImport($v_path, f_zs_invoke($v_this, 'dirOf', [$v_file])));
    Z::$l = 101;
    if (z_truthy(($v_f === null))) {
      Z::$l = 101;
      f_zs_invoke($v_this, 'err', [$v_file, z_index($v_s, 1), 'E0106', z_concat('nie znaleziono modułu ', z_b_join($v_path, '.'))]);
      continue 1;
    }
    Z::$l = 102;
    ($v_m = f_zs_invoke($v_this, 'loadModule', [$v_f, $v_path, $v_file, z_index($v_s, 1)]));
    Z::$l = 103;
    if (z_truthy(($v_m !== null))) {
      Z::$l = 103;
      z_aset($v_aliases, z_index($v_path, z_sub(z_b_count($v_path), 1)), $v_m);
    }
  }
  Z::$l = 105;
  return $v_aliases;
  return null;
}
function f_Linker__new() {
  $v___o = null;
  Z::$l = 19;
  ($v___o = z_b_zs_obj_new('Linker'));
  Z::$l = 19;
  z_b_zs_obj_set($v___o, 'errors', []);
  Z::$l = 19;
  z_b_zs_obj_set($v___o, 'loaded', []);
  Z::$l = 19;
  z_b_zs_obj_set($v___o, 'active', []);
  Z::$l = 19;
  z_b_zs_obj_set($v___o, 'out', []);
  Z::$l = 19;
  return $v___o;
  return null;
}
function f_VarPass__rw($v_this, $v_x) {
  $v_k = null;
  $v_args = null;
  $v_a = null;
  $v_out = null;
  $v_i = null;
  $v___r154 = null;
  $v___w155 = null;
  $v_named = null;
  $v_ps = null;
  $v___r156 = null;
  $v___w157 = null;
  $v_rest = null;
  $v_items = null;
  $v___r158 = null;
  $v___w159 = null;
  $v_o = null;
  $v_v = null;
  Z::$l = 152;
  if (z_truthy(!z_truthy(z_b_is_array($v_x)))) {
    Z::$l = 152;
    return $v_x;
  }
  Z::$l = 153;
  if (z_truthy((z_truthy((z_truthy((z_truthy(f_Workspace_parser__isNode($v_x)) && z_truthy((z_index($v_x, 0) === ':Call')))) && z_truthy((z_index(z_index($v_x, 2), 0) === ':Name')))) && z_truthy(z_b_has_key(z_b_zs_obj_get($v_this, 'fixed'), z_index(z_index($v_x, 2), 2)))))) {
    Z::$l = 154;
    ($v_k = z_index(z_b_zs_obj_get($v_this, 'fixed'), z_index(z_index($v_x, 2), 2)));
    Z::$l = 155;
    ($v_args = []);
    Z::$l = 156;
    foreach (z_foreach(z_index($v_x, 3)) as $_k157 => $_v157) {
      $v_a = $_v157;
      Z::$l = 156;
      z_aset($v_a, 3, f_zs_invoke($v_this, 'rw', [z_index($v_a, 3)]));
      Z::$l = 156;
      z_apush($v_args, $v_a);
    }
    Z::$l = 157;
    ($v_out = []);
    Z::$l = 158;
    ($v_i = 0);
    for (; z_truthy((z_truthy((z_cmp($v_i, z_b_count($v_args)) < 0)) && z_truthy((z_cmp($v_i, $v_k) < 0)))); z_last($_t31 = $v_i, $v_i = z_add($_t31, 1), $_t31)) {
      Z::$l = 159;
      if (z_truthy(z_index(z_index($v_args, $v_i), 4))) {
        Z::$l = 159;
        ($v___r154 = [z_index($v_x, 1), 'E0104', 'rozwinięcie ... w pozycji stałego parametru niedostępne w backendzie natywnym 0.0.1']);
        Z::$l = 159;
        ($v___w155 = z_b_zs_obj_take($v_this, 'errors'));
        Z::$l = 159;
        z_apush($v___w155, $v___r154);
        Z::$l = 159;
        z_b_zs_obj_put($v_this, 'errors', $v___w155);
      }
      Z::$l = 160;
      z_apush($v_out, z_index($v_args, $v_i));
    }
    Z::$l = 162;
    ($v_named = false);
    Z::$l = 163;
    foreach (z_foreach($v_args) as $_k159 => $_v159) {
      $v_a = $_v159;
      Z::$l = 163;
      if (z_truthy((z_index($v_a, 2) !== null))) {
        Z::$l = 163;
        ($v_named = true);
      }
    }
    Z::$l = 164;
    if (z_truthy(!z_truthy($v_named))) {
      Z::$l = 165;
      ($v_ps = z_index(z_b_zs_obj_get($v_this, 'defs'), z_index(z_index($v_x, 2), 2)));
      Z::$l = 166;
      ($v_i = z_b_count($v_out));
      for (; z_truthy((z_cmp($v_i, $v_k) < 0)); z_last($_t32 = $v_i, $v_i = z_add($_t32, 1), $_t32)) {
        Z::$l = 167;
        if (z_truthy((z_index(z_index($v_ps, $v_i), 4) === null))) {
          Z::$l = 167;
          ($v___r156 = [z_index($v_x, 1), 'E0104', 'za mało argumentów w wywołaniu funkcji wariadycznej']);
          Z::$l = 167;
          ($v___w157 = z_b_zs_obj_take($v_this, 'errors'));
          Z::$l = 167;
          z_apush($v___w157, $v___r156);
          Z::$l = 167;
          z_b_zs_obj_put($v_this, 'errors', $v___w157);
        } else {
          Z::$l = 168;
          z_apush($v_out, [':Arg', 0, null, z_index(z_index($v_ps, $v_i), 4), false]);
        }
      }
    }
    Z::$l = 171;
    ($v_rest = []);
    Z::$l = 172;
    ($v_i = $v_k);
    for (; z_truthy((z_cmp($v_i, z_b_count($v_args)) < 0)); z_last($_t33 = $v_i, $v_i = z_add($_t33, 1), $_t33)) {
      Z::$l = 172;
      z_apush($v_rest, z_index($v_args, $v_i));
    }
    Z::$l = 173;
    if (z_truthy((z_truthy((z_b_count($v_rest) === 1)) && z_truthy(z_index(z_index($v_rest, 0), 4))))) {
      Z::$l = 174;
      ($v_a = z_index($v_rest, 0));
      Z::$l = 174;
      z_aset($v_a, 4, false);
      Z::$l = 174;
      z_apush($v_out, $v_a);
    } else {
      Z::$l = 176;
      ($v_items = []);
      Z::$l = 177;
      foreach (z_foreach($v_rest) as $_k162 => $_v162) {
        $v_a = $_v162;
        Z::$l = 178;
        if (z_truthy(z_index($v_a, 4))) {
          Z::$l = 178;
          ($v___r158 = [z_index($v_x, 1), 'E0104', 'rozwinięcie ... wśród innych argumentów wariadycznych niedostępne w backendzie natywnym 0.0.1']);
          Z::$l = 178;
          ($v___w159 = z_b_zs_obj_take($v_this, 'errors'));
          Z::$l = 178;
          z_apush($v___w159, $v___r158);
          Z::$l = 178;
          z_b_zs_obj_put($v_this, 'errors', $v___w159);
        }
        Z::$l = 179;
        z_apush($v_items, [':Item', 0, null, z_index($v_a, 3), false]);
      }
      Z::$l = 181;
      z_apush($v_out, [':Arg', 0, null, [':Array', z_index($v_x, 1), $v_items], false]);
    }
    Z::$l = 183;
    z_aset($v_x, 3, $v_out);
    Z::$l = 184;
    return $v_x;
  }
  Z::$l = 186;
  ($v_o = []);
  Z::$l = 187;
  foreach (z_foreach($v_x) as $_k163 => $_v163) {
    $v_v = $_v163;
    $v_k = $_k163;
    Z::$l = 187;
    z_aset($v_o, $v_k, f_zs_invoke($v_this, 'rw', [$v_v]));
  }
  Z::$l = 188;
  return $v_o;
  return null;
}
function f_VarPass__new() {
  $v___o = null;
  Z::$l = 146;
  ($v___o = z_b_zs_obj_new('VarPass'));
  Z::$l = 146;
  z_b_zs_obj_set($v___o, 'fixed', []);
  Z::$l = 146;
  z_b_zs_obj_set($v___o, 'defs', []);
  Z::$l = 146;
  z_b_zs_obj_set($v___o, 'errors', []);
  Z::$l = 146;
  return $v___o;
  return null;
}
function f_LlEmitter____construct($v_this, $v_ir) {
  Z::$l = 38;
  z_b_zs_obj_set($v_this, 'ir', $v_ir);
  Z::$l = 39;
  z_b_zs_obj_set($v_this, 'code', []);
  Z::$l = 40;
  z_b_zs_obj_set($v_this, 'allocas', []);
  Z::$l = 41;
  z_b_zs_obj_set($v_this, 'globals', []);
  Z::$l = 42;
  z_b_zs_obj_set($v_this, 'strs', []);
  Z::$l = 43;
  z_b_zs_obj_set($v_this, 'strList', []);
  Z::$l = 44;
  z_b_zs_obj_set($v_this, 'cstrs', []);
  Z::$l = 45;
  z_b_zs_obj_set($v_this, 'cstrList', []);
  Z::$l = 46;
  z_b_zs_obj_set($v_this, 'floats', []);
  Z::$l = 47;
  z_b_zs_obj_set($v_this, 'tmp', 0);
  Z::$l = 48;
  z_b_zs_obj_set($v_this, 'lbl', 0);
  Z::$l = 49;
  z_b_zs_obj_set($v_this, 'loops', []);
  Z::$l = 50;
  z_b_zs_obj_set($v_this, 'loopId', 0);
  Z::$l = 51;
  z_b_zs_obj_set($v_this, 'tries', []);
  Z::$l = 52;
  z_b_zs_obj_set($v_this, 'rdStack', []);
  Z::$l = 53;
  z_b_zs_obj_set($v_this, 'fnCounts', []);
  Z::$l = 54;
  z_b_zs_obj_set($v_this, 'hid', 0);
  Z::$l = 55;
  z_b_zs_obj_set($v_this, 'curFunc', '');
  Z::$l = 56;
  z_b_zs_obj_set($v_this, 'term', false);
  Z::$l = 57;
  z_b_zs_obj_set($v_this, 'vol', '');
  Z::$l = 58;
  z_b_zs_obj_set($v_this, 'slotN', 0);
  return null;
}
function f_LlEmitter__r($v_this) {
  Z::$l = 62;
  z_b_zs_obj_set($v_this, 'tmp', z_add(z_b_zs_obj_get($v_this, 'tmp'), 1));
  Z::$l = 62;
  return z_concat('%t', z_b_zs_obj_get($v_this, 'tmp'));
  return null;
}
function f_LlEmitter__newLabel($v_this, $v_p) {
  Z::$l = 63;
  z_b_zs_obj_set($v_this, 'lbl', z_add(z_b_zs_obj_get($v_this, 'lbl'), 1));
  Z::$l = 63;
  return z_concat($v_p, z_b_zs_obj_get($v_this, 'lbl'));
  return null;
}
function f_LlEmitter__line($v_this, $v_s) {
  $v___r160 = null;
  $v___w161 = null;
  Z::$l = 66;
  if (z_truthy(z_b_zs_obj_get($v_this, 'term'))) {
    Z::$l = 66;
    f_zs_invoke($v_this, 'label', [f_zs_invoke($v_this, 'newLabel', ['dead'])]);
  }
  Z::$l = 67;
  ($v___r160 = z_concat('  ', $v_s));
  Z::$l = 67;
  ($v___w161 = z_b_zs_obj_take($v_this, 'code'));
  Z::$l = 67;
  z_apush($v___w161, $v___r160);
  Z::$l = 67;
  z_b_zs_obj_put($v_this, 'code', $v___w161);
  return null;
}
function f_LlEmitter__label($v_this, $v_l) {
  $v___r162 = null;
  $v___w163 = null;
  $v___r164 = null;
  $v___w165 = null;
  Z::$l = 71;
  if (z_truthy(!z_truthy(z_b_zs_obj_get($v_this, 'term')))) {
    Z::$l = 71;
    ($v___r162 = z_concat('  br label %', $v_l));
    Z::$l = 71;
    ($v___w163 = z_b_zs_obj_take($v_this, 'code'));
    Z::$l = 71;
    z_apush($v___w163, $v___r162);
    Z::$l = 71;
    z_b_zs_obj_put($v_this, 'code', $v___w163);
  }
  Z::$l = 72;
  ($v___r164 = z_concat($v_l, ':'));
  Z::$l = 72;
  ($v___w165 = z_b_zs_obj_take($v_this, 'code'));
  Z::$l = 72;
  z_apush($v___w165, $v___r164);
  Z::$l = 72;
  z_b_zs_obj_put($v_this, 'code', $v___w165);
  Z::$l = 73;
  z_b_zs_obj_set($v_this, 'term', false);
  return null;
}
function f_LlEmitter__terminate($v_this, $v_s) {
  $v___r166 = null;
  $v___w167 = null;
  Z::$l = 77;
  if (z_truthy(z_b_zs_obj_get($v_this, 'term'))) {
    Z::$l = 77;
    f_zs_invoke($v_this, 'label', [f_zs_invoke($v_this, 'newLabel', ['dead'])]);
  }
  Z::$l = 78;
  ($v___r166 = z_concat('  ', $v_s));
  Z::$l = 78;
  ($v___w167 = z_b_zs_obj_take($v_this, 'code'));
  Z::$l = 78;
  z_apush($v___w167, $v___r166);
  Z::$l = 78;
  z_b_zs_obj_put($v_this, 'code', $v___w167);
  Z::$l = 79;
  z_b_zs_obj_set($v_this, 'term', true);
  return null;
}
function f_LlEmitter__esc($v_this, $v_s) {
  $v_out = null;
  $v_c = null;
  $v_o = null;
  Z::$l = 83;
  ($v_out = '');
  Z::$l = 84;
  foreach (z_foreach(z_b_chars($v_s)) as $_k164 => $_v164) {
    $v_c = $_v164;
    Z::$l = 85;
    ($v_o = z_b_ord($v_c));
    Z::$l = 86;
    if (z_truthy((z_cmp(z_b_strlen($v_c), 1) > 0))) {
      Z::$l = 86;
      ($v_out = z_concat($v_out, $v_c));
    } else {
      Z::$l = 87;
      if (z_truthy((z_truthy((z_truthy((z_truthy((z_cmp($v_o, 32) < 0)) || z_truthy((z_cmp($v_o, 127) >= 0)))) || z_truthy(($v_c === '\\')))) || z_truthy(($v_c === '"'))))) {
        Z::$l = 87;
        ($v_out = z_concat($v_out, z_concat('\\', f_Workspace_emit_llvm__hex2($v_o))));
      } else {
        Z::$l = 88;
        ($v_out = z_concat($v_out, $v_c));
      }
    }
  }
  Z::$l = 90;
  return $v_out;
  return null;
}
function f_LlEmitter__cstr($v_this, $v_s) {
  $v___k168 = null;
  $v___r169 = null;
  $v___w170 = null;
  $v___r171 = null;
  $v___w172 = null;
  Z::$l = 95;
  if (z_truthy(!z_truthy(z_b_has_key(z_b_zs_obj_get($v_this, 'cstrs'), $v_s)))) {
    Z::$l = 96;
    ($v___k168 = $v_s);
    Z::$l = 96;
    ($v___r169 = z_b_count(z_b_zs_obj_get($v_this, 'cstrList')));
    Z::$l = 96;
    ($v___w170 = z_b_zs_obj_take($v_this, 'cstrs'));
    Z::$l = 96;
    z_aset($v___w170, $v___k168, $v___r169);
    Z::$l = 96;
    z_b_zs_obj_put($v_this, 'cstrs', $v___w170);
    Z::$l = 97;
    ($v___r171 = $v_s);
    Z::$l = 97;
    ($v___w172 = z_b_zs_obj_take($v_this, 'cstrList'));
    Z::$l = 97;
    z_apush($v___w172, $v___r171);
    Z::$l = 97;
    z_b_zs_obj_put($v_this, 'cstrList', $v___w172);
  }
  Z::$l = 99;
  return z_concat('@.c', z_index(z_b_zs_obj_get($v_this, 'cstrs'), $v_s));
  return null;
}
function f_LlEmitter__strSlot($v_this, $v_s) {
  $v___k173 = null;
  $v___r174 = null;
  $v___w175 = null;
  $v___r176 = null;
  $v___w177 = null;
  Z::$l = 104;
  if (z_truthy(!z_truthy(z_b_has_key(z_b_zs_obj_get($v_this, 'strs'), $v_s)))) {
    Z::$l = 105;
    ($v___k173 = $v_s);
    Z::$l = 105;
    ($v___r174 = z_b_count(z_b_zs_obj_get($v_this, 'strList')));
    Z::$l = 105;
    ($v___w175 = z_b_zs_obj_take($v_this, 'strs'));
    Z::$l = 105;
    z_aset($v___w175, $v___k173, $v___r174);
    Z::$l = 105;
    z_b_zs_obj_put($v_this, 'strs', $v___w175);
    Z::$l = 106;
    ($v___r176 = $v_s);
    Z::$l = 106;
    ($v___w177 = z_b_zs_obj_take($v_this, 'strList'));
    Z::$l = 106;
    z_apush($v___w177, $v___r176);
    Z::$l = 106;
    z_b_zs_obj_put($v_this, 'strList', $v___w177);
  }
  Z::$l = 108;
  return z_index(z_b_zs_obj_get($v_this, 'strs'), $v_s);
  return null;
}
function f_LlEmitter__slot($v_this) {
  $v_n = null;
  $v___r178 = null;
  $v___w179 = null;
  Z::$l = 112;
  z_b_zs_obj_set($v_this, 'slotN', z_add(z_b_zs_obj_get($v_this, 'slotN'), 1));
  Z::$l = 113;
  ($v_n = z_concat('%slot', z_b_zs_obj_get($v_this, 'slotN')));
  Z::$l = 114;
  ($v___r178 = z_concat(z_concat('  ', $v_n), ' = alloca { i64, i64 }, align 8'));
  Z::$l = 114;
  ($v___w179 = z_b_zs_obj_take($v_this, 'allocas'));
  Z::$l = 114;
  z_apush($v___w179, $v___r178);
  Z::$l = 114;
  z_b_zs_obj_put($v_this, 'allocas', $v___w179);
  Z::$l = 115;
  return $v_n;
  return null;
}
function f_LlEmitter__ty($v_this, $v_t) {
  Z::$l = 119;
  return (z_truthy(($v_t === 'V')) ? '{ i64, i64 }' : $v_t);
  return null;
}
function f_LlEmitter__rt($v_this, $v_fn, $v_ret, $v_args) {
  $v_parts = null;
  $v_a = null;
  $v_x = null;
  $v_y = null;
  $v_res = null;
  Z::$l = 123;
  ($v_parts = []);
  Z::$l = 124;
  foreach (z_foreach($v_args) as $_k165 => $_v165) {
    $v_a = $_v165;
    Z::$l = 125;
    if (z_truthy((z_index($v_a, 0) === 'V'))) {
      Z::$l = 126;
      ($v_x = f_zs_invoke($v_this, 'r', []));
      Z::$l = 127;
      ($v_y = f_zs_invoke($v_this, 'r', []));
      Z::$l = 128;
      f_zs_invoke($v_this, 'line', [z_concat(z_concat(z_concat($v_x, ' = extractvalue { i64, i64 } '), z_index($v_a, 1)), ', 0')]);
      Z::$l = 129;
      f_zs_invoke($v_this, 'line', [z_concat(z_concat(z_concat($v_y, ' = extractvalue { i64, i64 } '), z_index($v_a, 1)), ', 1')]);
      Z::$l = 130;
      z_apush($v_parts, z_concat('i64 ', $v_x));
      Z::$l = 131;
      z_apush($v_parts, z_concat('i64 ', $v_y));
    } else {
      Z::$l = 132;
      z_apush($v_parts, z_concat(z_concat(z_index($v_a, 0), ' '), z_index($v_a, 1)));
    }
  }
  Z::$l = 134;
  if (z_truthy(($v_ret === 'void'))) {
    Z::$l = 134;
    f_zs_invoke($v_this, 'line', [z_concat(z_concat(z_concat(z_concat('call void @', $v_fn), '('), z_b_join($v_parts, ', ')), ')')]);
    Z::$l = 134;
    return null;
  }
  Z::$l = 135;
  ($v_res = f_zs_invoke($v_this, 'r', []));
  Z::$l = 136;
  f_zs_invoke($v_this, 'line', [z_concat(z_concat(z_concat(z_concat(z_concat(z_concat(z_concat($v_res, ' = call '), f_zs_invoke($v_this, 'ty', [$v_ret])), ' @'), $v_fn), '('), z_b_join($v_parts, ', ')), ')')]);
  Z::$l = 137;
  return $v_res;
  return null;
}
function f_LlEmitter__vcall($v_this, $v_fn, $v_regs) {
  $v_args = null;
  $v_x = null;
  Z::$l = 141;
  ($v_args = []);
  Z::$l = 142;
  foreach (z_foreach($v_regs) as $_k166 => $_v166) {
    $v_x = $_v166;
    Z::$l = 142;
    z_apush($v_args, ['V', $v_x]);
  }
  Z::$l = 143;
  return f_zs_invoke($v_this, 'rt', [$v_fn, 'V', $v_args]);
  return null;
}
function f_LlEmitter__mkv($v_this, $v_tag, $v_bits) {
  $v_a = null;
  Z::$l = 147;
  ($v_a = f_zs_invoke($v_this, 'r', []));
  Z::$l = 148;
  f_zs_invoke($v_this, 'line', [z_concat(z_concat(z_concat(z_concat(z_concat($v_a, ' = insertvalue { i64, i64 } { i64 '), $v_tag), ', i64 0 }, i64 '), $v_bits), ', 1')]);
  Z::$l = 149;
  return $v_a;
  return null;
}
function f_LlEmitter__nullv($v_this) {
  Z::$l = 152;
  return f_zs_invoke($v_this, 'mkv', [0, '0']);
  return null;
}
function f_LlEmitter__truthy($v_this, $v_v) {
  $v_c = null;
  $v_b = null;
  Z::$l = 155;
  ($v_c = f_zs_invoke($v_this, 'rt', ['zv_truthy', 'i32', [['V', $v_v]]]));
  Z::$l = 156;
  ($v_b = f_zs_invoke($v_this, 'r', []));
  Z::$l = 157;
  f_zs_invoke($v_this, 'line', [z_concat(z_concat(z_concat($v_b, ' = icmp ne i32 '), $v_c), ', 0')]);
  Z::$l = 158;
  return $v_b;
  return null;
}
function f_LlEmitter__boolOf($v_this, $v_i1) {
  $v_z = null;
  $v_a = null;
  Z::$l = 162;
  ($v_z = f_zs_invoke($v_this, 'r', []));
  Z::$l = 163;
  f_zs_invoke($v_this, 'line', [z_concat(z_concat(z_concat($v_z, ' = zext i1 '), $v_i1), ' to i64')]);
  Z::$l = 164;
  ($v_a = f_zs_invoke($v_this, 'r', []));
  Z::$l = 165;
  f_zs_invoke($v_this, 'line', [z_concat(z_concat(z_concat($v_a, ' = insertvalue { i64, i64 } { i64 1, i64 0 }, i64 '), $v_z), ', 1')]);
  Z::$l = 166;
  return $v_a;
  return null;
}
function f_LlEmitter__ident($v_this, $v_n) {
  Z::$l = 169;
  return z_concat(z_concat('%"v_', $v_n), '"');
  return null;
}
function f_LlEmitter__load($v_this, $v_n) {
  $v_t = null;
  Z::$l = 172;
  ($v_t = f_zs_invoke($v_this, 'r', []));
  Z::$l = 173;
  f_zs_invoke($v_this, 'line', [z_concat(z_concat(z_concat(z_concat(z_concat($v_t, ' = load '), z_b_zs_obj_get($v_this, 'vol')), '{ i64, i64 }, ptr '), f_zs_invoke($v_this, 'ident', [$v_n])), ', align 8')]);
  Z::$l = 174;
  return $v_t;
  return null;
}
function f_LlEmitter__store($v_this, $v_n, $v_v) {
  Z::$l = 177;
  f_zs_invoke($v_this, 'line', [z_concat(z_concat(z_concat(z_concat(z_concat(z_concat('store ', z_b_zs_obj_get($v_this, 'vol')), '{ i64, i64 } '), $v_v), ', ptr '), f_zs_invoke($v_this, 'ident', [$v_n])), ', align 8')]);
  return null;
}
function f_LlEmitter__storeTo($v_this, $v_ptr, $v_v) {
  Z::$l = 179;
  f_zs_invoke($v_this, 'line', [z_concat(z_concat(z_concat(z_concat('store { i64, i64 } ', $v_v), ', ptr '), $v_ptr), ', align 8')]);
  return null;
}
function f_LlEmitter__loadFrom($v_this, $v_ptr) {
  $v_t = null;
  Z::$l = 182;
  ($v_t = f_zs_invoke($v_this, 'r', []));
  Z::$l = 183;
  f_zs_invoke($v_this, 'line', [z_concat(z_concat(z_concat($v_t, ' = load { i64, i64 }, ptr '), $v_ptr), ', align 8')]);
  Z::$l = 184;
  return $v_t;
  return null;
}
function f_LlEmitter__isLval($v_this, $v_e) {
  Z::$l = 188;
  return (z_truthy((z_index($v_e, 0) === ':Var')) || z_truthy((z_index($v_e, 0) === ':Index')));
  return null;
}
function f_LlEmitter__val($v_this, $v_e) {
  $v_x = null;
  Z::$l = 191;
  ($v_x = f_zs_invoke($v_this, 'expr', [$v_e]));
  Z::$l = 192;
  return (z_truthy(f_zs_invoke($v_this, 'isLval', [$v_e])) ? f_zs_invoke($v_this, 'vcall', ['zv_dup', [$v_x]]) : $v_x);
  return null;
}
function f_LlEmitter__binop($v_this, $v_op, $v_a, $v_b) {
  $v_m = null;
  $v_fn = null;
  $v_c = null;
  $v_p = null;
  $v_cc = null;
  $v_x = null;
  $v_y = null;
  Z::$l = 196;
  ($v_m = [z_k('Add') => 'zv_add', z_k('Sub') => 'zv_sub', z_k('Mul') => 'zv_mul', z_k('Div') => 'zv_div', z_k('Mod') => 'zv_mod', z_k('Pow') => 'zv_pow', z_k('Concat') => 'zv_concat', z_k('BitAnd') => 'zv_bitand', z_k('BitOr') => 'zv_bitor', z_k('BitXor') => 'zv_bitxor', z_k('Shl') => 'zv_shl', z_k('Shr') => 'zv_shr']);
  Z::$l = 197;
  if (z_truthy(z_b_has_key($v_m, $v_op))) {
    Z::$l = 197;
    return f_zs_invoke($v_this, 'vcall', [z_index($v_m, $v_op), [$v_a, $v_b]]);
  }
  Z::$l = 198;
  if (z_truthy((z_truthy((z_truthy((z_truthy(($v_op === 'Eq')) || z_truthy(($v_op === 'NotEq')))) || z_truthy(($v_op === 'Identical')))) || z_truthy(($v_op === 'NotIdentical'))))) {
    Z::$l = 199;
    ($v_fn = (z_truthy((z_truthy(($v_op === 'Eq')) || z_truthy(($v_op === 'NotEq')))) ? 'zv_eq' : 'zv_ident'));
    Z::$l = 200;
    ($v_c = f_zs_invoke($v_this, 'rt', [$v_fn, 'i32', [['V', $v_a], ['V', $v_b]]]));
    Z::$l = 201;
    ($v_p = f_zs_invoke($v_this, 'r', []));
    Z::$l = 202;
    f_zs_invoke($v_this, 'line', [z_concat(z_concat(z_concat(z_concat(z_concat($v_p, ' = icmp '), (z_truthy((z_truthy(($v_op === 'Eq')) || z_truthy(($v_op === 'Identical')))) ? 'ne' : 'eq')), ' i32 '), $v_c), ', 0')]);
    Z::$l = 203;
    return f_zs_invoke($v_this, 'boolOf', [$v_p]);
  }
  Z::$l = 205;
  if (z_truthy((z_truthy((z_truthy((z_truthy(($v_op === 'Lt')) || z_truthy(($v_op === 'Gt')))) || z_truthy(($v_op === 'Le')))) || z_truthy(($v_op === 'Ge'))))) {
    Z::$l = 206;
    ($v_c = f_zs_invoke($v_this, 'rt', ['zv_cmp', 'i32', [['V', $v_a], ['V', $v_b]]]));
    Z::$l = 207;
    ($v_cc = z_index([z_k('Lt') => 'slt', z_k('Gt') => 'sgt', z_k('Le') => 'sle', z_k('Ge') => 'sge'], $v_op));
    Z::$l = 208;
    ($v_p = f_zs_invoke($v_this, 'r', []));
    Z::$l = 209;
    f_zs_invoke($v_this, 'line', [z_concat(z_concat(z_concat(z_concat(z_concat($v_p, ' = icmp '), $v_cc), ' i32 '), $v_c), ', 0')]);
    Z::$l = 210;
    return f_zs_invoke($v_this, 'boolOf', [$v_p]);
  }
  Z::$l = 212;
  if (z_truthy(($v_op === 'Xor'))) {
    Z::$l = 213;
    ($v_x = f_zs_invoke($v_this, 'truthy', [$v_a]));
    Z::$l = 214;
    ($v_y = f_zs_invoke($v_this, 'truthy', [$v_b]));
    Z::$l = 215;
    ($v_p = f_zs_invoke($v_this, 'r', []));
    Z::$l = 216;
    f_zs_invoke($v_this, 'line', [z_concat(z_concat(z_concat(z_concat($v_p, ' = xor i1 '), $v_x), ', '), $v_y)]);
    Z::$l = 217;
    return f_zs_invoke($v_this, 'boolOf', [$v_p]);
  }
  Z::$l = 219;
  z_raise(new ZExc(0, z_concat('emit_llvm: nieobsługiwany operator ', $v_op)));
  return null;
}
function f_LlEmitter__quiet($v_this, $v_e) {
  $v_b = null;
  $v_k = null;
  Z::$l = 224;
  if (z_truthy((z_truthy((z_index($v_e, 0) === ':Index')) && z_truthy((z_index($v_e, 3) !== null))))) {
    Z::$l = 225;
    ($v_b = f_zs_invoke($v_this, 'quiet', [z_index($v_e, 2)]));
    Z::$l = 226;
    ($v_k = f_zs_invoke($v_this, 'expr', [z_index($v_e, 3)]));
    Z::$l = 227;
    return f_zs_invoke($v_this, 'vcall', ['zv_index_opt', [$v_b, $v_k]]);
  }
  Z::$l = 229;
  return f_zs_invoke($v_this, 'expr', [$v_e]);
  return null;
}
function f_LlEmitter__keyOf($v_this, $v_t, $v_arr) {
  $v_n = null;
  $v_a = null;
  Z::$l = 233;
  if (z_truthy((z_index($v_t, 3) === null))) {
    Z::$l = 234;
    ($v_n = f_zs_invoke($v_this, 'rt', ['zs_array_len', 'i64', [['V', $v_arr]]]));
    Z::$l = 235;
    ($v_a = f_zs_invoke($v_this, 'r', []));
    Z::$l = 236;
    f_zs_invoke($v_this, 'line', [z_concat(z_concat(z_concat($v_a, ' = insertvalue { i64, i64 } { i64 2, i64 0 }, i64 '), $v_n), ', 1')]);
    Z::$l = 237;
    return $v_a;
  }
  Z::$l = 239;
  return f_zs_invoke($v_this, 'expr', [z_index($v_t, 3)]);
  return null;
}
function f_LlEmitter__lv($v_this, $v_base) {
  $v_cur = null;
  $v_w = null;
  $v_p = null;
  $v_k = null;
  $v_e = null;
  $v_isnull = null;
  $v_tg = null;
  $v_sl = null;
  $v_lnew = null;
  $v_ljoin = null;
  Z::$l = 244;
  if (z_truthy((z_index($v_base, 0) === ':Var'))) {
    Z::$l = 245;
    ($v_cur = f_zs_invoke($v_this, 'load', [z_index($v_base, 2)]));
    Z::$l = 246;
    ($v_w = f_zs_invoke($v_this, 'vcall', ['zv_wr', [$v_cur]]));
    Z::$l = 247;
    f_zs_invoke($v_this, 'store', [z_index($v_base, 2), $v_w]);
    Z::$l = 248;
    return $v_w;
  }
  Z::$l = 250;
  ($v_p = f_zs_invoke($v_this, 'lv', [z_index($v_base, 2)]));
  Z::$l = 251;
  ($v_k = f_zs_invoke($v_this, 'keyOf', [$v_base, $v_p]));
  Z::$l = 252;
  ($v_e = f_zs_invoke($v_this, 'vcall', ['zv_index_opt', [$v_p, $v_k]]));
  Z::$l = 253;
  ($v_isnull = f_zs_invoke($v_this, 'r', []));
  Z::$l = 254;
  ($v_tg = f_zs_invoke($v_this, 'r', []));
  Z::$l = 255;
  f_zs_invoke($v_this, 'line', [z_concat(z_concat(z_concat($v_tg, ' = extractvalue { i64, i64 } '), $v_e), ', 0')]);
  Z::$l = 256;
  f_zs_invoke($v_this, 'line', [z_concat(z_concat(z_concat($v_isnull, ' = icmp eq i64 '), $v_tg), ', 0')]);
  Z::$l = 257;
  ($v_sl = f_zs_invoke($v_this, 'slot', []));
  Z::$l = 258;
  f_zs_invoke($v_this, 'storeTo', [$v_sl, $v_e]);
  Z::$l = 259;
  ($v_lnew = f_zs_invoke($v_this, 'newLabel', ['lvnew']));
  Z::$l = 260;
  ($v_ljoin = f_zs_invoke($v_this, 'newLabel', ['lvjoin']));
  Z::$l = 261;
  f_zs_invoke($v_this, 'terminate', [z_concat(z_concat(z_concat(z_concat(z_concat('br i1 ', $v_isnull), ', label %'), $v_lnew), ', label %'), $v_ljoin)]);
  Z::$l = 262;
  f_zs_invoke($v_this, 'label', [$v_lnew]);
  Z::$l = 263;
  f_zs_invoke($v_this, 'storeTo', [$v_sl, f_zs_invoke($v_this, 'newArr', [])]);
  Z::$l = 264;
  f_zs_invoke($v_this, 'label', [$v_ljoin]);
  Z::$l = 265;
  ($v_cur = f_zs_invoke($v_this, 'loadFrom', [$v_sl]));
  Z::$l = 266;
  ($v_w = f_zs_invoke($v_this, 'vcall', ['zv_wr', [$v_cur]]));
  Z::$l = 267;
  f_zs_invoke($v_this, 'vcallVoid', ['zv_set', [$v_p, $v_k, $v_w]]);
  Z::$l = 268;
  return $v_w;
  return null;
}
function f_LlEmitter__newArr($v_this) {
  Z::$l = 271;
  return f_zs_invoke($v_this, 'rt', ['zv_arr_new', 'V', [['i64', '4']]]);
  return null;
}
function f_LlEmitter__vcallVoid($v_this, $v_fn, $v_regs) {
  $v_args = null;
  $v_x = null;
  Z::$l = 274;
  ($v_args = []);
  Z::$l = 275;
  foreach (z_foreach($v_regs) as $_k167 => $_v167) {
    $v_x = $_v167;
    Z::$l = 275;
    z_apush($v_args, ['V', $v_x]);
  }
  Z::$l = 276;
  f_zs_invoke($v_this, 'rt', [$v_fn, 'void', $v_args]);
  return null;
}
function f_LlEmitter__incdec($v_this, $v_e) {
  $v_t = null;
  $v_fn = null;
  $v_prefix = null;
  $v_one = null;
  $v_o = null;
  $v_n = null;
  $v_a = null;
  $v_k = null;
  Z::$l = 280;
  ($v_t = z_index($v_e, 2));
  Z::$l = 281;
  ($v_fn = (z_truthy(z_index($v_e, 3)) ? 'zv_add' : 'zv_sub'));
  Z::$l = 282;
  ($v_prefix = z_index($v_e, 4));
  Z::$l = 283;
  ($v_one = f_zs_invoke($v_this, 'mkv', [2, '1']));
  Z::$l = 284;
  if (z_truthy((z_index($v_t, 0) === ':Var'))) {
    Z::$l = 285;
    ($v_o = f_zs_invoke($v_this, 'load', [z_index($v_t, 2)]));
    Z::$l = 286;
    ($v_n = f_zs_invoke($v_this, 'vcall', [$v_fn, [$v_o, $v_one]]));
    Z::$l = 287;
    f_zs_invoke($v_this, 'store', [z_index($v_t, 2), $v_n]);
    Z::$l = 288;
    return (z_truthy($v_prefix) ? $v_n : $v_o);
  }
  Z::$l = 290;
  ($v_a = f_zs_invoke($v_this, 'lv', [z_index($v_t, 2)]));
  Z::$l = 291;
  ($v_k = f_zs_invoke($v_this, 'keyOf', [$v_t, $v_a]));
  Z::$l = 292;
  ($v_o = f_zs_invoke($v_this, 'vcall', ['zv_index', [$v_a, $v_k]]));
  Z::$l = 293;
  ($v_n = f_zs_invoke($v_this, 'vcall', [$v_fn, [$v_o, $v_one]]));
  Z::$l = 294;
  f_zs_invoke($v_this, 'vcallVoid', ['zv_set', [$v_a, $v_k, $v_n]]);
  Z::$l = 295;
  return (z_truthy($v_prefix) ? $v_n : $v_o);
  return null;
}
function f_LlEmitter__assignop($v_this, $v_e) {
  $v_op = null;
  $v_t = null;
  $v_o = null;
  $v_r = null;
  $v_rhs = null;
  $v_n = null;
  $v_a = null;
  $v_k = null;
  Z::$l = 300;
  ($v_op = z_index($v_e, 2));
  Z::$l = 301;
  ($v_t = z_index($v_e, 3));
  Z::$l = 302;
  if (z_truthy((z_index($v_t, 0) === ':Var'))) {
    Z::$l = 303;
    ($v_o = f_zs_invoke($v_this, 'load', [z_index($v_t, 2)]));
    Z::$l = 304;
    if (z_truthy(($v_op === 'Coalesce'))) {
      Z::$l = 305;
      ($v_r = f_zs_invoke($v_this, 'coalesceWith', [$v_o, z_index($v_e, 4)]));
      Z::$l = 306;
      f_zs_invoke($v_this, 'store', [z_index($v_t, 2), $v_r]);
      Z::$l = 307;
      return $v_r;
    }
    Z::$l = 309;
    ($v_rhs = f_zs_invoke($v_this, 'expr', [z_index($v_e, 4)]));
    Z::$l = 310;
    ($v_n = f_zs_invoke($v_this, 'binop', [$v_op, $v_o, $v_rhs]));
    Z::$l = 311;
    f_zs_invoke($v_this, 'store', [z_index($v_t, 2), $v_n]);
    Z::$l = 312;
    return $v_n;
  }
  Z::$l = 314;
  ($v_a = f_zs_invoke($v_this, 'lv', [z_index($v_t, 2)]));
  Z::$l = 315;
  ($v_k = f_zs_invoke($v_this, 'keyOf', [$v_t, $v_a]));
  Z::$l = 316;
  if (z_truthy(($v_op === 'Coalesce'))) {
    Z::$l = 317;
    ($v_o = f_zs_invoke($v_this, 'vcall', ['zv_index_opt', [$v_a, $v_k]]));
    Z::$l = 318;
    ($v_n = f_zs_invoke($v_this, 'coalesceWith', [$v_o, z_index($v_e, 4)]));
  } else {
    Z::$l = 320;
    ($v_o = f_zs_invoke($v_this, 'vcall', ['zv_index', [$v_a, $v_k]]));
    Z::$l = 321;
    ($v_rhs = f_zs_invoke($v_this, 'expr', [z_index($v_e, 4)]));
    Z::$l = 322;
    ($v_n = f_zs_invoke($v_this, 'binop', [$v_op, $v_o, $v_rhs]));
  }
  Z::$l = 324;
  f_zs_invoke($v_this, 'vcallVoid', ['zv_set', [$v_a, $v_k, $v_n]]);
  Z::$l = 325;
  return $v_n;
  return null;
}
function f_LlEmitter__coalesceWith($v_this, $v_x, $v_rhsExpr) {
  $v_sl = null;
  $v_tg = null;
  $v_isn = null;
  $v_lr = null;
  $v_lj = null;
  $v_v = null;
  Z::$l = 330;
  ($v_sl = f_zs_invoke($v_this, 'slot', []));
  Z::$l = 331;
  f_zs_invoke($v_this, 'storeTo', [$v_sl, $v_x]);
  Z::$l = 332;
  ($v_tg = f_zs_invoke($v_this, 'r', []));
  Z::$l = 333;
  f_zs_invoke($v_this, 'line', [z_concat(z_concat(z_concat($v_tg, ' = extractvalue { i64, i64 } '), $v_x), ', 0')]);
  Z::$l = 334;
  ($v_isn = f_zs_invoke($v_this, 'r', []));
  Z::$l = 335;
  f_zs_invoke($v_this, 'line', [z_concat(z_concat(z_concat($v_isn, ' = icmp eq i64 '), $v_tg), ', 0')]);
  Z::$l = 336;
  ($v_lr = f_zs_invoke($v_this, 'newLabel', ['coal']));
  Z::$l = 337;
  ($v_lj = f_zs_invoke($v_this, 'newLabel', ['coalj']));
  Z::$l = 338;
  f_zs_invoke($v_this, 'terminate', [z_concat(z_concat(z_concat(z_concat(z_concat('br i1 ', $v_isn), ', label %'), $v_lr), ', label %'), $v_lj)]);
  Z::$l = 339;
  f_zs_invoke($v_this, 'label', [$v_lr]);
  Z::$l = 340;
  ($v_v = f_zs_invoke($v_this, 'val', [$v_rhsExpr]));
  Z::$l = 341;
  f_zs_invoke($v_this, 'storeTo', [$v_sl, $v_v]);
  Z::$l = 342;
  f_zs_invoke($v_this, 'label', [$v_lj]);
  Z::$l = 343;
  return f_zs_invoke($v_this, 'loadFrom', [$v_sl]);
  return null;
}
function f_LlEmitter__assign($v_this, $v_e) {
  $v_t = null;
  $v_v = null;
  $v_a = null;
  $v_k = null;
  Z::$l = 347;
  ($v_t = z_index($v_e, 2));
  Z::$l = 348;
  if (z_truthy((z_index($v_t, 0) === ':Var'))) {
    Z::$l = 349;
    ($v_v = f_zs_invoke($v_this, 'val', [z_index($v_e, 3)]));
    Z::$l = 350;
    f_zs_invoke($v_this, 'store', [z_index($v_t, 2), $v_v]);
    Z::$l = 351;
    return $v_v;
  }
  Z::$l = 353;
  ($v_a = f_zs_invoke($v_this, 'lv', [z_index($v_t, 2)]));
  Z::$l = 354;
  ($v_v = f_zs_invoke($v_this, 'val', [z_index($v_e, 3)]));
  Z::$l = 355;
  if (z_truthy((z_index($v_t, 3) === null))) {
    Z::$l = 355;
    f_zs_invoke($v_this, 'vcallVoid', ['zv_append', [$v_a, $v_v]]);
  } else {
    Z::$l = 357;
    ($v_k = f_zs_invoke($v_this, 'expr', [z_index($v_t, 3)]));
    Z::$l = 358;
    f_zs_invoke($v_this, 'vcallVoid', ['zv_set', [$v_a, $v_k, $v_v]]);
  }
  Z::$l = 360;
  return $v_v;
  return null;
}
function f_LlEmitter__argRegs($v_this, $v_list, $v_dup) {
  $v_out = null;
  $v_a = null;
  Z::$l = 364;
  ($v_out = []);
  Z::$l = 365;
  foreach (z_foreach($v_list) as $_k168 => $_v168) {
    $v_a = $_v168;
    Z::$l = 365;
    z_apush($v_out, (z_truthy($v_dup) ? f_zs_invoke($v_this, 'val', [z_index($v_a, 3)]) : f_zs_invoke($v_this, 'expr', [z_index($v_a, 3)])));
  }
  Z::$l = 366;
  return $v_out;
  return null;
}
function f_LlEmitter__call($v_this, $v_e) {
  $v_callee = null;
  $v_list = null;
  $v_n = null;
  $v_name = null;
  $v_f = null;
  $v_a = null;
  $v_i = null;
  $v_m = null;
  Z::$l = 370;
  ($v_callee = z_index($v_e, 2));
  Z::$l = 371;
  ($v_list = z_index($v_e, 3));
  Z::$l = 372;
  ($v_n = z_b_count($v_list));
  Z::$l = 373;
  if (z_truthy((z_index($v_callee, 0) === ':Prop'))) {
    Z::$l = 373;
    return f_zs_invoke($v_this, 'vcall', ['b_getmessage', [f_zs_invoke($v_this, 'expr', [z_index($v_callee, 2)])]]);
  }
  Z::$l = 374;
  if (z_truthy((z_index($v_callee, 0) === ':Name'))) {
    Z::$l = 375;
    ($v_name = z_index($v_callee, 2));
    Z::$l = 376;
    if (z_truthy(z_b_has_key(z_index(z_b_zs_obj_get($v_this, 'ir'), 'funcs'), $v_name))) {
      Z::$l = 377;
      ($v_f = z_index(z_index(z_b_zs_obj_get($v_this, 'ir'), 'funcs'), $v_name));
      Z::$l = 378;
      ($v_a = f_zs_invoke($v_this, 'argRegs', [$v_list, true]));
      Z::$l = 379;
      ($v_i = $v_n);
      for (; z_truthy((z_cmp($v_i, z_b_count(z_index($v_f, 'params'))) < 0)); z_last($_t34 = $v_i, $v_i = z_add($_t34, 1), $_t34)) {
        Z::$l = 379;
        z_apush($v_a, f_zs_invoke($v_this, 'expr', [z_index(z_index(z_index($v_f, 'params'), $v_i), 4)]));
      }
      Z::$l = 380;
      return f_zs_invoke($v_this, 'vcall', [z_concat('f_', $v_name), $v_a]);
    }
    Z::$l = 382;
    return f_zs_invoke($v_this, 'builtin', [$v_name, $v_list]);
  }
  Z::$l = 384;
  ($v_m = z_index(z_index($v_callee, 2), 2));
  Z::$l = 385;
  ($v_f = z_index($v_callee, 3));
  Z::$l = 386;
  ($v_a = f_zs_invoke($v_this, 'argRegs', [$v_list, false]));
  Z::$l = 387;
  if (z_truthy((z_truthy(($v_m === 'System')) && z_truthy(($v_f === 'exit'))))) {
    Z::$l = 387;
    return f_zs_invoke($v_this, 'doExit', [$v_a]);
  }
  Z::$l = 388;
  if (z_truthy((z_truthy(($v_m === 'Process')) && z_truthy((z_b_count($v_a) === 1))))) {
    Z::$l = 388;
    z_apush($v_a, f_zs_invoke($v_this, 'nullv', []));
  }
  Z::$l = 389;
  return f_zs_invoke($v_this, 'vcall', [z_concat(z_concat(z_concat('m_', $v_m), '_'), $v_f), $v_a]);
  return null;
}
function f_LlEmitter__doExit($v_this, $v_a) {
  $v_c = null;
  Z::$l = 393;
  ($v_c = (z_truthy((z_cmp(z_b_count($v_a), 0) > 0)) ? z_index($v_a, 0) : f_zs_invoke($v_this, 'mkv', [2, '0'])));
  Z::$l = 394;
  f_zs_invoke($v_this, 'vcallVoid', ['s_exit', [$v_c]]);
  Z::$l = 395;
  f_zs_invoke($v_this, 'terminate', ['unreachable']);
  Z::$l = 396;
  return f_zs_invoke($v_this, 'nullv', []);
  return null;
}
function f_LlEmitter__builtin($v_this, $v_name, $v_list) {
  $v_a = null;
  $v_first = null;
  $v_x = null;
  $v_r = null;
  $v_i = null;
  $v_has = null;
  $v_l = null;
  Z::$l = 400;
  ($v_a = f_zs_invoke($v_this, 'argRegs', [$v_list, false]));
  Z::$l = 401;
  if (z_truthy(($v_name === 'eecho'))) {
    Z::$l = 402;
    ($v_first = 1);
    Z::$l = 403;
    foreach (z_foreach($v_a) as $_k170 => $_v170) {
      $v_x = $_v170;
      Z::$l = 403;
      f_zs_invoke($v_this, 'rt', ['zs_eecho_v', 'void', [['V', $v_x], ['i32', z_concat('', $v_first)]]]);
      Z::$l = 403;
      ($v_first = 0);
    }
    Z::$l = 404;
    if (z_truthy((z_b_count($v_a) === 0))) {
      Z::$l = 404;
      f_zs_invoke($v_this, 'rt', ['zs_shutdown', 'void', []]);
    }
    Z::$l = 405;
    f_zs_invoke($v_this, 'rt', ['zs_eecho_end', 'void', []]);
    Z::$l = 406;
    return f_zs_invoke($v_this, 'nullv', []);
  }
  Z::$l = 408;
  if (z_truthy(($v_name === 'necho'))) {
    Z::$l = 409;
    foreach (z_foreach($v_a) as $_k171 => $_v171) {
      $v_x = $_v171;
      Z::$l = 409;
      f_zs_invoke($v_this, 'rt', ['zs_necho_v', 'void', [['V', $v_x]]]);
    }
    Z::$l = 410;
    return f_zs_invoke($v_this, 'nullv', []);
  }
  Z::$l = 412;
  if (z_truthy(($v_name === 'exit'))) {
    Z::$l = 412;
    return f_zs_invoke($v_this, 'doExit', [$v_a]);
  }
  Z::$l = 413;
  if (z_truthy(($v_name === 'dump'))) {
    Z::$l = 414;
    foreach (z_foreach($v_a) as $_k172 => $_v172) {
      $v_x = $_v172;
      Z::$l = 414;
      f_zs_invoke($v_this, 'vcall', ['b_dump', [$v_x]]);
    }
    Z::$l = 415;
    return f_zs_invoke($v_this, 'nullv', []);
  }
  Z::$l = 417;
  if (z_truthy(($v_name === 'push'))) {
    Z::$l = 418;
    ($v_r = z_index($v_a, 0));
    Z::$l = 419;
    ($v_i = 1);
    for (; z_truthy((z_cmp($v_i, z_b_count($v_a)) < 0)); z_last($_t35 = $v_i, $v_i = z_add($_t35, 1), $_t35)) {
      Z::$l = 419;
      ($v_r = f_zs_invoke($v_this, 'vcall', ['b_push', [$v_r, z_index($v_a, $v_i)]]));
    }
    Z::$l = 420;
    return $v_r;
  }
  Z::$l = 422;
  if (z_truthy(($v_name === 'substr'))) {
    Z::$l = 423;
    ($v_has = (z_truthy((z_b_count($v_a) === 3)) ? '1' : '0'));
    Z::$l = 424;
    ($v_l = (z_truthy((z_b_count($v_a) === 3)) ? z_index($v_a, 2) : f_zs_invoke($v_this, 'nullv', [])));
    Z::$l = 425;
    return f_zs_invoke($v_this, 'rt', ['b_substr', 'V', [['V', z_index($v_a, 0)], ['V', z_index($v_a, 1)], ['V', $v_l], ['i32', $v_has]]]);
  }
  Z::$l = 427;
  if (z_truthy((z_truthy((z_b_count($v_a) === 3)) && z_truthy(z_b_in_array($v_name, ['pad_left', 'pad_right', 'array_slice']))))) {
    Z::$l = 427;
    return f_zs_invoke($v_this, 'vcall', [z_concat(z_concat('b_', $v_name), '3'), $v_a]);
  }
  Z::$l = 428;
  return f_zs_invoke($v_this, 'vcall', [z_concat('b_', $v_name), $v_a]);
  return null;
}
function f_LlEmitter__expr($v_this, $v_e) {
  $v_k = null;
  $v_s = null;
  $v_i = null;
  $v_p = null;
  $v_msg = null;
  $v_arr = null;
  $v_it = null;
  $v_key = null;
  $v_b = null;
  $v_x = null;
  $v_t = null;
  $v_n = null;
  $v_op = null;
  $v_a = null;
  Z::$l = 432;
  ($v_k = z_index($v_e, 0));
  Z::$l = 433;
  if (z_truthy(($v_k === ':Null'))) {
    Z::$l = 433;
    return f_zs_invoke($v_this, 'nullv', []);
  }
  Z::$l = 434;
  if (z_truthy(($v_k === ':Bool'))) {
    Z::$l = 434;
    return f_zs_invoke($v_this, 'mkv', [1, (z_truthy(z_index($v_e, 2)) ? '1' : '0')]);
  }
  Z::$l = 435;
  if (z_truthy(($v_k === ':Int'))) {
    Z::$l = 435;
    return f_zs_invoke($v_this, 'mkv', [2, z_concat('', z_index($v_e, 2))]);
  }
  Z::$l = 436;
  if (z_truthy(($v_k === ':Float'))) {
    Z::$l = 437;
    ($v_s = z_b_strval(z_index($v_e, 2)));
    Z::$l = 438;
    return f_zs_invoke($v_this, 'rt', ['zl_float_lit', 'V', [['ptr', f_zs_invoke($v_this, 'cstr', [$v_s])]]]);
  }
  Z::$l = 440;
  if (z_truthy(($v_k === ':Str'))) {
    Z::$l = 441;
    ($v_i = f_zs_invoke($v_this, 'strSlot', [z_index($v_e, 2)]));
    Z::$l = 442;
    ($v_p = f_zs_invoke($v_this, 'r', []));
    Z::$l = 443;
    f_zs_invoke($v_this, 'line', [z_concat(z_concat($v_p, ' = getelementptr inbounds { i64, i64 }, ptr @S, i64 '), $v_i)]);
    Z::$l = 444;
    return f_zs_invoke($v_this, 'loadFrom', [$v_p]);
  }
  Z::$l = 446;
  if (z_truthy(($v_k === ':Var'))) {
    Z::$l = 447;
    if (z_truthy(!z_truthy(z_b_in_array(z_index($v_e, 2), z_b_zs_obj_get($v_this, 'known'))))) {
      Z::$l = 448;
      f_zs_invoke($v_this, 'setLine', [z_index($v_e, 1)]);
      Z::$l = 449;
      return f_zs_invoke($v_this, 'rt', ['zl_undef_var', 'V', [['ptr', f_zs_invoke($v_this, 'cstr', [z_index($v_e, 2)])]]]);
    }
    Z::$l = 451;
    return f_zs_invoke($v_this, 'load', [z_index($v_e, 2)]);
  }
  Z::$l = 453;
  if (z_truthy(($v_k === ':New'))) {
    Z::$l = 454;
    ($v_msg = (z_truthy((z_cmp(z_b_count(z_index($v_e, 3)), 0) > 0)) ? f_zs_invoke($v_this, 'expr', [z_index(z_index(z_index($v_e, 3), 0), 3)]) : f_zs_invoke($v_this, 'emptyStr', [])));
    Z::$l = 455;
    return f_zs_invoke($v_this, 'rt', ['zv_exc_new', 'V', [['i32', (z_truthy((z_index($v_e, 2) === 'Error')) ? '1' : '0')], ['V', $v_msg]]]);
  }
  Z::$l = 457;
  if (z_truthy(($v_k === ':Array'))) {
    Z::$l = 458;
    ($v_arr = f_zs_invoke($v_this, 'rt', ['zv_arr_new', 'V', [['i64', z_concat('', z_b_count(z_index($v_e, 2)))]]]));
    Z::$l = 459;
    foreach (z_foreach(z_index($v_e, 2)) as $_k174 => $_v174) {
      $v_it = $_v174;
      Z::$l = 460;
      if (z_truthy((z_index($v_it, 2) === null))) {
        Z::$l = 460;
        f_zs_invoke($v_this, 'vcallVoid', ['zv_append', [$v_arr, f_zs_invoke($v_this, 'val', [z_index($v_it, 3)])]]);
      } else {
        Z::$l = 462;
        ($v_key = f_zs_invoke($v_this, 'expr', [z_index($v_it, 2)]));
        Z::$l = 463;
        f_zs_invoke($v_this, 'vcallVoid', ['zv_set', [$v_arr, $v_key, f_zs_invoke($v_this, 'val', [z_index($v_it, 3)])]]);
      }
    }
    Z::$l = 466;
    return $v_arr;
  }
  Z::$l = 468;
  if (z_truthy(($v_k === ':Index'))) {
    Z::$l = 469;
    if (z_truthy((z_index($v_e, 3) === null))) {
      Z::$l = 469;
      z_raise(new ZExc(0, z_concat(z_concat('emit_llvm: odczyt `[]` niedozwolony (linia ', z_index($v_e, 1)), ')')));
    }
    Z::$l = 470;
    ($v_b = f_zs_invoke($v_this, 'expr', [z_index($v_e, 2)]));
    Z::$l = 471;
    ($v_i = f_zs_invoke($v_this, 'expr', [z_index($v_e, 3)]));
    Z::$l = 472;
    return f_zs_invoke($v_this, 'vcall', ['zv_index', [$v_b, $v_i]]);
  }
  Z::$l = 474;
  if (z_truthy(($v_k === ':Unary'))) {
    Z::$l = 475;
    ($v_x = f_zs_invoke($v_this, 'expr', [z_index($v_e, 3)]));
    Z::$l = 476;
    if (z_truthy((z_index($v_e, 2) === 'Not'))) {
      Z::$l = 477;
      ($v_t = f_zs_invoke($v_this, 'truthy', [$v_x]));
      Z::$l = 478;
      ($v_n = f_zs_invoke($v_this, 'r', []));
      Z::$l = 479;
      f_zs_invoke($v_this, 'line', [z_concat(z_concat(z_concat($v_n, ' = xor i1 '), $v_t), ', true')]);
      Z::$l = 480;
      return f_zs_invoke($v_this, 'boolOf', [$v_n]);
    }
    Z::$l = 482;
    if (z_truthy((z_index($v_e, 2) === 'Neg'))) {
      Z::$l = 482;
      return f_zs_invoke($v_this, 'vcall', ['zv_neg', [$v_x]]);
    }
    Z::$l = 483;
    if (z_truthy((z_index($v_e, 2) === 'BitNot'))) {
      Z::$l = 483;
      return f_zs_invoke($v_this, 'vcall', ['zv_bitnot', [$v_x]]);
    }
    Z::$l = 484;
    return $v_x;
  }
  Z::$l = 486;
  if (z_truthy(($v_k === ':Binary'))) {
    Z::$l = 487;
    ($v_op = z_index($v_e, 2));
    Z::$l = 488;
    if (z_truthy((z_truthy(($v_op === 'And')) || z_truthy(($v_op === 'Or'))))) {
      Z::$l = 488;
      return f_zs_invoke($v_this, 'shortCircuit', [($v_op === 'And'), z_index($v_e, 3), z_index($v_e, 4)]);
    }
    Z::$l = 489;
    if (z_truthy(($v_op === 'Coalesce'))) {
      Z::$l = 489;
      return f_zs_invoke($v_this, 'coalesceWith', [f_zs_invoke($v_this, 'quiet', [z_index($v_e, 3)]), z_index($v_e, 4)]);
    }
    Z::$l = 490;
    ($v_a = f_zs_invoke($v_this, 'expr', [z_index($v_e, 3)]));
    Z::$l = 491;
    ($v_b = f_zs_invoke($v_this, 'expr', [z_index($v_e, 4)]));
    Z::$l = 492;
    return f_zs_invoke($v_this, 'binop', [$v_op, $v_a, $v_b]);
  }
  Z::$l = 494;
  if (z_truthy(($v_k === ':Assign'))) {
    Z::$l = 494;
    return f_zs_invoke($v_this, 'assign', [$v_e]);
  }
  Z::$l = 495;
  if (z_truthy(($v_k === ':AssignOp'))) {
    Z::$l = 495;
    return f_zs_invoke($v_this, 'assignop', [$v_e]);
  }
  Z::$l = 496;
  if (z_truthy(($v_k === ':IncDec'))) {
    Z::$l = 496;
    return f_zs_invoke($v_this, 'incdec', [$v_e]);
  }
  Z::$l = 497;
  if (z_truthy(($v_k === ':Ternary'))) {
    Z::$l = 497;
    return f_zs_invoke($v_this, 'ternary', [$v_e]);
  }
  Z::$l = 498;
  if (z_truthy(($v_k === ':Call'))) {
    Z::$l = 498;
    return f_zs_invoke($v_this, 'call', [$v_e]);
  }
  Z::$l = 499;
  z_raise(new ZExc(0, z_concat(z_concat(z_concat(z_concat('emit_llvm: wyrażenie ', $v_k), ' (linia '), z_index($v_e, 1)), ')')));
  return null;
}
function f_LlEmitter__shortCircuit($v_this, $v_isAnd, $v_l, $v_r) {
  $v_x = null;
  $v_t = null;
  $v_sl = null;
  $v_lr = null;
  $v_lj = null;
  $v_y = null;
  $v_ty = null;
  Z::$l = 503;
  ($v_x = f_zs_invoke($v_this, 'expr', [$v_l]));
  Z::$l = 504;
  ($v_t = f_zs_invoke($v_this, 'truthy', [$v_x]));
  Z::$l = 505;
  ($v_sl = f_zs_invoke($v_this, 'slot', []));
  Z::$l = 506;
  f_zs_invoke($v_this, 'storeTo', [$v_sl, f_zs_invoke($v_this, 'boolOf', [$v_t])]);
  Z::$l = 507;
  ($v_lr = f_zs_invoke($v_this, 'newLabel', ['sc']));
  Z::$l = 508;
  ($v_lj = f_zs_invoke($v_this, 'newLabel', ['scj']));
  Z::$l = 509;
  if (z_truthy($v_isAnd)) {
    Z::$l = 509;
    f_zs_invoke($v_this, 'terminate', [z_concat(z_concat(z_concat(z_concat(z_concat('br i1 ', $v_t), ', label %'), $v_lr), ', label %'), $v_lj)]);
  } else {
    Z::$l = 510;
    f_zs_invoke($v_this, 'terminate', [z_concat(z_concat(z_concat(z_concat(z_concat('br i1 ', $v_t), ', label %'), $v_lj), ', label %'), $v_lr)]);
  }
  Z::$l = 511;
  f_zs_invoke($v_this, 'label', [$v_lr]);
  Z::$l = 512;
  ($v_y = f_zs_invoke($v_this, 'expr', [$v_r]));
  Z::$l = 513;
  ($v_ty = f_zs_invoke($v_this, 'truthy', [$v_y]));
  Z::$l = 514;
  f_zs_invoke($v_this, 'storeTo', [$v_sl, f_zs_invoke($v_this, 'boolOf', [$v_ty])]);
  Z::$l = 515;
  f_zs_invoke($v_this, 'label', [$v_lj]);
  Z::$l = 516;
  return f_zs_invoke($v_this, 'loadFrom', [$v_sl]);
  return null;
}
function f_LlEmitter__ternary($v_this, $v_e) {
  $v_sl = null;
  $v_lt = null;
  $v_lf = null;
  $v_lj = null;
  $v_c = null;
  $v_t = null;
  $v_a = null;
  $v_b = null;
  Z::$l = 520;
  ($v_sl = f_zs_invoke($v_this, 'slot', []));
  Z::$l = 521;
  ($v_lt = f_zs_invoke($v_this, 'newLabel', ['tt']));
  Z::$l = 522;
  ($v_lf = f_zs_invoke($v_this, 'newLabel', ['tf']));
  Z::$l = 523;
  ($v_lj = f_zs_invoke($v_this, 'newLabel', ['tj']));
  Z::$l = 524;
  if (z_truthy((z_index($v_e, 3) === null))) {
    Z::$l = 525;
    ($v_c = f_zs_invoke($v_this, 'expr', [z_index($v_e, 2)]));
    Z::$l = 526;
    f_zs_invoke($v_this, 'storeTo', [$v_sl, $v_c]);
    Z::$l = 527;
    ($v_t = f_zs_invoke($v_this, 'truthy', [$v_c]));
    Z::$l = 528;
    f_zs_invoke($v_this, 'terminate', [z_concat(z_concat(z_concat(z_concat(z_concat('br i1 ', $v_t), ', label %'), $v_lj), ', label %'), $v_lf)]);
  } else {
    Z::$l = 530;
    ($v_c = f_zs_invoke($v_this, 'expr', [z_index($v_e, 2)]));
    Z::$l = 531;
    ($v_t = f_zs_invoke($v_this, 'truthy', [$v_c]));
    Z::$l = 532;
    f_zs_invoke($v_this, 'terminate', [z_concat(z_concat(z_concat(z_concat(z_concat('br i1 ', $v_t), ', label %'), $v_lt), ', label %'), $v_lf)]);
    Z::$l = 533;
    f_zs_invoke($v_this, 'label', [$v_lt]);
    Z::$l = 534;
    ($v_a = f_zs_invoke($v_this, 'expr', [z_index($v_e, 3)]));
    Z::$l = 535;
    f_zs_invoke($v_this, 'storeTo', [$v_sl, $v_a]);
    Z::$l = 536;
    f_zs_invoke($v_this, 'terminate', [z_concat('br label %', $v_lj)]);
  }
  Z::$l = 538;
  f_zs_invoke($v_this, 'label', [$v_lf]);
  Z::$l = 539;
  ($v_b = f_zs_invoke($v_this, 'expr', [z_index($v_e, 4)]));
  Z::$l = 540;
  f_zs_invoke($v_this, 'storeTo', [$v_sl, $v_b]);
  Z::$l = 541;
  f_zs_invoke($v_this, 'label', [$v_lj]);
  Z::$l = 542;
  return f_zs_invoke($v_this, 'loadFrom', [$v_sl]);
  return null;
}
function f_LlEmitter__setLine($v_this, $v_n) {
  Z::$l = 546;
  f_zs_invoke($v_this, 'line', [z_concat(z_concat('store i64 ', $v_n), ', ptr @zs_line, align 8')]);
  return null;
}
function f_LlEmitter__block($v_this, $v_list) {
  $v_s = null;
  Z::$l = 548;
  foreach (z_foreach($v_list) as $_k175 => $_v175) {
    $v_s = $_v175;
    Z::$l = 548;
    f_zs_invoke($v_this, 'stmt', [$v_s]);
  }
  return null;
}
function f_LlEmitter__regionBegin($v_this, $v_loop, $v_body, $v_hdr, $v_pre, $v_id) {
  $v___r180 = null;
  $v___w181 = null;
  $v_names = null;
  $v_slot = null;
  $v___r182 = null;
  $v___w183 = null;
  $v_d = null;
  $v___r184 = null;
  $v___w185 = null;
  Z::$l = 552;
  if (z_truthy((z_cmp(z_b_count(z_b_zs_obj_get($v_this, 'tries')), 0) > 0))) {
    Z::$l = 552;
    ($v___r180 = null);
    Z::$l = 552;
    ($v___w181 = z_b_zs_obj_take($v_this, 'rdStack'));
    Z::$l = 552;
    z_apush($v___w181, $v___r180);
    Z::$l = 552;
    z_b_zs_obj_put($v_this, 'rdStack', $v___w181);
    Z::$l = 552;
    return null;
  }
  Z::$l = 553;
  ($v_names = f_Workspace_regions__region_carry($v_loop, $v_body, $v_hdr, $v_pre, z_b_zs_obj_get($v_this, 'fnCounts')));
  Z::$l = 554;
  ($v_slot = z_concat('%rdslot', $v_id));
  Z::$l = 555;
  ($v___r182 = z_concat(z_concat('  ', $v_slot), ' = alloca i32, align 4'));
  Z::$l = 555;
  ($v___w183 = z_b_zs_obj_take($v_this, 'allocas'));
  Z::$l = 555;
  z_apush($v___w183, $v___r182);
  Z::$l = 555;
  z_b_zs_obj_put($v_this, 'allocas', $v___w183);
  Z::$l = 556;
  ($v_d = f_zs_invoke($v_this, 'rt', ['zs_cur_depth', 'i32', []]));
  Z::$l = 557;
  f_zs_invoke($v_this, 'line', [z_concat(z_concat(z_concat(z_concat('store i32 ', $v_d), ', ptr '), $v_slot), ', align 4')]);
  Z::$l = 558;
  ($v___r184 = [$v_slot, $v_names]);
  Z::$l = 558;
  ($v___w185 = z_b_zs_obj_take($v_this, 'rdStack'));
  Z::$l = 558;
  z_apush($v___w185, $v___r184);
  Z::$l = 558;
  z_b_zs_obj_put($v_this, 'rdStack', $v___w185);
  return null;
}
function f_LlEmitter__regionEnter($v_this) {
  $v_r = null;
  Z::$l = 561;
  ($v_r = z_index(z_b_zs_obj_get($v_this, 'rdStack'), z_sub(z_b_count(z_b_zs_obj_get($v_this, 'rdStack')), 1)));
  Z::$l = 562;
  if (z_truthy(($v_r === null))) {
    Z::$l = 562;
    return null;
  }
  Z::$l = 563;
  f_zs_invoke($v_this, 'rt', ['zs_enter', 'i32', []]);
  return null;
}
function f_LlEmitter__regionExit($v_this) {
  $v_r = null;
  $v_l = null;
  $v_n = null;
  $v_v = null;
  $v_c = null;
  Z::$l = 566;
  ($v_r = z_index(z_b_zs_obj_get($v_this, 'rdStack'), z_sub(z_b_count(z_b_zs_obj_get($v_this, 'rdStack')), 1)));
  Z::$l = 567;
  if (z_truthy(($v_r === null))) {
    Z::$l = 567;
    return null;
  }
  Z::$l = 568;
  ($v_l = f_zs_invoke($v_this, 'r', []));
  Z::$l = 569;
  f_zs_invoke($v_this, 'line', [z_concat(z_concat(z_concat($v_l, ' = load i32, ptr '), z_index($v_r, 0)), ', align 4')]);
  Z::$l = 570;
  foreach (z_foreach(z_index(z_index($v_r, 1), 0)) as $_k176 => $_v176) {
    $v_n = $_v176;
    Z::$l = 571;
    ($v_v = f_zs_invoke($v_this, 'load', [$v_n]));
    Z::$l = 572;
    ($v_c = f_zs_invoke($v_this, 'rt', ['zs_carry_v', 'V', [['V', $v_v], ['i32', $v_l]]]));
    Z::$l = 573;
    f_zs_invoke($v_this, 'store', [$v_n, $v_c]);
  }
  Z::$l = 575;
  f_zs_invoke($v_this, 'rt', ['zs_pop', 'void', [['i32', $v_l]]]);
  Z::$l = 576;
  foreach (z_foreach(z_index(z_index($v_r, 1), 1)) as $_k177 => $_v177) {
    $v_n = $_v177;
    Z::$l = 576;
    f_zs_invoke($v_this, 'store', [$v_n, f_zs_invoke($v_this, 'nullv', [])]);
  }
  return null;
}
function f_LlEmitter__regionEnd($v_this) {
  Z::$l = 578;
  z_b_zs_obj_set($v_this, 'rdStack', z_b_array_slice(z_b_zs_obj_get($v_this, 'rdStack'), 0, z_sub(z_b_count(z_b_zs_obj_get($v_this, 'rdStack')), 1)));
  return null;
}
function f_LlEmitter__pushLoop($v_this) {
  $v___r186 = null;
  $v___w187 = null;
  Z::$l = 580;
  z_b_zs_obj_set($v_this, 'loopId', z_add(z_b_zs_obj_get($v_this, 'loopId'), 1));
  Z::$l = 580;
  ($v___r186 = [z_b_zs_obj_get($v_this, 'loopId'), 'loop', z_b_count(z_b_zs_obj_get($v_this, 'tries'))]);
  Z::$l = 580;
  ($v___w187 = z_b_zs_obj_take($v_this, 'loops'));
  Z::$l = 580;
  z_apush($v___w187, $v___r186);
  Z::$l = 580;
  z_b_zs_obj_put($v_this, 'loops', $v___w187);
  Z::$l = 580;
  return z_b_zs_obj_get($v_this, 'loopId');
  return null;
}
function f_LlEmitter__popLoop($v_this) {
  Z::$l = 581;
  z_b_zs_obj_set($v_this, 'loops', z_b_array_slice(z_b_zs_obj_get($v_this, 'loops'), 0, z_sub(z_b_count(z_b_zs_obj_get($v_this, 'loops')), 1)));
  return null;
}
function f_LlEmitter__jumpOut($v_this, $v_depth) {
  $v_saved = null;
  $v_i = null;
  $v_e = null;
  Z::$l = 584;
  ($v_saved = z_b_zs_obj_get($v_this, 'tries'));
  Z::$l = 585;
  ($v_i = z_sub(z_b_count($v_saved), 1));
  for (; z_truthy((z_cmp($v_i, $v_depth) >= 0)); z_last($_t36 = $v_i, $v_i = z_sub($_t36, 1), $_t36)) {
    Z::$l = 586;
    ($v_e = z_index($v_saved, $v_i));
    Z::$l = 587;
    f_zs_invoke($v_this, 'rt', ['zl_try_leave', 'void', [['ptr', z_index($v_e, 1)]]]);
    Z::$l = 588;
    if (z_truthy((z_index($v_e, 0) === 'finally'))) {
      Z::$l = 589;
      z_b_zs_obj_set($v_this, 'tries', z_b_array_slice($v_saved, 0, $v_i));
      Z::$l = 590;
      f_zs_invoke($v_this, 'block', [z_index($v_e, 2)]);
    }
  }
  Z::$l = 593;
  z_b_zs_obj_set($v_this, 'tries', $v_saved);
  return null;
}
function f_LlEmitter__catchCond($v_this, $v_types, $v_x) {
  $v_acc = null;
  $v_t = null;
  $v_c = null;
  $v_v = null;
  $v_o = null;
  Z::$l = 598;
  ($v_acc = null);
  Z::$l = 599;
  foreach (z_foreach($v_types) as $_k179 => $_v179) {
    $v_t = $_v179;
    Z::$l = 600;
    if (z_truthy((z_truthy(($v_t === 'Throwable')) || z_truthy(($v_t === 'Exception'))))) {
      Z::$l = 600;
      ($v_c = 'true');
    } else {
      Z::$l = 602;
      ($v_v = f_zs_invoke($v_this, 'rt', ['zv_exc_is', 'i32', [['V', $v_x], ['i32', '1']]]));
      Z::$l = 603;
      ($v_c = f_zs_invoke($v_this, 'r', []));
      Z::$l = 604;
      f_zs_invoke($v_this, 'line', [z_concat(z_concat(z_concat($v_c, ' = icmp ne i32 '), $v_v), ', 0')]);
    }
    Z::$l = 606;
    if (z_truthy(($v_acc === null))) {
      Z::$l = 606;
      ($v_acc = $v_c);
    } else {
      Z::$l = 608;
      ($v_o = f_zs_invoke($v_this, 'r', []));
      Z::$l = 609;
      f_zs_invoke($v_this, 'line', [z_concat(z_concat(z_concat(z_concat($v_o, ' = or i1 '), $v_acc), ', '), $v_c)]);
      Z::$l = 610;
      ($v_acc = $v_o);
    }
  }
  Z::$l = 613;
  return $v_acc;
  return null;
}
function f_LlEmitter__handler($v_this) {
  $v_h = null;
  $v___r188 = null;
  $v___w189 = null;
  Z::$l = 618;
  z_b_zs_obj_set($v_this, 'hid', z_add(z_b_zs_obj_get($v_this, 'hid'), 1));
  Z::$l = 619;
  ($v_h = z_concat('%h', z_b_zs_obj_get($v_this, 'hid')));
  Z::$l = 620;
  ($v___r188 = z_concat(z_concat('  ', $v_h), ' = alloca [512 x i8], align 16'));
  Z::$l = 620;
  ($v___w189 = z_b_zs_obj_take($v_this, 'allocas'));
  Z::$l = 620;
  z_apush($v___w189, $v___r188);
  Z::$l = 620;
  z_b_zs_obj_put($v_this, 'allocas', $v___w189);
  Z::$l = 621;
  return $v_h;
  return null;
}
function f_LlEmitter__jb($v_this, $v_h) {
  $v_p = null;
  Z::$l = 625;
  ($v_p = f_zs_invoke($v_this, 'r', []));
  Z::$l = 626;
  f_zs_invoke($v_this, 'line', [z_concat(z_concat(z_concat($v_p, ' = getelementptr inbounds i8, ptr '), $v_h), ', i64 16')]);
  Z::$l = 627;
  return $v_p;
  return null;
}
function f_LlEmitter__tryCatch($v_this, $v_body, $v_catches) {
  $v_h = null;
  $v_sj = null;
  $v_z = null;
  $v_lb = null;
  $v_lc = null;
  $v_le = null;
  $v___r190 = null;
  $v___w191 = null;
  $v_x = null;
  $v_xs = null;
  $v_c = null;
  $v_xv = null;
  $v_cond = null;
  $v_lm = null;
  $v_ln = null;
  Z::$l = 631;
  ($v_h = f_zs_invoke($v_this, 'handler', []));
  Z::$l = 632;
  f_zs_invoke($v_this, 'rt', ['zl_try_enter', 'void', [['ptr', $v_h]]]);
  Z::$l = 633;
  ($v_sj = f_zs_invoke($v_this, 'r', []));
  Z::$l = 634;
  f_zs_invoke($v_this, 'line', [z_concat(z_concat(z_concat($v_sj, ' = call i32 @_setjmp(ptr '), f_zs_invoke($v_this, 'jb', [$v_h])), ') returns_twice')]);
  Z::$l = 635;
  ($v_z = f_zs_invoke($v_this, 'r', []));
  Z::$l = 636;
  f_zs_invoke($v_this, 'line', [z_concat(z_concat(z_concat($v_z, ' = icmp eq i32 '), $v_sj), ', 0')]);
  Z::$l = 637;
  ($v_lb = f_zs_invoke($v_this, 'newLabel', ['try']));
  Z::$l = 638;
  ($v_lc = f_zs_invoke($v_this, 'newLabel', ['catch']));
  Z::$l = 639;
  ($v_le = f_zs_invoke($v_this, 'newLabel', ['tryend']));
  Z::$l = 640;
  f_zs_invoke($v_this, 'terminate', [z_concat(z_concat(z_concat(z_concat(z_concat('br i1 ', $v_z), ', label %'), $v_lb), ', label %'), $v_lc)]);
  Z::$l = 641;
  f_zs_invoke($v_this, 'label', [$v_lb]);
  Z::$l = 642;
  ($v___r190 = ['catch', $v_h, null]);
  Z::$l = 642;
  ($v___w191 = z_b_zs_obj_take($v_this, 'tries'));
  Z::$l = 642;
  z_apush($v___w191, $v___r190);
  Z::$l = 642;
  z_b_zs_obj_put($v_this, 'tries', $v___w191);
  Z::$l = 643;
  f_zs_invoke($v_this, 'block', [$v_body]);
  Z::$l = 644;
  z_b_zs_obj_set($v_this, 'tries', z_b_array_slice(z_b_zs_obj_get($v_this, 'tries'), 0, z_sub(z_b_count(z_b_zs_obj_get($v_this, 'tries')), 1)));
  Z::$l = 645;
  f_zs_invoke($v_this, 'rt', ['zl_try_leave', 'void', [['ptr', $v_h]]]);
  Z::$l = 646;
  f_zs_invoke($v_this, 'terminate', [z_concat('br label %', $v_le)]);
  Z::$l = 647;
  f_zs_invoke($v_this, 'label', [$v_lc]);
  Z::$l = 648;
  f_zs_invoke($v_this, 'rt', ['zl_try_leave', 'void', [['ptr', $v_h]]]);
  Z::$l = 649;
  ($v_x = f_zs_invoke($v_this, 'rt', ['zl_cur_exc', 'V', []]));
  Z::$l = 650;
  ($v_xs = f_zs_invoke($v_this, 'slot', []));
  Z::$l = 651;
  f_zs_invoke($v_this, 'storeTo', [$v_xs, $v_x]);
  Z::$l = 652;
  foreach (z_foreach($v_catches) as $_k180 => $_v180) {
    $v_c = $_v180;
    Z::$l = 653;
    ($v_xv = f_zs_invoke($v_this, 'loadFrom', [$v_xs]));
    Z::$l = 654;
    ($v_cond = f_zs_invoke($v_this, 'catchCond', [z_index($v_c, 2), $v_xv]));
    Z::$l = 655;
    ($v_lm = f_zs_invoke($v_this, 'newLabel', ['cmatch']));
    Z::$l = 656;
    ($v_ln = f_zs_invoke($v_this, 'newLabel', ['cnext']));
    Z::$l = 657;
    f_zs_invoke($v_this, 'terminate', [z_concat(z_concat(z_concat(z_concat(z_concat('br i1 ', $v_cond), ', label %'), $v_lm), ', label %'), $v_ln)]);
    Z::$l = 658;
    f_zs_invoke($v_this, 'label', [$v_lm]);
    Z::$l = 659;
    if (z_truthy((z_index($v_c, 3) !== null))) {
      Z::$l = 659;
      f_zs_invoke($v_this, 'store', [z_index($v_c, 3), f_zs_invoke($v_this, 'loadFrom', [$v_xs])]);
    }
    Z::$l = 660;
    f_zs_invoke($v_this, 'block', [z_index($v_c, 4)]);
    Z::$l = 661;
    f_zs_invoke($v_this, 'terminate', [z_concat('br label %', $v_le)]);
    Z::$l = 662;
    f_zs_invoke($v_this, 'label', [$v_ln]);
  }
  Z::$l = 664;
  f_zs_invoke($v_this, 'rt', ['zs_reraise', 'void', [['V', f_zs_invoke($v_this, 'loadFrom', [$v_xs])]]]);
  Z::$l = 665;
  f_zs_invoke($v_this, 'terminate', ['unreachable']);
  Z::$l = 666;
  f_zs_invoke($v_this, 'label', [$v_le]);
  return null;
}
function f_LlEmitter__tryStmt($v_this, $v_s) {
  $v_body = null;
  $v_catches = null;
  $v_fin = null;
  $v_h = null;
  $v_pend = null;
  $v_exc = null;
  $v_sj = null;
  $v_z = null;
  $v_lb = null;
  $v_lc = null;
  $v_lf = null;
  $v___r192 = null;
  $v___w193 = null;
  $v_p = null;
  $v_pt = null;
  $v_pc = null;
  $v_lr = null;
  $v_ld = null;
  Z::$l = 670;
  ($v_body = z_index($v_s, 2));
  Z::$l = 671;
  ($v_catches = z_index($v_s, 3));
  Z::$l = 672;
  ($v_fin = z_index($v_s, 4));
  Z::$l = 673;
  if (z_truthy(($v_fin === null))) {
    Z::$l = 673;
    f_zs_invoke($v_this, 'tryCatch', [$v_body, $v_catches]);
    Z::$l = 673;
    return null;
  }
  Z::$l = 674;
  ($v_h = f_zs_invoke($v_this, 'handler', []));
  Z::$l = 675;
  ($v_pend = f_zs_invoke($v_this, 'slot', []));
  Z::$l = 676;
  ($v_exc = f_zs_invoke($v_this, 'slot', []));
  Z::$l = 677;
  f_zs_invoke($v_this, 'storeTo', [$v_pend, f_zs_invoke($v_this, 'mkv', [2, '0'])]);
  Z::$l = 678;
  f_zs_invoke($v_this, 'storeTo', [$v_exc, f_zs_invoke($v_this, 'nullv', [])]);
  Z::$l = 679;
  f_zs_invoke($v_this, 'rt', ['zl_try_enter', 'void', [['ptr', $v_h]]]);
  Z::$l = 680;
  ($v_sj = f_zs_invoke($v_this, 'r', []));
  Z::$l = 681;
  f_zs_invoke($v_this, 'line', [z_concat(z_concat(z_concat($v_sj, ' = call i32 @_setjmp(ptr '), f_zs_invoke($v_this, 'jb', [$v_h])), ') returns_twice')]);
  Z::$l = 682;
  ($v_z = f_zs_invoke($v_this, 'r', []));
  Z::$l = 683;
  f_zs_invoke($v_this, 'line', [z_concat(z_concat(z_concat($v_z, ' = icmp eq i32 '), $v_sj), ', 0')]);
  Z::$l = 684;
  ($v_lb = f_zs_invoke($v_this, 'newLabel', ['fbody']));
  Z::$l = 685;
  ($v_lc = f_zs_invoke($v_this, 'newLabel', ['fexc']));
  Z::$l = 686;
  ($v_lf = f_zs_invoke($v_this, 'newLabel', ['ffin']));
  Z::$l = 687;
  f_zs_invoke($v_this, 'terminate', [z_concat(z_concat(z_concat(z_concat(z_concat('br i1 ', $v_z), ', label %'), $v_lb), ', label %'), $v_lc)]);
  Z::$l = 688;
  f_zs_invoke($v_this, 'label', [$v_lb]);
  Z::$l = 689;
  ($v___r192 = ['finally', $v_h, $v_fin]);
  Z::$l = 689;
  ($v___w193 = z_b_zs_obj_take($v_this, 'tries'));
  Z::$l = 689;
  z_apush($v___w193, $v___r192);
  Z::$l = 689;
  z_b_zs_obj_put($v_this, 'tries', $v___w193);
  Z::$l = 690;
  if (z_truthy((z_cmp(z_b_count($v_catches), 0) > 0))) {
    Z::$l = 690;
    f_zs_invoke($v_this, 'tryCatch', [$v_body, $v_catches]);
  } else {
    Z::$l = 690;
    f_zs_invoke($v_this, 'block', [$v_body]);
  }
  Z::$l = 691;
  z_b_zs_obj_set($v_this, 'tries', z_b_array_slice(z_b_zs_obj_get($v_this, 'tries'), 0, z_sub(z_b_count(z_b_zs_obj_get($v_this, 'tries')), 1)));
  Z::$l = 692;
  f_zs_invoke($v_this, 'rt', ['zl_try_leave', 'void', [['ptr', $v_h]]]);
  Z::$l = 693;
  f_zs_invoke($v_this, 'terminate', [z_concat('br label %', $v_lf)]);
  Z::$l = 694;
  f_zs_invoke($v_this, 'label', [$v_lc]);
  Z::$l = 695;
  f_zs_invoke($v_this, 'rt', ['zl_try_leave', 'void', [['ptr', $v_h]]]);
  Z::$l = 696;
  f_zs_invoke($v_this, 'storeTo', [$v_exc, f_zs_invoke($v_this, 'rt', ['zl_cur_exc', 'V', []])]);
  Z::$l = 697;
  f_zs_invoke($v_this, 'storeTo', [$v_pend, f_zs_invoke($v_this, 'mkv', [2, '1'])]);
  Z::$l = 698;
  f_zs_invoke($v_this, 'label', [$v_lf]);
  Z::$l = 699;
  f_zs_invoke($v_this, 'block', [$v_fin]);
  Z::$l = 700;
  ($v_p = f_zs_invoke($v_this, 'loadFrom', [$v_pend]));
  Z::$l = 701;
  ($v_pt = f_zs_invoke($v_this, 'r', []));
  Z::$l = 702;
  f_zs_invoke($v_this, 'line', [z_concat(z_concat(z_concat($v_pt, ' = extractvalue { i64, i64 } '), $v_p), ', 1')]);
  Z::$l = 703;
  ($v_pc = f_zs_invoke($v_this, 'r', []));
  Z::$l = 704;
  f_zs_invoke($v_this, 'line', [z_concat(z_concat(z_concat($v_pc, ' = icmp ne i64 '), $v_pt), ', 0')]);
  Z::$l = 705;
  ($v_lr = f_zs_invoke($v_this, 'newLabel', ['frethrow']));
  Z::$l = 706;
  ($v_ld = f_zs_invoke($v_this, 'newLabel', ['fdone']));
  Z::$l = 707;
  f_zs_invoke($v_this, 'terminate', [z_concat(z_concat(z_concat(z_concat(z_concat('br i1 ', $v_pc), ', label %'), $v_lr), ', label %'), $v_ld)]);
  Z::$l = 708;
  f_zs_invoke($v_this, 'label', [$v_lr]);
  Z::$l = 709;
  f_zs_invoke($v_this, 'rt', ['zs_reraise', 'void', [['V', f_zs_invoke($v_this, 'loadFrom', [$v_exc])]]]);
  Z::$l = 710;
  f_zs_invoke($v_this, 'terminate', ['unreachable']);
  Z::$l = 711;
  f_zs_invoke($v_this, 'label', [$v_ld]);
  return null;
}
function f_LlEmitter__chkType($v_this, $v_types, $v_v, $v_what) {
  Z::$l = 715;
  if (z_truthy((z_truthy((z_b_count($v_types) === 1)) && z_truthy(z_b_in_array(z_index($v_types, 0), ['int', 'float', 'string', 'bool', 'array']))))) {
    Z::$l = 716;
    return f_zs_invoke($v_this, 'rt', ['zv_chk', 'V', [['V', $v_v], ['ptr', f_zs_invoke($v_this, 'cstr', [z_index($v_types, 0)])], ['ptr', f_zs_invoke($v_this, 'cstr', [$v_what])]]]);
  }
  Z::$l = 718;
  return $v_v;
  return null;
}
function f_LlEmitter__stmt($v_this, $v_s) {
  $v_k = null;
  $v_line = null;
  $v_vals = null;
  $v_e = null;
  $v_first = null;
  $v_x = null;
  $v_c = null;
  $v_lt = null;
  $v_le = null;
  $v_lj = null;
  $v_id = null;
  $v_lc = null;
  $v_lb = null;
  $v_lbody = null;
  $v_ltop = null;
  $v_ltest = null;
  $v_lstep = null;
  $v_hdr = null;
  $v_it = null;
  $v_itSlot = null;
  $v_tg = null;
  $v_isArr = null;
  $v_lok = null;
  $v_lbad = null;
  $v_n = null;
  $v_iSlot = null;
  $v___r194 = null;
  $v___w195 = null;
  $v_lhead = null;
  $v_i = null;
  $v_cnd = null;
  $v_cur = null;
  $v_v = null;
  $v_kv = null;
  $v_i2 = null;
  $v_i3 = null;
  $v_sv = null;
  $v_svSlot = null;
  $v_labels = null;
  $v_def = null;
  $v_cv = null;
  $v_eq = null;
  $v_p = null;
  $v_lnext = null;
  $v_ret = null;
  $v_rv = null;
  $v_lv = null;
  $v_lp = null;
  $v_msg = null;
  $v_ex = null;
  $v_tv = null;
  Z::$l = 722;
  ($v_k = z_index($v_s, 0));
  Z::$l = 723;
  ($v_line = z_index($v_s, 1));
  Z::$l = 724;
  if (z_truthy(($v_k === ':Expr'))) {
    Z::$l = 724;
    f_zs_invoke($v_this, 'setLine', [$v_line]);
    Z::$l = 724;
    f_zs_invoke($v_this, 'expr', [z_index($v_s, 2)]);
    Z::$l = 724;
    return null;
  }
  Z::$l = 725;
  if (z_truthy(($v_k === ':Echo'))) {
    Z::$l = 726;
    f_zs_invoke($v_this, 'setLine', [$v_line]);
    Z::$l = 727;
    ($v_vals = []);
    Z::$l = 728;
    foreach (z_foreach(z_index($v_s, 2)) as $_k181 => $_v181) {
      $v_e = $_v181;
      Z::$l = 728;
      z_apush($v_vals, f_zs_invoke($v_this, 'expr', [$v_e]));
    }
    Z::$l = 729;
    ($v_first = 1);
    Z::$l = 730;
    foreach (z_foreach($v_vals) as $_k182 => $_v182) {
      $v_x = $_v182;
      Z::$l = 730;
      f_zs_invoke($v_this, 'rt', ['zs_echo_v', 'void', [['V', $v_x], ['i32', z_concat('', $v_first)]]]);
      Z::$l = 730;
      ($v_first = 0);
    }
    Z::$l = 731;
    f_zs_invoke($v_this, 'rt', ['zs_echo_end', 'void', []]);
    Z::$l = 732;
    return null;
  }
  Z::$l = 734;
  if (z_truthy(($v_k === ':Block'))) {
    Z::$l = 734;
    f_zs_invoke($v_this, 'block', [z_index($v_s, 2)]);
    Z::$l = 734;
    return null;
  }
  Z::$l = 735;
  if (z_truthy(($v_k === ':If'))) {
    Z::$l = 736;
    f_zs_invoke($v_this, 'setLine', [$v_line]);
    Z::$l = 737;
    ($v_c = f_zs_invoke($v_this, 'truthy', [f_zs_invoke($v_this, 'expr', [z_index($v_s, 2)])]));
    Z::$l = 738;
    ($v_lt = f_zs_invoke($v_this, 'newLabel', ['then']));
    Z::$l = 739;
    ($v_le = f_zs_invoke($v_this, 'newLabel', ['else']));
    Z::$l = 740;
    ($v_lj = f_zs_invoke($v_this, 'newLabel', ['endif']));
    Z::$l = 741;
    f_zs_invoke($v_this, 'terminate', [z_concat(z_concat(z_concat(z_concat(z_concat('br i1 ', $v_c), ', label %'), $v_lt), ', label %'), (z_truthy((z_index($v_s, 4) !== null)) ? $v_le : $v_lj))]);
    Z::$l = 742;
    f_zs_invoke($v_this, 'label', [$v_lt]);
    Z::$l = 743;
    f_zs_invoke($v_this, 'block', [z_index($v_s, 3)]);
    Z::$l = 744;
    f_zs_invoke($v_this, 'terminate', [z_concat('br label %', $v_lj)]);
    Z::$l = 745;
    if (z_truthy((z_index($v_s, 4) !== null))) {
      Z::$l = 746;
      f_zs_invoke($v_this, 'label', [$v_le]);
      Z::$l = 747;
      f_zs_invoke($v_this, 'block', [z_index($v_s, 4)]);
      Z::$l = 748;
      f_zs_invoke($v_this, 'terminate', [z_concat('br label %', $v_lj)]);
    }
    Z::$l = 750;
    f_zs_invoke($v_this, 'label', [$v_lj]);
    Z::$l = 751;
    return null;
  }
  Z::$l = 753;
  if (z_truthy(($v_k === ':While'))) {
    Z::$l = 754;
    ($v_id = f_zs_invoke($v_this, 'pushLoop', []));
    Z::$l = 755;
    ($v_lc = z_concat('cont_', $v_id));
    Z::$l = 756;
    ($v_lb = z_concat('brk_', $v_id));
    Z::$l = 757;
    ($v_lbody = f_zs_invoke($v_this, 'newLabel', ['wbody']));
    Z::$l = 758;
    f_zs_invoke($v_this, 'regionBegin', [$v_s, z_index($v_s, 3), [z_index($v_s, 2)], [], $v_id]);
    Z::$l = 759;
    f_zs_invoke($v_this, 'terminate', [z_concat('br label %', $v_lc)]);
    Z::$l = 760;
    f_zs_invoke($v_this, 'label', [$v_lc]);
    Z::$l = 761;
    f_zs_invoke($v_this, 'regionExit', []);
    Z::$l = 762;
    f_zs_invoke($v_this, 'setLine', [$v_line]);
    Z::$l = 763;
    ($v_c = f_zs_invoke($v_this, 'truthy', [f_zs_invoke($v_this, 'expr', [z_index($v_s, 2)])]));
    Z::$l = 764;
    f_zs_invoke($v_this, 'terminate', [z_concat(z_concat(z_concat(z_concat(z_concat('br i1 ', $v_c), ', label %'), $v_lbody), ', label %'), $v_lb)]);
    Z::$l = 765;
    f_zs_invoke($v_this, 'label', [$v_lbody]);
    Z::$l = 766;
    f_zs_invoke($v_this, 'regionEnter', []);
    Z::$l = 767;
    f_zs_invoke($v_this, 'block', [z_index($v_s, 3)]);
    Z::$l = 768;
    f_zs_invoke($v_this, 'terminate', [z_concat('br label %', $v_lc)]);
    Z::$l = 769;
    f_zs_invoke($v_this, 'label', [$v_lb]);
    Z::$l = 770;
    f_zs_invoke($v_this, 'regionExit', []);
    Z::$l = 771;
    f_zs_invoke($v_this, 'regionEnd', []);
    Z::$l = 772;
    f_zs_invoke($v_this, 'popLoop', []);
    Z::$l = 773;
    return null;
  }
  Z::$l = 775;
  if (z_truthy(($v_k === ':DoWhile'))) {
    Z::$l = 776;
    ($v_id = f_zs_invoke($v_this, 'pushLoop', []));
    Z::$l = 777;
    ($v_lc = z_concat('cont_', $v_id));
    Z::$l = 778;
    ($v_lb = z_concat('brk_', $v_id));
    Z::$l = 779;
    ($v_ltop = f_zs_invoke($v_this, 'newLabel', ['dtop']));
    Z::$l = 780;
    f_zs_invoke($v_this, 'regionBegin', [$v_s, z_index($v_s, 2), [z_index($v_s, 3)], [], $v_id]);
    Z::$l = 781;
    f_zs_invoke($v_this, 'terminate', [z_concat('br label %', $v_ltop)]);
    Z::$l = 782;
    f_zs_invoke($v_this, 'label', [$v_ltop]);
    Z::$l = 783;
    f_zs_invoke($v_this, 'regionEnter', []);
    Z::$l = 784;
    f_zs_invoke($v_this, 'block', [z_index($v_s, 2)]);
    Z::$l = 785;
    f_zs_invoke($v_this, 'terminate', [z_concat('br label %', $v_lc)]);
    Z::$l = 786;
    f_zs_invoke($v_this, 'label', [$v_lc]);
    Z::$l = 787;
    f_zs_invoke($v_this, 'regionExit', []);
    Z::$l = 788;
    f_zs_invoke($v_this, 'setLine', [$v_line]);
    Z::$l = 789;
    ($v_c = f_zs_invoke($v_this, 'truthy', [f_zs_invoke($v_this, 'expr', [z_index($v_s, 3)])]));
    Z::$l = 790;
    f_zs_invoke($v_this, 'terminate', [z_concat(z_concat(z_concat(z_concat(z_concat('br i1 ', $v_c), ', label %'), $v_ltop), ', label %'), $v_lb)]);
    Z::$l = 791;
    f_zs_invoke($v_this, 'label', [$v_lb]);
    Z::$l = 792;
    f_zs_invoke($v_this, 'regionExit', []);
    Z::$l = 793;
    f_zs_invoke($v_this, 'regionEnd', []);
    Z::$l = 794;
    f_zs_invoke($v_this, 'popLoop', []);
    Z::$l = 795;
    return null;
  }
  Z::$l = 797;
  if (z_truthy(($v_k === ':For'))) {
    Z::$l = 798;
    ($v_id = f_zs_invoke($v_this, 'pushLoop', []));
    Z::$l = 799;
    ($v_lc = z_concat('cont_', $v_id));
    Z::$l = 800;
    ($v_lb = z_concat('brk_', $v_id));
    Z::$l = 801;
    ($v_ltest = f_zs_invoke($v_this, 'newLabel', ['ftest']));
    Z::$l = 802;
    ($v_lbody = f_zs_invoke($v_this, 'newLabel', ['fbody']));
    Z::$l = 803;
    ($v_lstep = f_zs_invoke($v_this, 'newLabel', ['fstep']));
    Z::$l = 804;
    ($v_hdr = z_index($v_s, 4));
    Z::$l = 805;
    z_apush($v_hdr, z_index($v_s, 3));
    Z::$l = 806;
    f_zs_invoke($v_this, 'regionBegin', [$v_s, z_index($v_s, 5), $v_hdr, [], $v_id]);
    Z::$l = 807;
    foreach (z_foreach(z_index($v_s, 2)) as $_k183 => $_v183) {
      $v_e = $_v183;
      Z::$l = 807;
      f_zs_invoke($v_this, 'setLine', [$v_line]);
      Z::$l = 807;
      f_zs_invoke($v_this, 'expr', [$v_e]);
    }
    Z::$l = 808;
    f_zs_invoke($v_this, 'terminate', [z_concat('br label %', $v_ltest)]);
    Z::$l = 809;
    f_zs_invoke($v_this, 'label', [$v_ltest]);
    Z::$l = 810;
    if (z_truthy((z_index($v_s, 3) !== null))) {
      Z::$l = 811;
      f_zs_invoke($v_this, 'setLine', [$v_line]);
      Z::$l = 812;
      ($v_c = f_zs_invoke($v_this, 'truthy', [f_zs_invoke($v_this, 'expr', [z_index($v_s, 3)])]));
      Z::$l = 813;
      f_zs_invoke($v_this, 'terminate', [z_concat(z_concat(z_concat(z_concat(z_concat('br i1 ', $v_c), ', label %'), $v_lbody), ', label %'), $v_lb)]);
    } else {
      Z::$l = 814;
      f_zs_invoke($v_this, 'terminate', [z_concat('br label %', $v_lbody)]);
    }
    Z::$l = 815;
    f_zs_invoke($v_this, 'label', [$v_lbody]);
    Z::$l = 816;
    f_zs_invoke($v_this, 'regionEnter', []);
    Z::$l = 817;
    f_zs_invoke($v_this, 'block', [z_index($v_s, 5)]);
    Z::$l = 818;
    f_zs_invoke($v_this, 'terminate', [z_concat('br label %', $v_lc)]);
    Z::$l = 819;
    f_zs_invoke($v_this, 'label', [$v_lc]);
    Z::$l = 820;
    f_zs_invoke($v_this, 'regionExit', []);
    Z::$l = 821;
    foreach (z_foreach(z_index($v_s, 4)) as $_k184 => $_v184) {
      $v_e = $_v184;
      Z::$l = 821;
      f_zs_invoke($v_this, 'expr', [$v_e]);
    }
    Z::$l = 822;
    f_zs_invoke($v_this, 'terminate', [z_concat('br label %', $v_ltest)]);
    Z::$l = 823;
    f_zs_invoke($v_this, 'label', [$v_lb]);
    Z::$l = 824;
    f_zs_invoke($v_this, 'regionExit', []);
    Z::$l = 825;
    f_zs_invoke($v_this, 'regionEnd', []);
    Z::$l = 826;
    f_zs_invoke($v_this, 'popLoop', []);
    Z::$l = 827;
    return null;
  }
  Z::$l = 829;
  if (z_truthy(($v_k === ':Foreach'))) {
    Z::$l = 830;
    ($v_id = f_zs_invoke($v_this, 'pushLoop', []));
    Z::$l = 831;
    ($v_lc = z_concat('cont_', $v_id));
    Z::$l = 832;
    ($v_lb = z_concat('brk_', $v_id));
    Z::$l = 833;
    f_zs_invoke($v_this, 'setLine', [$v_line]);
    Z::$l = 834;
    ($v_it = f_zs_invoke($v_this, 'val', [z_index($v_s, 2)]));
    Z::$l = 835;
    f_zs_invoke($v_this, 'regionBegin', [$v_s, z_index($v_s, 5), [], [z_index($v_s, 3), z_index($v_s, 4)], $v_id]);
    Z::$l = 836;
    ($v_itSlot = f_zs_invoke($v_this, 'slot', []));
    Z::$l = 837;
    f_zs_invoke($v_this, 'storeTo', [$v_itSlot, $v_it]);
    Z::$l = 838;
    ($v_tg = f_zs_invoke($v_this, 'r', []));
    Z::$l = 839;
    f_zs_invoke($v_this, 'line', [z_concat(z_concat(z_concat($v_tg, ' = extractvalue { i64, i64 } '), $v_it), ', 0')]);
    Z::$l = 840;
    ($v_isArr = f_zs_invoke($v_this, 'r', []));
    Z::$l = 841;
    f_zs_invoke($v_this, 'line', [z_concat(z_concat(z_concat($v_isArr, ' = icmp eq i64 '), $v_tg), ', 5')]);
    Z::$l = 842;
    ($v_lok = f_zs_invoke($v_this, 'newLabel', ['fe_ok']));
    Z::$l = 843;
    ($v_lbad = f_zs_invoke($v_this, 'newLabel', ['fe_bad']));
    Z::$l = 844;
    f_zs_invoke($v_this, 'terminate', [z_concat(z_concat(z_concat(z_concat(z_concat('br i1 ', $v_isArr), ', label %'), $v_lok), ', label %'), $v_lbad)]);
    Z::$l = 845;
    f_zs_invoke($v_this, 'label', [$v_lbad]);
    Z::$l = 846;
    f_zs_invoke($v_this, 'rt', ['zl_foreach_die', 'void', [['V', $v_it]]]);
    Z::$l = 847;
    f_zs_invoke($v_this, 'terminate', ['unreachable']);
    Z::$l = 848;
    f_zs_invoke($v_this, 'label', [$v_lok]);
    Z::$l = 849;
    ($v_n = f_zs_invoke($v_this, 'rt', ['zs_array_len', 'i64', [['V', $v_it]]]));
    Z::$l = 850;
    ($v_iSlot = f_zs_invoke($v_this, 'r', []));
    Z::$l = 851;
    ($v___r194 = z_concat(z_concat('  ', $v_iSlot), ' = alloca i64, align 8'));
    Z::$l = 851;
    ($v___w195 = z_b_zs_obj_take($v_this, 'allocas'));
    Z::$l = 851;
    z_apush($v___w195, $v___r194);
    Z::$l = 851;
    z_b_zs_obj_put($v_this, 'allocas', $v___w195);
    Z::$l = 852;
    f_zs_invoke($v_this, 'line', [z_concat(z_concat('store i64 0, ptr ', $v_iSlot), ', align 8')]);
    Z::$l = 853;
    ($v_lhead = f_zs_invoke($v_this, 'newLabel', ['fe_head']));
    Z::$l = 854;
    ($v_lbody = f_zs_invoke($v_this, 'newLabel', ['fe_body']));
    Z::$l = 855;
    f_zs_invoke($v_this, 'terminate', [z_concat('br label %', $v_lhead)]);
    Z::$l = 856;
    f_zs_invoke($v_this, 'label', [$v_lhead]);
    Z::$l = 857;
    ($v_i = f_zs_invoke($v_this, 'r', []));
    Z::$l = 858;
    f_zs_invoke($v_this, 'line', [z_concat(z_concat(z_concat($v_i, ' = load i64, ptr '), $v_iSlot), ', align 8')]);
    Z::$l = 859;
    ($v_cnd = f_zs_invoke($v_this, 'r', []));
    Z::$l = 860;
    f_zs_invoke($v_this, 'line', [z_concat(z_concat(z_concat(z_concat($v_cnd, ' = icmp slt i64 '), $v_i), ', '), $v_n)]);
    Z::$l = 861;
    f_zs_invoke($v_this, 'terminate', [z_concat(z_concat(z_concat(z_concat(z_concat('br i1 ', $v_cnd), ', label %'), $v_lbody), ', label %'), $v_lb)]);
    Z::$l = 862;
    f_zs_invoke($v_this, 'label', [$v_lbody]);
    Z::$l = 863;
    ($v_cur = f_zs_invoke($v_this, 'loadFrom', [$v_itSlot]));
    Z::$l = 864;
    ($v_v = f_zs_invoke($v_this, 'rt', ['zv_get_raw', 'V', [['V', $v_cur], ['i64', $v_i]]]));
    Z::$l = 865;
    f_zs_invoke($v_this, 'store', [z_index($v_s, 4), $v_v]);
    Z::$l = 866;
    if (z_truthy((z_index($v_s, 3) !== null))) {
      Z::$l = 867;
      ($v_kv = f_zs_invoke($v_this, 'rt', ['zv_key_at', 'V', [['V', $v_cur], ['i64', $v_i]]]));
      Z::$l = 868;
      f_zs_invoke($v_this, 'store', [z_index($v_s, 3), $v_kv]);
    }
    Z::$l = 870;
    f_zs_invoke($v_this, 'regionEnter', []);
    Z::$l = 871;
    f_zs_invoke($v_this, 'block', [z_index($v_s, 5)]);
    Z::$l = 872;
    f_zs_invoke($v_this, 'terminate', [z_concat('br label %', $v_lc)]);
    Z::$l = 873;
    f_zs_invoke($v_this, 'label', [$v_lc]);
    Z::$l = 874;
    f_zs_invoke($v_this, 'regionExit', []);
    Z::$l = 875;
    ($v_i2 = f_zs_invoke($v_this, 'r', []));
    Z::$l = 876;
    f_zs_invoke($v_this, 'line', [z_concat(z_concat(z_concat($v_i2, ' = load i64, ptr '), $v_iSlot), ', align 8')]);
    Z::$l = 877;
    ($v_i3 = f_zs_invoke($v_this, 'r', []));
    Z::$l = 878;
    f_zs_invoke($v_this, 'line', [z_concat(z_concat(z_concat($v_i3, ' = add i64 '), $v_i2), ', 1')]);
    Z::$l = 879;
    f_zs_invoke($v_this, 'line', [z_concat(z_concat(z_concat(z_concat('store i64 ', $v_i3), ', ptr '), $v_iSlot), ', align 8')]);
    Z::$l = 880;
    f_zs_invoke($v_this, 'terminate', [z_concat('br label %', $v_lhead)]);
    Z::$l = 881;
    f_zs_invoke($v_this, 'label', [$v_lb]);
    Z::$l = 882;
    f_zs_invoke($v_this, 'regionExit', []);
    Z::$l = 883;
    f_zs_invoke($v_this, 'regionEnd', []);
    Z::$l = 884;
    f_zs_invoke($v_this, 'popLoop', []);
    Z::$l = 885;
    return null;
  }
  Z::$l = 887;
  if (z_truthy(($v_k === ':Switch'))) {
    Z::$l = 888;
    ($v_id = f_zs_invoke($v_this, 'pushLoop', []));
    Z::$l = 889;
    ($v_lb = z_concat('brk_', $v_id));
    Z::$l = 890;
    ($v_lc = z_concat('cont_', $v_id));
    Z::$l = 891;
    f_zs_invoke($v_this, 'setLine', [$v_line]);
    Z::$l = 892;
    ($v_sv = f_zs_invoke($v_this, 'expr', [z_index($v_s, 2)]));
    Z::$l = 893;
    ($v_svSlot = f_zs_invoke($v_this, 'slot', []));
    Z::$l = 894;
    f_zs_invoke($v_this, 'storeTo', [$v_svSlot, $v_sv]);
    Z::$l = 895;
    ($v_n = z_b_count(z_index($v_s, 3)));
    Z::$l = 896;
    ($v_labels = []);
    Z::$l = 897;
    ($v_i = 0);
    for (; z_truthy((z_cmp($v_i, $v_n) < 0)); z_last($_t37 = $v_i, $v_i = z_add($_t37, 1), $_t37)) {
      Z::$l = 897;
      z_apush($v_labels, f_zs_invoke($v_this, 'newLabel', ['case']));
    }
    Z::$l = 898;
    ($v_def = z_neg(1));
    Z::$l = 899;
    ($v_i = 0);
    for (; z_truthy((z_cmp($v_i, $v_n) < 0)); z_last($_t38 = $v_i, $v_i = z_add($_t38, 1), $_t38)) {
      Z::$l = 900;
      ($v_c = z_index(z_index($v_s, 3), $v_i));
      Z::$l = 901;
      if (z_truthy((z_index($v_c, 2) === null))) {
        Z::$l = 901;
        ($v_def = $v_i);
        continue 1;
      }
      Z::$l = 902;
      ($v_cv = f_zs_invoke($v_this, 'expr', [z_index($v_c, 2)]));
      Z::$l = 903;
      ($v_eq = f_zs_invoke($v_this, 'rt', ['zv_eq', 'i32', [['V', f_zs_invoke($v_this, 'loadFrom', [$v_svSlot])], ['V', $v_cv]]]));
      Z::$l = 904;
      ($v_p = f_zs_invoke($v_this, 'r', []));
      Z::$l = 905;
      f_zs_invoke($v_this, 'line', [z_concat(z_concat(z_concat($v_p, ' = icmp ne i32 '), $v_eq), ', 0')]);
      Z::$l = 906;
      ($v_lnext = f_zs_invoke($v_this, 'newLabel', ['cmp']));
      Z::$l = 907;
      f_zs_invoke($v_this, 'terminate', [z_concat(z_concat(z_concat(z_concat(z_concat('br i1 ', $v_p), ', label %'), z_index($v_labels, $v_i)), ', label %'), $v_lnext)]);
      Z::$l = 908;
      f_zs_invoke($v_this, 'label', [$v_lnext]);
    }
    Z::$l = 910;
    f_zs_invoke($v_this, 'terminate', [z_concat('br label %', (z_truthy((z_cmp($v_def, 0) >= 0)) ? z_index($v_labels, $v_def) : $v_lb))]);
    Z::$l = 911;
    ($v_i = 0);
    for (; z_truthy((z_cmp($v_i, $v_n) < 0)); z_last($_t39 = $v_i, $v_i = z_add($_t39, 1), $_t39)) {
      Z::$l = 912;
      f_zs_invoke($v_this, 'label', [z_index($v_labels, $v_i)]);
      Z::$l = 913;
      f_zs_invoke($v_this, 'block', [z_index(z_index(z_index($v_s, 3), $v_i), 3)]);
    }
    Z::$l = 915;
    f_zs_invoke($v_this, 'terminate', [z_concat('br label %', $v_lb)]);
    Z::$l = 916;
    f_zs_invoke($v_this, 'label', [$v_lb]);
    Z::$l = 917;
    f_zs_invoke($v_this, 'label', [$v_lc]);
    Z::$l = 918;
    f_zs_invoke($v_this, 'popLoop', []);
    Z::$l = 919;
    return null;
  }
  Z::$l = 921;
  if (z_truthy(($v_k === ':Return'))) {
    Z::$l = 922;
    f_zs_invoke($v_this, 'setLine', [$v_line]);
    Z::$l = 923;
    ($v_v = (z_truthy((z_index($v_s, 2) === null)) ? f_zs_invoke($v_this, 'nullv', []) : f_zs_invoke($v_this, 'val', [z_index($v_s, 2)])));
    Z::$l = 924;
    ($v_ret = (($_t40 = z_indexopt(z_indexopt(z_indexopt(z_b_zs_obj_get($v_this, 'ir'), 'funcs'), z_b_zs_obj_get($v_this, 'curFunc')), 'ret')) !== null ? $_t40 : []));
    Z::$l = 925;
    ($v_rv = f_zs_invoke($v_this, 'chkType', [$v_ret, $v_v, z_concat('wartość zwracana funkcji ', z_b_zs_obj_get($v_this, 'curFunc'))]));
    Z::$l = 926;
    if (z_truthy((z_cmp(z_b_count(z_b_zs_obj_get($v_this, 'tries')), 0) > 0))) {
      Z::$l = 926;
      f_zs_invoke($v_this, 'jumpOut', [0]);
    }
    Z::$l = 927;
    f_zs_invoke($v_this, 'terminate', [z_concat('ret { i64, i64 } ', $v_rv)]);
    Z::$l = 928;
    return null;
  }
  Z::$l = 930;
  if (z_truthy((z_truthy(($v_k === ':Break')) || z_truthy(($v_k === ':Continue'))))) {
    Z::$l = 931;
    ($v_lv = z_index($v_s, 2));
    Z::$l = 932;
    ($v_i = z_sub(z_b_count(z_b_zs_obj_get($v_this, 'loops')), $v_lv));
    Z::$l = 933;
    if (z_truthy((z_cmp($v_i, 0) < 0))) {
      Z::$l = 933;
      z_raise(new ZExc(0, z_concat(z_concat(z_concat(z_concat('emit_llvm: break/continue ', $v_lv), ' poza pętlą (linia '), $v_line), ')')));
    }
    Z::$l = 934;
    ($v_lp = z_index(z_b_zs_obj_get($v_this, 'loops'), $v_i));
    Z::$l = 935;
    f_zs_invoke($v_this, 'jumpOut', [z_index($v_lp, 2)]);
    Z::$l = 936;
    f_zs_invoke($v_this, 'terminate', [z_concat(z_concat('br label %', (z_truthy(($v_k === ':Break')) ? 'brk_' : 'cont_')), z_index($v_lp, 0))]);
    Z::$l = 937;
    return null;
  }
  Z::$l = 939;
  if (z_truthy(($v_k === ':Try'))) {
    Z::$l = 939;
    f_zs_invoke($v_this, 'tryStmt', [$v_s]);
    Z::$l = 939;
    return null;
  }
  Z::$l = 940;
  if (z_truthy(($v_k === ':Throw'))) {
    Z::$l = 941;
    ($v_x = z_index($v_s, 2));
    Z::$l = 942;
    f_zs_invoke($v_this, 'setLine', [$v_line]);
    Z::$l = 943;
    if (z_truthy((z_index($v_x, 0) === ':New'))) {
      Z::$l = 944;
      ($v_msg = (z_truthy((z_cmp(z_b_count(z_index($v_x, 3)), 0) > 0)) ? f_zs_invoke($v_this, 'expr', [z_index(z_index(z_index($v_x, 3), 0), 3)]) : f_zs_invoke($v_this, 'emptyStr', [])));
      Z::$l = 945;
      ($v_ex = f_zs_invoke($v_this, 'rt', ['zv_exc_new', 'V', [['i32', (z_truthy((z_index($v_x, 2) === 'Error')) ? '1' : '0')], ['V', $v_msg]]]));
      Z::$l = 946;
      f_zs_invoke($v_this, 'rt', ['zs_raise', 'void', [['V', $v_ex]]]);
    } else {
      Z::$l = 947;
      ($v_tv = f_zs_invoke($v_this, 'expr', [$v_x]));
      Z::$l = 947;
      f_zs_invoke($v_this, 'setLine', [$v_line]);
      Z::$l = 947;
      f_zs_invoke($v_this, 'vcall', ['b_throw_v', [$v_tv]]);
    }
    Z::$l = 948;
    f_zs_invoke($v_this, 'terminate', ['unreachable']);
    Z::$l = 949;
    return null;
  }
  Z::$l = 951;
  z_raise(new ZExc(0, z_concat(z_concat(z_concat(z_concat('emit_llvm: instrukcja ', $v_k), ' (linia '), $v_line), ')')));
  return null;
}
function f_LlEmitter__emptyStr($v_this) {
  $v_i = null;
  $v_p = null;
  Z::$l = 955;
  ($v_i = f_zs_invoke($v_this, 'strSlot', ['']));
  Z::$l = 956;
  ($v_p = f_zs_invoke($v_this, 'r', []));
  Z::$l = 957;
  f_zs_invoke($v_this, 'line', [z_concat(z_concat($v_p, ' = getelementptr inbounds { i64, i64 }, ptr @S, i64 '), $v_i)]);
  Z::$l = 958;
  return f_zs_invoke($v_this, 'loadFrom', [$v_p]);
  return null;
}
function f_LlEmitter__beginFunc($v_this, $v_vol) {
  Z::$l = 963;
  z_b_zs_obj_set($v_this, 'code', []);
  Z::$l = 964;
  z_b_zs_obj_set($v_this, 'allocas', []);
  Z::$l = 965;
  z_b_zs_obj_set($v_this, 'loops', []);
  Z::$l = 966;
  z_b_zs_obj_set($v_this, 'tries', []);
  Z::$l = 967;
  z_b_zs_obj_set($v_this, 'term', false);
  Z::$l = 968;
  z_b_zs_obj_set($v_this, 'vol', (z_truthy($v_vol) ? 'volatile ' : ''));
  return null;
}
function f_LlEmitter__initLocals($v_this, $v_locals, $v_params) {
  $v_n = null;
  $v___r196 = null;
  $v___w197 = null;
  Z::$l = 972;
  z_b_zs_obj_set($v_this, 'known', $v_locals);
  Z::$l = 973;
  foreach (z_foreach($v_locals) as $_k188 => $_v188) {
    $v_n = $_v188;
    Z::$l = 974;
    ($v___r196 = z_concat(z_concat('  ', f_zs_invoke($v_this, 'ident', [$v_n])), ' = alloca { i64, i64 }, align 8'));
    Z::$l = 974;
    ($v___w197 = z_b_zs_obj_take($v_this, 'allocas'));
    Z::$l = 974;
    z_apush($v___w197, $v___r196);
    Z::$l = 974;
    z_b_zs_obj_put($v_this, 'allocas', $v___w197);
  }
  Z::$l = 976;
  foreach (z_foreach($v_locals) as $_k189 => $_v189) {
    $v_n = $_v189;
    Z::$l = 977;
    if (z_truthy(!z_truthy(z_b_in_array($v_n, $v_params)))) {
      Z::$l = 977;
      f_zs_invoke($v_this, 'store', [$v_n, f_zs_invoke($v_this, 'nullv', [])]);
    }
  }
  return null;
}
function f_LlEmitter__finishFunc($v_this, $v_header, $v_kind) {
  $v_out = null;
  $v_a = null;
  $v_c = null;
  Z::$l = 982;
  if (z_truthy(!z_truthy(z_b_zs_obj_get($v_this, 'term')))) {
    Z::$l = 983;
    if (z_truthy(($v_kind === 'V'))) {
      Z::$l = 983;
      f_zs_invoke($v_this, 'terminate', ['ret { i64, i64 } zeroinitializer']);
    } else {
      Z::$l = 984;
      f_zs_invoke($v_this, 'terminate', ['ret i32 0']);
    }
  }
  Z::$l = 986;
  ($v_out = [z_concat($v_header, ' {'), 'entry:']);
  Z::$l = 987;
  foreach (z_foreach(z_b_zs_obj_get($v_this, 'allocas')) as $_k190 => $_v190) {
    $v_a = $_v190;
    Z::$l = 987;
    z_apush($v_out, $v_a);
  }
  Z::$l = 988;
  z_apush($v_out, '  br label %body');
  Z::$l = 989;
  z_apush($v_out, 'body:');
  Z::$l = 990;
  foreach (z_foreach(z_b_zs_obj_get($v_this, 'code')) as $_k191 => $_v191) {
    $v_c = $_v191;
    Z::$l = 990;
    z_apush($v_out, $v_c);
  }
  Z::$l = 991;
  z_apush($v_out, '}');
  Z::$l = 992;
  z_apush($v_out, '');
  Z::$l = 993;
  return $v_out;
  return null;
}
function f_LlEmitter__funcDef($v_this, $v_name) {
  $v_f = null;
  $v_pn = null;
  $v_sig = null;
  $v_p = null;
  $v_i = null;
  $v_r0 = null;
  $v_r1 = null;
  $v_v = null;
  $v_inner = null;
  $v_w = null;
  $v_args = null;
  $v_l = null;
  Z::$l = 997;
  ($v_f = z_index(z_index(z_b_zs_obj_get($v_this, 'ir'), 'funcs'), $v_name));
  Z::$l = 998;
  z_b_zs_obj_set($v_this, 'curFunc', $v_name);
  Z::$l = 999;
  z_b_zs_obj_set($v_this, 'fnCounts', f_Workspace_regions__var_counts(z_index($v_f, 'body'), []));
  Z::$l = 1000;
  f_zs_invoke($v_this, 'beginFunc', [z_index($v_f, 'has_try')]);
  Z::$l = 1001;
  ($v_pn = []);
  Z::$l = 1002;
  ($v_sig = []);
  Z::$l = 1003;
  foreach (z_foreach(z_index($v_f, 'params')) as $_k192 => $_v192) {
    $v_p = $_v192;
    Z::$l = 1003;
    z_apush($v_pn, z_index($v_p, 2));
  }
  Z::$l = 1004;
  ($v_i = 0);
  Z::$l = 1005;
  foreach (z_foreach(z_index($v_f, 'params')) as $_k193 => $_v193) {
    $v_p = $_v193;
    Z::$l = 1005;
    z_apush($v_sig, z_concat(z_concat(z_concat(z_concat('i64 %a', $v_i), 'x, i64 %a'), $v_i), 'y'));
    Z::$l = 1005;
    z_last($_t41 = $v_i, $v_i = z_add($_t41, 1), $_t41);
  }
  Z::$l = 1006;
  f_zs_invoke($v_this, 'initLocals', [z_index($v_f, 'locals'), $v_pn]);
  Z::$l = 1007;
  ($v_i = 0);
  Z::$l = 1008;
  foreach (z_foreach(z_index($v_f, 'params')) as $_k194 => $_v194) {
    $v_p = $_v194;
    Z::$l = 1009;
    ($v_r0 = f_zs_invoke($v_this, 'r', []));
    Z::$l = 1010;
    ($v_r1 = f_zs_invoke($v_this, 'r', []));
    Z::$l = 1011;
    f_zs_invoke($v_this, 'line', [z_concat(z_concat(z_concat($v_r0, ' = insertvalue { i64, i64 } undef, i64 %a'), $v_i), 'x, 0')]);
    Z::$l = 1012;
    f_zs_invoke($v_this, 'line', [z_concat(z_concat(z_concat(z_concat(z_concat($v_r1, ' = insertvalue { i64, i64 } '), $v_r0), ', i64 %a'), $v_i), 'y, 1')]);
    Z::$l = 1013;
    ($v_v = $v_r1);
    Z::$l = 1014;
    if (z_truthy((z_truthy((z_b_count(z_index($v_p, 3)) === 1)) && z_truthy(z_b_in_array(z_index(z_index($v_p, 3), 0), ['int', 'float', 'string', 'bool', 'array']))))) {
      Z::$l = 1015;
      ($v_v = f_zs_invoke($v_this, 'rt', ['zv_chk', 'V', [['V', $v_r1], ['ptr', f_zs_invoke($v_this, 'cstr', [z_index(z_index($v_p, 3), 0)])], ['ptr', f_zs_invoke($v_this, 'cstr', [z_concat(z_concat(z_concat('argument $', z_index($v_p, 2)), ' funkcji '), $v_name)])]]]));
    }
    Z::$l = 1017;
    f_zs_invoke($v_this, 'store', [z_index($v_p, 2), $v_v]);
    Z::$l = 1018;
    z_last($_t42 = $v_i, $v_i = z_add($_t42, 1), $_t42);
  }
  Z::$l = 1020;
  f_zs_invoke($v_this, 'block', [z_index($v_f, 'body')]);
  Z::$l = 1021;
  ($v_inner = f_zs_invoke($v_this, 'finishFunc', [z_concat(z_concat(z_concat(z_concat('define internal { i64, i64 } @"f_', $v_name), '__z"('), z_b_join($v_sig, ', ')), ')'), 'V']));
  Z::$l = 1023;
  ($v_w = []);
  Z::$l = 1024;
  z_apush($v_w, z_concat(z_concat(z_concat(z_concat('define internal { i64, i64 } @"f_', $v_name), '"('), z_b_join($v_sig, ', ')), ') {'));
  Z::$l = 1025;
  z_apush($v_w, 'entry:');
  Z::$l = 1026;
  z_apush($v_w, '  %lv = call i32 @zs_enter()');
  Z::$l = 1027;
  ($v_args = []);
  Z::$l = 1028;
  ($v_i = 0);
  Z::$l = 1029;
  foreach (z_foreach(z_index($v_f, 'params')) as $_k195 => $_v195) {
    $v_p = $_v195;
    Z::$l = 1029;
    z_apush($v_args, z_concat(z_concat(z_concat(z_concat('i64 %a', $v_i), 'x, i64 %a'), $v_i), 'y'));
    Z::$l = 1029;
    z_last($_t43 = $v_i, $v_i = z_add($_t43, 1), $_t43);
  }
  Z::$l = 1030;
  z_apush($v_w, z_concat(z_concat(z_concat(z_concat('  %r = call { i64, i64 } @"f_', $v_name), '__z"('), z_b_join($v_args, ', ')), ')'));
  Z::$l = 1031;
  z_apush($v_w, '  %rx = extractvalue { i64, i64 } %r, 0');
  Z::$l = 1032;
  z_apush($v_w, '  %ry = extractvalue { i64, i64 } %r, 1');
  Z::$l = 1033;
  z_apush($v_w, '  %o = call { i64, i64 } @zs_leave(i32 %lv, i64 %rx, i64 %ry)');
  Z::$l = 1034;
  z_apush($v_w, '  ret { i64, i64 } %o');
  Z::$l = 1035;
  z_apush($v_w, '}');
  Z::$l = 1036;
  z_apush($v_w, '');
  Z::$l = 1037;
  foreach (z_foreach($v_w) as $_k196 => $_v196) {
    $v_l = $_v196;
    Z::$l = 1037;
    z_apush($v_inner, $v_l);
  }
  Z::$l = 1038;
  return $v_inner;
  return null;
}
function f_LlEmitter__generate($v_this, $v_triple) {
  $v_ir = null;
  $v_funcs = null;
  $v_name = null;
  $v_l = null;
  $v_topLines = null;
  $v_o = null;
  $v_d = null;
  $v_sc = null;
  $v_i = null;
  $v_c = null;
  $v_s = null;
  Z::$l = 1042;
  ($v_ir = z_b_zs_obj_get($v_this, 'ir'));
  Z::$l = 1043;
  ($v_funcs = []);
  Z::$l = 1044;
  foreach (z_foreach(z_index($v_ir, 'order')) as $_k197 => $_v197) {
    $v_name = $_v197;
    Z::$l = 1044;
    foreach (z_foreach(f_zs_invoke($v_this, 'funcDef', [$v_name])) as $_k198 => $_v198) {
      $v_l = $_v198;
      Z::$l = 1044;
      z_apush($v_funcs, $v_l);
    }
  }
  Z::$l = 1045;
  z_b_zs_obj_set($v_this, 'curFunc', '');
  Z::$l = 1046;
  z_b_zs_obj_set($v_this, 'fnCounts', f_Workspace_regions__var_counts(z_index($v_ir, 'top'), []));
  Z::$l = 1047;
  f_zs_invoke($v_this, 'beginFunc', [z_index($v_ir, 'top_has_try')]);
  Z::$l = 1048;
  f_zs_invoke($v_this, 'initLocals', [z_index($v_ir, 'toplocals'), []]);
  Z::$l = 1049;
  f_zs_invoke($v_this, 'block', [z_index($v_ir, 'top')]);
  Z::$l = 1050;
  ($v_topLines = f_zs_invoke($v_this, 'finishFunc', ['define internal i32 @zs_top()', 'i32']));
  Z::$l = 1052;
  ($v_o = []);
  Z::$l = 1053;
  z_apush($v_o, '; wygenerowane przez zsc (backend LLVM, Z# 0.0.1) — nie edytuj');
  Z::$l = 1054;
  z_apush($v_o, z_concat(z_concat('target triple = "', $v_triple), '"'));
  Z::$l = 1055;
  z_apush($v_o, '');
  Z::$l = 1056;
  foreach (z_foreach(f_zs_invoke($v_this, 'decls', [])) as $_k199 => $_v199) {
    $v_d = $_v199;
    Z::$l = 1056;
    z_apush($v_o, $v_d);
  }
  Z::$l = 1057;
  z_apush($v_o, 'attributes #0 = { returns_twice }');
  Z::$l = 1058;
  z_apush($v_o, '');
  Z::$l = 1059;
  ($v_sc = (z_truthy((z_cmp(z_b_count(z_b_zs_obj_get($v_this, 'strList')), 0) > 0)) ? z_b_count(z_b_zs_obj_get($v_this, 'strList')) : 1));
  Z::$l = 1060;
  z_apush($v_o, z_concat(z_concat('@S = internal global [', $v_sc), ' x { i64, i64 }] zeroinitializer, align 16'));
  Z::$l = 1061;
  ($v_i = 0);
  Z::$l = 1062;
  foreach (z_foreach(z_b_zs_obj_get($v_this, 'cstrList')) as $_k200 => $_v200) {
    $v_c = $_v200;
    Z::$l = 1063;
    z_apush($v_o, z_concat(z_concat(z_concat(z_concat(z_concat(z_concat('@.c', $v_i), ' = private unnamed_addr constant ['), z_add(z_b_strlen($v_c), 1)), ' x i8] c"'), f_zs_invoke($v_this, 'esc', [$v_c])), '\\00", align 1'));
    Z::$l = 1064;
    z_last($_t44 = $v_i, $v_i = z_add($_t44, 1), $_t44);
  }
  Z::$l = 1066;
  ($v_i = 0);
  Z::$l = 1067;
  foreach (z_foreach(z_b_zs_obj_get($v_this, 'strList')) as $_k201 => $_v201) {
    $v_s = $_v201;
    Z::$l = 1068;
    z_apush($v_o, z_concat(z_concat(z_concat(z_concat(z_concat(z_concat('@.s', $v_i), ' = private unnamed_addr constant ['), z_add(z_b_strlen($v_s), 1)), ' x i8] c"'), f_zs_invoke($v_this, 'esc', [$v_s])), '\\00", align 1'));
    Z::$l = 1069;
    z_last($_t45 = $v_i, $v_i = z_add($_t45, 1), $_t45);
  }
  Z::$l = 1071;
  z_apush($v_o, '');
  Z::$l = 1072;
  z_apush($v_o, 'define internal void @zs_strings_init() {');
  Z::$l = 1073;
  z_apush($v_o, 'entry:');
  Z::$l = 1074;
  ($v_i = 0);
  Z::$l = 1075;
  foreach (z_foreach(z_b_zs_obj_get($v_this, 'strList')) as $_k202 => $_v202) {
    $v_s = $_v202;
    Z::$l = 1076;
    z_apush($v_o, z_concat(z_concat(z_concat(z_concat(z_concat(z_concat('  %r', $v_i), ' = call { i64, i64 } @zv_strn(ptr @.s'), $v_i), ', i64 '), z_b_strlen($v_s)), ')'));
    Z::$l = 1077;
    z_apush($v_o, z_concat(z_concat(z_concat('  %p', $v_i), ' = getelementptr inbounds { i64, i64 }, ptr @S, i64 '), $v_i));
    Z::$l = 1078;
    z_apush($v_o, z_concat(z_concat(z_concat(z_concat('  store { i64, i64 } %r', $v_i), ', ptr %p'), $v_i), ', align 8'));
    Z::$l = 1079;
    z_last($_t46 = $v_i, $v_i = z_add($_t46, 1), $_t46);
  }
  Z::$l = 1081;
  z_apush($v_o, '  ret void');
  Z::$l = 1082;
  z_apush($v_o, '}');
  Z::$l = 1083;
  z_apush($v_o, '');
  Z::$l = 1084;
  foreach (z_foreach($v_funcs) as $_k203 => $_v203) {
    $v_l = $_v203;
    Z::$l = 1084;
    z_apush($v_o, $v_l);
  }
  Z::$l = 1085;
  foreach (z_foreach($v_topLines) as $_k204 => $_v204) {
    $v_l = $_v204;
    Z::$l = 1085;
    z_apush($v_o, $v_l);
  }
  Z::$l = 1086;
  z_apush($v_o, 'define i32 @main(i32 %argc, ptr %argv) {');
  Z::$l = 1087;
  z_apush($v_o, 'entry:');
  Z::$l = 1088;
  z_apush($v_o, '  call void @zs_init(i32 %argc, ptr %argv)');
  Z::$l = 1089;
  z_apush($v_o, '  call void @zs_strings_init()');
  Z::$l = 1090;
  z_apush($v_o, '  %top_lv = call i32 @zs_enter()');
  Z::$l = 1091;
  z_apush($v_o, '  %rc = call i32 @zs_top()');
  Z::$l = 1092;
  if (z_truthy((z_truthy(z_b_has_key(z_index($v_ir, 'funcs'), 'main')) && z_truthy(!z_truthy(z_index($v_ir, 'calls_main')))))) {
    Z::$l = 1093;
    z_apush($v_o, '  %m = call { i64, i64 } @"f_main"()');
    Z::$l = 1094;
    z_apush($v_o, '  %mt = extractvalue { i64, i64 } %m, 0');
    Z::$l = 1095;
    z_apush($v_o, '  %mi = extractvalue { i64, i64 } %m, 1');
    Z::$l = 1096;
    z_apush($v_o, '  %isint = icmp eq i64 %mt, 2');
    Z::$l = 1097;
    z_apush($v_o, '  %mc = trunc i64 %mi to i32');
    Z::$l = 1098;
    z_apush($v_o, '  %rc2 = select i1 %isint, i32 %mc, i32 %rc');
    Z::$l = 1099;
    z_apush($v_o, '  call void @zs_shutdown()');
    Z::$l = 1100;
    z_apush($v_o, '  ret i32 %rc2');
  } else {
    Z::$l = 1102;
    z_apush($v_o, '  call void @zs_shutdown()');
    Z::$l = 1103;
    z_apush($v_o, '  ret i32 %rc');
  }
  Z::$l = 1105;
  z_apush($v_o, '}');
  Z::$l = 1106;
  return z_concat(z_b_join($v_o, '
'), '
');
  return null;
}
function f_LlEmitter__decls($v_this) {
  $v_d = null;
  $v_v = null;
  $v_f = null;
  $v_mod = null;
  $v_fns = null;
  $v_fn = null;
  $v_ar = null;
  $v_n = null;
  $v_ps = null;
  $v_i = null;
  Z::$l = 1110;
  ($v_d = []);
  Z::$l = 1111;
  ($v_v = 'i64, i64');
  Z::$l = 1112;
  z_apush($v_d, 'declare void @zs_init(i32, ptr)');
  Z::$l = 1113;
  z_apush($v_d, 'declare void @zs_shutdown()');
  Z::$l = 1114;
  z_apush($v_d, 'declare i32 @zs_enter()');
  Z::$l = 1115;
  z_apush($v_d, 'declare { i64, i64 } @zs_leave(i32, i64, i64)');
  Z::$l = 1116;
  z_apush($v_d, 'declare { i64, i64 } @zs_carry_v(i64, i64, i32)');
  Z::$l = 1117;
  z_apush($v_d, 'declare void @zs_pop(i32)');
  Z::$l = 1118;
  z_apush($v_d, 'declare i32 @zs_cur_depth()');
  Z::$l = 1119;
  z_apush($v_d, 'declare { i64, i64 } @zv_strn(ptr, i64)');
  Z::$l = 1120;
  z_apush($v_d, 'declare { i64, i64 } @zl_float_lit(ptr)');
  Z::$l = 1121;
  z_apush($v_d, 'declare void @zl_try_enter(ptr)');
  Z::$l = 1122;
  z_apush($v_d, 'declare void @zl_try_leave(ptr)');
  Z::$l = 1123;
  z_apush($v_d, 'declare { i64, i64 } @zl_cur_exc()');
  Z::$l = 1124;
  z_apush($v_d, z_concat(z_concat('declare void @zl_foreach_die(', $v_v), ')'));
  Z::$l = 1125;
  z_apush($v_d, 'declare { i64, i64 } @zl_undef_var(ptr)');
  Z::$l = 1126;
  z_apush($v_d, 'declare i32 @_setjmp(ptr) #0');
  Z::$l = 1127;
  z_apush($v_d, '@zs_line = external global i64, align 8');
  Z::$l = 1128;
  z_apush($v_d, z_concat(z_concat('declare i32 @zv_truthy(', $v_v), ')'));
  Z::$l = 1129;
  z_apush($v_d, z_concat(z_concat(z_concat(z_concat('declare i32 @zv_eq(', $v_v), ', '), $v_v), ')'));
  Z::$l = 1130;
  z_apush($v_d, z_concat(z_concat(z_concat(z_concat('declare i32 @zv_ident(', $v_v), ', '), $v_v), ')'));
  Z::$l = 1131;
  z_apush($v_d, z_concat(z_concat(z_concat(z_concat('declare i32 @zv_cmp(', $v_v), ', '), $v_v), ')'));
  Z::$l = 1132;
  z_apush($v_d, z_concat(z_concat('declare i32 @zv_exc_is(', $v_v), ', i32)'));
  Z::$l = 1133;
  z_apush($v_d, z_concat(z_concat('declare i64 @zs_array_len(', $v_v), ')'));
  Z::$l = 1134;
  z_apush($v_d, 'declare { i64, i64 } @zv_arr_new(i64)');
  Z::$l = 1135;
  z_apush($v_d, z_concat(z_concat(z_concat(z_concat('declare void @zv_append(', $v_v), ', '), $v_v), ')'));
  Z::$l = 1136;
  z_apush($v_d, z_concat(z_concat(z_concat(z_concat(z_concat(z_concat('declare void @zv_set(', $v_v), ', '), $v_v), ', '), $v_v), ')'));
  Z::$l = 1137;
  z_apush($v_d, z_concat(z_concat('declare { i64, i64 } @zv_get_raw(', $v_v), ', i64)'));
  Z::$l = 1138;
  z_apush($v_d, z_concat(z_concat('declare { i64, i64 } @zv_key_at(', $v_v), ', i64)'));
  Z::$l = 1139;
  z_apush($v_d, z_concat(z_concat('declare { i64, i64 } @zv_exc_new(i32, ', $v_v), ')'));
  Z::$l = 1140;
  z_apush($v_d, z_concat(z_concat('declare void @zs_raise(', $v_v), ')'));
  Z::$l = 1141;
  z_apush($v_d, z_concat(z_concat('declare void @zs_reraise(', $v_v), ')'));
  Z::$l = 1142;
  z_apush($v_d, z_concat(z_concat('declare { i64, i64 } @zv_chk(', $v_v), ', ptr, ptr)'));
  Z::$l = 1143;
  z_apush($v_d, z_concat(z_concat('declare void @zs_echo_v(', $v_v), ', i32)'));
  Z::$l = 1144;
  z_apush($v_d, 'declare void @zs_echo_end()');
  Z::$l = 1145;
  z_apush($v_d, z_concat(z_concat('declare void @zs_necho_v(', $v_v), ')'));
  Z::$l = 1146;
  z_apush($v_d, z_concat(z_concat('declare void @zs_eecho_v(', $v_v), ', i32)'));
  Z::$l = 1147;
  z_apush($v_d, 'declare void @zs_eecho_end()');
  Z::$l = 1148;
  z_apush($v_d, z_concat(z_concat('declare { i64, i64 } @s_exit(', $v_v), ')'));
  Z::$l = 1149;
  z_apush($v_d, z_concat(z_concat(z_concat(z_concat(z_concat(z_concat('declare { i64, i64 } @b_substr(', $v_v), ', '), $v_v), ', '), $v_v), ', i32)'));
  Z::$l = 1150;
  foreach (z_foreach(['zv_dup', 'zv_wr', 'zv_neg', 'zv_bitnot', 'b_getmessage', 'b_zs_obj_new', 'b_zs_obj_class', 'b_zs_no_class', 'b_zs_fn_id', 'b_zs_fn_cap', 'b_is_callable', 'b_zs_sget', 'b_throw_v', 'b_dump', 'b_count', 'b_strlen', 'b_typeof', 'b_is_int', 'b_is_float', 'b_is_string', 'b_is_bool', 'b_is_array', 'b_is_null', 'b_strval', 'b_boolval', 'b_intval', 'b_floatval', 'b_ord', 'b_chr', 'b_trim', 'b_keys', 'b_values', 'b_upper', 'b_lower', 'b_chars', 'b_reverse', 'b_sort', 'b_to_hex', 'b_is_digit', 'b_is_alpha', 'b_is_alnum', 'b_is_space', 'b_is_hex_digit', 'm_Math_sqrt', 'm_Math_floor', 'm_Math_ceil', 'm_Math_round', 'm_Math_abs']) as $_k205 => $_v205) {
    $v_f = $_v205;
    Z::$l = 1156;
    z_apush($v_d, z_concat(z_concat(z_concat(z_concat('declare { i64, i64 } @', $v_f), '('), $v_v), ')'));
  }
  Z::$l = 1158;
  foreach (z_foreach(['zv_add', 'zv_sub', 'zv_mul', 'zv_div', 'zv_mod', 'zv_pow', 'zv_concat', 'zv_bitand', 'zv_bitor', 'zv_bitxor', 'zv_shl', 'zv_shr', 'zv_index', 'zv_index_opt', 'b_contains', 'b_starts_with', 'b_ends_with', 'b_index_of', 'b_repeat', 'b_join', 'b_in_array', 'b_range', 'b_has_key', 'b_pad_left', 'b_pad_right', 'b_array_slice', 'b_push', 'm_Math_min', 'm_Math_max', 'm_Math_pow', 'b_split', 'b_zs_obj_get', 'b_zs_obj_take', 'b_zs_no_method', 'b_zs_mkfn', 'b_zs_sset']) as $_k206 => $_v206) {
    $v_f = $_v206;
    Z::$l = 1162;
    z_apush($v_d, z_concat(z_concat(z_concat(z_concat(z_concat(z_concat('declare { i64, i64 } @', $v_f), '('), $v_v), ', '), $v_v), ')'));
  }
  Z::$l = 1164;
  foreach (z_foreach(['b_zs_obj_set', 'b_zs_obj_put', 'b_replace', 'b_pad_left3', 'b_pad_right3', 'b_array_slice3']) as $_k207 => $_v207) {
    $v_f = $_v207;
    Z::$l = 1165;
    z_apush($v_d, z_concat(z_concat(z_concat(z_concat(z_concat(z_concat(z_concat(z_concat('declare { i64, i64 } @', $v_f), '('), $v_v), ', '), $v_v), ', '), $v_v), ')'));
  }
  Z::$l = 1167;
  foreach (z_foreach(['b_read_line']) as $_k208 => $_v208) {
    $v_f = $_v208;
    Z::$l = 1168;
    z_apush($v_d, z_concat(z_concat('declare { i64, i64 } @', $v_f), '()'));
  }
  Z::$l = 1171;
  foreach (z_foreach([z_k('System') => [z_k('args') => 0, z_k('env') => 1, z_k('os') => 0, z_k('architecture') => 0, z_k('time') => 0, z_k('cpuCount') => 0, z_k('dirname') => 1, z_k('resolveImport') => 2, z_k('version') => 0, z_k('exit') => z_neg(1), z_k('setEnv') => 2, z_k('unsetEnv') => 1, z_k('environ') => 0, z_k('cwd') => 0, z_k('chdir') => 1, z_k('pid') => 0, z_k('hostname') => 0, z_k('bytes') => 1, z_k('fromBytes') => 1, z_k('nowNanos') => 0, z_k('monotonic') => 0, z_k('sleep') => 1, z_k('localOffset') => 1, z_k('gc') => 0, z_k('gcStats') => 0], z_k('File') => [z_k('read') => 1, z_k('write') => 2, z_k('append') => 2, z_k('exists') => 1, z_k('delete') => 1, z_k('stat') => 1, z_k('rename') => 2, z_k('realpath') => 1, z_k('chmod') => 2, z_k('symlink') => 2, z_k('readlink') => 1], z_k('Directory') => [z_k('create') => 1, z_k('exists') => 1, z_k('list') => 1, z_k('remove') => 1], z_k('Process') => [z_k('run') => z_neg(1), z_k('exec') => z_neg(1)], z_k('Socket') => [z_k('tcpConnect') => 3, z_k('tcpListen') => 2, z_k('accept') => 1, z_k('read') => 2, z_k('write') => 2, z_k('close') => 1, z_k('setTimeout') => 2, z_k('udpBind') => 2, z_k('sendTo') => 4, z_k('recvFrom') => 2, z_k('resolve') => 1, z_k('localAddr') => 1, z_k('peerAddr') => 1]]) as $_k209 => $_v209) {
    $v_fns = $_v209;
    $v_mod = $_k209;
    Z::$l = 1172;
    foreach (z_foreach($v_fns) as $_k210 => $_v210) {
      $v_ar = $_v210;
      $v_fn = $_k210;
      Z::$l = 1173;
      if (z_truthy((z_truthy(($v_mod === 'System')) && z_truthy(($v_fn === 'exit'))))) {
        continue 1;
      }
      Z::$l = 1174;
      ($v_n = (z_truthy((z_cmp($v_ar, 0) < 0)) ? 2 : $v_ar));
      Z::$l = 1175;
      ($v_ps = []);
      Z::$l = 1176;
      ($v_i = 0);
      for (; z_truthy((z_cmp($v_i, $v_n) < 0)); z_last($_t47 = $v_i, $v_i = z_add($_t47, 1), $_t47)) {
        Z::$l = 1176;
        z_apush($v_ps, $v_v);
      }
      Z::$l = 1177;
      z_apush($v_d, z_concat(z_concat(z_concat(z_concat(z_concat(z_concat('declare { i64, i64 } @m_', $v_mod), '_'), $v_fn), '('), z_b_join($v_ps, ', ')), ')'));
    }
  }
  Z::$l = 1180;
  return $v_d;
  return null;
}
function f_LlEmitter__new($v_ir) {
  $v___o = null;
  Z::$l = 13;
  ($v___o = z_b_zs_obj_new('LlEmitter'));
  Z::$l = 13;
  z_b_zs_obj_set($v___o, 'ir', null);
  Z::$l = 13;
  z_b_zs_obj_set($v___o, 'code', null);
  Z::$l = 13;
  z_b_zs_obj_set($v___o, 'allocas', null);
  Z::$l = 13;
  z_b_zs_obj_set($v___o, 'globals', null);
  Z::$l = 13;
  z_b_zs_obj_set($v___o, 'strs', null);
  Z::$l = 13;
  z_b_zs_obj_set($v___o, 'strList', null);
  Z::$l = 13;
  z_b_zs_obj_set($v___o, 'cstrs', null);
  Z::$l = 13;
  z_b_zs_obj_set($v___o, 'cstrList', null);
  Z::$l = 13;
  z_b_zs_obj_set($v___o, 'floats', null);
  Z::$l = 13;
  z_b_zs_obj_set($v___o, 'tmp', null);
  Z::$l = 13;
  z_b_zs_obj_set($v___o, 'lbl', null);
  Z::$l = 13;
  z_b_zs_obj_set($v___o, 'loops', null);
  Z::$l = 13;
  z_b_zs_obj_set($v___o, 'loopId', null);
  Z::$l = 13;
  z_b_zs_obj_set($v___o, 'fnCounts', null);
  Z::$l = 13;
  z_b_zs_obj_set($v___o, 'rdStack', null);
  Z::$l = 13;
  z_b_zs_obj_set($v___o, 'tries', null);
  Z::$l = 13;
  z_b_zs_obj_set($v___o, 'hid', null);
  Z::$l = 13;
  z_b_zs_obj_set($v___o, 'curFunc', null);
  Z::$l = 13;
  z_b_zs_obj_set($v___o, 'term', null);
  Z::$l = 13;
  z_b_zs_obj_set($v___o, 'vol', null);
  Z::$l = 13;
  z_b_zs_obj_set($v___o, 'known', null);
  Z::$l = 13;
  z_b_zs_obj_set($v___o, 'slotN', null);
  Z::$l = 13;
  f_LlEmitter____construct($v___o, $v_ir);
  Z::$l = 13;
  return $v___o;
  return null;
}
function f_Exception____construct($v_this, $v_message) {
  Z::$l = 1;
  z_b_zs_obj_set($v_this, 'message', $v_message);
  return null;
}
function f_Exception__getMessage($v_this) {
  Z::$l = 1;
  return z_b_zs_obj_get($v_this, 'message');
  return null;
}
function f_Exception__new($v_message) {
  $v___o = null;
  Z::$l = 1;
  ($v___o = z_b_zs_obj_new('Exception'));
  Z::$l = 1;
  z_b_zs_obj_set($v___o, 'message', '');
  Z::$l = 1;
  z_b_zs_obj_set($v___o, 'line', 0);
  Z::$l = 1;
  f_Exception____construct($v___o, $v_message);
  Z::$l = 1;
  return $v___o;
  return null;
}
function f_Error__new($v_message) {
  $v___o = null;
  Z::$l = 1;
  ($v___o = z_b_zs_obj_new('Error'));
  Z::$l = 1;
  z_b_zs_obj_set($v___o, 'message', '');
  Z::$l = 1;
  z_b_zs_obj_set($v___o, 'line', 0);
  Z::$l = 1;
  f_Exception____construct($v___o, $v_message);
  Z::$l = 1;
  return $v___o;
  return null;
}
function f_Exception__getMessage__w($v_this, $v_args) {
  Z::$l = 1;
  if (z_truthy((z_cmp(z_b_count($v_args), 0) >= 0))) {
    Z::$l = 1;
    return f_Exception__getMessage($v_this);
  }
  Z::$l = 1;
  return null;
  return null;
}
function f_Lexer__peek__w($v_this, $v_args) {
  Z::$l = 54;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 54;
    return f_Lexer__peek($v_this, 0);
  }
  Z::$l = 54;
  if (z_truthy((z_cmp(z_b_count($v_args), 1) >= 0))) {
    Z::$l = 54;
    return f_Lexer__peek($v_this, z_index($v_args, 0));
  }
  Z::$l = 54;
  return null;
  return null;
}
function f_Lexer__bump__w($v_this, $v_args) {
  Z::$l = 58;
  if (z_truthy((z_cmp(z_b_count($v_args), 0) >= 0))) {
    Z::$l = 58;
    return f_Lexer__bump($v_this);
  }
  Z::$l = 58;
  return null;
  return null;
}
function f_Lexer__fail__w($v_this, $v_args) {
  Z::$l = 70;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 70;
    z_raise(new ZExc(1, 'fail: brak argumentu $msg'));
  }
  Z::$l = 70;
  if (z_truthy((z_b_count($v_args) === 1))) {
    Z::$l = 70;
    z_raise(new ZExc(1, 'fail: brak argumentu $line'));
  }
  Z::$l = 70;
  if (z_truthy((z_b_count($v_args) === 2))) {
    Z::$l = 70;
    z_raise(new ZExc(1, 'fail: brak argumentu $col'));
  }
  Z::$l = 70;
  if (z_truthy((z_cmp(z_b_count($v_args), 3) >= 0))) {
    Z::$l = 70;
    return f_Lexer__fail($v_this, z_index($v_args, 0), z_index($v_args, 1), z_index($v_args, 2));
  }
  Z::$l = 70;
  return null;
  return null;
}
function f_Lexer__emit__w($v_this, $v_args) {
  Z::$l = 72;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 72;
    z_raise(new ZExc(1, 'emit: brak argumentu $kind'));
  }
  Z::$l = 72;
  if (z_truthy((z_b_count($v_args) === 1))) {
    Z::$l = 72;
    z_raise(new ZExc(1, 'emit: brak argumentu $text'));
  }
  Z::$l = 72;
  if (z_truthy((z_b_count($v_args) === 2))) {
    Z::$l = 72;
    z_raise(new ZExc(1, 'emit: brak argumentu $start'));
  }
  Z::$l = 72;
  if (z_truthy((z_b_count($v_args) === 3))) {
    Z::$l = 72;
    z_raise(new ZExc(1, 'emit: brak argumentu $line'));
  }
  Z::$l = 72;
  if (z_truthy((z_b_count($v_args) === 4))) {
    Z::$l = 72;
    z_raise(new ZExc(1, 'emit: brak argumentu $col'));
  }
  Z::$l = 72;
  if (z_truthy((z_b_count($v_args) === 5))) {
    Z::$l = 72;
    return f_Lexer__emit($v_this, z_index($v_args, 0), z_index($v_args, 1), z_index($v_args, 2), z_index($v_args, 3), z_index($v_args, 4), null);
  }
  Z::$l = 72;
  if (z_truthy((z_cmp(z_b_count($v_args), 6) >= 0))) {
    Z::$l = 72;
    return f_Lexer__emit($v_this, z_index($v_args, 0), z_index($v_args, 1), z_index($v_args, 2), z_index($v_args, 3), z_index($v_args, 4), z_index($v_args, 5));
  }
  Z::$l = 72;
  return null;
  return null;
}
function f_Lexer__run__w($v_this, $v_args) {
  Z::$l = 77;
  if (z_truthy((z_cmp(z_b_count($v_args), 0) >= 0))) {
    Z::$l = 77;
    return f_Lexer__run($v_this);
  }
  Z::$l = 77;
  return null;
  return null;
}
function f_Lexer__skipTrivia__w($v_this, $v_args) {
  Z::$l = 98;
  if (z_truthy((z_cmp(z_b_count($v_args), 0) >= 0))) {
    Z::$l = 98;
    return f_Lexer__skipTrivia($v_this);
  }
  Z::$l = 98;
  return null;
  return null;
}
function f_Lexer__variable__w($v_this, $v_args) {
  Z::$l = 139;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 139;
    z_raise(new ZExc(1, 'variable: brak argumentu $start'));
  }
  Z::$l = 139;
  if (z_truthy((z_b_count($v_args) === 1))) {
    Z::$l = 139;
    z_raise(new ZExc(1, 'variable: brak argumentu $line'));
  }
  Z::$l = 139;
  if (z_truthy((z_b_count($v_args) === 2))) {
    Z::$l = 139;
    z_raise(new ZExc(1, 'variable: brak argumentu $col'));
  }
  Z::$l = 139;
  if (z_truthy((z_cmp(z_b_count($v_args), 3) >= 0))) {
    Z::$l = 139;
    return f_Lexer__variable($v_this, z_index($v_args, 0), z_index($v_args, 1), z_index($v_args, 2));
  }
  Z::$l = 139;
  return null;
  return null;
}
function f_Lexer__ident__w($v_this, $v_args) {
  Z::$l = 148;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 148;
    z_raise(new ZExc(1, 'ident: brak argumentu $start'));
  }
  Z::$l = 148;
  if (z_truthy((z_b_count($v_args) === 1))) {
    Z::$l = 148;
    z_raise(new ZExc(1, 'ident: brak argumentu $line'));
  }
  Z::$l = 148;
  if (z_truthy((z_b_count($v_args) === 2))) {
    Z::$l = 148;
    z_raise(new ZExc(1, 'ident: brak argumentu $col'));
  }
  Z::$l = 148;
  if (z_truthy((z_cmp(z_b_count($v_args), 3) >= 0))) {
    Z::$l = 148;
    return f_Lexer__ident($v_this, z_index($v_args, 0), z_index($v_args, 1), z_index($v_args, 2));
  }
  Z::$l = 148;
  return null;
  return null;
}
function f_Lexer__digitValue__w($v_this, $v_args) {
  Z::$l = 154;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 154;
    z_raise(new ZExc(1, 'digitValue: brak argumentu $c'));
  }
  Z::$l = 154;
  if (z_truthy((z_cmp(z_b_count($v_args), 1) >= 0))) {
    Z::$l = 154;
    return f_Lexer__digitValue($v_this, z_index($v_args, 0));
  }
  Z::$l = 154;
  return null;
  return null;
}
function f_Lexer__digits__w($v_this, $v_args) {
  Z::$l = 163;
  if (z_truthy((z_cmp(z_b_count($v_args), 0) >= 0))) {
    Z::$l = 163;
    return f_Lexer__digits($v_this);
  }
  Z::$l = 163;
  return null;
  return null;
}
function f_Lexer__number__w($v_this, $v_args) {
  Z::$l = 167;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 167;
    z_raise(new ZExc(1, 'number: brak argumentu $start'));
  }
  Z::$l = 167;
  if (z_truthy((z_b_count($v_args) === 1))) {
    Z::$l = 167;
    z_raise(new ZExc(1, 'number: brak argumentu $line'));
  }
  Z::$l = 167;
  if (z_truthy((z_b_count($v_args) === 2))) {
    Z::$l = 167;
    z_raise(new ZExc(1, 'number: brak argumentu $col'));
  }
  Z::$l = 167;
  if (z_truthy((z_cmp(z_b_count($v_args), 3) >= 0))) {
    Z::$l = 167;
    return f_Lexer__number($v_this, z_index($v_args, 0), z_index($v_args, 1), z_index($v_args, 2));
  }
  Z::$l = 167;
  return null;
  return null;
}
function f_Lexer__string__w($v_this, $v_args) {
  Z::$l = 210;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 210;
    z_raise(new ZExc(1, 'string: brak argumentu $q'));
  }
  Z::$l = 210;
  if (z_truthy((z_b_count($v_args) === 1))) {
    Z::$l = 210;
    z_raise(new ZExc(1, 'string: brak argumentu $start'));
  }
  Z::$l = 210;
  if (z_truthy((z_b_count($v_args) === 2))) {
    Z::$l = 210;
    z_raise(new ZExc(1, 'string: brak argumentu $line'));
  }
  Z::$l = 210;
  if (z_truthy((z_b_count($v_args) === 3))) {
    Z::$l = 210;
    z_raise(new ZExc(1, 'string: brak argumentu $col'));
  }
  Z::$l = 210;
  if (z_truthy((z_cmp(z_b_count($v_args), 4) >= 0))) {
    Z::$l = 210;
    return f_Lexer__string($v_this, z_index($v_args, 0), z_index($v_args, 1), z_index($v_args, 2), z_index($v_args, 3));
  }
  Z::$l = 210;
  return null;
  return null;
}
function f_Lexer__op__w($v_this, $v_args) {
  Z::$l = 232;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 232;
    z_raise(new ZExc(1, 'op: brak argumentu $start'));
  }
  Z::$l = 232;
  if (z_truthy((z_b_count($v_args) === 1))) {
    Z::$l = 232;
    z_raise(new ZExc(1, 'op: brak argumentu $line'));
  }
  Z::$l = 232;
  if (z_truthy((z_b_count($v_args) === 2))) {
    Z::$l = 232;
    z_raise(new ZExc(1, 'op: brak argumentu $col'));
  }
  Z::$l = 232;
  if (z_truthy((z_cmp(z_b_count($v_args), 3) >= 0))) {
    Z::$l = 232;
    return f_Lexer__op($v_this, z_index($v_args, 0), z_index($v_args, 1), z_index($v_args, 2));
  }
  Z::$l = 232;
  return null;
  return null;
}
function f_Parser__cur__w($v_this, $v_args) {
  Z::$l = 68;
  if (z_truthy((z_cmp(z_b_count($v_args), 0) >= 0))) {
    Z::$l = 68;
    return f_Parser__cur($v_this);
  }
  Z::$l = 68;
  return null;
  return null;
}
function f_Parser__at__w($v_this, $v_args) {
  Z::$l = 69;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 69;
    z_raise(new ZExc(1, 'at: brak argumentu $n'));
  }
  Z::$l = 69;
  if (z_truthy((z_cmp(z_b_count($v_args), 1) >= 0))) {
    Z::$l = 69;
    return f_Parser__at($v_this, z_index($v_args, 0));
  }
  Z::$l = 69;
  return null;
  return null;
}
function f_Parser__line__w($v_this, $v_args) {
  Z::$l = 70;
  if (z_truthy((z_cmp(z_b_count($v_args), 0) >= 0))) {
    Z::$l = 70;
    return f_Parser__line($v_this);
  }
  Z::$l = 70;
  return null;
  return null;
}
function f_Parser__atEof__w($v_this, $v_args) {
  Z::$l = 71;
  if (z_truthy((z_cmp(z_b_count($v_args), 0) >= 0))) {
    Z::$l = 71;
    return f_Parser__atEof($v_this);
  }
  Z::$l = 71;
  return null;
  return null;
}
function f_Parser__bump__w($v_this, $v_args) {
  Z::$l = 72;
  if (z_truthy((z_cmp(z_b_count($v_args), 0) >= 0))) {
    Z::$l = 72;
    return f_Parser__bump($v_this);
  }
  Z::$l = 72;
  return null;
  return null;
}
function f_Parser__back__w($v_this, $v_args) {
  Z::$l = 73;
  if (z_truthy((z_cmp(z_b_count($v_args), 0) >= 0))) {
    Z::$l = 73;
    return f_Parser__back($v_this);
  }
  Z::$l = 73;
  return null;
  return null;
}
function f_Parser__fail__w($v_this, $v_args) {
  Z::$l = 74;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 74;
    z_raise(new ZExc(1, 'fail: brak argumentu $msg'));
  }
  Z::$l = 74;
  if (z_truthy((z_cmp(z_b_count($v_args), 1) >= 0))) {
    Z::$l = 74;
    return f_Parser__fail($v_this, z_index($v_args, 0));
  }
  Z::$l = 74;
  return null;
  return null;
}
function f_Parser__isOp__w($v_this, $v_args) {
  Z::$l = 75;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 75;
    z_raise(new ZExc(1, 'isOp: brak argumentu $s'));
  }
  Z::$l = 75;
  if (z_truthy((z_cmp(z_b_count($v_args), 1) >= 0))) {
    Z::$l = 75;
    return f_Parser__isOp($v_this, z_index($v_args, 0));
  }
  Z::$l = 75;
  return null;
  return null;
}
function f_Parser__isKw__w($v_this, $v_args) {
  Z::$l = 76;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 76;
    z_raise(new ZExc(1, 'isKw: brak argumentu $s'));
  }
  Z::$l = 76;
  if (z_truthy((z_cmp(z_b_count($v_args), 1) >= 0))) {
    Z::$l = 76;
    return f_Parser__isKw($v_this, z_index($v_args, 0));
  }
  Z::$l = 76;
  return null;
  return null;
}
function f_Parser__isWord__w($v_this, $v_args) {
  Z::$l = 77;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 77;
    z_raise(new ZExc(1, 'isWord: brak argumentu $s'));
  }
  Z::$l = 77;
  if (z_truthy((z_cmp(z_b_count($v_args), 1) >= 0))) {
    Z::$l = 77;
    return f_Parser__isWord($v_this, z_index($v_args, 0));
  }
  Z::$l = 77;
  return null;
  return null;
}
function f_Parser__isVar__w($v_this, $v_args) {
  Z::$l = 78;
  if (z_truthy((z_cmp(z_b_count($v_args), 0) >= 0))) {
    Z::$l = 78;
    return f_Parser__isVar($v_this);
  }
  Z::$l = 78;
  return null;
  return null;
}
function f_Parser__eatOp__w($v_this, $v_args) {
  Z::$l = 79;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 79;
    z_raise(new ZExc(1, 'eatOp: brak argumentu $s'));
  }
  Z::$l = 79;
  if (z_truthy((z_cmp(z_b_count($v_args), 1) >= 0))) {
    Z::$l = 79;
    return f_Parser__eatOp($v_this, z_index($v_args, 0));
  }
  Z::$l = 79;
  return null;
  return null;
}
function f_Parser__eatKw__w($v_this, $v_args) {
  Z::$l = 80;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 80;
    z_raise(new ZExc(1, 'eatKw: brak argumentu $s'));
  }
  Z::$l = 80;
  if (z_truthy((z_cmp(z_b_count($v_args), 1) >= 0))) {
    Z::$l = 80;
    return f_Parser__eatKw($v_this, z_index($v_args, 0));
  }
  Z::$l = 80;
  return null;
  return null;
}
function f_Parser__eatWord__w($v_this, $v_args) {
  Z::$l = 81;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 81;
    z_raise(new ZExc(1, 'eatWord: brak argumentu $s'));
  }
  Z::$l = 81;
  if (z_truthy((z_cmp(z_b_count($v_args), 1) >= 0))) {
    Z::$l = 81;
    return f_Parser__eatWord($v_this, z_index($v_args, 0));
  }
  Z::$l = 81;
  return null;
  return null;
}
function f_Parser__expectOp__w($v_this, $v_args) {
  Z::$l = 82;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 82;
    z_raise(new ZExc(1, 'expectOp: brak argumentu $s'));
  }
  Z::$l = 82;
  if (z_truthy((z_cmp(z_b_count($v_args), 1) >= 0))) {
    Z::$l = 82;
    return f_Parser__expectOp($v_this, z_index($v_args, 0));
  }
  Z::$l = 82;
  return null;
  return null;
}
function f_Parser__ident__w($v_this, $v_args) {
  Z::$l = 85;
  if (z_truthy((z_cmp(z_b_count($v_args), 0) >= 0))) {
    Z::$l = 85;
    return f_Parser__ident($v_this);
  }
  Z::$l = 85;
  return null;
  return null;
}
function f_Parser__varName__w($v_this, $v_args) {
  Z::$l = 90;
  if (z_truthy((z_cmp(z_b_count($v_args), 0) >= 0))) {
    Z::$l = 90;
    return f_Parser__varName($v_this);
  }
  Z::$l = 90;
  return null;
  return null;
}
function f_Parser__isFuncKw__w($v_this, $v_args) {
  Z::$l = 95;
  if (z_truthy((z_cmp(z_b_count($v_args), 0) >= 0))) {
    Z::$l = 95;
    return f_Parser__isFuncKw($v_this);
  }
  Z::$l = 95;
  return null;
  return null;
}
function f_Parser__block__w($v_this, $v_args) {
  Z::$l = 98;
  if (z_truthy((z_cmp(z_b_count($v_args), 0) >= 0))) {
    Z::$l = 98;
    return f_Parser__block($v_this);
  }
  Z::$l = 98;
  return null;
  return null;
}
function f_Parser__body__w($v_this, $v_args) {
  Z::$l = 109;
  if (z_truthy((z_cmp(z_b_count($v_args), 0) >= 0))) {
    Z::$l = 109;
    return f_Parser__body($v_this);
  }
  Z::$l = 109;
  return null;
  return null;
}
function f_Parser__parenExpr__w($v_this, $v_args) {
  Z::$l = 114;
  if (z_truthy((z_cmp(z_b_count($v_args), 0) >= 0))) {
    Z::$l = 114;
    return f_Parser__parenExpr($v_this);
  }
  Z::$l = 114;
  return null;
  return null;
}
function f_Parser__path__w($v_this, $v_args) {
  Z::$l = 121;
  if (z_truthy((z_cmp(z_b_count($v_args), 0) >= 0))) {
    Z::$l = 121;
    return f_Parser__path($v_this);
  }
  Z::$l = 121;
  return null;
  return null;
}
function f_Parser__stmt__w($v_this, $v_args) {
  Z::$l = 127;
  if (z_truthy((z_cmp(z_b_count($v_args), 0) >= 0))) {
    Z::$l = 127;
    return f_Parser__stmt($v_this);
  }
  Z::$l = 127;
  return null;
  return null;
}
function f_Parser__ifRest__w($v_this, $v_args) {
  Z::$l = 194;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 194;
    z_raise(new ZExc(1, 'ifRest: brak argumentu $line'));
  }
  Z::$l = 194;
  if (z_truthy((z_cmp(z_b_count($v_args), 1) >= 0))) {
    Z::$l = 194;
    return f_Parser__ifRest($v_this, z_index($v_args, 0));
  }
  Z::$l = 194;
  return null;
  return null;
}
function f_Parser__exprList__w($v_this, $v_args) {
  Z::$l = 208;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 208;
    z_raise(new ZExc(1, 'exprList: brak argumentu $close'));
  }
  Z::$l = 208;
  if (z_truthy((z_cmp(z_b_count($v_args), 1) >= 0))) {
    Z::$l = 208;
    return f_Parser__exprList($v_this, z_index($v_args, 0));
  }
  Z::$l = 208;
  return null;
  return null;
}
function f_Parser__forStmt__w($v_this, $v_args) {
  Z::$l = 217;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 217;
    z_raise(new ZExc(1, 'forStmt: brak argumentu $line'));
  }
  Z::$l = 217;
  if (z_truthy((z_cmp(z_b_count($v_args), 1) >= 0))) {
    Z::$l = 217;
    return f_Parser__forStmt($v_this, z_index($v_args, 0));
  }
  Z::$l = 217;
  return null;
  return null;
}
function f_Parser__foreachStmt__w($v_this, $v_args) {
  Z::$l = 229;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 229;
    z_raise(new ZExc(1, 'foreachStmt: brak argumentu $line'));
  }
  Z::$l = 229;
  if (z_truthy((z_cmp(z_b_count($v_args), 1) >= 0))) {
    Z::$l = 229;
    return f_Parser__foreachStmt($v_this, z_index($v_args, 0));
  }
  Z::$l = 229;
  return null;
  return null;
}
function f_Parser__switchStmt__w($v_this, $v_args) {
  Z::$l = 242;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 242;
    z_raise(new ZExc(1, 'switchStmt: brak argumentu $line'));
  }
  Z::$l = 242;
  if (z_truthy((z_cmp(z_b_count($v_args), 1) >= 0))) {
    Z::$l = 242;
    return f_Parser__switchStmt($v_this, z_index($v_args, 0));
  }
  Z::$l = 242;
  return null;
  return null;
}
function f_Parser__tryStmt__w($v_this, $v_args) {
  Z::$l = 264;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 264;
    z_raise(new ZExc(1, 'tryStmt: brak argumentu $line'));
  }
  Z::$l = 264;
  if (z_truthy((z_cmp(z_b_count($v_args), 1) >= 0))) {
    Z::$l = 264;
    return f_Parser__tryStmt($v_this, z_index($v_args, 0));
  }
  Z::$l = 264;
  return null;
  return null;
}
function f_Parser__externStmt__w($v_this, $v_args) {
  Z::$l = 284;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 284;
    z_raise(new ZExc(1, 'externStmt: brak argumentu $line'));
  }
  Z::$l = 284;
  if (z_truthy((z_cmp(z_b_count($v_args), 1) >= 0))) {
    Z::$l = 284;
    return f_Parser__externStmt($v_this, z_index($v_args, 0));
  }
  Z::$l = 284;
  return null;
  return null;
}
function f_Parser__types__w($v_this, $v_args) {
  Z::$l = 306;
  if (z_truthy((z_cmp(z_b_count($v_args), 0) >= 0))) {
    Z::$l = 306;
    return f_Parser__types($v_this);
  }
  Z::$l = 306;
  return null;
  return null;
}
function f_Parser__params__w($v_this, $v_args) {
  Z::$l = 321;
  if (z_truthy((z_cmp(z_b_count($v_args), 0) >= 0))) {
    Z::$l = 321;
    return f_Parser__params($v_this);
  }
  Z::$l = 321;
  return null;
  return null;
}
function f_Parser__funcRest__w($v_this, $v_args) {
  Z::$l = 336;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 336;
    z_raise(new ZExc(1, 'funcRest: brak argumentu $named'));
  }
  Z::$l = 336;
  if (z_truthy((z_cmp(z_b_count($v_args), 1) >= 0))) {
    Z::$l = 336;
    return f_Parser__funcRest($v_this, z_index($v_args, 0));
  }
  Z::$l = 336;
  return null;
  return null;
}
function f_Parser__classDecl__w($v_this, $v_args) {
  Z::$l = 345;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 345;
    z_raise(new ZExc(1, 'classDecl: brak argumentu $line'));
  }
  Z::$l = 345;
  if (z_truthy((z_cmp(z_b_count($v_args), 1) >= 0))) {
    Z::$l = 345;
    return f_Parser__classDecl($v_this, z_index($v_args, 0));
  }
  Z::$l = 345;
  return null;
  return null;
}
function f_Parser__expr__w($v_this, $v_args) {
  Z::$l = 404;
  if (z_truthy((z_cmp(z_b_count($v_args), 0) >= 0))) {
    Z::$l = 404;
    return f_Parser__expr($v_this);
  }
  Z::$l = 404;
  return null;
  return null;
}
function f_Parser__checkLvalue__w($v_this, $v_args) {
  Z::$l = 406;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 406;
    z_raise(new ZExc(1, 'checkLvalue: brak argumentu $e'));
  }
  Z::$l = 406;
  if (z_truthy((z_cmp(z_b_count($v_args), 1) >= 0))) {
    Z::$l = 406;
    return f_Parser__checkLvalue($v_this, z_index($v_args, 0));
  }
  Z::$l = 406;
  return null;
  return null;
}
function f_Parser__exprBp__w($v_this, $v_args) {
  Z::$l = 412;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 412;
    z_raise(new ZExc(1, 'exprBp: brak argumentu $min'));
  }
  Z::$l = 412;
  if (z_truthy((z_cmp(z_b_count($v_args), 1) >= 0))) {
    Z::$l = 412;
    return f_Parser__exprBp($v_this, z_index($v_args, 0));
  }
  Z::$l = 412;
  return null;
  return null;
}
function f_Parser__unary__w($v_this, $v_args) {
  Z::$l = 451;
  if (z_truthy((z_cmp(z_b_count($v_args), 0) >= 0))) {
    Z::$l = 451;
    return f_Parser__unary($v_this);
  }
  Z::$l = 451;
  return null;
  return null;
}
function f_Parser__args__w($v_this, $v_args) {
  Z::$l = 477;
  if (z_truthy((z_cmp(z_b_count($v_args), 0) >= 0))) {
    Z::$l = 477;
    return f_Parser__args($v_this);
  }
  Z::$l = 477;
  return null;
  return null;
}
function f_Parser__postfix__w($v_this, $v_args) {
  Z::$l = 494;
  if (z_truthy((z_cmp(z_b_count($v_args), 0) >= 0))) {
    Z::$l = 494;
    return f_Parser__postfix($v_this);
  }
  Z::$l = 494;
  return null;
  return null;
}
function f_Parser__primary__w($v_this, $v_args) {
  Z::$l = 526;
  if (z_truthy((z_cmp(z_b_count($v_args), 0) >= 0))) {
    Z::$l = 526;
    return f_Parser__primary($v_this);
  }
  Z::$l = 526;
  return null;
  return null;
}
function f_Parser__matchExpr__w($v_this, $v_args) {
  Z::$l = 587;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 587;
    z_raise(new ZExc(1, 'matchExpr: brak argumentu $line'));
  }
  Z::$l = 587;
  if (z_truthy((z_cmp(z_b_count($v_args), 1) >= 0))) {
    Z::$l = 587;
    return f_Parser__matchExpr($v_this, z_index($v_args, 0));
  }
  Z::$l = 587;
  return null;
  return null;
}
function f_Bundler__scan__w($v_this, $v_args) {
  Z::$l = 18;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 18;
    z_raise(new ZExc(1, 'scan: brak argumentu $stmts'));
  }
  Z::$l = 18;
  if (z_truthy((z_b_count($v_args) === 1))) {
    Z::$l = 18;
    z_raise(new ZExc(1, 'scan: brak argumentu $dir'));
  }
  Z::$l = 18;
  if (z_truthy((z_cmp(z_b_count($v_args), 2) >= 0))) {
    Z::$l = 18;
    return f_Bundler__scan($v_this, z_index($v_args, 0), z_index($v_args, 1));
  }
  Z::$l = 18;
  return null;
  return null;
}
function f_SemaScope__raise__w($v_this, $v_args) {
  Z::$l = 42;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 42;
    z_raise(new ZExc(1, 'raise: brak argumentu $v'));
  }
  Z::$l = 42;
  if (z_truthy((z_b_count($v_args) === 1))) {
    Z::$l = 42;
    z_raise(new ZExc(1, 'raise: brak argumentu $lv'));
  }
  Z::$l = 42;
  if (z_truthy((z_cmp(z_b_count($v_args), 2) >= 0))) {
    Z::$l = 42;
    return f_SemaScope__raise($v_this, z_index($v_args, 0), z_index($v_args, 1));
  }
  Z::$l = 42;
  return null;
  return null;
}
function f_Analyzer__baseVar__w($v_this, $v_args) {
  Z::$l = 57;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 57;
    z_raise(new ZExc(1, 'baseVar: brak argumentu $e'));
  }
  Z::$l = 57;
  if (z_truthy((z_cmp(z_b_count($v_args), 1) >= 0))) {
    Z::$l = 57;
    return f_Analyzer__baseVar($v_this, z_index($v_args, 0));
  }
  Z::$l = 57;
  return null;
  return null;
}
function f_Analyzer__allocKind__w($v_this, $v_args) {
  Z::$l = 62;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 62;
    z_raise(new ZExc(1, 'allocKind: brak argumentu $e'));
  }
  Z::$l = 62;
  if (z_truthy((z_cmp(z_b_count($v_args), 1) >= 0))) {
    Z::$l = 62;
    return f_Analyzer__allocKind($v_this, z_index($v_args, 0));
  }
  Z::$l = 62;
  return null;
  return null;
}
function f_Analyzer__valueVars__w($v_this, $v_args) {
  Z::$l = 70;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 70;
    z_raise(new ZExc(1, 'valueVars: brak argumentu $e'));
  }
  Z::$l = 70;
  if (z_truthy((z_cmp(z_b_count($v_args), 1) >= 0))) {
    Z::$l = 70;
    return f_Analyzer__valueVars($v_this, z_index($v_args, 0));
  }
  Z::$l = 70;
  return null;
  return null;
}
function f_Analyzer__visitAny__w($v_this, $v_args) {
  Z::$l = 87;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 87;
    z_raise(new ZExc(1, 'visitAny: brak argumentu $x'));
  }
  Z::$l = 87;
  if (z_truthy((z_b_count($v_args) === 1))) {
    Z::$l = 87;
    z_raise(new ZExc(1, 'visitAny: brak argumentu $sc'));
  }
  Z::$l = 87;
  if (z_truthy((z_b_count($v_args) === 2))) {
    Z::$l = 87;
    z_raise(new ZExc(1, 'visitAny: brak argumentu $prefix'));
  }
  Z::$l = 87;
  if (z_truthy((z_cmp(z_b_count($v_args), 3) >= 0))) {
    Z::$l = 87;
    return f_Analyzer__visitAny($v_this, z_index($v_args, 0), z_index($v_args, 1), z_index($v_args, 2));
  }
  Z::$l = 87;
  return null;
  return null;
}
function f_Analyzer__visitChildren__w($v_this, $v_args) {
  Z::$l = 92;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 92;
    z_raise(new ZExc(1, 'visitChildren: brak argumentu $n'));
  }
  Z::$l = 92;
  if (z_truthy((z_b_count($v_args) === 1))) {
    Z::$l = 92;
    z_raise(new ZExc(1, 'visitChildren: brak argumentu $sc'));
  }
  Z::$l = 92;
  if (z_truthy((z_b_count($v_args) === 2))) {
    Z::$l = 92;
    z_raise(new ZExc(1, 'visitChildren: brak argumentu $prefix'));
  }
  Z::$l = 92;
  if (z_truthy((z_cmp(z_b_count($v_args), 3) >= 0))) {
    Z::$l = 92;
    return f_Analyzer__visitChildren($v_this, z_index($v_args, 0), z_index($v_args, 1), z_index($v_args, 2));
  }
  Z::$l = 92;
  return null;
  return null;
}
function f_Analyzer__visit__w($v_this, $v_args) {
  Z::$l = 96;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 96;
    z_raise(new ZExc(1, 'visit: brak argumentu $n'));
  }
  Z::$l = 96;
  if (z_truthy((z_b_count($v_args) === 1))) {
    Z::$l = 96;
    z_raise(new ZExc(1, 'visit: brak argumentu $sc'));
  }
  Z::$l = 96;
  if (z_truthy((z_b_count($v_args) === 2))) {
    Z::$l = 96;
    z_raise(new ZExc(1, 'visit: brak argumentu $prefix'));
  }
  Z::$l = 96;
  if (z_truthy((z_cmp(z_b_count($v_args), 3) >= 0))) {
    Z::$l = 96;
    return f_Analyzer__visit($v_this, z_index($v_args, 0), z_index($v_args, 1), z_index($v_args, 2));
  }
  Z::$l = 96;
  return null;
  return null;
}
function f_Analyzer__fnScope__w($v_this, $v_args) {
  Z::$l = 199;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 199;
    z_raise(new ZExc(1, 'fnScope: brak argumentu $decl'));
  }
  Z::$l = 199;
  if (z_truthy((z_b_count($v_args) === 1))) {
    Z::$l = 199;
    z_raise(new ZExc(1, 'fnScope: brak argumentu $prefix'));
  }
  Z::$l = 199;
  if (z_truthy((z_b_count($v_args) === 2))) {
    Z::$l = 199;
    z_raise(new ZExc(1, 'fnScope: brak argumentu $isClosure'));
  }
  Z::$l = 199;
  if (z_truthy((z_b_count($v_args) === 3))) {
    Z::$l = 199;
    z_raise(new ZExc(1, 'fnScope: brak argumentu $parent'));
  }
  Z::$l = 199;
  if (z_truthy((z_cmp(z_b_count($v_args), 4) >= 0))) {
    Z::$l = 199;
    return f_Analyzer__fnScope($v_this, z_index($v_args, 0), z_index($v_args, 1), z_index($v_args, 2), z_index($v_args, 3));
  }
  Z::$l = 199;
  return null;
  return null;
}
function f_Analyzer__resolveChildren__w($v_this, $v_args) {
  Z::$l = 216;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 216;
    z_raise(new ZExc(1, 'resolveChildren: brak argumentu $sc'));
  }
  Z::$l = 216;
  if (z_truthy((z_cmp(z_b_count($v_args), 1) >= 0))) {
    Z::$l = 216;
    return f_Analyzer__resolveChildren($v_this, z_index($v_args, 0));
  }
  Z::$l = 216;
  return null;
  return null;
}
function f_Analyzer__finish__w($v_this, $v_args) {
  Z::$l = 227;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 227;
    z_raise(new ZExc(1, 'finish: brak argumentu $sc'));
  }
  Z::$l = 227;
  if (z_truthy((z_b_count($v_args) === 1))) {
    Z::$l = 227;
    z_raise(new ZExc(1, 'finish: brak argumentu $report'));
  }
  Z::$l = 227;
  if (z_truthy((z_cmp(z_b_count($v_args), 2) >= 0))) {
    Z::$l = 227;
    return f_Analyzer__finish($v_this, z_index($v_args, 0), z_index($v_args, 1));
  }
  Z::$l = 227;
  return null;
  return null;
}
function f_Lowerer__err__w($v_this, $v_args) {
  Z::$l = 55;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 55;
    z_raise(new ZExc(1, 'err: brak argumentu $line'));
  }
  Z::$l = 55;
  if (z_truthy((z_b_count($v_args) === 1))) {
    Z::$l = 55;
    z_raise(new ZExc(1, 'err: brak argumentu $code'));
  }
  Z::$l = 55;
  if (z_truthy((z_b_count($v_args) === 2))) {
    Z::$l = 55;
    z_raise(new ZExc(1, 'err: brak argumentu $msg'));
  }
  Z::$l = 55;
  if (z_truthy((z_cmp(z_b_count($v_args), 3) >= 0))) {
    Z::$l = 55;
    return f_Lowerer__err($v_this, z_index($v_args, 0), z_index($v_args, 1), z_index($v_args, 2));
  }
  Z::$l = 55;
  return null;
  return null;
}
function f_Lowerer__addLocal__w($v_this, $v_args) {
  Z::$l = 58;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 58;
    z_raise(new ZExc(1, 'addLocal: brak argumentu $locals'));
  }
  Z::$l = 58;
  if (z_truthy((z_b_count($v_args) === 1))) {
    Z::$l = 58;
    z_raise(new ZExc(1, 'addLocal: brak argumentu $name'));
  }
  Z::$l = 58;
  if (z_truthy((z_cmp(z_b_count($v_args), 2) >= 0))) {
    Z::$l = 58;
    return f_Lowerer__addLocal($v_this, z_index($v_args, 0), z_index($v_args, 1));
  }
  Z::$l = 58;
  return null;
  return null;
}
function f_Lowerer__collectExpr__w($v_this, $v_args) {
  Z::$l = 63;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 63;
    z_raise(new ZExc(1, 'collectExpr: brak argumentu $e'));
  }
  Z::$l = 63;
  if (z_truthy((z_b_count($v_args) === 1))) {
    Z::$l = 63;
    z_raise(new ZExc(1, 'collectExpr: brak argumentu $locals'));
  }
  Z::$l = 63;
  if (z_truthy((z_cmp(z_b_count($v_args), 2) >= 0))) {
    Z::$l = 63;
    return f_Lowerer__collectExpr($v_this, z_index($v_args, 0), z_index($v_args, 1));
  }
  Z::$l = 63;
  return null;
  return null;
}
function f_Lowerer__collectTarget__w($v_this, $v_args) {
  Z::$l = 73;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 73;
    z_raise(new ZExc(1, 'collectTarget: brak argumentu $t'));
  }
  Z::$l = 73;
  if (z_truthy((z_b_count($v_args) === 1))) {
    Z::$l = 73;
    z_raise(new ZExc(1, 'collectTarget: brak argumentu $locals'));
  }
  Z::$l = 73;
  if (z_truthy((z_cmp(z_b_count($v_args), 2) >= 0))) {
    Z::$l = 73;
    return f_Lowerer__collectTarget($v_this, z_index($v_args, 0), z_index($v_args, 1));
  }
  Z::$l = 73;
  return null;
  return null;
}
function f_Lowerer__collectAny__w($v_this, $v_args) {
  Z::$l = 79;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 79;
    z_raise(new ZExc(1, 'collectAny: brak argumentu $x'));
  }
  Z::$l = 79;
  if (z_truthy((z_b_count($v_args) === 1))) {
    Z::$l = 79;
    z_raise(new ZExc(1, 'collectAny: brak argumentu $locals'));
  }
  Z::$l = 79;
  if (z_truthy((z_cmp(z_b_count($v_args), 2) >= 0))) {
    Z::$l = 79;
    return f_Lowerer__collectAny($v_this, z_index($v_args, 0), z_index($v_args, 1));
  }
  Z::$l = 79;
  return null;
  return null;
}
function f_Lowerer__checkStmts__w($v_this, $v_args) {
  Z::$l = 93;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 93;
    z_raise(new ZExc(1, 'checkStmts: brak argumentu $list'));
  }
  Z::$l = 93;
  if (z_truthy((z_b_count($v_args) === 1))) {
    Z::$l = 93;
    z_raise(new ZExc(1, 'checkStmts: brak argumentu $depth'));
  }
  Z::$l = 93;
  if (z_truthy((z_cmp(z_b_count($v_args), 2) >= 0))) {
    Z::$l = 93;
    return f_Lowerer__checkStmts($v_this, z_index($v_args, 0), z_index($v_args, 1));
  }
  Z::$l = 93;
  return null;
  return null;
}
function f_Lowerer__checkStmt__w($v_this, $v_args) {
  Z::$l = 95;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 95;
    z_raise(new ZExc(1, 'checkStmt: brak argumentu $s'));
  }
  Z::$l = 95;
  if (z_truthy((z_b_count($v_args) === 1))) {
    Z::$l = 95;
    z_raise(new ZExc(1, 'checkStmt: brak argumentu $depth'));
  }
  Z::$l = 95;
  if (z_truthy((z_cmp(z_b_count($v_args), 2) >= 0))) {
    Z::$l = 95;
    return f_Lowerer__checkStmt($v_this, z_index($v_args, 0), z_index($v_args, 1));
  }
  Z::$l = 95;
  return null;
  return null;
}
function f_Lowerer__checkNew__w($v_this, $v_args) {
  Z::$l = 144;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 144;
    z_raise(new ZExc(1, 'checkNew: brak argumentu $x'));
  }
  Z::$l = 144;
  if (z_truthy((z_cmp(z_b_count($v_args), 1) >= 0))) {
    Z::$l = 144;
    return f_Lowerer__checkNew($v_this, z_index($v_args, 0));
  }
  Z::$l = 144;
  return null;
  return null;
}
function f_Lowerer__containsTry__w($v_this, $v_args) {
  Z::$l = 150;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 150;
    z_raise(new ZExc(1, 'containsTry: brak argumentu $x'));
  }
  Z::$l = 150;
  if (z_truthy((z_cmp(z_b_count($v_args), 1) >= 0))) {
    Z::$l = 150;
    return f_Lowerer__containsTry($v_this, z_index($v_args, 0));
  }
  Z::$l = 150;
  return null;
  return null;
}
function f_Lowerer__calleeName__w($v_this, $v_args) {
  Z::$l = 161;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 161;
    z_raise(new ZExc(1, 'calleeName: brak argumentu $c'));
  }
  Z::$l = 161;
  if (z_truthy((z_cmp(z_b_count($v_args), 1) >= 0))) {
    Z::$l = 161;
    return f_Lowerer__calleeName($v_this, z_index($v_args, 0));
  }
  Z::$l = 161;
  return null;
  return null;
}
function f_Lowerer__checkExpr__w($v_this, $v_args) {
  Z::$l = 166;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 166;
    z_raise(new ZExc(1, 'checkExpr: brak argumentu $e'));
  }
  Z::$l = 166;
  if (z_truthy((z_cmp(z_b_count($v_args), 1) >= 0))) {
    Z::$l = 166;
    return f_Lowerer__checkExpr($v_this, z_index($v_args, 0));
  }
  Z::$l = 166;
  return null;
  return null;
}
function f_Lowerer__checkLvalue__w($v_this, $v_args) {
  Z::$l = 207;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 207;
    z_raise(new ZExc(1, 'checkLvalue: brak argumentu $t'));
  }
  Z::$l = 207;
  if (z_truthy((z_cmp(z_b_count($v_args), 1) >= 0))) {
    Z::$l = 207;
    return f_Lowerer__checkLvalue($v_this, z_index($v_args, 0));
  }
  Z::$l = 207;
  return null;
  return null;
}
function f_Lowerer__checkCall__w($v_this, $v_args) {
  Z::$l = 213;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 213;
    z_raise(new ZExc(1, 'checkCall: brak argumentu $e'));
  }
  Z::$l = 213;
  if (z_truthy((z_cmp(z_b_count($v_args), 1) >= 0))) {
    Z::$l = 213;
    return f_Lowerer__checkCall($v_this, z_index($v_args, 0));
  }
  Z::$l = 213;
  return null;
  return null;
}
function f_Lowerer__topCallsMain__w($v_this, $v_args) {
  Z::$l = 263;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 263;
    z_raise(new ZExc(1, 'topCallsMain: brak argumentu $x'));
  }
  Z::$l = 263;
  if (z_truthy((z_cmp(z_b_count($v_args), 1) >= 0))) {
    Z::$l = 263;
    return f_Lowerer__topCallsMain($v_this, z_index($v_args, 0));
  }
  Z::$l = 263;
  return null;
  return null;
}
function f_Lifter__err__w($v_this, $v_args) {
  Z::$l = 62;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 62;
    z_raise(new ZExc(1, 'err: brak argumentu $line'));
  }
  Z::$l = 62;
  if (z_truthy((z_b_count($v_args) === 1))) {
    Z::$l = 62;
    z_raise(new ZExc(1, 'err: brak argumentu $m'));
  }
  Z::$l = 62;
  if (z_truthy((z_cmp(z_b_count($v_args), 2) >= 0))) {
    Z::$l = 62;
    return f_Lifter__err($v_this, z_index($v_args, 0), z_index($v_args, 1));
  }
  Z::$l = 62;
  return null;
  return null;
}
function f_Lifter__scan__w($v_this, $v_args) {
  Z::$l = 65;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 65;
    z_raise(new ZExc(1, 'scan: brak argumentu $x'));
  }
  Z::$l = 65;
  if (z_truthy((z_cmp(z_b_count($v_args), 1) >= 0))) {
    Z::$l = 65;
    return f_Lifter__scan($v_this, z_index($v_args, 0));
  }
  Z::$l = 65;
  return null;
  return null;
}
function f_Lifter__names__w($v_this, $v_args) {
  Z::$l = 80;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 80;
    z_raise(new ZExc(1, 'names: brak argumentu $x'));
  }
  Z::$l = 80;
  if (z_truthy((z_cmp(z_b_count($v_args), 1) >= 0))) {
    Z::$l = 80;
    return f_Lifter__names($v_this, z_index($v_args, 0));
  }
  Z::$l = 80;
  return null;
  return null;
}
function f_Lifter__freeOf__w($v_this, $v_args) {
  Z::$l = 90;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 90;
    z_raise(new ZExc(1, 'freeOf: brak argumentu $f'));
  }
  Z::$l = 90;
  if (z_truthy((z_cmp(z_b_count($v_args), 1) >= 0))) {
    Z::$l = 90;
    return f_Lifter__freeOf($v_this, z_index($v_args, 0));
  }
  Z::$l = 90;
  return null;
  return null;
}
function f_Lifter__lift__w($v_this, $v_args) {
  Z::$l = 100;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 100;
    z_raise(new ZExc(1, 'lift: brak argumentu $x'));
  }
  Z::$l = 100;
  if (z_truthy((z_b_count($v_args) === 1))) {
    Z::$l = 100;
    z_raise(new ZExc(1, 'lift: brak argumentu $vis'));
  }
  Z::$l = 100;
  if (z_truthy((z_cmp(z_b_count($v_args), 2) >= 0))) {
    Z::$l = 100;
    return f_Lifter__lift($v_this, z_index($v_args, 0), z_index($v_args, 1));
  }
  Z::$l = 100;
  return null;
  return null;
}
function f_Lifter__rw__w($v_this, $v_args) {
  Z::$l = 129;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 129;
    z_raise(new ZExc(1, 'rw: brak argumentu $x'));
  }
  Z::$l = 129;
  if (z_truthy((z_b_count($v_args) === 1))) {
    Z::$l = 129;
    z_raise(new ZExc(1, 'rw: brak argumentu $vis'));
  }
  Z::$l = 129;
  if (z_truthy((z_cmp(z_b_count($v_args), 2) >= 0))) {
    Z::$l = 129;
    return f_Lifter__rw($v_this, z_index($v_args, 0), z_index($v_args, 1));
  }
  Z::$l = 129;
  return null;
  return null;
}
function f_Lifter__argsArray__w($v_this, $v_args) {
  Z::$l = 146;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 146;
    z_raise(new ZExc(1, 'argsArray: brak argumentu $line'));
  }
  Z::$l = 146;
  if (z_truthy((z_b_count($v_args) === 1))) {
    Z::$l = 146;
    z_raise(new ZExc(1, 'argsArray: brak argumentu $args'));
  }
  Z::$l = 146;
  if (z_truthy((z_b_count($v_args) === 2))) {
    Z::$l = 146;
    z_raise(new ZExc(1, 'argsArray: brak argumentu $vis'));
  }
  Z::$l = 146;
  if (z_truthy((z_cmp(z_b_count($v_args), 3) >= 0))) {
    Z::$l = 146;
    return f_Lifter__argsArray($v_this, z_index($v_args, 0), z_index($v_args, 1), z_index($v_args, 2));
  }
  Z::$l = 146;
  return null;
  return null;
}
function f_Lifter__rwCall__w($v_this, $v_args) {
  Z::$l = 168;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 168;
    z_raise(new ZExc(1, 'rwCall: brak argumentu $x'));
  }
  Z::$l = 168;
  if (z_truthy((z_b_count($v_args) === 1))) {
    Z::$l = 168;
    z_raise(new ZExc(1, 'rwCall: brak argumentu $vis'));
  }
  Z::$l = 168;
  if (z_truthy((z_cmp(z_b_count($v_args), 2) >= 0))) {
    Z::$l = 168;
    return f_Lifter__rwCall($v_this, z_index($v_args, 0), z_index($v_args, 1));
  }
  Z::$l = 168;
  return null;
  return null;
}
function f_Lifter__plain__w($v_this, $v_args) {
  Z::$l = 201;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 201;
    z_raise(new ZExc(1, 'plain: brak argumentu $x'));
  }
  Z::$l = 201;
  if (z_truthy((z_b_count($v_args) === 1))) {
    Z::$l = 201;
    z_raise(new ZExc(1, 'plain: brak argumentu $vis'));
  }
  Z::$l = 201;
  if (z_truthy((z_cmp(z_b_count($v_args), 2) >= 0))) {
    Z::$l = 201;
    return f_Lifter__plain($v_this, z_index($v_args, 0), z_index($v_args, 1));
  }
  Z::$l = 201;
  return null;
  return null;
}
function f_Lifter__reorder__w($v_this, $v_args) {
  Z::$l = 208;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 208;
    z_raise(new ZExc(1, 'reorder: brak argumentu $x'));
  }
  Z::$l = 208;
  if (z_truthy((z_b_count($v_args) === 1))) {
    Z::$l = 208;
    z_raise(new ZExc(1, 'reorder: brak argumentu $vis'));
  }
  Z::$l = 208;
  if (z_truthy((z_cmp(z_b_count($v_args), 2) >= 0))) {
    Z::$l = 208;
    return f_Lifter__reorder($v_this, z_index($v_args, 0), z_index($v_args, 1));
  }
  Z::$l = 208;
  return null;
  return null;
}
function f_Lifter__helpers__w($v_this, $v_args) {
  Z::$l = 241;
  if (z_truthy((z_cmp(z_b_count($v_args), 0) >= 0))) {
    Z::$l = 241;
    return f_Lifter__helpers($v_this);
  }
  Z::$l = 241;
  return null;
  return null;
}
function f_Lifter__dispatcher__w($v_this, $v_args) {
  Z::$l = 252;
  if (z_truthy((z_cmp(z_b_count($v_args), 0) >= 0))) {
    Z::$l = 252;
    return f_Lifter__dispatcher($v_this);
  }
  Z::$l = 252;
  return null;
  return null;
}
function f_Desugar__err__w($v_this, $v_args) {
  Z::$l = 38;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 38;
    z_raise(new ZExc(1, 'err: brak argumentu $line'));
  }
  Z::$l = 38;
  if (z_truthy((z_b_count($v_args) === 1))) {
    Z::$l = 38;
    z_raise(new ZExc(1, 'err: brak argumentu $msg'));
  }
  Z::$l = 38;
  if (z_truthy((z_cmp(z_b_count($v_args), 2) >= 0))) {
    Z::$l = 38;
    return f_Desugar__err($v_this, z_index($v_args, 0), z_index($v_args, 1));
  }
  Z::$l = 38;
  return null;
  return null;
}
function f_Desugar__node__w($v_this, $v_args) {
  Z::$l = 40;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 40;
    z_raise(new ZExc(1, 'node: brak argumentu $k'));
  }
  Z::$l = 40;
  if (z_truthy((z_b_count($v_args) === 1))) {
    Z::$l = 40;
    z_raise(new ZExc(1, 'node: brak argumentu $line'));
  }
  Z::$l = 40;
  if (z_truthy((z_b_count($v_args) === 2))) {
    Z::$l = 40;
    return f_Desugar__node($v_this, z_index($v_args, 0), z_index($v_args, 1), null, null, null, null);
  }
  Z::$l = 40;
  if (z_truthy((z_b_count($v_args) === 3))) {
    Z::$l = 40;
    return f_Desugar__node($v_this, z_index($v_args, 0), z_index($v_args, 1), z_index($v_args, 2), null, null, null);
  }
  Z::$l = 40;
  if (z_truthy((z_b_count($v_args) === 4))) {
    Z::$l = 40;
    return f_Desugar__node($v_this, z_index($v_args, 0), z_index($v_args, 1), z_index($v_args, 2), z_index($v_args, 3), null, null);
  }
  Z::$l = 40;
  if (z_truthy((z_b_count($v_args) === 5))) {
    Z::$l = 40;
    return f_Desugar__node($v_this, z_index($v_args, 0), z_index($v_args, 1), z_index($v_args, 2), z_index($v_args, 3), z_index($v_args, 4), null);
  }
  Z::$l = 40;
  if (z_truthy((z_cmp(z_b_count($v_args), 6) >= 0))) {
    Z::$l = 40;
    return f_Desugar__node($v_this, z_index($v_args, 0), z_index($v_args, 1), z_index($v_args, 2), z_index($v_args, 3), z_index($v_args, 4), z_index($v_args, 5));
  }
  Z::$l = 40;
  return null;
  return null;
}
function f_Desugar__nm__w($v_this, $v_args) {
  Z::$l = 41;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 41;
    z_raise(new ZExc(1, 'nm: brak argumentu $line'));
  }
  Z::$l = 41;
  if (z_truthy((z_b_count($v_args) === 1))) {
    Z::$l = 41;
    z_raise(new ZExc(1, 'nm: brak argumentu $n'));
  }
  Z::$l = 41;
  if (z_truthy((z_cmp(z_b_count($v_args), 2) >= 0))) {
    Z::$l = 41;
    return f_Desugar__nm($v_this, z_index($v_args, 0), z_index($v_args, 1));
  }
  Z::$l = 41;
  return null;
  return null;
}
function f_Desugar__mkstr__w($v_this, $v_args) {
  Z::$l = 42;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 42;
    z_raise(new ZExc(1, 'mkstr: brak argumentu $line'));
  }
  Z::$l = 42;
  if (z_truthy((z_b_count($v_args) === 1))) {
    Z::$l = 42;
    z_raise(new ZExc(1, 'mkstr: brak argumentu $s'));
  }
  Z::$l = 42;
  if (z_truthy((z_cmp(z_b_count($v_args), 2) >= 0))) {
    Z::$l = 42;
    return f_Desugar__mkstr($v_this, z_index($v_args, 0), z_index($v_args, 1));
  }
  Z::$l = 42;
  return null;
  return null;
}
function f_Desugar__mkvar__w($v_this, $v_args) {
  Z::$l = 43;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 43;
    z_raise(new ZExc(1, 'mkvar: brak argumentu $line'));
  }
  Z::$l = 43;
  if (z_truthy((z_b_count($v_args) === 1))) {
    Z::$l = 43;
    z_raise(new ZExc(1, 'mkvar: brak argumentu $n'));
  }
  Z::$l = 43;
  if (z_truthy((z_cmp(z_b_count($v_args), 2) >= 0))) {
    Z::$l = 43;
    return f_Desugar__mkvar($v_this, z_index($v_args, 0), z_index($v_args, 1));
  }
  Z::$l = 43;
  return null;
  return null;
}
function f_Desugar__call__w($v_this, $v_args) {
  Z::$l = 44;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 44;
    z_raise(new ZExc(1, 'call: brak argumentu $line'));
  }
  Z::$l = 44;
  if (z_truthy((z_b_count($v_args) === 1))) {
    Z::$l = 44;
    z_raise(new ZExc(1, 'call: brak argumentu $fn'));
  }
  Z::$l = 44;
  if (z_truthy((z_b_count($v_args) === 2))) {
    Z::$l = 44;
    z_raise(new ZExc(1, 'call: brak argumentu $args'));
  }
  Z::$l = 44;
  if (z_truthy((z_cmp(z_b_count($v_args), 3) >= 0))) {
    Z::$l = 44;
    return f_Desugar__call($v_this, z_index($v_args, 0), z_index($v_args, 1), z_index($v_args, 2));
  }
  Z::$l = 44;
  return null;
  return null;
}
function f_Desugar__fresh__w($v_this, $v_args) {
  Z::$l = 49;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 49;
    z_raise(new ZExc(1, 'fresh: brak argumentu $p'));
  }
  Z::$l = 49;
  if (z_truthy((z_cmp(z_b_count($v_args), 1) >= 0))) {
    Z::$l = 49;
    return f_Desugar__fresh($v_this, z_index($v_args, 0));
  }
  Z::$l = 49;
  return null;
  return null;
}
function f_Desugar__collect__w($v_this, $v_args) {
  Z::$l = 52;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 52;
    z_raise(new ZExc(1, 'collect: brak argumentu $ast'));
  }
  Z::$l = 52;
  if (z_truthy((z_cmp(z_b_count($v_args), 1) >= 0))) {
    Z::$l = 52;
    return f_Desugar__collect($v_this, z_index($v_args, 0));
  }
  Z::$l = 52;
  return null;
  return null;
}
function f_Desugar__chain__w($v_this, $v_args) {
  Z::$l = 66;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 66;
    z_raise(new ZExc(1, 'chain: brak argumentu $name'));
  }
  Z::$l = 66;
  if (z_truthy((z_cmp(z_b_count($v_args), 1) >= 0))) {
    Z::$l = 66;
    return f_Desugar__chain($v_this, z_index($v_args, 0));
  }
  Z::$l = 66;
  return null;
  return null;
}
function f_Desugar__owner__w($v_this, $v_args) {
  Z::$l = 74;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 74;
    z_raise(new ZExc(1, 'owner: brak argumentu $cls'));
  }
  Z::$l = 74;
  if (z_truthy((z_b_count($v_args) === 1))) {
    Z::$l = 74;
    z_raise(new ZExc(1, 'owner: brak argumentu $m'));
  }
  Z::$l = 74;
  if (z_truthy((z_cmp(z_b_count($v_args), 2) >= 0))) {
    Z::$l = 74;
    return f_Desugar__owner($v_this, z_index($v_args, 0), z_index($v_args, 1));
  }
  Z::$l = 74;
  return null;
  return null;
}
function f_Desugar__allProps__w($v_this, $v_args) {
  Z::$l = 81;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 81;
    z_raise(new ZExc(1, 'allProps: brak argumentu $cls'));
  }
  Z::$l = 81;
  if (z_truthy((z_cmp(z_b_count($v_args), 1) >= 0))) {
    Z::$l = 81;
    return f_Desugar__allProps($v_this, z_index($v_args, 0));
  }
  Z::$l = 81;
  return null;
  return null;
}
function f_Desugar__isaNames__w($v_this, $v_args) {
  Z::$l = 94;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 94;
    z_raise(new ZExc(1, 'isaNames: brak argumentu $cls'));
  }
  Z::$l = 94;
  if (z_truthy((z_cmp(z_b_count($v_args), 1) >= 0))) {
    Z::$l = 94;
    return f_Desugar__isaNames($v_this, z_index($v_args, 0));
  }
  Z::$l = 94;
  return null;
  return null;
}
function f_Desugar__rwList__w($v_this, $v_args) {
  Z::$l = 113;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 113;
    z_raise(new ZExc(1, 'rwList: brak argumentu $xs'));
  }
  Z::$l = 113;
  if (z_truthy((z_cmp(z_b_count($v_args), 1) >= 0))) {
    Z::$l = 113;
    return f_Desugar__rwList($v_this, z_index($v_args, 0));
  }
  Z::$l = 113;
  return null;
  return null;
}
function f_Desugar__rw__w($v_this, $v_args) {
  Z::$l = 125;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 125;
    z_raise(new ZExc(1, 'rw: brak argumentu $x'));
  }
  Z::$l = 125;
  if (z_truthy((z_cmp(z_b_count($v_args), 1) >= 0))) {
    Z::$l = 125;
    return f_Desugar__rw($v_this, z_index($v_args, 0));
  }
  Z::$l = 125;
  return null;
  return null;
}
function f_Desugar__baseOk__w($v_this, $v_args) {
  Z::$l = 190;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 190;
    z_raise(new ZExc(1, 'baseOk: brak argumentu $b'));
  }
  Z::$l = 190;
  if (z_truthy((z_cmp(z_b_count($v_args), 1) >= 0))) {
    Z::$l = 190;
    return f_Desugar__baseOk($v_this, z_index($v_args, 0));
  }
  Z::$l = 190;
  return null;
  return null;
}
function f_Desugar__propModify__w($v_this, $v_args) {
  Z::$l = 192;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 192;
    z_raise(new ZExc(1, 'propModify: brak argumentu $line'));
  }
  Z::$l = 192;
  if (z_truthy((z_b_count($v_args) === 1))) {
    Z::$l = 192;
    z_raise(new ZExc(1, 'propModify: brak argumentu $t'));
  }
  Z::$l = 192;
  if (z_truthy((z_b_count($v_args) === 2))) {
    Z::$l = 192;
    z_raise(new ZExc(1, 'propModify: brak argumentu $op'));
  }
  Z::$l = 192;
  if (z_truthy((z_b_count($v_args) === 3))) {
    Z::$l = 192;
    z_raise(new ZExc(1, 'propModify: brak argumentu $rhs'));
  }
  Z::$l = 192;
  if (z_truthy((z_cmp(z_b_count($v_args), 4) >= 0))) {
    Z::$l = 192;
    return f_Desugar__propModify($v_this, z_index($v_args, 0), z_index($v_args, 1), z_index($v_args, 2), z_index($v_args, 3));
  }
  Z::$l = 192;
  return null;
  return null;
}
function f_Desugar__staticName__w($v_this, $v_args) {
  Z::$l = 200;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 200;
    z_raise(new ZExc(1, 'staticName: brak argumentu $cn'));
  }
  Z::$l = 200;
  if (z_truthy((z_b_count($v_args) === 1))) {
    Z::$l = 200;
    z_raise(new ZExc(1, 'staticName: brak argumentu $p'));
  }
  Z::$l = 200;
  if (z_truthy((z_cmp(z_b_count($v_args), 2) >= 0))) {
    Z::$l = 200;
    return f_Desugar__staticName($v_this, z_index($v_args, 0), z_index($v_args, 1));
  }
  Z::$l = 200;
  return null;
  return null;
}
function f_Desugar__staticTarget__w($v_this, $v_args) {
  Z::$l = 208;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 208;
    z_raise(new ZExc(1, 'staticTarget: brak argumentu $t'));
  }
  Z::$l = 208;
  if (z_truthy((z_cmp(z_b_count($v_args), 1) >= 0))) {
    Z::$l = 208;
    return f_Desugar__staticTarget($v_this, z_index($v_args, 0));
  }
  Z::$l = 208;
  return null;
  return null;
}
function f_Desugar__clsName__w($v_this, $v_args) {
  Z::$l = 215;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 215;
    z_raise(new ZExc(1, 'clsName: brak argumentu $n'));
  }
  Z::$l = 215;
  if (z_truthy((z_cmp(z_b_count($v_args), 1) >= 0))) {
    Z::$l = 215;
    return f_Desugar__clsName($v_this, z_index($v_args, 0));
  }
  Z::$l = 215;
  return null;
  return null;
}
function f_Desugar__constOf__w($v_this, $v_args) {
  Z::$l = 220;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 220;
    z_raise(new ZExc(1, 'constOf: brak argumentu $cn'));
  }
  Z::$l = 220;
  if (z_truthy((z_b_count($v_args) === 1))) {
    Z::$l = 220;
    z_raise(new ZExc(1, 'constOf: brak argumentu $k'));
  }
  Z::$l = 220;
  if (z_truthy((z_cmp(z_b_count($v_args), 2) >= 0))) {
    Z::$l = 220;
    return f_Desugar__constOf($v_this, z_index($v_args, 0), z_index($v_args, 1));
  }
  Z::$l = 220;
  return null;
  return null;
}
function f_Desugar__rwNew__w($v_this, $v_args) {
  Z::$l = 227;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 227;
    z_raise(new ZExc(1, 'rwNew: brak argumentu $x'));
  }
  Z::$l = 227;
  if (z_truthy((z_cmp(z_b_count($v_args), 1) >= 0))) {
    Z::$l = 227;
    return f_Desugar__rwNew($v_this, z_index($v_args, 0));
  }
  Z::$l = 227;
  return null;
  return null;
}
function f_Desugar__rwCall__w($v_this, $v_args) {
  Z::$l = 238;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 238;
    z_raise(new ZExc(1, 'rwCall: brak argumentu $x'));
  }
  Z::$l = 238;
  if (z_truthy((z_cmp(z_b_count($v_args), 1) >= 0))) {
    Z::$l = 238;
    return f_Desugar__rwCall($v_this, z_index($v_args, 0));
  }
  Z::$l = 238;
  return null;
  return null;
}
function f_Desugar__rwTry__w($v_this, $v_args) {
  Z::$l = 294;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 294;
    z_raise(new ZExc(1, 'rwTry: brak argumentu $x'));
  }
  Z::$l = 294;
  if (z_truthy((z_cmp(z_b_count($v_args), 1) >= 0))) {
    Z::$l = 294;
    return f_Desugar__rwTry($v_this, z_index($v_args, 0));
  }
  Z::$l = 294;
  return null;
  return null;
}
function f_Desugar__anyMethod__w($v_this, $v_args) {
  Z::$l = 314;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 314;
    z_raise(new ZExc(1, 'anyMethod: brak argumentu $m'));
  }
  Z::$l = 314;
  if (z_truthy((z_cmp(z_b_count($v_args), 1) >= 0))) {
    Z::$l = 314;
    return f_Desugar__anyMethod($v_this, z_index($v_args, 0));
  }
  Z::$l = 314;
  return null;
  return null;
}
function f_Desugar__stmtExpr__w($v_this, $v_args) {
  Z::$l = 320;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 320;
    z_raise(new ZExc(1, 'stmtExpr: brak argumentu $s'));
  }
  Z::$l = 320;
  if (z_truthy((z_cmp(z_b_count($v_args), 1) >= 0))) {
    Z::$l = 320;
    return f_Desugar__stmtExpr($v_this, z_index($v_args, 0));
  }
  Z::$l = 320;
  return null;
  return null;
}
function f_Desugar__funcStmt__w($v_this, $v_args) {
  Z::$l = 369;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 369;
    z_raise(new ZExc(1, 'funcStmt: brak argumentu $line'));
  }
  Z::$l = 369;
  if (z_truthy((z_b_count($v_args) === 1))) {
    Z::$l = 369;
    z_raise(new ZExc(1, 'funcStmt: brak argumentu $name'));
  }
  Z::$l = 369;
  if (z_truthy((z_b_count($v_args) === 2))) {
    Z::$l = 369;
    z_raise(new ZExc(1, 'funcStmt: brak argumentu $params'));
  }
  Z::$l = 369;
  if (z_truthy((z_b_count($v_args) === 3))) {
    Z::$l = 369;
    z_raise(new ZExc(1, 'funcStmt: brak argumentu $body'));
  }
  Z::$l = 369;
  if (z_truthy((z_cmp(z_b_count($v_args), 4) >= 0))) {
    Z::$l = 369;
    return f_Desugar__funcStmt($v_this, z_index($v_args, 0), z_index($v_args, 1), z_index($v_args, 2), z_index($v_args, 3));
  }
  Z::$l = 369;
  return null;
  return null;
}
function f_Desugar__param__w($v_this, $v_args) {
  Z::$l = 373;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 373;
    z_raise(new ZExc(1, 'param: brak argumentu $name'));
  }
  Z::$l = 373;
  if (z_truthy((z_b_count($v_args) === 1))) {
    Z::$l = 373;
    return f_Desugar__param($v_this, z_index($v_args, 0), null);
  }
  Z::$l = 373;
  if (z_truthy((z_cmp(z_b_count($v_args), 2) >= 0))) {
    Z::$l = 373;
    return f_Desugar__param($v_this, z_index($v_args, 0), z_index($v_args, 1));
  }
  Z::$l = 373;
  return null;
  return null;
}
function f_Desugar__genClass__w($v_this, $v_args) {
  Z::$l = 375;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 375;
    z_raise(new ZExc(1, 'genClass: brak argumentu $k'));
  }
  Z::$l = 375;
  if (z_truthy((z_cmp(z_b_count($v_args), 1) >= 0))) {
    Z::$l = 375;
    return f_Desugar__genClass($v_this, z_index($v_args, 0));
  }
  Z::$l = 375;
  return null;
  return null;
}
function f_Desugar__wrapper__w($v_this, $v_args) {
  Z::$l = 410;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 410;
    z_raise(new ZExc(1, 'wrapper: brak argumentu $owner'));
  }
  Z::$l = 410;
  if (z_truthy((z_b_count($v_args) === 1))) {
    Z::$l = 410;
    z_raise(new ZExc(1, 'wrapper: brak argumentu $m'));
  }
  Z::$l = 410;
  if (z_truthy((z_cmp(z_b_count($v_args), 2) >= 0))) {
    Z::$l = 410;
    return f_Desugar__wrapper($v_this, z_index($v_args, 0), z_index($v_args, 1));
  }
  Z::$l = 410;
  return null;
  return null;
}
function f_Desugar__wrapperN__w($v_this, $v_args) {
  Z::$l = 443;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 443;
    z_raise(new ZExc(1, 'wrapperN: brak argumentu $owner'));
  }
  Z::$l = 443;
  if (z_truthy((z_b_count($v_args) === 1))) {
    Z::$l = 443;
    z_raise(new ZExc(1, 'wrapperN: brak argumentu $m'));
  }
  Z::$l = 443;
  if (z_truthy((z_cmp(z_b_count($v_args), 2) >= 0))) {
    Z::$l = 443;
    return f_Desugar__wrapperN($v_this, z_index($v_args, 0), z_index($v_args, 1));
  }
  Z::$l = 443;
  return null;
  return null;
}
function f_Desugar__genDispatchN__w($v_this, $v_args) {
  Z::$l = 451;
  if (z_truthy((z_cmp(z_b_count($v_args), 0) >= 0))) {
    Z::$l = 451;
    return f_Desugar__genDispatchN($v_this);
  }
  Z::$l = 451;
  return null;
  return null;
}
function f_Desugar__genDispatch__w($v_this, $v_args) {
  Z::$l = 477;
  if (z_truthy((z_cmp(z_b_count($v_args), 0) >= 0))) {
    Z::$l = 477;
    return f_Desugar__genDispatch($v_this);
  }
  Z::$l = 477;
  return null;
  return null;
}
function f_Linker__err__w($v_this, $v_args) {
  Z::$l = 25;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 25;
    z_raise(new ZExc(1, 'err: brak argumentu $file'));
  }
  Z::$l = 25;
  if (z_truthy((z_b_count($v_args) === 1))) {
    Z::$l = 25;
    z_raise(new ZExc(1, 'err: brak argumentu $line'));
  }
  Z::$l = 25;
  if (z_truthy((z_b_count($v_args) === 2))) {
    Z::$l = 25;
    z_raise(new ZExc(1, 'err: brak argumentu $code'));
  }
  Z::$l = 25;
  if (z_truthy((z_b_count($v_args) === 3))) {
    Z::$l = 25;
    z_raise(new ZExc(1, 'err: brak argumentu $msg'));
  }
  Z::$l = 25;
  if (z_truthy((z_cmp(z_b_count($v_args), 4) >= 0))) {
    Z::$l = 25;
    return f_Linker__err($v_this, z_index($v_args, 0), z_index($v_args, 1), z_index($v_args, 2), z_index($v_args, 3));
  }
  Z::$l = 25;
  return null;
  return null;
}
function f_Linker__prefixOf__w($v_this, $v_args) {
  Z::$l = 27;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 27;
    z_raise(new ZExc(1, 'prefixOf: brak argumentu $path'));
  }
  Z::$l = 27;
  if (z_truthy((z_cmp(z_b_count($v_args), 1) >= 0))) {
    Z::$l = 27;
    return f_Linker__prefixOf($v_this, z_index($v_args, 0));
  }
  Z::$l = 27;
  return null;
  return null;
}
function f_Linker__dirOf__w($v_this, $v_args) {
  Z::$l = 29;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 29;
    z_raise(new ZExc(1, 'dirOf: brak argumentu $file'));
  }
  Z::$l = 29;
  if (z_truthy((z_cmp(z_b_count($v_args), 1) >= 0))) {
    Z::$l = 29;
    return f_Linker__dirOf($v_this, z_index($v_args, 0));
  }
  Z::$l = 29;
  return null;
  return null;
}
function f_Linker__rw__w($v_this, $v_args) {
  Z::$l = 35;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 35;
    z_raise(new ZExc(1, 'rw: brak argumentu $x'));
  }
  Z::$l = 35;
  if (z_truthy((z_b_count($v_args) === 1))) {
    Z::$l = 35;
    z_raise(new ZExc(1, 'rw: brak argumentu $self'));
  }
  Z::$l = 35;
  if (z_truthy((z_b_count($v_args) === 2))) {
    Z::$l = 35;
    z_raise(new ZExc(1, 'rw: brak argumentu $funcs'));
  }
  Z::$l = 35;
  if (z_truthy((z_b_count($v_args) === 3))) {
    Z::$l = 35;
    z_raise(new ZExc(1, 'rw: brak argumentu $aliases'));
  }
  Z::$l = 35;
  if (z_truthy((z_cmp(z_b_count($v_args), 4) >= 0))) {
    Z::$l = 35;
    return f_Linker__rw($v_this, z_index($v_args, 0), z_index($v_args, 1), z_index($v_args, 2), z_index($v_args, 3));
  }
  Z::$l = 35;
  return null;
  return null;
}
function f_Linker__loadModule__w($v_this, $v_args) {
  Z::$l = 61;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 61;
    z_raise(new ZExc(1, 'loadModule: brak argumentu $file'));
  }
  Z::$l = 61;
  if (z_truthy((z_b_count($v_args) === 1))) {
    Z::$l = 61;
    z_raise(new ZExc(1, 'loadModule: brak argumentu $path'));
  }
  Z::$l = 61;
  if (z_truthy((z_b_count($v_args) === 2))) {
    Z::$l = 61;
    z_raise(new ZExc(1, 'loadModule: brak argumentu $fromFile'));
  }
  Z::$l = 61;
  if (z_truthy((z_b_count($v_args) === 3))) {
    Z::$l = 61;
    z_raise(new ZExc(1, 'loadModule: brak argumentu $line'));
  }
  Z::$l = 61;
  if (z_truthy((z_cmp(z_b_count($v_args), 4) >= 0))) {
    Z::$l = 61;
    return f_Linker__loadModule($v_this, z_index($v_args, 0), z_index($v_args, 1), z_index($v_args, 2), z_index($v_args, 3));
  }
  Z::$l = 61;
  return null;
  return null;
}
function f_Linker__collectImports__w($v_this, $v_args) {
  Z::$l = 94;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 94;
    z_raise(new ZExc(1, 'collectImports: brak argumentu $ast'));
  }
  Z::$l = 94;
  if (z_truthy((z_b_count($v_args) === 1))) {
    Z::$l = 94;
    z_raise(new ZExc(1, 'collectImports: brak argumentu $file'));
  }
  Z::$l = 94;
  if (z_truthy((z_cmp(z_b_count($v_args), 2) >= 0))) {
    Z::$l = 94;
    return f_Linker__collectImports($v_this, z_index($v_args, 0), z_index($v_args, 1));
  }
  Z::$l = 94;
  return null;
  return null;
}
function f_VarPass__rw__w($v_this, $v_args) {
  Z::$l = 151;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 151;
    z_raise(new ZExc(1, 'rw: brak argumentu $x'));
  }
  Z::$l = 151;
  if (z_truthy((z_cmp(z_b_count($v_args), 1) >= 0))) {
    Z::$l = 151;
    return f_VarPass__rw($v_this, z_index($v_args, 0));
  }
  Z::$l = 151;
  return null;
  return null;
}
function f_LlEmitter__r__w($v_this, $v_args) {
  Z::$l = 62;
  if (z_truthy((z_cmp(z_b_count($v_args), 0) >= 0))) {
    Z::$l = 62;
    return f_LlEmitter__r($v_this);
  }
  Z::$l = 62;
  return null;
  return null;
}
function f_LlEmitter__newLabel__w($v_this, $v_args) {
  Z::$l = 63;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 63;
    z_raise(new ZExc(1, 'newLabel: brak argumentu $p'));
  }
  Z::$l = 63;
  if (z_truthy((z_cmp(z_b_count($v_args), 1) >= 0))) {
    Z::$l = 63;
    return f_LlEmitter__newLabel($v_this, z_index($v_args, 0));
  }
  Z::$l = 63;
  return null;
  return null;
}
function f_LlEmitter__line__w($v_this, $v_args) {
  Z::$l = 65;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 65;
    z_raise(new ZExc(1, 'line: brak argumentu $s'));
  }
  Z::$l = 65;
  if (z_truthy((z_cmp(z_b_count($v_args), 1) >= 0))) {
    Z::$l = 65;
    return f_LlEmitter__line($v_this, z_index($v_args, 0));
  }
  Z::$l = 65;
  return null;
  return null;
}
function f_LlEmitter__label__w($v_this, $v_args) {
  Z::$l = 70;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 70;
    z_raise(new ZExc(1, 'label: brak argumentu $l'));
  }
  Z::$l = 70;
  if (z_truthy((z_cmp(z_b_count($v_args), 1) >= 0))) {
    Z::$l = 70;
    return f_LlEmitter__label($v_this, z_index($v_args, 0));
  }
  Z::$l = 70;
  return null;
  return null;
}
function f_LlEmitter__terminate__w($v_this, $v_args) {
  Z::$l = 76;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 76;
    z_raise(new ZExc(1, 'terminate: brak argumentu $s'));
  }
  Z::$l = 76;
  if (z_truthy((z_cmp(z_b_count($v_args), 1) >= 0))) {
    Z::$l = 76;
    return f_LlEmitter__terminate($v_this, z_index($v_args, 0));
  }
  Z::$l = 76;
  return null;
  return null;
}
function f_LlEmitter__esc__w($v_this, $v_args) {
  Z::$l = 82;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 82;
    z_raise(new ZExc(1, 'esc: brak argumentu $s'));
  }
  Z::$l = 82;
  if (z_truthy((z_cmp(z_b_count($v_args), 1) >= 0))) {
    Z::$l = 82;
    return f_LlEmitter__esc($v_this, z_index($v_args, 0));
  }
  Z::$l = 82;
  return null;
  return null;
}
function f_LlEmitter__cstr__w($v_this, $v_args) {
  Z::$l = 94;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 94;
    z_raise(new ZExc(1, 'cstr: brak argumentu $s'));
  }
  Z::$l = 94;
  if (z_truthy((z_cmp(z_b_count($v_args), 1) >= 0))) {
    Z::$l = 94;
    return f_LlEmitter__cstr($v_this, z_index($v_args, 0));
  }
  Z::$l = 94;
  return null;
  return null;
}
function f_LlEmitter__strSlot__w($v_this, $v_args) {
  Z::$l = 103;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 103;
    z_raise(new ZExc(1, 'strSlot: brak argumentu $s'));
  }
  Z::$l = 103;
  if (z_truthy((z_cmp(z_b_count($v_args), 1) >= 0))) {
    Z::$l = 103;
    return f_LlEmitter__strSlot($v_this, z_index($v_args, 0));
  }
  Z::$l = 103;
  return null;
  return null;
}
function f_LlEmitter__slot__w($v_this, $v_args) {
  Z::$l = 111;
  if (z_truthy((z_cmp(z_b_count($v_args), 0) >= 0))) {
    Z::$l = 111;
    return f_LlEmitter__slot($v_this);
  }
  Z::$l = 111;
  return null;
  return null;
}
function f_LlEmitter__ty__w($v_this, $v_args) {
  Z::$l = 119;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 119;
    z_raise(new ZExc(1, 'ty: brak argumentu $t'));
  }
  Z::$l = 119;
  if (z_truthy((z_cmp(z_b_count($v_args), 1) >= 0))) {
    Z::$l = 119;
    return f_LlEmitter__ty($v_this, z_index($v_args, 0));
  }
  Z::$l = 119;
  return null;
  return null;
}
function f_LlEmitter__rt__w($v_this, $v_args) {
  Z::$l = 122;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 122;
    z_raise(new ZExc(1, 'rt: brak argumentu $fn'));
  }
  Z::$l = 122;
  if (z_truthy((z_b_count($v_args) === 1))) {
    Z::$l = 122;
    z_raise(new ZExc(1, 'rt: brak argumentu $ret'));
  }
  Z::$l = 122;
  if (z_truthy((z_b_count($v_args) === 2))) {
    Z::$l = 122;
    z_raise(new ZExc(1, 'rt: brak argumentu $args'));
  }
  Z::$l = 122;
  if (z_truthy((z_cmp(z_b_count($v_args), 3) >= 0))) {
    Z::$l = 122;
    return f_LlEmitter__rt($v_this, z_index($v_args, 0), z_index($v_args, 1), z_index($v_args, 2));
  }
  Z::$l = 122;
  return null;
  return null;
}
function f_LlEmitter__vcall__w($v_this, $v_args) {
  Z::$l = 140;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 140;
    z_raise(new ZExc(1, 'vcall: brak argumentu $fn'));
  }
  Z::$l = 140;
  if (z_truthy((z_b_count($v_args) === 1))) {
    Z::$l = 140;
    z_raise(new ZExc(1, 'vcall: brak argumentu $regs'));
  }
  Z::$l = 140;
  if (z_truthy((z_cmp(z_b_count($v_args), 2) >= 0))) {
    Z::$l = 140;
    return f_LlEmitter__vcall($v_this, z_index($v_args, 0), z_index($v_args, 1));
  }
  Z::$l = 140;
  return null;
  return null;
}
function f_LlEmitter__mkv__w($v_this, $v_args) {
  Z::$l = 146;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 146;
    z_raise(new ZExc(1, 'mkv: brak argumentu $tag'));
  }
  Z::$l = 146;
  if (z_truthy((z_b_count($v_args) === 1))) {
    Z::$l = 146;
    z_raise(new ZExc(1, 'mkv: brak argumentu $bits'));
  }
  Z::$l = 146;
  if (z_truthy((z_cmp(z_b_count($v_args), 2) >= 0))) {
    Z::$l = 146;
    return f_LlEmitter__mkv($v_this, z_index($v_args, 0), z_index($v_args, 1));
  }
  Z::$l = 146;
  return null;
  return null;
}
function f_LlEmitter__nullv__w($v_this, $v_args) {
  Z::$l = 152;
  if (z_truthy((z_cmp(z_b_count($v_args), 0) >= 0))) {
    Z::$l = 152;
    return f_LlEmitter__nullv($v_this);
  }
  Z::$l = 152;
  return null;
  return null;
}
function f_LlEmitter__truthy__w($v_this, $v_args) {
  Z::$l = 154;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 154;
    z_raise(new ZExc(1, 'truthy: brak argumentu $v'));
  }
  Z::$l = 154;
  if (z_truthy((z_cmp(z_b_count($v_args), 1) >= 0))) {
    Z::$l = 154;
    return f_LlEmitter__truthy($v_this, z_index($v_args, 0));
  }
  Z::$l = 154;
  return null;
  return null;
}
function f_LlEmitter__boolOf__w($v_this, $v_args) {
  Z::$l = 161;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 161;
    z_raise(new ZExc(1, 'boolOf: brak argumentu $i1'));
  }
  Z::$l = 161;
  if (z_truthy((z_cmp(z_b_count($v_args), 1) >= 0))) {
    Z::$l = 161;
    return f_LlEmitter__boolOf($v_this, z_index($v_args, 0));
  }
  Z::$l = 161;
  return null;
  return null;
}
function f_LlEmitter__ident__w($v_this, $v_args) {
  Z::$l = 169;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 169;
    z_raise(new ZExc(1, 'ident: brak argumentu $n'));
  }
  Z::$l = 169;
  if (z_truthy((z_cmp(z_b_count($v_args), 1) >= 0))) {
    Z::$l = 169;
    return f_LlEmitter__ident($v_this, z_index($v_args, 0));
  }
  Z::$l = 169;
  return null;
  return null;
}
function f_LlEmitter__load__w($v_this, $v_args) {
  Z::$l = 171;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 171;
    z_raise(new ZExc(1, 'load: brak argumentu $n'));
  }
  Z::$l = 171;
  if (z_truthy((z_cmp(z_b_count($v_args), 1) >= 0))) {
    Z::$l = 171;
    return f_LlEmitter__load($v_this, z_index($v_args, 0));
  }
  Z::$l = 171;
  return null;
  return null;
}
function f_LlEmitter__store__w($v_this, $v_args) {
  Z::$l = 177;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 177;
    z_raise(new ZExc(1, 'store: brak argumentu $n'));
  }
  Z::$l = 177;
  if (z_truthy((z_b_count($v_args) === 1))) {
    Z::$l = 177;
    z_raise(new ZExc(1, 'store: brak argumentu $v'));
  }
  Z::$l = 177;
  if (z_truthy((z_cmp(z_b_count($v_args), 2) >= 0))) {
    Z::$l = 177;
    return f_LlEmitter__store($v_this, z_index($v_args, 0), z_index($v_args, 1));
  }
  Z::$l = 177;
  return null;
  return null;
}
function f_LlEmitter__storeTo__w($v_this, $v_args) {
  Z::$l = 179;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 179;
    z_raise(new ZExc(1, 'storeTo: brak argumentu $ptr'));
  }
  Z::$l = 179;
  if (z_truthy((z_b_count($v_args) === 1))) {
    Z::$l = 179;
    z_raise(new ZExc(1, 'storeTo: brak argumentu $v'));
  }
  Z::$l = 179;
  if (z_truthy((z_cmp(z_b_count($v_args), 2) >= 0))) {
    Z::$l = 179;
    return f_LlEmitter__storeTo($v_this, z_index($v_args, 0), z_index($v_args, 1));
  }
  Z::$l = 179;
  return null;
  return null;
}
function f_LlEmitter__loadFrom__w($v_this, $v_args) {
  Z::$l = 181;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 181;
    z_raise(new ZExc(1, 'loadFrom: brak argumentu $ptr'));
  }
  Z::$l = 181;
  if (z_truthy((z_cmp(z_b_count($v_args), 1) >= 0))) {
    Z::$l = 181;
    return f_LlEmitter__loadFrom($v_this, z_index($v_args, 0));
  }
  Z::$l = 181;
  return null;
  return null;
}
function f_LlEmitter__isLval__w($v_this, $v_args) {
  Z::$l = 188;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 188;
    z_raise(new ZExc(1, 'isLval: brak argumentu $e'));
  }
  Z::$l = 188;
  if (z_truthy((z_cmp(z_b_count($v_args), 1) >= 0))) {
    Z::$l = 188;
    return f_LlEmitter__isLval($v_this, z_index($v_args, 0));
  }
  Z::$l = 188;
  return null;
  return null;
}
function f_LlEmitter__val__w($v_this, $v_args) {
  Z::$l = 190;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 190;
    z_raise(new ZExc(1, 'val: brak argumentu $e'));
  }
  Z::$l = 190;
  if (z_truthy((z_cmp(z_b_count($v_args), 1) >= 0))) {
    Z::$l = 190;
    return f_LlEmitter__val($v_this, z_index($v_args, 0));
  }
  Z::$l = 190;
  return null;
  return null;
}
function f_LlEmitter__binop__w($v_this, $v_args) {
  Z::$l = 195;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 195;
    z_raise(new ZExc(1, 'binop: brak argumentu $op'));
  }
  Z::$l = 195;
  if (z_truthy((z_b_count($v_args) === 1))) {
    Z::$l = 195;
    z_raise(new ZExc(1, 'binop: brak argumentu $a'));
  }
  Z::$l = 195;
  if (z_truthy((z_b_count($v_args) === 2))) {
    Z::$l = 195;
    z_raise(new ZExc(1, 'binop: brak argumentu $b'));
  }
  Z::$l = 195;
  if (z_truthy((z_cmp(z_b_count($v_args), 3) >= 0))) {
    Z::$l = 195;
    return f_LlEmitter__binop($v_this, z_index($v_args, 0), z_index($v_args, 1), z_index($v_args, 2));
  }
  Z::$l = 195;
  return null;
  return null;
}
function f_LlEmitter__quiet__w($v_this, $v_args) {
  Z::$l = 223;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 223;
    z_raise(new ZExc(1, 'quiet: brak argumentu $e'));
  }
  Z::$l = 223;
  if (z_truthy((z_cmp(z_b_count($v_args), 1) >= 0))) {
    Z::$l = 223;
    return f_LlEmitter__quiet($v_this, z_index($v_args, 0));
  }
  Z::$l = 223;
  return null;
  return null;
}
function f_LlEmitter__keyOf__w($v_this, $v_args) {
  Z::$l = 232;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 232;
    z_raise(new ZExc(1, 'keyOf: brak argumentu $t'));
  }
  Z::$l = 232;
  if (z_truthy((z_b_count($v_args) === 1))) {
    Z::$l = 232;
    z_raise(new ZExc(1, 'keyOf: brak argumentu $arr'));
  }
  Z::$l = 232;
  if (z_truthy((z_cmp(z_b_count($v_args), 2) >= 0))) {
    Z::$l = 232;
    return f_LlEmitter__keyOf($v_this, z_index($v_args, 0), z_index($v_args, 1));
  }
  Z::$l = 232;
  return null;
  return null;
}
function f_LlEmitter__lv__w($v_this, $v_args) {
  Z::$l = 243;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 243;
    z_raise(new ZExc(1, 'lv: brak argumentu $base'));
  }
  Z::$l = 243;
  if (z_truthy((z_cmp(z_b_count($v_args), 1) >= 0))) {
    Z::$l = 243;
    return f_LlEmitter__lv($v_this, z_index($v_args, 0));
  }
  Z::$l = 243;
  return null;
  return null;
}
function f_LlEmitter__newArr__w($v_this, $v_args) {
  Z::$l = 271;
  if (z_truthy((z_cmp(z_b_count($v_args), 0) >= 0))) {
    Z::$l = 271;
    return f_LlEmitter__newArr($v_this);
  }
  Z::$l = 271;
  return null;
  return null;
}
function f_LlEmitter__vcallVoid__w($v_this, $v_args) {
  Z::$l = 273;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 273;
    z_raise(new ZExc(1, 'vcallVoid: brak argumentu $fn'));
  }
  Z::$l = 273;
  if (z_truthy((z_b_count($v_args) === 1))) {
    Z::$l = 273;
    z_raise(new ZExc(1, 'vcallVoid: brak argumentu $regs'));
  }
  Z::$l = 273;
  if (z_truthy((z_cmp(z_b_count($v_args), 2) >= 0))) {
    Z::$l = 273;
    return f_LlEmitter__vcallVoid($v_this, z_index($v_args, 0), z_index($v_args, 1));
  }
  Z::$l = 273;
  return null;
  return null;
}
function f_LlEmitter__incdec__w($v_this, $v_args) {
  Z::$l = 279;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 279;
    z_raise(new ZExc(1, 'incdec: brak argumentu $e'));
  }
  Z::$l = 279;
  if (z_truthy((z_cmp(z_b_count($v_args), 1) >= 0))) {
    Z::$l = 279;
    return f_LlEmitter__incdec($v_this, z_index($v_args, 0));
  }
  Z::$l = 279;
  return null;
  return null;
}
function f_LlEmitter__assignop__w($v_this, $v_args) {
  Z::$l = 299;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 299;
    z_raise(new ZExc(1, 'assignop: brak argumentu $e'));
  }
  Z::$l = 299;
  if (z_truthy((z_cmp(z_b_count($v_args), 1) >= 0))) {
    Z::$l = 299;
    return f_LlEmitter__assignop($v_this, z_index($v_args, 0));
  }
  Z::$l = 299;
  return null;
  return null;
}
function f_LlEmitter__coalesceWith__w($v_this, $v_args) {
  Z::$l = 329;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 329;
    z_raise(new ZExc(1, 'coalesceWith: brak argumentu $x'));
  }
  Z::$l = 329;
  if (z_truthy((z_b_count($v_args) === 1))) {
    Z::$l = 329;
    z_raise(new ZExc(1, 'coalesceWith: brak argumentu $rhsExpr'));
  }
  Z::$l = 329;
  if (z_truthy((z_cmp(z_b_count($v_args), 2) >= 0))) {
    Z::$l = 329;
    return f_LlEmitter__coalesceWith($v_this, z_index($v_args, 0), z_index($v_args, 1));
  }
  Z::$l = 329;
  return null;
  return null;
}
function f_LlEmitter__assign__w($v_this, $v_args) {
  Z::$l = 346;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 346;
    z_raise(new ZExc(1, 'assign: brak argumentu $e'));
  }
  Z::$l = 346;
  if (z_truthy((z_cmp(z_b_count($v_args), 1) >= 0))) {
    Z::$l = 346;
    return f_LlEmitter__assign($v_this, z_index($v_args, 0));
  }
  Z::$l = 346;
  return null;
  return null;
}
function f_LlEmitter__argRegs__w($v_this, $v_args) {
  Z::$l = 363;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 363;
    z_raise(new ZExc(1, 'argRegs: brak argumentu $list'));
  }
  Z::$l = 363;
  if (z_truthy((z_b_count($v_args) === 1))) {
    Z::$l = 363;
    z_raise(new ZExc(1, 'argRegs: brak argumentu $dup'));
  }
  Z::$l = 363;
  if (z_truthy((z_cmp(z_b_count($v_args), 2) >= 0))) {
    Z::$l = 363;
    return f_LlEmitter__argRegs($v_this, z_index($v_args, 0), z_index($v_args, 1));
  }
  Z::$l = 363;
  return null;
  return null;
}
function f_LlEmitter__call__w($v_this, $v_args) {
  Z::$l = 369;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 369;
    z_raise(new ZExc(1, 'call: brak argumentu $e'));
  }
  Z::$l = 369;
  if (z_truthy((z_cmp(z_b_count($v_args), 1) >= 0))) {
    Z::$l = 369;
    return f_LlEmitter__call($v_this, z_index($v_args, 0));
  }
  Z::$l = 369;
  return null;
  return null;
}
function f_LlEmitter__doExit__w($v_this, $v_args) {
  Z::$l = 392;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 392;
    z_raise(new ZExc(1, 'doExit: brak argumentu $a'));
  }
  Z::$l = 392;
  if (z_truthy((z_cmp(z_b_count($v_args), 1) >= 0))) {
    Z::$l = 392;
    return f_LlEmitter__doExit($v_this, z_index($v_args, 0));
  }
  Z::$l = 392;
  return null;
  return null;
}
function f_LlEmitter__builtin__w($v_this, $v_args) {
  Z::$l = 399;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 399;
    z_raise(new ZExc(1, 'builtin: brak argumentu $name'));
  }
  Z::$l = 399;
  if (z_truthy((z_b_count($v_args) === 1))) {
    Z::$l = 399;
    z_raise(new ZExc(1, 'builtin: brak argumentu $list'));
  }
  Z::$l = 399;
  if (z_truthy((z_cmp(z_b_count($v_args), 2) >= 0))) {
    Z::$l = 399;
    return f_LlEmitter__builtin($v_this, z_index($v_args, 0), z_index($v_args, 1));
  }
  Z::$l = 399;
  return null;
  return null;
}
function f_LlEmitter__expr__w($v_this, $v_args) {
  Z::$l = 431;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 431;
    z_raise(new ZExc(1, 'expr: brak argumentu $e'));
  }
  Z::$l = 431;
  if (z_truthy((z_cmp(z_b_count($v_args), 1) >= 0))) {
    Z::$l = 431;
    return f_LlEmitter__expr($v_this, z_index($v_args, 0));
  }
  Z::$l = 431;
  return null;
  return null;
}
function f_LlEmitter__shortCircuit__w($v_this, $v_args) {
  Z::$l = 502;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 502;
    z_raise(new ZExc(1, 'shortCircuit: brak argumentu $isAnd'));
  }
  Z::$l = 502;
  if (z_truthy((z_b_count($v_args) === 1))) {
    Z::$l = 502;
    z_raise(new ZExc(1, 'shortCircuit: brak argumentu $l'));
  }
  Z::$l = 502;
  if (z_truthy((z_b_count($v_args) === 2))) {
    Z::$l = 502;
    z_raise(new ZExc(1, 'shortCircuit: brak argumentu $r'));
  }
  Z::$l = 502;
  if (z_truthy((z_cmp(z_b_count($v_args), 3) >= 0))) {
    Z::$l = 502;
    return f_LlEmitter__shortCircuit($v_this, z_index($v_args, 0), z_index($v_args, 1), z_index($v_args, 2));
  }
  Z::$l = 502;
  return null;
  return null;
}
function f_LlEmitter__ternary__w($v_this, $v_args) {
  Z::$l = 519;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 519;
    z_raise(new ZExc(1, 'ternary: brak argumentu $e'));
  }
  Z::$l = 519;
  if (z_truthy((z_cmp(z_b_count($v_args), 1) >= 0))) {
    Z::$l = 519;
    return f_LlEmitter__ternary($v_this, z_index($v_args, 0));
  }
  Z::$l = 519;
  return null;
  return null;
}
function f_LlEmitter__setLine__w($v_this, $v_args) {
  Z::$l = 546;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 546;
    z_raise(new ZExc(1, 'setLine: brak argumentu $n'));
  }
  Z::$l = 546;
  if (z_truthy((z_cmp(z_b_count($v_args), 1) >= 0))) {
    Z::$l = 546;
    return f_LlEmitter__setLine($v_this, z_index($v_args, 0));
  }
  Z::$l = 546;
  return null;
  return null;
}
function f_LlEmitter__block__w($v_this, $v_args) {
  Z::$l = 548;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 548;
    z_raise(new ZExc(1, 'block: brak argumentu $list'));
  }
  Z::$l = 548;
  if (z_truthy((z_cmp(z_b_count($v_args), 1) >= 0))) {
    Z::$l = 548;
    return f_LlEmitter__block($v_this, z_index($v_args, 0));
  }
  Z::$l = 548;
  return null;
  return null;
}
function f_LlEmitter__regionBegin__w($v_this, $v_args) {
  Z::$l = 551;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 551;
    z_raise(new ZExc(1, 'regionBegin: brak argumentu $loop'));
  }
  Z::$l = 551;
  if (z_truthy((z_b_count($v_args) === 1))) {
    Z::$l = 551;
    z_raise(new ZExc(1, 'regionBegin: brak argumentu $body'));
  }
  Z::$l = 551;
  if (z_truthy((z_b_count($v_args) === 2))) {
    Z::$l = 551;
    z_raise(new ZExc(1, 'regionBegin: brak argumentu $hdr'));
  }
  Z::$l = 551;
  if (z_truthy((z_b_count($v_args) === 3))) {
    Z::$l = 551;
    z_raise(new ZExc(1, 'regionBegin: brak argumentu $pre'));
  }
  Z::$l = 551;
  if (z_truthy((z_b_count($v_args) === 4))) {
    Z::$l = 551;
    z_raise(new ZExc(1, 'regionBegin: brak argumentu $id'));
  }
  Z::$l = 551;
  if (z_truthy((z_cmp(z_b_count($v_args), 5) >= 0))) {
    Z::$l = 551;
    return f_LlEmitter__regionBegin($v_this, z_index($v_args, 0), z_index($v_args, 1), z_index($v_args, 2), z_index($v_args, 3), z_index($v_args, 4));
  }
  Z::$l = 551;
  return null;
  return null;
}
function f_LlEmitter__regionEnter__w($v_this, $v_args) {
  Z::$l = 560;
  if (z_truthy((z_cmp(z_b_count($v_args), 0) >= 0))) {
    Z::$l = 560;
    return f_LlEmitter__regionEnter($v_this);
  }
  Z::$l = 560;
  return null;
  return null;
}
function f_LlEmitter__regionExit__w($v_this, $v_args) {
  Z::$l = 565;
  if (z_truthy((z_cmp(z_b_count($v_args), 0) >= 0))) {
    Z::$l = 565;
    return f_LlEmitter__regionExit($v_this);
  }
  Z::$l = 565;
  return null;
  return null;
}
function f_LlEmitter__regionEnd__w($v_this, $v_args) {
  Z::$l = 578;
  if (z_truthy((z_cmp(z_b_count($v_args), 0) >= 0))) {
    Z::$l = 578;
    return f_LlEmitter__regionEnd($v_this);
  }
  Z::$l = 578;
  return null;
  return null;
}
function f_LlEmitter__pushLoop__w($v_this, $v_args) {
  Z::$l = 580;
  if (z_truthy((z_cmp(z_b_count($v_args), 0) >= 0))) {
    Z::$l = 580;
    return f_LlEmitter__pushLoop($v_this);
  }
  Z::$l = 580;
  return null;
  return null;
}
function f_LlEmitter__popLoop__w($v_this, $v_args) {
  Z::$l = 581;
  if (z_truthy((z_cmp(z_b_count($v_args), 0) >= 0))) {
    Z::$l = 581;
    return f_LlEmitter__popLoop($v_this);
  }
  Z::$l = 581;
  return null;
  return null;
}
function f_LlEmitter__jumpOut__w($v_this, $v_args) {
  Z::$l = 583;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 583;
    z_raise(new ZExc(1, 'jumpOut: brak argumentu $depth'));
  }
  Z::$l = 583;
  if (z_truthy((z_cmp(z_b_count($v_args), 1) >= 0))) {
    Z::$l = 583;
    return f_LlEmitter__jumpOut($v_this, z_index($v_args, 0));
  }
  Z::$l = 583;
  return null;
  return null;
}
function f_LlEmitter__catchCond__w($v_this, $v_args) {
  Z::$l = 596;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 596;
    z_raise(new ZExc(1, 'catchCond: brak argumentu $types'));
  }
  Z::$l = 596;
  if (z_truthy((z_b_count($v_args) === 1))) {
    Z::$l = 596;
    z_raise(new ZExc(1, 'catchCond: brak argumentu $x'));
  }
  Z::$l = 596;
  if (z_truthy((z_cmp(z_b_count($v_args), 2) >= 0))) {
    Z::$l = 596;
    return f_LlEmitter__catchCond($v_this, z_index($v_args, 0), z_index($v_args, 1));
  }
  Z::$l = 596;
  return null;
  return null;
}
function f_LlEmitter__handler__w($v_this, $v_args) {
  Z::$l = 617;
  if (z_truthy((z_cmp(z_b_count($v_args), 0) >= 0))) {
    Z::$l = 617;
    return f_LlEmitter__handler($v_this);
  }
  Z::$l = 617;
  return null;
  return null;
}
function f_LlEmitter__jb__w($v_this, $v_args) {
  Z::$l = 624;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 624;
    z_raise(new ZExc(1, 'jb: brak argumentu $h'));
  }
  Z::$l = 624;
  if (z_truthy((z_cmp(z_b_count($v_args), 1) >= 0))) {
    Z::$l = 624;
    return f_LlEmitter__jb($v_this, z_index($v_args, 0));
  }
  Z::$l = 624;
  return null;
  return null;
}
function f_LlEmitter__tryCatch__w($v_this, $v_args) {
  Z::$l = 630;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 630;
    z_raise(new ZExc(1, 'tryCatch: brak argumentu $body'));
  }
  Z::$l = 630;
  if (z_truthy((z_b_count($v_args) === 1))) {
    Z::$l = 630;
    z_raise(new ZExc(1, 'tryCatch: brak argumentu $catches'));
  }
  Z::$l = 630;
  if (z_truthy((z_cmp(z_b_count($v_args), 2) >= 0))) {
    Z::$l = 630;
    return f_LlEmitter__tryCatch($v_this, z_index($v_args, 0), z_index($v_args, 1));
  }
  Z::$l = 630;
  return null;
  return null;
}
function f_LlEmitter__tryStmt__w($v_this, $v_args) {
  Z::$l = 669;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 669;
    z_raise(new ZExc(1, 'tryStmt: brak argumentu $s'));
  }
  Z::$l = 669;
  if (z_truthy((z_cmp(z_b_count($v_args), 1) >= 0))) {
    Z::$l = 669;
    return f_LlEmitter__tryStmt($v_this, z_index($v_args, 0));
  }
  Z::$l = 669;
  return null;
  return null;
}
function f_LlEmitter__chkType__w($v_this, $v_args) {
  Z::$l = 714;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 714;
    z_raise(new ZExc(1, 'chkType: brak argumentu $types'));
  }
  Z::$l = 714;
  if (z_truthy((z_b_count($v_args) === 1))) {
    Z::$l = 714;
    z_raise(new ZExc(1, 'chkType: brak argumentu $v'));
  }
  Z::$l = 714;
  if (z_truthy((z_b_count($v_args) === 2))) {
    Z::$l = 714;
    z_raise(new ZExc(1, 'chkType: brak argumentu $what'));
  }
  Z::$l = 714;
  if (z_truthy((z_cmp(z_b_count($v_args), 3) >= 0))) {
    Z::$l = 714;
    return f_LlEmitter__chkType($v_this, z_index($v_args, 0), z_index($v_args, 1), z_index($v_args, 2));
  }
  Z::$l = 714;
  return null;
  return null;
}
function f_LlEmitter__stmt__w($v_this, $v_args) {
  Z::$l = 721;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 721;
    z_raise(new ZExc(1, 'stmt: brak argumentu $s'));
  }
  Z::$l = 721;
  if (z_truthy((z_cmp(z_b_count($v_args), 1) >= 0))) {
    Z::$l = 721;
    return f_LlEmitter__stmt($v_this, z_index($v_args, 0));
  }
  Z::$l = 721;
  return null;
  return null;
}
function f_LlEmitter__emptyStr__w($v_this, $v_args) {
  Z::$l = 954;
  if (z_truthy((z_cmp(z_b_count($v_args), 0) >= 0))) {
    Z::$l = 954;
    return f_LlEmitter__emptyStr($v_this);
  }
  Z::$l = 954;
  return null;
  return null;
}
function f_LlEmitter__beginFunc__w($v_this, $v_args) {
  Z::$l = 962;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 962;
    z_raise(new ZExc(1, 'beginFunc: brak argumentu $vol'));
  }
  Z::$l = 962;
  if (z_truthy((z_cmp(z_b_count($v_args), 1) >= 0))) {
    Z::$l = 962;
    return f_LlEmitter__beginFunc($v_this, z_index($v_args, 0));
  }
  Z::$l = 962;
  return null;
  return null;
}
function f_LlEmitter__initLocals__w($v_this, $v_args) {
  Z::$l = 971;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 971;
    z_raise(new ZExc(1, 'initLocals: brak argumentu $locals'));
  }
  Z::$l = 971;
  if (z_truthy((z_b_count($v_args) === 1))) {
    Z::$l = 971;
    z_raise(new ZExc(1, 'initLocals: brak argumentu $params'));
  }
  Z::$l = 971;
  if (z_truthy((z_cmp(z_b_count($v_args), 2) >= 0))) {
    Z::$l = 971;
    return f_LlEmitter__initLocals($v_this, z_index($v_args, 0), z_index($v_args, 1));
  }
  Z::$l = 971;
  return null;
  return null;
}
function f_LlEmitter__finishFunc__w($v_this, $v_args) {
  Z::$l = 981;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 981;
    z_raise(new ZExc(1, 'finishFunc: brak argumentu $header'));
  }
  Z::$l = 981;
  if (z_truthy((z_b_count($v_args) === 1))) {
    Z::$l = 981;
    z_raise(new ZExc(1, 'finishFunc: brak argumentu $kind'));
  }
  Z::$l = 981;
  if (z_truthy((z_cmp(z_b_count($v_args), 2) >= 0))) {
    Z::$l = 981;
    return f_LlEmitter__finishFunc($v_this, z_index($v_args, 0), z_index($v_args, 1));
  }
  Z::$l = 981;
  return null;
  return null;
}
function f_LlEmitter__funcDef__w($v_this, $v_args) {
  Z::$l = 996;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 996;
    z_raise(new ZExc(1, 'funcDef: brak argumentu $name'));
  }
  Z::$l = 996;
  if (z_truthy((z_cmp(z_b_count($v_args), 1) >= 0))) {
    Z::$l = 996;
    return f_LlEmitter__funcDef($v_this, z_index($v_args, 0));
  }
  Z::$l = 996;
  return null;
  return null;
}
function f_LlEmitter__generate__w($v_this, $v_args) {
  Z::$l = 1041;
  if (z_truthy((z_b_count($v_args) === 0))) {
    Z::$l = 1041;
    z_raise(new ZExc(1, 'generate: brak argumentu $triple'));
  }
  Z::$l = 1041;
  if (z_truthy((z_cmp(z_b_count($v_args), 1) >= 0))) {
    Z::$l = 1041;
    return f_LlEmitter__generate($v_this, z_index($v_args, 0));
  }
  Z::$l = 1041;
  return null;
  return null;
}
function f_LlEmitter__decls__w($v_this, $v_args) {
  Z::$l = 1109;
  if (z_truthy((z_cmp(z_b_count($v_args), 0) >= 0))) {
    Z::$l = 1109;
    return f_LlEmitter__decls($v_this);
  }
  Z::$l = 1109;
  return null;
  return null;
}
function f_zs_invoke($v_o, $v_name, $v_args) {
  $v_c = null;
  Z::$l = 0;
  ($v_c = z_b_zs_obj_class($v_o));
  Z::$l = 0;
  if (z_truthy(($v_c === null))) {
    Z::$l = 0;
    if (z_truthy(($v_name === 'getMessage'))) {
      Z::$l = 0;
      return z_getmessage($v_o);
    }
  }
  Z::$l = 0;
  if (z_truthy(($v_c === 'LexError'))) {
    Z::$l = 0;
    if (z_truthy(($v_name === 'getMessage'))) {
      Z::$l = 0;
      return f_Exception__getMessage__w($v_o, $v_args);
    }
  }
  Z::$l = 0;
  if (z_truthy(($v_c === 'Lexer'))) {
    Z::$l = 0;
    if (z_truthy(($v_name === 'peek'))) {
      Z::$l = 0;
      return f_Lexer__peek__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'bump'))) {
      Z::$l = 0;
      return f_Lexer__bump__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'fail'))) {
      Z::$l = 0;
      return f_Lexer__fail__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'emit'))) {
      Z::$l = 0;
      return f_Lexer__emit__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'run'))) {
      Z::$l = 0;
      return f_Lexer__run__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'skipTrivia'))) {
      Z::$l = 0;
      return f_Lexer__skipTrivia__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'variable'))) {
      Z::$l = 0;
      return f_Lexer__variable__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'ident'))) {
      Z::$l = 0;
      return f_Lexer__ident__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'digitValue'))) {
      Z::$l = 0;
      return f_Lexer__digitValue__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'digits'))) {
      Z::$l = 0;
      return f_Lexer__digits__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'number'))) {
      Z::$l = 0;
      return f_Lexer__number__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'string'))) {
      Z::$l = 0;
      return f_Lexer__string__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'op'))) {
      Z::$l = 0;
      return f_Lexer__op__w($v_o, $v_args);
    }
  }
  Z::$l = 0;
  if (z_truthy(($v_c === 'ParseError'))) {
    Z::$l = 0;
    if (z_truthy(($v_name === 'getMessage'))) {
      Z::$l = 0;
      return f_Exception__getMessage__w($v_o, $v_args);
    }
  }
  Z::$l = 0;
  if (z_truthy(($v_c === 'Parser'))) {
    Z::$l = 0;
    if (z_truthy(($v_name === 'cur'))) {
      Z::$l = 0;
      return f_Parser__cur__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'at'))) {
      Z::$l = 0;
      return f_Parser__at__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'line'))) {
      Z::$l = 0;
      return f_Parser__line__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'atEof'))) {
      Z::$l = 0;
      return f_Parser__atEof__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'bump'))) {
      Z::$l = 0;
      return f_Parser__bump__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'back'))) {
      Z::$l = 0;
      return f_Parser__back__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'fail'))) {
      Z::$l = 0;
      return f_Parser__fail__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'isOp'))) {
      Z::$l = 0;
      return f_Parser__isOp__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'isKw'))) {
      Z::$l = 0;
      return f_Parser__isKw__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'isWord'))) {
      Z::$l = 0;
      return f_Parser__isWord__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'isVar'))) {
      Z::$l = 0;
      return f_Parser__isVar__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'eatOp'))) {
      Z::$l = 0;
      return f_Parser__eatOp__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'eatKw'))) {
      Z::$l = 0;
      return f_Parser__eatKw__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'eatWord'))) {
      Z::$l = 0;
      return f_Parser__eatWord__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'expectOp'))) {
      Z::$l = 0;
      return f_Parser__expectOp__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'ident'))) {
      Z::$l = 0;
      return f_Parser__ident__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'varName'))) {
      Z::$l = 0;
      return f_Parser__varName__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'isFuncKw'))) {
      Z::$l = 0;
      return f_Parser__isFuncKw__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'block'))) {
      Z::$l = 0;
      return f_Parser__block__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'body'))) {
      Z::$l = 0;
      return f_Parser__body__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'parenExpr'))) {
      Z::$l = 0;
      return f_Parser__parenExpr__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'path'))) {
      Z::$l = 0;
      return f_Parser__path__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'stmt'))) {
      Z::$l = 0;
      return f_Parser__stmt__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'ifRest'))) {
      Z::$l = 0;
      return f_Parser__ifRest__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'exprList'))) {
      Z::$l = 0;
      return f_Parser__exprList__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'forStmt'))) {
      Z::$l = 0;
      return f_Parser__forStmt__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'foreachStmt'))) {
      Z::$l = 0;
      return f_Parser__foreachStmt__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'switchStmt'))) {
      Z::$l = 0;
      return f_Parser__switchStmt__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'tryStmt'))) {
      Z::$l = 0;
      return f_Parser__tryStmt__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'externStmt'))) {
      Z::$l = 0;
      return f_Parser__externStmt__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'types'))) {
      Z::$l = 0;
      return f_Parser__types__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'params'))) {
      Z::$l = 0;
      return f_Parser__params__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'funcRest'))) {
      Z::$l = 0;
      return f_Parser__funcRest__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'classDecl'))) {
      Z::$l = 0;
      return f_Parser__classDecl__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'expr'))) {
      Z::$l = 0;
      return f_Parser__expr__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'checkLvalue'))) {
      Z::$l = 0;
      return f_Parser__checkLvalue__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'exprBp'))) {
      Z::$l = 0;
      return f_Parser__exprBp__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'unary'))) {
      Z::$l = 0;
      return f_Parser__unary__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'args'))) {
      Z::$l = 0;
      return f_Parser__args__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'postfix'))) {
      Z::$l = 0;
      return f_Parser__postfix__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'primary'))) {
      Z::$l = 0;
      return f_Parser__primary__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'matchExpr'))) {
      Z::$l = 0;
      return f_Parser__matchExpr__w($v_o, $v_args);
    }
  }
  Z::$l = 0;
  if (z_truthy(($v_c === 'Bundler'))) {
    Z::$l = 0;
    if (z_truthy(($v_name === 'scan'))) {
      Z::$l = 0;
      return f_Bundler__scan__w($v_o, $v_args);
    }
  }
  Z::$l = 0;
  if (z_truthy(($v_c === 'SemaScope'))) {
    Z::$l = 0;
    if (z_truthy(($v_name === 'raise'))) {
      Z::$l = 0;
      return f_SemaScope__raise__w($v_o, $v_args);
    }
  }
  Z::$l = 0;
  if (z_truthy(($v_c === 'Analyzer'))) {
    Z::$l = 0;
    if (z_truthy(($v_name === 'baseVar'))) {
      Z::$l = 0;
      return f_Analyzer__baseVar__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'allocKind'))) {
      Z::$l = 0;
      return f_Analyzer__allocKind__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'valueVars'))) {
      Z::$l = 0;
      return f_Analyzer__valueVars__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'visitAny'))) {
      Z::$l = 0;
      return f_Analyzer__visitAny__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'visitChildren'))) {
      Z::$l = 0;
      return f_Analyzer__visitChildren__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'visit'))) {
      Z::$l = 0;
      return f_Analyzer__visit__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'fnScope'))) {
      Z::$l = 0;
      return f_Analyzer__fnScope__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'resolveChildren'))) {
      Z::$l = 0;
      return f_Analyzer__resolveChildren__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'finish'))) {
      Z::$l = 0;
      return f_Analyzer__finish__w($v_o, $v_args);
    }
  }
  Z::$l = 0;
  if (z_truthy(($v_c === 'Lowerer'))) {
    Z::$l = 0;
    if (z_truthy(($v_name === 'err'))) {
      Z::$l = 0;
      return f_Lowerer__err__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'addLocal'))) {
      Z::$l = 0;
      return f_Lowerer__addLocal__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'collectExpr'))) {
      Z::$l = 0;
      return f_Lowerer__collectExpr__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'collectTarget'))) {
      Z::$l = 0;
      return f_Lowerer__collectTarget__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'collectAny'))) {
      Z::$l = 0;
      return f_Lowerer__collectAny__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'checkStmts'))) {
      Z::$l = 0;
      return f_Lowerer__checkStmts__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'checkStmt'))) {
      Z::$l = 0;
      return f_Lowerer__checkStmt__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'checkNew'))) {
      Z::$l = 0;
      return f_Lowerer__checkNew__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'containsTry'))) {
      Z::$l = 0;
      return f_Lowerer__containsTry__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'calleeName'))) {
      Z::$l = 0;
      return f_Lowerer__calleeName__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'checkExpr'))) {
      Z::$l = 0;
      return f_Lowerer__checkExpr__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'checkLvalue'))) {
      Z::$l = 0;
      return f_Lowerer__checkLvalue__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'checkCall'))) {
      Z::$l = 0;
      return f_Lowerer__checkCall__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'topCallsMain'))) {
      Z::$l = 0;
      return f_Lowerer__topCallsMain__w($v_o, $v_args);
    }
  }
  Z::$l = 0;
  if (z_truthy(($v_c === 'Lifter'))) {
    Z::$l = 0;
    if (z_truthy(($v_name === 'err'))) {
      Z::$l = 0;
      return f_Lifter__err__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'scan'))) {
      Z::$l = 0;
      return f_Lifter__scan__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'names'))) {
      Z::$l = 0;
      return f_Lifter__names__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'freeOf'))) {
      Z::$l = 0;
      return f_Lifter__freeOf__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'lift'))) {
      Z::$l = 0;
      return f_Lifter__lift__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'rw'))) {
      Z::$l = 0;
      return f_Lifter__rw__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'argsArray'))) {
      Z::$l = 0;
      return f_Lifter__argsArray__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'rwCall'))) {
      Z::$l = 0;
      return f_Lifter__rwCall__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'plain'))) {
      Z::$l = 0;
      return f_Lifter__plain__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'reorder'))) {
      Z::$l = 0;
      return f_Lifter__reorder__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'helpers'))) {
      Z::$l = 0;
      return f_Lifter__helpers__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'dispatcher'))) {
      Z::$l = 0;
      return f_Lifter__dispatcher__w($v_o, $v_args);
    }
  }
  Z::$l = 0;
  if (z_truthy(($v_c === 'Desugar'))) {
    Z::$l = 0;
    if (z_truthy(($v_name === 'err'))) {
      Z::$l = 0;
      return f_Desugar__err__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'node'))) {
      Z::$l = 0;
      return f_Desugar__node__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'nm'))) {
      Z::$l = 0;
      return f_Desugar__nm__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'mkstr'))) {
      Z::$l = 0;
      return f_Desugar__mkstr__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'mkvar'))) {
      Z::$l = 0;
      return f_Desugar__mkvar__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'call'))) {
      Z::$l = 0;
      return f_Desugar__call__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'fresh'))) {
      Z::$l = 0;
      return f_Desugar__fresh__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'collect'))) {
      Z::$l = 0;
      return f_Desugar__collect__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'chain'))) {
      Z::$l = 0;
      return f_Desugar__chain__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'owner'))) {
      Z::$l = 0;
      return f_Desugar__owner__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'allProps'))) {
      Z::$l = 0;
      return f_Desugar__allProps__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'isaNames'))) {
      Z::$l = 0;
      return f_Desugar__isaNames__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'rwList'))) {
      Z::$l = 0;
      return f_Desugar__rwList__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'rw'))) {
      Z::$l = 0;
      return f_Desugar__rw__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'baseOk'))) {
      Z::$l = 0;
      return f_Desugar__baseOk__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'propModify'))) {
      Z::$l = 0;
      return f_Desugar__propModify__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'staticName'))) {
      Z::$l = 0;
      return f_Desugar__staticName__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'staticTarget'))) {
      Z::$l = 0;
      return f_Desugar__staticTarget__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'clsName'))) {
      Z::$l = 0;
      return f_Desugar__clsName__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'constOf'))) {
      Z::$l = 0;
      return f_Desugar__constOf__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'rwNew'))) {
      Z::$l = 0;
      return f_Desugar__rwNew__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'rwCall'))) {
      Z::$l = 0;
      return f_Desugar__rwCall__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'rwTry'))) {
      Z::$l = 0;
      return f_Desugar__rwTry__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'anyMethod'))) {
      Z::$l = 0;
      return f_Desugar__anyMethod__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'stmtExpr'))) {
      Z::$l = 0;
      return f_Desugar__stmtExpr__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'funcStmt'))) {
      Z::$l = 0;
      return f_Desugar__funcStmt__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'param'))) {
      Z::$l = 0;
      return f_Desugar__param__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'genClass'))) {
      Z::$l = 0;
      return f_Desugar__genClass__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'wrapper'))) {
      Z::$l = 0;
      return f_Desugar__wrapper__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'wrapperN'))) {
      Z::$l = 0;
      return f_Desugar__wrapperN__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'genDispatchN'))) {
      Z::$l = 0;
      return f_Desugar__genDispatchN__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'genDispatch'))) {
      Z::$l = 0;
      return f_Desugar__genDispatch__w($v_o, $v_args);
    }
  }
  Z::$l = 0;
  if (z_truthy(($v_c === 'Linker'))) {
    Z::$l = 0;
    if (z_truthy(($v_name === 'err'))) {
      Z::$l = 0;
      return f_Linker__err__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'prefixOf'))) {
      Z::$l = 0;
      return f_Linker__prefixOf__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'dirOf'))) {
      Z::$l = 0;
      return f_Linker__dirOf__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'rw'))) {
      Z::$l = 0;
      return f_Linker__rw__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'loadModule'))) {
      Z::$l = 0;
      return f_Linker__loadModule__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'collectImports'))) {
      Z::$l = 0;
      return f_Linker__collectImports__w($v_o, $v_args);
    }
  }
  Z::$l = 0;
  if (z_truthy(($v_c === 'VarPass'))) {
    Z::$l = 0;
    if (z_truthy(($v_name === 'rw'))) {
      Z::$l = 0;
      return f_VarPass__rw__w($v_o, $v_args);
    }
  }
  Z::$l = 0;
  if (z_truthy(($v_c === 'LlEmitter'))) {
    Z::$l = 0;
    if (z_truthy(($v_name === 'r'))) {
      Z::$l = 0;
      return f_LlEmitter__r__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'newLabel'))) {
      Z::$l = 0;
      return f_LlEmitter__newLabel__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'line'))) {
      Z::$l = 0;
      return f_LlEmitter__line__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'label'))) {
      Z::$l = 0;
      return f_LlEmitter__label__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'terminate'))) {
      Z::$l = 0;
      return f_LlEmitter__terminate__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'esc'))) {
      Z::$l = 0;
      return f_LlEmitter__esc__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'cstr'))) {
      Z::$l = 0;
      return f_LlEmitter__cstr__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'strSlot'))) {
      Z::$l = 0;
      return f_LlEmitter__strSlot__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'slot'))) {
      Z::$l = 0;
      return f_LlEmitter__slot__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'ty'))) {
      Z::$l = 0;
      return f_LlEmitter__ty__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'rt'))) {
      Z::$l = 0;
      return f_LlEmitter__rt__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'vcall'))) {
      Z::$l = 0;
      return f_LlEmitter__vcall__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'mkv'))) {
      Z::$l = 0;
      return f_LlEmitter__mkv__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'nullv'))) {
      Z::$l = 0;
      return f_LlEmitter__nullv__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'truthy'))) {
      Z::$l = 0;
      return f_LlEmitter__truthy__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'boolOf'))) {
      Z::$l = 0;
      return f_LlEmitter__boolOf__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'ident'))) {
      Z::$l = 0;
      return f_LlEmitter__ident__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'load'))) {
      Z::$l = 0;
      return f_LlEmitter__load__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'store'))) {
      Z::$l = 0;
      return f_LlEmitter__store__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'storeTo'))) {
      Z::$l = 0;
      return f_LlEmitter__storeTo__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'loadFrom'))) {
      Z::$l = 0;
      return f_LlEmitter__loadFrom__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'isLval'))) {
      Z::$l = 0;
      return f_LlEmitter__isLval__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'val'))) {
      Z::$l = 0;
      return f_LlEmitter__val__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'binop'))) {
      Z::$l = 0;
      return f_LlEmitter__binop__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'quiet'))) {
      Z::$l = 0;
      return f_LlEmitter__quiet__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'keyOf'))) {
      Z::$l = 0;
      return f_LlEmitter__keyOf__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'lv'))) {
      Z::$l = 0;
      return f_LlEmitter__lv__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'newArr'))) {
      Z::$l = 0;
      return f_LlEmitter__newArr__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'vcallVoid'))) {
      Z::$l = 0;
      return f_LlEmitter__vcallVoid__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'incdec'))) {
      Z::$l = 0;
      return f_LlEmitter__incdec__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'assignop'))) {
      Z::$l = 0;
      return f_LlEmitter__assignop__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'coalesceWith'))) {
      Z::$l = 0;
      return f_LlEmitter__coalesceWith__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'assign'))) {
      Z::$l = 0;
      return f_LlEmitter__assign__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'argRegs'))) {
      Z::$l = 0;
      return f_LlEmitter__argRegs__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'call'))) {
      Z::$l = 0;
      return f_LlEmitter__call__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'doExit'))) {
      Z::$l = 0;
      return f_LlEmitter__doExit__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'builtin'))) {
      Z::$l = 0;
      return f_LlEmitter__builtin__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'expr'))) {
      Z::$l = 0;
      return f_LlEmitter__expr__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'shortCircuit'))) {
      Z::$l = 0;
      return f_LlEmitter__shortCircuit__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'ternary'))) {
      Z::$l = 0;
      return f_LlEmitter__ternary__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'setLine'))) {
      Z::$l = 0;
      return f_LlEmitter__setLine__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'block'))) {
      Z::$l = 0;
      return f_LlEmitter__block__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'regionBegin'))) {
      Z::$l = 0;
      return f_LlEmitter__regionBegin__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'regionEnter'))) {
      Z::$l = 0;
      return f_LlEmitter__regionEnter__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'regionExit'))) {
      Z::$l = 0;
      return f_LlEmitter__regionExit__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'regionEnd'))) {
      Z::$l = 0;
      return f_LlEmitter__regionEnd__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'pushLoop'))) {
      Z::$l = 0;
      return f_LlEmitter__pushLoop__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'popLoop'))) {
      Z::$l = 0;
      return f_LlEmitter__popLoop__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'jumpOut'))) {
      Z::$l = 0;
      return f_LlEmitter__jumpOut__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'catchCond'))) {
      Z::$l = 0;
      return f_LlEmitter__catchCond__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'handler'))) {
      Z::$l = 0;
      return f_LlEmitter__handler__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'jb'))) {
      Z::$l = 0;
      return f_LlEmitter__jb__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'tryCatch'))) {
      Z::$l = 0;
      return f_LlEmitter__tryCatch__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'tryStmt'))) {
      Z::$l = 0;
      return f_LlEmitter__tryStmt__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'chkType'))) {
      Z::$l = 0;
      return f_LlEmitter__chkType__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'stmt'))) {
      Z::$l = 0;
      return f_LlEmitter__stmt__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'emptyStr'))) {
      Z::$l = 0;
      return f_LlEmitter__emptyStr__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'beginFunc'))) {
      Z::$l = 0;
      return f_LlEmitter__beginFunc__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'initLocals'))) {
      Z::$l = 0;
      return f_LlEmitter__initLocals__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'finishFunc'))) {
      Z::$l = 0;
      return f_LlEmitter__finishFunc__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'funcDef'))) {
      Z::$l = 0;
      return f_LlEmitter__funcDef__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'generate'))) {
      Z::$l = 0;
      return f_LlEmitter__generate__w($v_o, $v_args);
    }
    Z::$l = 0;
    if (z_truthy(($v_name === 'decls'))) {
      Z::$l = 0;
      return f_LlEmitter__decls__w($v_o, $v_args);
    }
  }
  Z::$l = 0;
  if (z_truthy(($v_c === 'Exception'))) {
    Z::$l = 0;
    if (z_truthy(($v_name === 'getMessage'))) {
      Z::$l = 0;
      return f_Exception__getMessage__w($v_o, $v_args);
    }
  }
  Z::$l = 0;
  if (z_truthy(($v_c === 'Error'))) {
    Z::$l = 0;
    if (z_truthy(($v_name === 'getMessage'))) {
      Z::$l = 0;
      return f_Exception__getMessage__w($v_o, $v_args);
    }
  }
  Z::$l = 0;
  return z_b_zs_no_method($v_o, $v_name);
  return null;
}
function f_zs_isa($v_o, $v_k) {
  $v_c = null;
  $v_t = null;
  Z::$l = 0;
  ($v_c = z_b_zs_obj_class($v_o));
  Z::$l = 0;
  if (z_truthy(($v_c === null))) {
    Z::$l = 0;
    ($v_t = z_b_typeof($v_o));
    Z::$l = 0;
    return (z_truthy(($v_t === $v_k)) || z_truthy((z_truthy((z_truthy(($v_k === 'Exception')) && z_truthy(($v_t === 'Error')))) || z_truthy((z_truthy(($v_k === 'Throwable')) && z_truthy((z_truthy(($v_t === 'Exception')) || z_truthy(($v_t === 'Error')))))))));
  }
  Z::$l = 0;
  if (z_truthy(($v_c === 'LexError'))) {
    Z::$l = 0;
    return (z_truthy((z_truthy(($v_k === 'LexError')) || z_truthy(($v_k === 'Exception')))) || z_truthy(($v_k === 'Throwable')));
  }
  Z::$l = 0;
  if (z_truthy(($v_c === 'LexTables'))) {
    Z::$l = 0;
    return ($v_k === 'LexTables');
  }
  Z::$l = 0;
  if (z_truthy(($v_c === 'Lexer'))) {
    Z::$l = 0;
    return ($v_k === 'Lexer');
  }
  Z::$l = 0;
  if (z_truthy(($v_c === 'ParseError'))) {
    Z::$l = 0;
    return (z_truthy((z_truthy(($v_k === 'ParseError')) || z_truthy(($v_k === 'Exception')))) || z_truthy(($v_k === 'Throwable')));
  }
  Z::$l = 0;
  if (z_truthy(($v_c === 'Tables'))) {
    Z::$l = 0;
    return ($v_k === 'Tables');
  }
  Z::$l = 0;
  if (z_truthy(($v_c === 'Parser'))) {
    Z::$l = 0;
    return ($v_k === 'Parser');
  }
  Z::$l = 0;
  if (z_truthy(($v_c === 'ZbcTables'))) {
    Z::$l = 0;
    return ($v_k === 'ZbcTables');
  }
  Z::$l = 0;
  if (z_truthy(($v_c === 'Bundler'))) {
    Z::$l = 0;
    return ($v_k === 'Bundler');
  }
  Z::$l = 0;
  if (z_truthy(($v_c === 'SemaTables'))) {
    Z::$l = 0;
    return ($v_k === 'SemaTables');
  }
  Z::$l = 0;
  if (z_truthy(($v_c === 'SemaScope'))) {
    Z::$l = 0;
    return ($v_k === 'SemaScope');
  }
  Z::$l = 0;
  if (z_truthy(($v_c === 'Analyzer'))) {
    Z::$l = 0;
    return ($v_k === 'Analyzer');
  }
  Z::$l = 0;
  if (z_truthy(($v_c === 'IrTables'))) {
    Z::$l = 0;
    return ($v_k === 'IrTables');
  }
  Z::$l = 0;
  if (z_truthy(($v_c === 'Lowerer'))) {
    Z::$l = 0;
    return ($v_k === 'Lowerer');
  }
  Z::$l = 0;
  if (z_truthy(($v_c === 'Lifter'))) {
    Z::$l = 0;
    return ($v_k === 'Lifter');
  }
  Z::$l = 0;
  if (z_truthy(($v_c === 'Cls'))) {
    Z::$l = 0;
    return ($v_k === 'Cls');
  }
  Z::$l = 0;
  if (z_truthy(($v_c === 'Desugar'))) {
    Z::$l = 0;
    return ($v_k === 'Desugar');
  }
  Z::$l = 0;
  if (z_truthy(($v_c === 'Linker'))) {
    Z::$l = 0;
    return ($v_k === 'Linker');
  }
  Z::$l = 0;
  if (z_truthy(($v_c === 'VarPass'))) {
    Z::$l = 0;
    return ($v_k === 'VarPass');
  }
  Z::$l = 0;
  if (z_truthy(($v_c === 'LlEmitter'))) {
    Z::$l = 0;
    return ($v_k === 'LlEmitter');
  }
  Z::$l = 0;
  if (z_truthy(($v_c === 'Exception'))) {
    Z::$l = 0;
    return (z_truthy(($v_k === 'Exception')) || z_truthy(($v_k === 'Throwable')));
  }
  Z::$l = 0;
  if (z_truthy(($v_c === 'Error'))) {
    Z::$l = 0;
    return (z_truthy((z_truthy(($v_k === 'Error')) || z_truthy(($v_k === 'Exception')))) || z_truthy(($v_k === 'Throwable')));
  }
  Z::$l = 0;
  return false;
  return null;
}
function f_Workspace_lexer__tokenize($v_src, $v_keep) {
  $v_lx = null;
  Z::$l = 252;
  ($v_lx = f_Lexer__new($v_src, $v_keep));
  Z::$l = 253;
  return f_zs_invoke($v_lx, 'run', []);
  return null;
}
function f_Workspace_parser__node($v_kind, $v_line, $v_rest) {
  $v_a = null;
  $v_x = null;
  Z::$l = 41;
  ($v_a = [z_concat(':', $v_kind), $v_line]);
  Z::$l = 42;
  foreach (z_foreach($v_rest) as $_k212 => $_v212) {
    $v_x = $_v212;
    Z::$l = 42;
    z_apush($v_a, $v_x);
  }
  Z::$l = 43;
  return $v_a;
  return null;
}
function f_Workspace_parser__isNode($v_v) {
  Z::$l = 47;
  return (z_truthy((z_truthy((z_truthy(z_b_is_array($v_v)) && z_truthy((z_cmp(z_b_count($v_v), 1) > 0)))) && z_truthy(z_b_is_string(z_index($v_v, 0))))) && z_truthy(z_b_starts_with(z_index($v_v, 0), ':')));
  return null;
}
function f_Workspace_parser__isNamePath($v_e) {
  Z::$l = 51;
  if (z_truthy((z_index($v_e, 0) === ':Name'))) {
    Z::$l = 51;
    return true;
  }
  Z::$l = 52;
  if (z_truthy((z_index($v_e, 0) === ':Dot'))) {
    Z::$l = 52;
    return f_Workspace_parser__isNamePath(z_index($v_e, 2));
  }
  Z::$l = 53;
  return false;
  return null;
}
function f_Workspace_parser__parse($v_src) {
  $v_all = null;
  $v_toks = null;
  $v_t = null;
  $v_p = null;
  $v_out = null;
  Z::$l = 614;
  ($v_all = f_Workspace_lexer__tokenize($v_src, false));
  Z::$l = 615;
  ($v_toks = []);
  Z::$l = 616;
  foreach (z_foreach($v_all) as $_k213 => $_v213) {
    $v_t = $_v213;
    Z::$l = 617;
    if (z_truthy((z_truthy((z_index($v_t, 'kind') !== 'shebang')) && z_truthy((z_index($v_t, 'kind') !== 'doc'))))) {
      Z::$l = 617;
      z_apush($v_toks, $v_t);
    }
  }
  Z::$l = 619;
  ($v_p = f_Parser__new($v_toks));
  Z::$l = 620;
  ($v_out = []);
  while (true) {
    Z::$l = 621;
    if (!z_truthy(!z_truthy(f_zs_invoke($v_p, 'atEof', [])))) break;
    Z::$l = 621;
    z_apush($v_out, f_zs_invoke($v_p, 'stmt', []));
  }
  Z::$l = 622;
  return $v_out;
  return null;
}
function f_Workspace_parser__escapeStr($v_s) {
  Z::$l = 626;
  ($v_s = z_b_replace($v_s, '\\', '\\\\'));
  Z::$l = 627;
  ($v_s = z_b_replace($v_s, '"', '\\"'));
  Z::$l = 628;
  ($v_s = z_b_replace($v_s, '
', '\\n'));
  Z::$l = 629;
  ($v_s = z_b_replace($v_s, '	', '\\t'));
  Z::$l = 630;
  ($v_s = z_b_replace($v_s, '', '\\r'));
  Z::$l = 631;
  return z_concat(z_concat('"', $v_s), '"');
  return null;
}
function f_Workspace_parser__dump($v_v) {
  $v_s = null;
  $v_i = null;
  $v_parts = null;
  $v_x = null;
  Z::$l = 638;
  if (z_truthy(($v_v === null))) {
    Z::$l = 638;
    return '_';
  }
  Z::$l = 639;
  if (z_truthy(z_b_is_bool($v_v))) {
    Z::$l = 639;
    return (z_truthy($v_v) ? 'true' : 'false');
  }
  Z::$l = 640;
  if (z_truthy(z_b_is_int($v_v))) {
    Z::$l = 640;
    return z_concat('', $v_v);
  }
  Z::$l = 641;
  if (z_truthy(z_b_is_float($v_v))) {
    Z::$l = 641;
    return z_concat('', $v_v);
  }
  Z::$l = 642;
  if (z_truthy(z_b_is_string($v_v))) {
    Z::$l = 642;
    return f_Workspace_parser__escapeStr($v_v);
  }
  Z::$l = 643;
  if (z_truthy(f_Workspace_parser__isNode($v_v))) {
    Z::$l = 644;
    ($v_s = z_concat(z_concat(z_concat('(', z_b_substr(z_index($v_v, 0), 1)), '@'), z_index($v_v, 1)));
    Z::$l = 645;
    ($v_i = 2);
    for (; z_truthy((z_cmp($v_i, z_b_count($v_v)) < 0)); z_last($_t48 = $v_i, $v_i = z_add($_t48, 1), $_t48)) {
      Z::$l = 645;
      ($v_s = z_concat(z_concat($v_s, ' '), f_Workspace_parser__dump(z_index($v_v, $v_i))));
    }
    Z::$l = 646;
    return z_concat($v_s, ')');
  }
  Z::$l = 648;
  ($v_parts = []);
  Z::$l = 649;
  foreach (z_foreach($v_v) as $_k216 => $_v216) {
    $v_x = $_v216;
    Z::$l = 649;
    z_apush($v_parts, f_Workspace_parser__dump($v_x));
  }
  Z::$l = 650;
  return z_concat(z_concat('[', z_b_join($v_parts, ' ')), ']');
  return null;
}
function f_Workspace_zbc__bundle($v_entryFile) {
  $v_b = null;
  $v_ast = null;
  $v_lines = null;
  $v_key = null;
  $v_stmts = null;
  $v_s = null;
  Z::$l = 45;
  ($v_b = f_Bundler__new());
  Z::$l = 46;
  ($v_ast = f_Workspace_parser__parse(z_m_File_read($v_entryFile)));
  Z::$l = 47;
  f_zs_invoke($v_b, 'scan', [$v_ast, z_m_System_dirname($v_entryFile)]);
  Z::$l = 48;
  ($v_lines = ['ZBC 1']);
  Z::$l = 49;
  foreach (z_foreach(z_b_zs_obj_get($v_b, 'mods')) as $_k217 => $_v217) {
    $v_stmts = $_v217;
    $v_key = $_k217;
    Z::$l = 50;
    z_apush($v_lines, z_concat('@@module ', $v_key));
    Z::$l = 51;
    foreach (z_foreach($v_stmts) as $_k218 => $_v218) {
      $v_s = $_v218;
      Z::$l = 51;
      z_apush($v_lines, f_Workspace_parser__dump($v_s));
    }
  }
  Z::$l = 53;
  z_apush($v_lines, '@@entry');
  Z::$l = 54;
  foreach (z_foreach($v_ast) as $_k219 => $_v219) {
    $v_s = $_v219;
    Z::$l = 54;
    z_apush($v_lines, f_Workspace_parser__dump($v_s));
  }
  Z::$l = 55;
  z_apush($v_lines, '');
  Z::$l = 56;
  return z_b_join($v_lines, '
');
  return null;
}
function f_Workspace_sema__analyze($v_stmts) {
  $v_an = null;
  $v_sc = null;
  Z::$l = 264;
  ($v_an = f_Analyzer__new());
  Z::$l = 265;
  ($v_sc = f_SemaScope__new('{main}', 1, false));
  Z::$l = 266;
  f_zs_invoke($v_an, 'visitAny', [$v_stmts, $v_sc, '']);
  Z::$l = 267;
  f_zs_invoke($v_an, 'finish', [$v_sc, false]);
  Z::$l = 268;
  return [z_k('warnings') => z_b_zs_obj_get($v_an, 'warnings'), z_k('functions') => z_b_zs_obj_get($v_an, 'functions')];
  return null;
}
function f_Workspace_sema__report($v_r) {
  $v_out = null;
  $v_w = null;
  $v_f = null;
  $v_s = null;
  Z::$l = 275;
  ($v_out = []);
  Z::$l = 276;
  foreach (z_foreach(z_index($v_r, 'warnings')) as $_k220 => $_v220) {
    $v_w = $_v220;
    Z::$l = 276;
    z_apush($v_out, z_concat(z_concat(z_concat('warn ', z_index($v_w, 0)), ': '), z_index($v_w, 1)));
  }
  Z::$l = 277;
  foreach (z_foreach(z_index($v_r, 'functions')) as $_k221 => $_v221) {
    $v_f = $_v221;
    Z::$l = 278;
    if (z_truthy((z_b_count(z_index($v_f, 'sites')) === 0))) {
      continue 1;
    }
    Z::$l = 279;
    z_apush($v_out, z_concat(z_concat(z_concat('fn ', z_index($v_f, 'name')), ' @'), z_index($v_f, 'line')));
    Z::$l = 280;
    foreach (z_foreach(z_index($v_f, 'sites')) as $_k222 => $_v222) {
      $v_s = $_v222;
      Z::$l = 281;
      z_apush($v_out, z_concat(z_concat(z_concat(z_concat(z_concat(z_concat(z_concat(z_concat(z_concat('  ', z_index($v_s, 'line')), ': $'), z_index($v_s, 'var')), ' = '), z_index($v_s, 'kind')), ' -> Escape::'), z_index($v_s, 'escape')), ' => '), z_index($v_s, 'zamm')));
    }
  }
  Z::$l = 284;
  return z_b_join($v_out, '
');
  return null;
}
function f_Workspace_ir__lower($v_ast) {
  $v_lw = null;
  $v_top = null;
  $v_s = null;
  $v_f = null;
  $v_name = null;
  $v___r198 = null;
  $v___w199 = null;
  $v_p = null;
  $v___r200 = null;
  $v___w201 = null;
  $v___k202 = null;
  $v___r203 = null;
  $v___w204 = null;
  $v___r205 = null;
  $v___w206 = null;
  $v_k = null;
  $v_path = null;
  $v___r207 = null;
  $v___w208 = null;
  $v_loc = null;
  $v___k209 = null;
  $v___r210 = null;
  $v___w211 = null;
  $v_toploc = null;
  $v_callsMain = null;
  Z::$l = 279;
  ($v_lw = f_Lowerer__new());
  Z::$l = 280;
  ($v_top = []);
  Z::$l = 282;
  foreach (z_foreach($v_ast) as $_k223 => $_v223) {
    $v_s = $_v223;
    Z::$l = 283;
    if (z_truthy((z_index($v_s, 0) === ':FuncStmt'))) {
      Z::$l = 284;
      ($v_f = z_index($v_s, 2));
      Z::$l = 285;
      ($v_name = z_index($v_f, 2));
      Z::$l = 286;
      if (z_truthy(z_b_has_key(z_b_zs_obj_get($v_lw, 'funcs'), $v_name))) {
        Z::$l = 286;
        ($v___r198 = [z_index($v_s, 1), 'E0101', z_concat(z_concat('funkcja ', $v_name), ' zdefiniowana wielokrotnie')]);
        Z::$l = 286;
        ($v___w199 = z_b_zs_obj_take($v_lw, 'errors'));
        Z::$l = 286;
        z_apush($v___w199, $v___r198);
        Z::$l = 286;
        z_b_zs_obj_put($v_lw, 'errors', $v___w199);
        continue 1;
      }
      Z::$l = 287;
      foreach (z_foreach(z_index($v_f, 3)) as $_k224 => $_v224) {
        $v_p = $_v224;
        Z::$l = 288;
        if (z_truthy(z_index($v_p, 5))) {
          Z::$l = 288;
          ($v___r200 = [z_index($v_s, 1), 'E0104', 'parametry variadic (...) niedostępne w backendzie natywnym 0.0.1']);
          Z::$l = 288;
          ($v___w201 = z_b_zs_obj_take($v_lw, 'errors'));
          Z::$l = 288;
          z_apush($v___w201, $v___r200);
          Z::$l = 288;
          z_b_zs_obj_put($v_lw, 'errors', $v___w201);
        }
      }
      Z::$l = 290;
      ($v___k202 = $v_name);
      Z::$l = 290;
      ($v___r203 = [z_k('name') => $v_name, z_k('line') => z_index($v_s, 1), z_k('params') => z_index($v_f, 3), z_k('ret') => z_index($v_f, 4), z_k('body') => z_index($v_f, 5), z_k('locals') => [], z_k('has_try') => false]);
      Z::$l = 290;
      ($v___w204 = z_b_zs_obj_take($v_lw, 'funcs'));
      Z::$l = 290;
      z_aset($v___w204, $v___k202, $v___r203);
      Z::$l = 290;
      z_b_zs_obj_put($v_lw, 'funcs', $v___w204);
      Z::$l = 291;
      ($v___r205 = $v_name);
      Z::$l = 291;
      ($v___w206 = z_b_zs_obj_take($v_lw, 'order'));
      Z::$l = 291;
      z_apush($v___w206, $v___r205);
      Z::$l = 291;
      z_b_zs_obj_put($v_lw, 'order', $v___w206);
    }
  }
  Z::$l = 295;
  foreach (z_foreach($v_ast) as $_k225 => $_v225) {
    $v_s = $_v225;
    Z::$l = 296;
    ($v_k = z_index($v_s, 0));
    Z::$l = 297;
    if (z_truthy((z_truthy(($v_k === ':FuncStmt')) || z_truthy(($v_k === ':Namespace'))))) {
      continue 1;
    }
    Z::$l = 298;
    if (z_truthy(($v_k === ':Import'))) {
      Z::$l = 299;
      ($v_path = z_index($v_s, 2));
      Z::$l = 300;
      if (z_truthy(!z_truthy(z_b_in_array(z_index($v_path, 0), ['System', 'Math', 'File', 'Directory', 'Process'])))) {
        Z::$l = 301;
        ($v___r207 = [z_index($v_s, 1), 'E0106', z_concat(z_concat('import ', z_b_join($v_path, '.')), ': moduły Z# nie są jeszcze obsługiwane w backendzie natywnym 0.0.1 (użyj `zsc build --emit zbc`)')]);
        Z::$l = 301;
        ($v___w208 = z_b_zs_obj_take($v_lw, 'errors'));
        Z::$l = 301;
        z_apush($v___w208, $v___r207);
        Z::$l = 301;
        z_b_zs_obj_put($v_lw, 'errors', $v___w208);
      }
      continue 1;
    }
    Z::$l = 305;
    z_apush($v_top, $v_s);
  }
  Z::$l = 307;
  foreach (z_foreach(z_b_zs_obj_get($v_lw, 'order')) as $_k226 => $_v226) {
    $v_name = $_v226;
    Z::$l = 308;
    ($v_f = z_index(z_b_zs_obj_get($v_lw, 'funcs'), $v_name));
    Z::$l = 309;
    f_zs_invoke($v_lw, 'checkStmts', [z_index($v_f, 'body'), 0]);
    Z::$l = 310;
    ($v_loc = []);
    Z::$l = 311;
    foreach (z_foreach(z_index($v_f, 'params')) as $_k227 => $_v227) {
      $v_p = $_v227;
      Z::$l = 311;
      ($v_loc = f_zs_invoke($v_lw, 'addLocal', [$v_loc, z_index($v_p, 2)]));
    }
    Z::$l = 312;
    ($v_loc = f_zs_invoke($v_lw, 'collectAny', [z_index($v_f, 'body'), $v_loc]));
    Z::$l = 313;
    z_aset($v_f, 'locals', $v_loc);
    Z::$l = 314;
    z_aset($v_f, 'has_try', f_zs_invoke($v_lw, 'containsTry', [z_index($v_f, 'body')]));
    Z::$l = 315;
    ($v___k209 = $v_name);
    Z::$l = 315;
    ($v___r210 = $v_f);
    Z::$l = 315;
    ($v___w211 = z_b_zs_obj_take($v_lw, 'funcs'));
    Z::$l = 315;
    z_aset($v___w211, $v___k209, $v___r210);
    Z::$l = 315;
    z_b_zs_obj_put($v_lw, 'funcs', $v___w211);
  }
  Z::$l = 317;
  f_zs_invoke($v_lw, 'checkStmts', [$v_top, 0]);
  Z::$l = 318;
  ($v_toploc = f_zs_invoke($v_lw, 'collectAny', [$v_top, []]));
  Z::$l = 319;
  ($v_callsMain = false);
  Z::$l = 320;
  foreach (z_foreach($v_top) as $_k228 => $_v228) {
    $v_s = $_v228;
    Z::$l = 320;
    if (z_truthy(f_zs_invoke($v_lw, 'topCallsMain', [$v_s]))) {
      Z::$l = 320;
      ($v_callsMain = true);
    }
  }
  Z::$l = 321;
  return [z_k('funcs') => z_b_zs_obj_get($v_lw, 'funcs'), z_k('order') => z_b_zs_obj_get($v_lw, 'order'), z_k('top') => $v_top, z_k('top_has_try') => f_zs_invoke($v_lw, 'containsTry', [$v_top]), z_k('toplocals') => $v_toploc, z_k('calls_main') => $v_callsMain, z_k('errors') => z_b_zs_obj_get($v_lw, 'errors')];
  return null;
}
function f_Workspace_ir__report($v_ir) {
  $v_out = null;
  $v_name = null;
  $v_f = null;
  $v_ps = null;
  $v_p = null;
  Z::$l = 328;
  ($v_out = []);
  Z::$l = 329;
  foreach (z_foreach(z_index($v_ir, 'order')) as $_k229 => $_v229) {
    $v_name = $_v229;
    Z::$l = 330;
    ($v_f = z_index(z_index($v_ir, 'funcs'), $v_name));
    Z::$l = 331;
    ($v_ps = []);
    Z::$l = 332;
    foreach (z_foreach(z_index($v_f, 'params')) as $_k230 => $_v230) {
      $v_p = $_v230;
      Z::$l = 332;
      z_apush($v_ps, z_concat(z_concat(z_concat('$', z_index($v_p, 2)), (z_truthy((z_cmp(z_b_count(z_index($v_p, 3)), 0) > 0)) ? z_concat(':', z_b_join(z_index($v_p, 3), '|')) : '')), (z_truthy((z_index($v_p, 4) !== null)) ? '=…' : '')));
    }
    Z::$l = 333;
    z_apush($v_out, z_concat(z_concat(z_concat(z_concat(z_concat(z_concat(z_concat('fn ', $v_name), '('), z_b_join($v_ps, ', ')), ')'), (z_truthy((z_cmp(z_b_count(z_index($v_f, 'ret')), 0) > 0)) ? z_concat(': ', z_b_join(z_index($v_f, 'ret'), '|')) : '')), ' @'), z_index($v_f, 'line')));
    Z::$l = 334;
    z_apush($v_out, z_concat('  locals: ', z_b_join(z_index($v_f, 'locals'), ', ')));
    Z::$l = 335;
    z_apush($v_out, z_concat('  stmts: ', z_b_count(z_index($v_f, 'body'))));
  }
  Z::$l = 337;
  z_apush($v_out, z_concat(z_concat(z_concat('top: ', z_b_count(z_index($v_ir, 'top'))), ' instrukcji, locals: '), z_b_join(z_index($v_ir, 'toplocals'), ', ')));
  Z::$l = 338;
  z_apush($v_out, z_concat('main: ', (z_truthy(z_b_has_key(z_index($v_ir, 'funcs'), 'main')) ? (z_truthy(z_index($v_ir, 'calls_main')) ? 'wywołane jawnie' : 'wywoływane automatycznie') : 'brak')));
  Z::$l = 339;
  return z_b_join($v_out, '
');
  return null;
}
function f_Workspace_cli__parse($v_args, $v_valueOpts) {
  $v_positional = null;
  $v_flags = null;
  $v_options = null;
  $v_i = null;
  $v_n = null;
  $v_rest = null;
  $v_a = null;
  $v_body = null;
  $v_eq = null;
  $v_name = null;
  Z::$l = 8;
  ($v_positional = []);
  Z::$l = 9;
  ($v_flags = []);
  Z::$l = 10;
  ($v_options = []);
  Z::$l = 11;
  ($v_i = 1);
  Z::$l = 12;
  ($v_n = z_b_count($v_args));
  Z::$l = 13;
  ($v_rest = false);
  while (true) {
    Z::$l = 14;
    if (!z_truthy((z_cmp($v_i, $v_n) < 0))) break;
    Z::$l = 15;
    ($v_a = z_index($v_args, $v_i));
    Z::$l = 16;
    if (z_truthy((z_truthy((z_truthy($v_rest) || z_truthy(!z_truthy(z_b_starts_with($v_a, '-'))))) || z_truthy(($v_a === '-'))))) {
      Z::$l = 17;
      z_apush($v_positional, $v_a);
    } else {
      Z::$l = 18;
      if (z_truthy(($v_a === '--'))) {
        Z::$l = 19;
        ($v_rest = true);
      } else {
        Z::$l = 20;
        if (z_truthy(z_b_starts_with($v_a, '--'))) {
          Z::$l = 21;
          ($v_body = z_b_substr($v_a, 2));
          Z::$l = 22;
          ($v_eq = z_b_index_of($v_body, '='));
          Z::$l = 23;
          if (z_truthy((z_cmp($v_eq, 0) >= 0))) {
            Z::$l = 23;
            z_aset($v_options, z_b_substr($v_body, 0, $v_eq), z_b_substr($v_body, z_add($v_eq, 1)));
          } else {
            Z::$l = 24;
            if (z_truthy((z_truthy(z_b_in_array($v_body, $v_valueOpts)) && z_truthy((z_cmp(z_add($v_i, 1), $v_n) < 0))))) {
              Z::$l = 24;
              z_last($_t49 = $v_i, $v_i = z_add($_t49, 1), $_t49);
              Z::$l = 24;
              z_aset($v_options, $v_body, z_index($v_args, $v_i));
            } else {
              Z::$l = 25;
              z_aset($v_flags, $v_a, true);
            }
          }
        } else {
          Z::$l = 27;
          ($v_name = z_b_substr($v_a, 1));
          Z::$l = 28;
          if (z_truthy((z_truthy(z_b_in_array($v_name, $v_valueOpts)) && z_truthy((z_cmp(z_add($v_i, 1), $v_n) < 0))))) {
            Z::$l = 28;
            z_last($_t50 = $v_i, $v_i = z_add($_t50, 1), $_t50);
            Z::$l = 28;
            z_aset($v_options, $v_name, z_index($v_args, $v_i));
          } else {
            Z::$l = 29;
            z_aset($v_flags, $v_a, true);
          }
        }
      }
    }
    Z::$l = 31;
    z_last($_t51 = $v_i, $v_i = z_add($_t51, 1), $_t51);
  }
  Z::$l = 33;
  return [z_k('positional') => $v_positional, z_k('flags') => $v_flags, z_k('options') => $v_options];
  return null;
}
function f_pipeline__stages() {
  Z::$l = 4;
  return [[z_k('name') => 'lexer', z_k('status') => 'done', z_k('impl') => 'Workspace.lexer (Z#, parytet z Rust)'], [z_k('name') => 'parser + AST', z_k('status') => 'done', z_k('impl') => 'Workspace.parser (Z#, parytet z Rust: scripts/tests/parser_parity.zsharp)'], [z_k('name') => 'semantic analysis', z_k('status') => 'done', z_k('impl') => 'Workspace.sema (zmienne + analiza ucieczki -> klasy ZAMM)'], [z_k('name') => 'zbc packer', z_k('status') => 'done', z_k('impl') => 'Workspace.zbc (.zbc = AST bez źródeł; zsc0 exec / zsi)'], [z_k('name') => 'Z# IR', z_k('status') => 'done', z_k('impl') => 'Workspace.ir (strukturalne IR, walidacja, lokalne; SSA: todo)'], [z_k('name') => 'ZAMM runtime', z_k('status') => 'done', z_k('impl') => 'Z-Sharp/zamm + runtime (Z# = definicja); natywnie: runtime/native/zs_rt.c (C, bez Rusta)'], [z_k('name') => 'ZAMM lowering', z_k('status') => 'todo', z_k('impl') => '- (wyniki analizy ucieczki -> ramki; natywnie: czas życia Persistent)'], [z_k('name') => 'C backend', z_k('status') => 'done', z_k('impl') => 'Workspace.emit_c (podzbiór: funkcje, tablice indeksowane, napisy, pętle, switch)'], [z_k('name') => 'linker + runtime', z_k('status') => 'done', z_k('impl') => 'cc/clang + runtime/native/zs_rt.c'], [z_k('name') => 'LLVM backend', z_k('status') => 'done', z_k('impl') => 'Workspace.emit_llvm (podzbiór natywny; .ll + clang; --target <triple>)'], [z_k('name') => 'native classes', z_k('status') => 'todo', z_k('impl') => 'klasy, domknięcia, importy w backendach natywnych (warunek samokompilacji natywnej)'], [z_k('name') => 'extern linking', z_k('status') => 'todo', z_k('impl') => 'składnia sparsowana w stage0; linkowanie w zsc']];
  return null;
}
function f_llvmtool__MIN_MAJOR() {
  Z::$l = 12;
  return 21;
  return null;
}
function f_llvmtool__MIN_MAJOR_LEGACY() {
  Z::$l = 13;
  return 17;
  return null;
}
function f_llvmtool__parse_major($v_text) {
  $v_i = null;
  $v_j = null;
  $v_n = null;
  Z::$l = 16;
  ($v_i = z_b_index_of($v_text, 'version '));
  Z::$l = 17;
  if (z_truthy((z_cmp($v_i, 0) < 0))) {
    Z::$l = 17;
    return 0;
  }
  Z::$l = 18;
  ($v_j = z_add($v_i, 8));
  Z::$l = 19;
  ($v_n = '');
  while (true) {
    Z::$l = 20;
    if (!z_truthy((z_truthy((z_cmp($v_j, z_b_strlen($v_text)) < 0)) && z_truthy(z_b_is_digit(z_b_substr($v_text, $v_j, 1)))))) break;
    Z::$l = 20;
    ($v_n = z_concat($v_n, z_b_substr($v_text, $v_j, 1)));
    Z::$l = 20;
    z_last($_t52 = $v_j, $v_j = z_add($_t52, 1), $_t52);
  }
  Z::$l = 21;
  return (z_truthy(($v_n === '')) ? 0 : z_b_intval($v_n));
  return null;
}
function f_llvmtool__first_line($v_text) {
  $v_p = null;
  $v_l = null;
  Z::$l = 25;
  ($v_p = z_b_split($v_text, '
'));
  Z::$l = 26;
  foreach (z_foreach($v_p) as $_k233 => $_v233) {
    $v_l = $_v233;
    Z::$l = 26;
    if (z_truthy(z_b_contains($v_l, 'version '))) {
      Z::$l = 26;
      return z_b_trim($v_l);
    }
  }
  Z::$l = 27;
  return (z_truthy((z_cmp(z_b_count($v_p), 0) > 0)) ? z_b_trim(z_index($v_p, 0)) : '');
  return null;
}
function f_llvmtool__probe($v_cmd) {
  $v_r = null;
  $v_t = null;
  $v___ex212 = null;
  $v_e = null;
  try {
    Z::$l = 32;
    ($v_r = z_m_Process_run($v_cmd, ['--version']));
    Z::$l = 33;
    if (z_truthy((z_index($v_r, 'status') !== 0))) {
      Z::$l = 33;
      return null;
    }
    Z::$l = 34;
    ($v_t = z_concat(z_index($v_r, 'stdout'), z_index($v_r, 'stderr')));
    Z::$l = 35;
    return [z_k('cmd') => $v_cmd, z_k('major') => f_llvmtool__parse_major($v_t), z_k('line') => f_llvmtool__first_line($v_t)];
  } catch (ZEx $_ex234) {
    $_e234 = $_ex234->val;
    if (true) {
      $v___ex212 = $_e234;
      Z::$l = 31;
      if (z_truthy(f_zs_isa($v___ex212, 'Exception'))) {
        Z::$l = 31;
        ($v_e = $v___ex212);
        Z::$l = 37;
        return null;
      } else {
        Z::$l = 31;
        z_throwv($v___ex212);
      }
    }
    else throw $_ex234;
  }
  return null;
}
function f_llvmtool__candidates($v_name, $v_binDir) {
  $v_c = null;
  $v_d = null;
  Z::$l = 42;
  ($v_c = []);
  Z::$l = 43;
  if (z_truthy((z_truthy(($v_binDir !== null)) && z_truthy(($v_binDir !== ''))))) {
    Z::$l = 44;
    z_apush($v_c, z_concat(z_concat(z_concat(z_concat($v_binDir, '/'), $v_name), '-'), f_llvmtool__MIN_MAJOR()));
    Z::$l = 45;
    z_apush($v_c, z_concat(z_concat($v_binDir, '/'), $v_name));
  }
  Z::$l = 47;
  z_apush($v_c, z_concat(z_concat($v_name, '-'), f_llvmtool__MIN_MAJOR()));
  Z::$l = 48;
  z_apush($v_c, $v_name);
  Z::$l = 49;
  foreach (z_foreach([z_concat(z_concat('/usr/lib/llvm-', f_llvmtool__MIN_MAJOR()), '/bin/'), '/usr/local/llvm/bin/', '/opt/llvm/bin/', '/opt/homebrew/opt/llvm/bin/', '/usr/local/opt/llvm/bin/']) as $_k235 => $_v235) {
    $v_d = $_v235;
    Z::$l = 50;
    z_apush($v_c, z_concat($v_d, $v_name));
  }
  Z::$l = 52;
  return $v_c;
  return null;
}
function f_llvmtool__find_tool($v_name, $v_binDir, $v_min) {
  $v_seen = null;
  $v_best = null;
  $v_c = null;
  $v_p = null;
  Z::$l = 60;
  ($v_seen = []);
  Z::$l = 61;
  ($v_best = null);
  Z::$l = 62;
  foreach (z_foreach(f_llvmtool__candidates($v_name, $v_binDir)) as $_k236 => $_v236) {
    $v_c = $_v236;
    Z::$l = 63;
    ($v_p = f_llvmtool__probe($v_c));
    Z::$l = 64;
    if (z_truthy(($v_p === null))) {
      continue 1;
    }
    Z::$l = 65;
    z_apush($v_seen, z_concat(z_concat(z_concat(z_index($v_p, 'cmd'), ' ('), z_index($v_p, 'major')), ')'));
    Z::$l = 66;
    if (z_truthy((z_cmp(z_index($v_p, 'major'), $v_min) >= 0))) {
      Z::$l = 66;
      return [z_k('ok') => true, z_k('cmd') => z_index($v_p, 'cmd'), z_k('major') => z_index($v_p, 'major'), z_k('line') => z_index($v_p, 'line')];
    }
  }
  Z::$l = 68;
  if (z_truthy((z_b_count($v_seen) === 0))) {
    Z::$l = 69;
    return [z_k('ok') => false, z_k('err') => z_concat(z_concat(z_concat(z_concat('zsc: nie znaleziono narzędzia LLVM \'', $v_name), '\' (wymagany LLVM >= '), $v_min), '; ustaw --llvm-bin <katalog> lub ZS_LLVM_BIN)')];
  }
  Z::$l = 71;
  return [z_k('ok') => false, z_k('err') => z_concat(z_concat(z_concat(z_concat(z_concat(z_concat(z_concat(z_concat('zsc: \'', $v_name), '\' ma za starą wersję: '), z_b_join($v_seen, ', ')), ' — wymagany LLVM >= '), $v_min), ' (--allow-older-llvm / ZS_ALLOW_OLD_LLVM=1 obniża próg do '), f_llvmtool__MIN_MAJOR_LEGACY()), ' bez gwarancji)')];
  return null;
}
function f_llvmtool__allow_old($v_opts) {
  $v_e = null;
  Z::$l = 76;
  if (z_truthy(z_b_has_key(z_index($v_opts, 'flags'), '--allow-older-llvm'))) {
    Z::$l = 76;
    return true;
  }
  Z::$l = 77;
  ($v_e = z_m_System_env('ZS_ALLOW_OLD_LLVM'));
  Z::$l = 78;
  return (z_truthy((z_truthy(($v_e !== null)) && z_truthy(($v_e !== '')))) && z_truthy(($v_e !== '0')));
  return null;
}
function f_llvmtool__llvm_bin($v_opts) {
  $v_b = null;
  $v_e = null;
  Z::$l = 82;
  ($v_b = (($_t53 = z_indexopt(z_indexopt($v_opts, 'options'), 'llvm-bin')) !== null ? $_t53 : null));
  Z::$l = 83;
  if (z_truthy((z_truthy(($v_b !== null)) && z_truthy(($v_b !== ''))))) {
    Z::$l = 83;
    return $v_b;
  }
  Z::$l = 84;
  ($v_e = z_m_System_env('ZS_LLVM_BIN'));
  Z::$l = 85;
  if (z_truthy((z_truthy(($v_e !== null)) && z_truthy(($v_e !== ''))))) {
    Z::$l = 85;
    return $v_e;
  }
  Z::$l = 86;
  return null;
  return null;
}
function f_llvmtool__detect($v_opts) {
  $v_min = null;
  $v_bin = null;
  $v_tc = null;
  $v_opt = null;
  $v_llc = null;
  $v_clang = null;
  Z::$l = 94;
  ($v_min = (z_truthy(f_llvmtool__allow_old($v_opts)) ? f_llvmtool__MIN_MAJOR_LEGACY() : f_llvmtool__MIN_MAJOR()));
  Z::$l = 95;
  ($v_bin = f_llvmtool__llvm_bin($v_opts));
  Z::$l = 96;
  ($v_tc = [z_k('ok') => false, z_k('lines') => [], z_k('min') => $v_min]);
  Z::$l = 97;
  ($v_opt = f_llvmtool__find_tool('opt', $v_bin, $v_min));
  Z::$l = 98;
  if (z_truthy(!z_truthy(z_index($v_opt, 'ok')))) {
    Z::$l = 98;
    z_aset($v_tc, 'err', z_index($v_opt, 'err'));
    Z::$l = 98;
    return $v_tc;
  }
  Z::$l = 99;
  ($v_llc = f_llvmtool__find_tool('llc', $v_bin, $v_min));
  Z::$l = 100;
  if (z_truthy(!z_truthy(z_index($v_llc, 'ok')))) {
    Z::$l = 100;
    z_aset($v_tc, 'err', z_index($v_llc, 'err'));
    Z::$l = 100;
    return $v_tc;
  }
  Z::$l = 101;
  ($v_clang = f_llvmtool__find_tool('clang', $v_bin, $v_min));
  Z::$l = 102;
  z_aset($v_tc, 'opt', z_index($v_opt, 'cmd'));
  Z::$l = 103;
  z_aset($v_tc, 'llc', z_index($v_llc, 'cmd'));
  Z::$l = 104;
  z_aset($v_tc, 'clang', (z_truthy(z_index($v_clang, 'ok')) ? z_index($v_clang, 'cmd') : null));
  Z::$l = 105;
  z_aset($v_tc, 'major', z_index($v_llc, 'major'));
  Z::$l = 106;
  z_aset($v_tc, 'lines', [z_concat(z_concat(z_index($v_opt, 'cmd'), ': '), z_index($v_opt, 'line')), z_concat(z_concat(z_index($v_llc, 'cmd'), ': '), z_index($v_llc, 'line')), z_concat('clang: ', (z_truthy(z_index($v_clang, 'ok')) ? z_concat(z_concat(z_index($v_clang, 'cmd'), ': '), z_index($v_clang, 'line')) : 'brak'))]);
  Z::$l = 107;
  z_aset($v_tc, 'ok', true);
  Z::$l = 108;
  return $v_tc;
  return null;
}
function f_llvmtool__host_triple($v_tc) {
  $v_cands = null;
  $v_c = null;
  $v_r = null;
  $v___ex213 = null;
  $v_e = null;
  $v_l = null;
  $v_t = null;
  $v___ex214 = null;
  Z::$l = 112;
  ($v_cands = []);
  Z::$l = 113;
  if (z_truthy((z_index($v_tc, 'clang') !== null))) {
    Z::$l = 113;
    z_apush($v_cands, z_index($v_tc, 'clang'));
  }
  Z::$l = 114;
  foreach (z_foreach($v_cands) as $_k237 => $_v237) {
    $v_c = $_v237;
    try {
      Z::$l = 116;
      ($v_r = z_m_Process_run($v_c, ['-dumpmachine']));
      Z::$l = 117;
      if (z_truthy((z_truthy((z_index($v_r, 'status') === 0)) && z_truthy((z_b_trim(z_index($v_r, 'stdout')) !== ''))))) {
        Z::$l = 117;
        return z_b_trim(z_index($v_r, 'stdout'));
      }
    } catch (ZEx $_ex238) {
      $_e238 = $_ex238->val;
      if (true) {
        $v___ex213 = $_e238;
        Z::$l = 115;
        if (z_truthy(f_zs_isa($v___ex213, 'Exception'))) {
          Z::$l = 115;
          ($v_e = $v___ex213);
        } else {
          Z::$l = 115;
          z_throwv($v___ex213);
        }
      }
      else throw $_ex238;
    }
  }
  try {
    Z::$l = 121;
    ($v_r = z_m_Process_run(z_index($v_tc, 'llc'), ['--version']));
    Z::$l = 122;
    foreach (z_foreach(z_b_split(z_index($v_r, 'stdout'), '
')) as $_k240 => $_v240) {
      $v_l = $_v240;
      Z::$l = 123;
      ($v_t = z_b_trim($v_l));
      Z::$l = 124;
      if (z_truthy(z_b_starts_with($v_t, 'Default target:'))) {
        Z::$l = 124;
        return z_b_trim(z_b_substr($v_t, 15));
      }
    }
  } catch (ZEx $_ex239) {
    $_e239 = $_ex239->val;
    if (true) {
      $v___ex214 = $_e239;
      Z::$l = 120;
      if (z_truthy(f_zs_isa($v___ex214, 'Exception'))) {
        Z::$l = 120;
        ($v_e = $v___ex214);
      } else {
        Z::$l = 120;
        z_throwv($v___ex214);
      }
    }
    else throw $_ex239;
  }
  Z::$l = 127;
  return 'x86_64-pc-linux-gnu';
  return null;
}
function f_llvmtool__mkdirs($v_path) {
  $v_parts = null;
  $v_cur = null;
  $v_p = null;
  Z::$l = 133;
  if (z_truthy(z_m_Directory_exists($v_path))) {
    Z::$l = 133;
    return null;
  }
  Z::$l = 134;
  ($v_parts = z_b_split($v_path, '/'));
  Z::$l = 135;
  ($v_cur = (z_truthy(z_b_starts_with($v_path, '/')) ? '' : '.'));
  Z::$l = 136;
  foreach (z_foreach($v_parts) as $_k241 => $_v241) {
    $v_p = $_v241;
    Z::$l = 137;
    if (z_truthy(($v_p === ''))) {
      continue 1;
    }
    Z::$l = 138;
    ($v_cur = z_concat(z_concat($v_cur, '/'), $v_p));
    Z::$l = 139;
    if (z_truthy(!z_truthy(z_m_Directory_exists($v_cur)))) {
      Z::$l = 139;
      z_m_Directory_create($v_cur);
    }
  }
  return null;
}
function f_llvmtool__cache_dir() {
  $v_e = null;
  $v_x = null;
  $v_h = null;
  Z::$l = 144;
  ($v_e = z_m_System_env('ZS_CACHE'));
  Z::$l = 145;
  if (z_truthy((z_truthy(($v_e !== null)) && z_truthy(($v_e !== ''))))) {
    Z::$l = 145;
    return $v_e;
  }
  Z::$l = 146;
  ($v_x = z_m_System_env('XDG_CACHE_HOME'));
  Z::$l = 147;
  if (z_truthy((z_truthy(($v_x !== null)) && z_truthy(($v_x !== ''))))) {
    Z::$l = 147;
    return z_concat($v_x, '/zsc');
  }
  Z::$l = 148;
  ($v_h = z_m_System_env('HOME'));
  Z::$l = 149;
  if (z_truthy((z_truthy(($v_h !== null)) && z_truthy(($v_h !== ''))))) {
    Z::$l = 149;
    return z_concat($v_h, '/.cache/zsc');
  }
  Z::$l = 150;
  return z_concat((($_t54 = z_m_System_env('TMPDIR')) !== null ? $_t54 : '/tmp'), '/zsc-cache');
  return null;
}
function f_llvmtool__tmp_dir() {
  $v_base = null;
  $v_d = null;
  Z::$l = 154;
  ($v_base = (($_t55 = z_m_System_env('TMPDIR')) !== null ? $_t55 : '/tmp'));
  Z::$l = 155;
  ($v_d = z_concat(z_concat(z_concat(z_concat($v_base, '/zsc-'), z_m_System_pid()), '-'), z_m_System_nowNanos()));
  Z::$l = 156;
  f_llvmtool__mkdirs($v_d);
  Z::$l = 157;
  return $v_d;
  return null;
}
function f_llvmtool__sanitize($v_s) {
  $v_o = null;
  $v_c = null;
  Z::$l = 161;
  ($v_o = '');
  Z::$l = 162;
  foreach (z_foreach(z_b_chars($v_s)) as $_k242 => $_v242) {
    $v_c = $_v242;
    Z::$l = 162;
    ($v_o = z_concat($v_o, (z_truthy((z_truthy((z_truthy(z_b_is_alnum($v_c)) || z_truthy(($v_c === '.')))) || z_truthy(($v_c === '-')))) ? $v_c : '_')));
  }
  Z::$l = 163;
  return $v_o;
  return null;
}
function f_llvmtool__opt_pass($v_level) {
  Z::$l = 167;
  if (z_truthy(($v_level === '-O0'))) {
    Z::$l = 167;
    return 'default<O0>';
  }
  Z::$l = 168;
  if (z_truthy(($v_level === '-O1'))) {
    Z::$l = 168;
    return 'default<O1>';
  }
  Z::$l = 169;
  if (z_truthy(($v_level === '-O3'))) {
    Z::$l = 169;
    return 'default<O3>';
  }
  Z::$l = 170;
  if (z_truthy(($v_level === '-Os'))) {
    Z::$l = 170;
    return 'default<Os>';
  }
  Z::$l = 171;
  if (z_truthy(($v_level === '-Oz'))) {
    Z::$l = 171;
    return 'default<Oz>';
  }
  Z::$l = 172;
  return 'default<O2>';
  return null;
}
function f_llvmtool__llc_level($v_level) {
  Z::$l = 176;
  if (z_truthy(($v_level === '-O0'))) {
    Z::$l = 176;
    return '-O0';
  }
  Z::$l = 177;
  if (z_truthy(($v_level === '-O1'))) {
    Z::$l = 177;
    return '-O1';
  }
  Z::$l = 178;
  if (z_truthy(($v_level === '-O3'))) {
    Z::$l = 178;
    return '-O3';
  }
  Z::$l = 179;
  return '-O2';
  return null;
}
function f_llvmtool__run_tool($v_cmd, $v_args, $v_what) {
  $v_r = null;
  $v___ex215 = null;
  $v_e = null;
  try {
    Z::$l = 183;
    ($v_r = z_m_Process_run($v_cmd, $v_args));
  } catch (ZEx $_ex243) {
    $_e243 = $_ex243->val;
    if (true) {
      $v___ex215 = $_e243;
      Z::$l = 183;
      if (z_truthy(f_zs_isa($v___ex215, 'Exception'))) {
        Z::$l = 183;
        ($v_e = $v___ex215);
        Z::$l = 184;
        return [z_k('ok') => false, z_k('err') => z_concat(z_concat(z_concat(z_concat(z_concat('zsc: nie można uruchomić ', $v_what), ' ('), $v_cmd), '): '), f_zs_invoke($v_e, 'getMessage', []))];
      } else {
        Z::$l = 183;
        z_throwv($v___ex215);
      }
    }
    else throw $_ex243;
  }
  Z::$l = 185;
  if (z_truthy((z_index($v_r, 'status') !== 0))) {
    Z::$l = 186;
    return [z_k('ok') => false, z_k('err') => z_concat(z_concat(z_concat(z_concat(z_b_trim(z_concat(z_index($v_r, 'stderr'), z_index($v_r, 'stdout'))), '
zsc: '), $v_what), ' zakończył się kodem '), z_index($v_r, 'status'))];
  }
  Z::$l = 188;
  return [z_k('ok') => true, z_k('stdout') => z_index($v_r, 'stdout'), z_k('stderr') => z_index($v_r, 'stderr')];
  return null;
}
function f_llvmtool__optimize($v_tc, $v_ll, $v_bc, $v_level, $v_triple) {
  $v_a = null;
  Z::$l = 195;
  ($v_a = [z_concat('-passes=', f_llvmtool__opt_pass($v_level)), $v_ll, '-o', $v_bc]);
  Z::$l = 196;
  return f_llvmtool__run_tool(z_index($v_tc, 'opt'), $v_a, 'opt');
  return null;
}
function f_llvmtool__codegen($v_tc, $v_in, $v_out, $v_level, $v_triple, $v_kind, $v_triple_explicit) {
  $v_a = null;
  Z::$l = 203;
  ($v_a = [f_llvmtool__llc_level($v_level), z_concat('-filetype=', $v_kind), '-relocation-model=pic']);
  Z::$l = 204;
  if (z_truthy($v_triple_explicit)) {
    Z::$l = 204;
    z_apush($v_a, z_concat('-mtriple=', $v_triple));
  }
  Z::$l = 205;
  z_apush($v_a, $v_in);
  Z::$l = 206;
  z_apush($v_a, '-o');
  Z::$l = 207;
  z_apush($v_a, $v_out);
  Z::$l = 208;
  return f_llvmtool__run_tool(z_index($v_tc, 'llc'), $v_a, 'llc');
  return null;
}
function f_llvmtool__runtime_obj($v_tc, $v_root, $v_triple, $v_opts, $v_level) {
  $v_given = null;
  $v_src = null;
  $v_hdr = null;
  $v_ss = null;
  $v_hs = null;
  $v_cc = null;
  $v_lv = null;
  $v_key = null;
  $v_dir = null;
  $v_obj = null;
  $v___ex216 = null;
  $v_e = null;
  $v_tmp = null;
  $v_dest = null;
  $v_args = null;
  $v_r = null;
  Z::$l = 215;
  ($v_given = (($_t56 = z_indexopt(z_indexopt($v_opts, 'options'), 'runtime-obj')) !== null ? $_t56 : z_m_System_env('ZS_RUNTIME_OBJ')));
  Z::$l = 216;
  if (z_truthy((z_truthy(($v_given !== null)) && z_truthy(($v_given !== ''))))) {
    Z::$l = 217;
    if (z_truthy(!z_truthy(z_m_File_exists($v_given)))) {
      Z::$l = 217;
      return [z_k('ok') => false, z_k('err') => z_concat('zsc: brak obiektu runtime ', $v_given)];
    }
    Z::$l = 218;
    return [z_k('ok') => true, z_k('path') => $v_given];
  }
  Z::$l = 220;
  ($v_src = z_concat($v_root, '/runtime/native/zs_rt.c'));
  Z::$l = 221;
  ($v_hdr = z_concat($v_root, '/runtime/include/zs_native.h'));
  Z::$l = 222;
  if (z_truthy((z_truthy(!z_truthy(z_m_File_exists($v_src))) || z_truthy(!z_truthy(z_m_File_exists($v_hdr)))))) {
    Z::$l = 223;
    return [z_k('ok') => false, z_k('err') => z_concat(z_concat('zsc: nie znaleziono runtime (', $v_src), ') — ustaw ZS_HOME albo --runtime-obj')];
  }
  Z::$l = 225;
  ($v_ss = z_m_File_stat($v_src));
  Z::$l = 226;
  ($v_hs = z_m_File_stat($v_hdr));
  Z::$l = 227;
  ($v_cc = z_index($v_tc, 'clang'));
  Z::$l = 228;
  if (z_truthy(($v_cc === null))) {
    Z::$l = 229;
    return [z_k('ok') => false, z_k('err') => z_concat(z_concat('zsc: do zbudowania runtime potrzebny jest clang >= ', z_index($v_tc, 'min')), ' (albo gotowy obiekt: --runtime-obj)')];
  }
  Z::$l = 231;
  ($v_lv = (z_truthy(($v_level === '-O0')) ? '-O0' : '-O2'));
  Z::$l = 232;
  ($v_key = z_concat(z_concat(z_concat(z_concat(z_concat(z_concat(z_concat(z_concat(z_concat(z_concat(z_concat(z_concat(z_concat(z_concat('rt-', z_index($v_ss, 'size')), '-'), z_index($v_ss, 'mtime')), '-'), z_index($v_hs, 'size')), '-'), z_index($v_hs, 'mtime')), '-'), f_llvmtool__sanitize($v_triple)), '-'), $v_lv), '-llvm'), z_index($v_tc, 'major')), '.o'));
  Z::$l = 233;
  ($v_dir = f_llvmtool__cache_dir());
  Z::$l = 234;
  ($v_obj = z_concat(z_concat($v_dir, '/'), $v_key));
  Z::$l = 235;
  if (z_truthy(z_m_File_exists($v_obj))) {
    Z::$l = 235;
    return [z_k('ok') => true, z_k('path') => $v_obj];
  }
  try {
    Z::$l = 236;
    f_llvmtool__mkdirs($v_dir);
  } catch (ZEx $_ex244) {
    $_e244 = $_ex244->val;
    if (true) {
      $v___ex216 = $_e244;
      Z::$l = 236;
      if (z_truthy(f_zs_isa($v___ex216, 'Exception'))) {
        Z::$l = 236;
        ($v_e = $v___ex216);
      } else {
        Z::$l = 236;
        z_throwv($v___ex216);
      }
    }
    else throw $_ex244;
  }
  Z::$l = 237;
  ($v_tmp = z_concat(z_concat(z_concat($v_obj, '.'), z_m_System_pid()), '.tmp'));
  Z::$l = 238;
  ($v_dest = (z_truthy(z_m_Directory_exists($v_dir)) ? $v_tmp : z_concat(f_llvmtool__tmp_dir(), '/zs_rt.o')));
  Z::$l = 239;
  ($v_args = ['-c', $v_src, '-o', $v_dest, $v_lv, '-std=gnu11', '-w', '-fPIC', '-I', z_concat($v_root, '/runtime/include'), z_concat('--target=', $v_triple)]);
  Z::$l = 240;
  ($v_r = f_llvmtool__run_tool($v_cc, $v_args, 'clang (runtime)'));
  Z::$l = 241;
  if (z_truthy(!z_truthy(z_index($v_r, 'ok')))) {
    Z::$l = 241;
    return $v_r;
  }
  Z::$l = 242;
  if (z_truthy(($v_dest === $v_tmp))) {
    Z::$l = 242;
    z_m_File_rename($v_tmp, $v_obj);
    Z::$l = 242;
    return [z_k('ok') => true, z_k('path') => $v_obj];
  }
  Z::$l = 243;
  return [z_k('ok') => true, z_k('path') => $v_dest];
  return null;
}
function f_llvmtool__link($v_tc, $v_objs, $v_out, $v_triple, $v_triple_explicit, $v_opts) {
  $v_drivers = null;
  $v_l = null;
  $v_c = null;
  $v_last = null;
  $v_d = null;
  $v_a = null;
  $v_o = null;
  $v_extra = null;
  $v_x = null;
  $v_r = null;
  $v___ex217 = null;
  $v_e = null;
  Z::$l = 251;
  ($v_drivers = []);
  Z::$l = 252;
  ($v_l = (($_t57 = z_indexopt(z_indexopt($v_opts, 'options'), 'linker')) !== null ? $_t57 : z_m_System_env('ZS_LINKER')));
  Z::$l = 253;
  if (z_truthy((z_truthy(($v_l !== null)) && z_truthy(($v_l !== ''))))) {
    Z::$l = 253;
    z_apush($v_drivers, $v_l);
  }
  Z::$l = 254;
  if (z_truthy((z_index($v_tc, 'clang') !== null))) {
    Z::$l = 254;
    z_apush($v_drivers, z_index($v_tc, 'clang'));
  }
  Z::$l = 255;
  foreach (z_foreach(['cc', 'gcc']) as $_k245 => $_v245) {
    $v_c = $_v245;
    Z::$l = 255;
    z_apush($v_drivers, $v_c);
  }
  Z::$l = 256;
  ($v_last = '');
  Z::$l = 257;
  foreach (z_foreach($v_drivers) as $_k246 => $_v246) {
    $v_d = $_v246;
    Z::$l = 258;
    ($v_a = []);
    Z::$l = 259;
    foreach (z_foreach($v_objs) as $_k247 => $_v247) {
      $v_o = $_v247;
      Z::$l = 259;
      z_apush($v_a, $v_o);
    }
    Z::$l = 260;
    z_apush($v_a, '-o');
    Z::$l = 261;
    z_apush($v_a, $v_out);
    Z::$l = 262;
    z_apush($v_a, '-lm');
    Z::$l = 263;
    if (z_truthy((z_truthy($v_triple_explicit) && z_truthy(($v_d === z_index($v_tc, 'clang')))))) {
      Z::$l = 263;
      z_apush($v_a, z_concat('--target=', $v_triple));
    }
    Z::$l = 264;
    ($v_extra = (($_t58 = z_indexopt(z_indexopt($v_opts, 'options'), 'ldflags')) !== null ? $_t58 : null));
    Z::$l = 265;
    if (z_truthy((z_truthy(($v_extra !== null)) && z_truthy(($v_extra !== ''))))) {
      Z::$l = 265;
      foreach (z_foreach(z_b_split($v_extra, ' ')) as $_k248 => $_v248) {
        $v_x = $_v248;
        Z::$l = 265;
        if (z_truthy(($v_x !== ''))) {
          Z::$l = 265;
          z_apush($v_a, $v_x);
        }
      }
    }
    try {
      Z::$l = 266;
      ($v_r = z_m_Process_run($v_d, $v_a));
    } catch (ZEx $_ex249) {
      $_e249 = $_ex249->val;
      if (true) {
        $v___ex217 = $_e249;
        Z::$l = 266;
        if (z_truthy(f_zs_isa($v___ex217, 'Exception'))) {
          Z::$l = 266;
          ($v_e = $v___ex217);
          Z::$l = 267;
          ($v_last = f_zs_invoke($v_e, 'getMessage', []));
          continue 1;
        } else {
          Z::$l = 266;
          z_throwv($v___ex217);
        }
      }
      else throw $_ex249;
    }
    Z::$l = 268;
    if (z_truthy((z_index($v_r, 'status') === 0))) {
      Z::$l = 268;
      return [z_k('ok') => true, z_k('driver') => $v_d];
    }
    Z::$l = 269;
    ($v_last = z_b_trim(z_index($v_r, 'stderr')));
  }
  Z::$l = 271;
  return [z_k('ok') => false, z_k('err') => z_concat($v_last, '
zsc: linkowanie nie powiodło się (sterownik: --linker / ZS_LINKER)')];
  return null;
}
function f_llvmtool__cleanup($v_dir) {
  $v_f = null;
  $v___ex218 = null;
  $v_e = null;
  try {
    Z::$l = 276;
    foreach (z_foreach(z_m_Directory_list($v_dir)) as $_k251 => $_v251) {
      $v_f = $_v251;
      Z::$l = 276;
      z_m_File_delete(z_concat(z_concat($v_dir, '/'), $v_f));
    }
    Z::$l = 277;
    z_m_Directory_remove($v_dir);
  } catch (ZEx $_ex250) {
    $_e250 = $_ex250->val;
    if (true) {
      $v___ex218 = $_e250;
      Z::$l = 275;
      if (z_truthy(f_zs_isa($v___ex218, 'Exception'))) {
        Z::$l = 275;
        ($v_e = $v___ex218);
      } else {
        Z::$l = 275;
        z_throwv($v___ex218);
      }
    }
    else throw $_ex250;
  }
  return null;
}
function f_Workspace_closures__nm($v_line, $v_n) {
  Z::$l = 18;
  return [':Name', $v_line, $v_n];
  return null;
}
function f_Workspace_closures__str($v_line, $v_s) {
  Z::$l = 19;
  return [':Str', $v_line, $v_s];
  return null;
}
function f_Workspace_closures__var($v_line, $v_n) {
  Z::$l = 20;
  return [':Var', $v_line, $v_n];
  return null;
}
function f_Workspace_closures__intl($v_line, $v_i) {
  Z::$l = 21;
  return [':Int', $v_line, $v_i];
  return null;
}
function f_Workspace_closures__arg($v_e) {
  Z::$l = 22;
  return [':Arg', 0, null, $v_e, false];
  return null;
}
function f_Workspace_closures__call($v_line, $v_fn, $v_args) {
  $v_as = null;
  $v_a = null;
  Z::$l = 24;
  ($v_as = []);
  Z::$l = 25;
  foreach (z_foreach($v_args) as $_k252 => $_v252) {
    $v_a = $_v252;
    Z::$l = 25;
    z_apush($v_as, f_Workspace_closures__arg($v_a));
  }
  Z::$l = 26;
  return [':Call', $v_line, f_Workspace_closures__nm($v_line, $v_fn), $v_as];
  return null;
}
function f_Workspace_closures__param($v_name) {
  Z::$l = 28;
  return [':Param', 0, $v_name, [], null, false];
  return null;
}
function f_Workspace_closures__bindArgs($v_line, $v_params, $v_argsName, $v_fname) {
  $v_out = null;
  $v_i = null;
  $v_p = null;
  $v_a = null;
  $v_d = null;
  $v_byName = null;
  Z::$l = 35;
  ($v_out = []);
  Z::$l = 36;
  ($v_i = 0);
  for (; z_truthy((z_cmp($v_i, z_b_count($v_params)) < 0)); z_last($_t59 = $v_i, $v_i = z_add($_t59, 1), $_t59)) {
    Z::$l = 37;
    ($v_p = z_index($v_params, $v_i));
    Z::$l = 38;
    if (z_truthy(z_index($v_p, 5))) {
      Z::$l = 39;
      z_apush($v_out, [':Arg', 0, null, f_Workspace_closures__call($v_line, 'array_slice', [f_Workspace_closures__var($v_line, $v_argsName), f_Workspace_closures__intl($v_line, $v_i)]), true]);
      continue 1;
    }
    Z::$l = 42;
    ($v_a = f_Workspace_closures__var($v_line, $v_argsName));
    Z::$l = 43;
    ($v_d = (z_truthy((z_index($v_p, 4) !== null)) ? z_index($v_p, 4) : f_Workspace_closures__call($v_line, 'zs_arg_missing', [f_Workspace_closures__str($v_line, $v_fname), f_Workspace_closures__str($v_line, z_index($v_p, 2))])));
    Z::$l = 44;
    ($v_byName = [':Ternary', $v_line, f_Workspace_closures__call($v_line, 'has_key', [$v_a, f_Workspace_closures__str($v_line, z_index($v_p, 2))]), [':Index', $v_line, $v_a, f_Workspace_closures__str($v_line, z_index($v_p, 2))], $v_d]);
    Z::$l = 45;
    z_apush($v_out, f_Workspace_closures__arg([':Ternary', $v_line, f_Workspace_closures__call($v_line, 'has_key', [$v_a, f_Workspace_closures__intl($v_line, $v_i)]), [':Index', $v_line, $v_a, f_Workspace_closures__intl($v_line, $v_i)], $v_byName]));
  }
  Z::$l = 47;
  return $v_out;
  return null;
}
function f_Workspace_closures__prepend($v_v, $v_xs) {
  $v_o = null;
  $v_x = null;
  Z::$l = 272;
  ($v_o = [$v_v]);
  Z::$l = 273;
  foreach (z_foreach($v_xs) as $_k254 => $_v254) {
    $v_x = $_v254;
    Z::$l = 273;
    z_apush($v_o, $v_x);
  }
  Z::$l = 274;
  return $v_o;
  return null;
}
function f_Workspace_closures__lift($v_ast) {
  $v_l = null;
  $v_s = null;
  $v___k219 = null;
  $v___r220 = null;
  $v___w221 = null;
  $v_rest = null;
  $v_topvis = null;
  $v_out = null;
  $v_f = null;
  $v_vis = null;
  $v_p = null;
  Z::$l = 281;
  ($v_l = f_Lifter__new());
  Z::$l = 282;
  foreach (z_foreach($v_ast) as $_k255 => $_v255) {
    $v_s = $_v255;
    Z::$l = 282;
    if (z_truthy((z_index($v_s, 0) === ':FuncStmt'))) {
      Z::$l = 282;
      ($v___k219 = z_index(z_index($v_s, 2), 2));
      Z::$l = 282;
      ($v___r220 = z_index(z_index($v_s, 2), 3));
      Z::$l = 282;
      ($v___w221 = z_b_zs_obj_take($v_l, 'fnp'));
      Z::$l = 282;
      z_aset($v___w221, $v___k219, $v___r220);
      Z::$l = 282;
      z_b_zs_obj_put($v_l, 'fnp', $v___w221);
    }
  }
  Z::$l = 283;
  ($v_rest = []);
  Z::$l = 284;
  foreach (z_foreach($v_ast) as $_k256 => $_v256) {
    $v_s = $_v256;
    Z::$l = 284;
    if (z_truthy((z_index($v_s, 0) !== ':FuncStmt'))) {
      Z::$l = 284;
      z_apush($v_rest, $v_s);
    }
  }
  Z::$l = 285;
  ($v_topvis = f_zs_invoke($v_l, 'names', [$v_rest]));
  Z::$l = 286;
  ($v_out = []);
  Z::$l = 287;
  foreach (z_foreach($v_ast) as $_k257 => $_v257) {
    $v_s = $_v257;
    Z::$l = 288;
    if (z_truthy((z_index($v_s, 0) === ':FuncStmt'))) {
      Z::$l = 289;
      ($v_f = z_index($v_s, 2));
      Z::$l = 290;
      ($v_vis = f_zs_invoke($v_l, 'names', [z_index($v_f, 5)]));
      Z::$l = 291;
      foreach (z_foreach(z_index($v_f, 3)) as $_k258 => $_v258) {
        $v_p = $_v258;
        Z::$l = 291;
        z_aset($v_vis, z_index($v_p, 2), true);
      }
      Z::$l = 292;
      z_aset($v_f, 5, f_zs_invoke($v_l, 'rw', [z_index($v_f, 5), $v_vis]));
      Z::$l = 293;
      z_aset($v_s, 2, $v_f);
      Z::$l = 294;
      z_apush($v_out, $v_s);
    } else {
      Z::$l = 296;
      z_apush($v_out, f_zs_invoke($v_l, 'rw', [$v_s, $v_topvis]));
    }
  }
  Z::$l = 299;
  if (z_truthy((z_truthy((z_truthy((z_truthy((z_b_zs_obj_get($v_l, 'n') === 0)) && z_truthy(!z_truthy(z_b_zs_obj_get($v_l, 'dyn'))))) && z_truthy(!z_truthy(z_b_zs_obj_get($v_l, 'usesSpread'))))) && z_truthy(!z_truthy(z_b_zs_obj_get($v_l, 'sawHelper')))))) {
    Z::$l = 299;
    return [z_k('ast') => $v_out, z_k('errors') => z_b_zs_obj_get($v_l, 'errors')];
  }
  Z::$l = 300;
  foreach (z_foreach(z_b_zs_obj_get($v_l, 'out')) as $_k259 => $_v259) {
    $v_s = $_v259;
    Z::$l = 300;
    z_apush($v_out, $v_s);
  }
  Z::$l = 301;
  foreach (z_foreach(f_zs_invoke($v_l, 'helpers', [])) as $_k260 => $_v260) {
    $v_s = $_v260;
    Z::$l = 301;
    z_apush($v_out, $v_s);
  }
  Z::$l = 302;
  return [z_k('ast') => $v_out, z_k('errors') => z_b_zs_obj_get($v_l, 'errors')];
  return null;
}
function f_Workspace_classes__pseudo_exceptions() {
  Z::$l = 7;
  return f_Workspace_parser__parse('class Exception { public $message = ""; public $line = 0; func __construct($message = "") { $this->message = $message; } func getMessage() { return $this->message; } } class Error extends Exception { }');
  return null;
}
function f_Workspace_classes__array_reverse_names($v_xs) {
  $v_o = null;
  $v_i = null;
  Z::$l = 529;
  ($v_o = []);
  Z::$l = 530;
  ($v_i = z_sub(z_b_count($v_xs), 1));
  for (; z_truthy((z_cmp($v_i, 0) >= 0)); z_last($_t60 = $v_i, $v_i = z_sub($_t60, 1), $_t60)) {
    Z::$l = 530;
    z_apush($v_o, z_index($v_xs, $v_i));
  }
  Z::$l = 531;
  return $v_o;
  return null;
}
function f_Workspace_classes__prepend($v_v, $v_xs) {
  $v_o = null;
  $v_x = null;
  Z::$l = 534;
  ($v_o = [$v_v]);
  Z::$l = 535;
  foreach (z_foreach($v_xs) as $_k262 => $_v262) {
    $v_x = $_v262;
    Z::$l = 535;
    z_apush($v_o, $v_x);
  }
  Z::$l = 536;
  return $v_o;
  return null;
}
function f_Workspace_classes__desugar($v_ast) {
  $v_has = null;
  $v_s = null;
  $v_d = null;
  $v_k = null;
  $v_r = null;
  $v_guard = null;
  $v_n = null;
  $v_pseudo = null;
  $v_rest = null;
  $v_statics = null;
  $v_pn = null;
  $v_pd = null;
  $v_ln = null;
  $v_dv = null;
  $v_body = null;
  $v_f = null;
  $v_y = null;
  $v_out = null;
  Z::$l = 543;
  ($v_has = false);
  Z::$l = 544;
  foreach (z_foreach($v_ast) as $_k263 => $_v263) {
    $v_s = $_v263;
    Z::$l = 544;
    if (z_truthy((z_index($v_s, 0) === ':ClassStmt'))) {
      Z::$l = 544;
      ($v_has = true);
    }
  }
  Z::$l = 545;
  if (z_truthy(!z_truthy($v_has))) {
    Z::$l = 545;
    return [z_k('ast') => $v_ast, z_k('errors') => []];
  }
  Z::$l = 546;
  ($v_d = f_Desugar__new());
  Z::$l = 547;
  f_zs_invoke($v_d, 'collect', [$v_ast]);
  Z::$l = 548;
  foreach (z_foreach(z_b_zs_obj_get($v_d, 'classes')) as $_k264 => $_v264) {
    $v_k = $_v264;
    Z::$l = 549;
    ($v_r = z_b_zs_obj_get($v_k, 'name'));
    Z::$l = 550;
    ($v_guard = 0);
    Z::$l = 551;
    ($v_n = z_b_zs_obj_get($v_k, 'parent'));
    while (true) {
      Z::$l = 552;
      if (!z_truthy((z_truthy((z_truthy(($v_n !== null)) && z_truthy(z_b_has_key(z_b_zs_obj_get($v_d, 'classes'), $v_n)))) && z_truthy((z_cmp($v_guard, 64) < 0))))) break;
      Z::$l = 552;
      ($v_n = z_b_zs_obj_get(z_index(z_b_zs_obj_get($v_d, 'classes'), $v_n), 'parent'));
      Z::$l = 552;
      z_last($_t61 = $v_guard, $v_guard = z_add($_t61, 1), $_t61);
    }
    Z::$l = 553;
    if (z_truthy((z_truthy(($v_n === 'Exception')) || z_truthy(($v_n === 'Error'))))) {
      Z::$l = 553;
      z_b_zs_obj_set($v_d, 'excMode', true);
    }
  }
  Z::$l = 555;
  if (z_truthy((z_truthy((z_truthy(z_b_zs_obj_get($v_d, 'excMode')) && z_truthy(!z_truthy(z_b_has_key(z_b_zs_obj_get($v_d, 'classes'), 'Exception'))))) && z_truthy(!z_truthy(z_b_has_key(z_b_zs_obj_get($v_d, 'classes'), 'Error')))))) {
    Z::$l = 556;
    ($v_pseudo = f_Workspace_classes__pseudo_exceptions());
    Z::$l = 557;
    f_zs_invoke($v_d, 'collect', [$v_pseudo]);
    Z::$l = 558;
    ($v_ast = $v_ast);
    Z::$l = 559;
    foreach (z_foreach($v_pseudo) as $_k266 => $_v266) {
      $v_s = $_v266;
      Z::$l = 559;
      z_apush($v_ast, $v_s);
    }
  }
  Z::$l = 561;
  ($v_rest = []);
  Z::$l = 562;
  foreach (z_foreach($v_ast) as $_k267 => $_v267) {
    $v_s = $_v267;
    Z::$l = 562;
    if (z_truthy((z_index($v_s, 0) !== ':ClassStmt'))) {
      Z::$l = 562;
      z_apush($v_rest, $v_s);
    }
  }
  Z::$l = 563;
  foreach (z_foreach(z_b_zs_obj_get($v_d, 'classes')) as $_k268 => $_v268) {
    $v_k = $_v268;
    Z::$l = 563;
    f_zs_invoke($v_d, 'genClass', [$v_k]);
  }
  Z::$l = 564;
  z_b_zs_obj_set($v_d, 'cur', null);
  Z::$l = 565;
  ($v_statics = []);
  Z::$l = 566;
  foreach (z_foreach(z_b_zs_obj_get($v_d, 'classes')) as $_k269 => $_v269) {
    $v_k = $_v269;
    Z::$l = 567;
    z_b_zs_obj_set($v_d, 'cur', $v_k);
    Z::$l = 568;
    foreach (z_foreach(z_b_zs_obj_get($v_k, 'props')) as $_k270 => $_v270) {
      $v_pd = $_v270;
      $v_pn = $_k270;
      Z::$l = 569;
      if (z_truthy(!z_truthy(z_index($v_pd, 'static')))) {
        continue 1;
      }
      Z::$l = 570;
      ($v_ln = z_b_zs_obj_get($v_k, 'line'));
      Z::$l = 571;
      ($v_dv = (z_truthy((z_index($v_pd, 'default') === null)) ? [':Null', $v_ln] : f_zs_invoke($v_d, 'rw', [z_index($v_pd, 'default')])));
      Z::$l = 572;
      z_apush($v_statics, [':Expr', $v_ln, f_zs_invoke($v_d, 'call', [$v_ln, 'zs_sset', [f_zs_invoke($v_d, 'mkstr', [$v_ln, z_concat(z_concat(z_b_zs_obj_get($v_k, 'name'), '::'), $v_pn)]), $v_dv]])]);
    }
  }
  Z::$l = 575;
  z_b_zs_obj_set($v_d, 'cur', null);
  Z::$l = 576;
  ($v_body = []);
  Z::$l = 577;
  foreach (z_foreach($v_rest) as $_k271 => $_v271) {
    $v_s = $_v271;
    Z::$l = 578;
    if (z_truthy((z_index($v_s, 0) === ':FuncStmt'))) {
      Z::$l = 579;
      ($v_f = z_index($v_s, 2));
      Z::$l = 580;
      z_aset($v_f, 5, f_zs_invoke($v_d, 'rwList', [z_index($v_f, 5)]));
      Z::$l = 581;
      z_aset($v_s, 2, $v_f);
      Z::$l = 582;
      z_apush($v_body, $v_s);
    } else {
      Z::$l = 584;
      ($v_r = (z_truthy((z_index($v_s, 0) === ':Expr')) ? f_zs_invoke($v_d, 'stmtExpr', [$v_s]) : null));
      Z::$l = 585;
      if (z_truthy(($v_r !== null))) {
        Z::$l = 585;
        foreach (z_foreach($v_r) as $_k272 => $_v272) {
          $v_y = $_v272;
          Z::$l = 585;
          z_apush($v_body, $v_y);
        }
      } else {
        Z::$l = 586;
        z_apush($v_body, f_zs_invoke($v_d, 'rw', [$v_s]));
      }
    }
  }
  Z::$l = 589;
  f_zs_invoke($v_d, 'genDispatch', []);
  Z::$l = 590;
  ($v_out = []);
  Z::$l = 591;
  foreach (z_foreach(z_b_zs_obj_get($v_d, 'extra')) as $_k273 => $_v273) {
    $v_s = $_v273;
    Z::$l = 591;
    z_apush($v_out, $v_s);
  }
  Z::$l = 592;
  foreach (z_foreach($v_statics) as $_k274 => $_v274) {
    $v_s = $_v274;
    Z::$l = 592;
    z_apush($v_out, $v_s);
  }
  Z::$l = 593;
  foreach (z_foreach($v_body) as $_k275 => $_v275) {
    $v_s = $_v275;
    Z::$l = 593;
    z_apush($v_out, $v_s);
  }
  Z::$l = 594;
  return [z_k('ast') => $v_out, z_k('errors') => z_b_zs_obj_get($v_d, 'errors')];
  return null;
}
function f_Workspace_prelude__names() {
  Z::$l = 10;
  return ['map', 'filter', 'reduce', 'each', 'find', 'any', 'all', 'usort', 'sum'];
  return null;
}
function f_Workspace_prelude__source() {
  $v_l = null;
  Z::$l = 14;
  ($v_l = []);
  Z::$l = 15;
  z_apush($v_l, 'func map($a, $f) { $o = []; foreach ($a as $k => $v) { $o[$k] = $f($v); } return $o; }');
  Z::$l = 16;
  z_apush($v_l, 'func filter($a, $f) { $o = []; foreach ($a as $k => $v) { if ($f($v)) { $o[$k] = $v; } } return $o; }');
  Z::$l = 17;
  z_apush($v_l, 'func reduce($a, $f, $acc) { foreach ($a as $v) { $acc = $f($acc, $v); } return $acc; }');
  Z::$l = 18;
  z_apush($v_l, 'func each($a, $f) { foreach ($a as $v) { $f($v); } return null; }');
  Z::$l = 19;
  z_apush($v_l, 'func find($a, $f) { foreach ($a as $v) { if ($f($v)) { return $v; } } return null; }');
  Z::$l = 20;
  z_apush($v_l, 'func any($a, $f) { foreach ($a as $v) { if ($f($v)) { return true; } } return false; }');
  Z::$l = 21;
  z_apush($v_l, 'func all($a, $f) { foreach ($a as $v) { if (!$f($v)) { return false; } } return true; }');
  Z::$l = 22;
  z_apush($v_l, 'func sum($a) { $t = 0; foreach ($a as $v) { $t = $t + $v; } return $t; }');
  Z::$l = 24;
  z_apush($v_l, 'func usort($a, $f) { $v = values($a); return usort_rec($v, $f); }');
  Z::$l = 25;
  z_apush($v_l, 'func usort_rec($v, $f) { $n = count($v); if ($n < 2) { return $v; } $m = intval($n / 2); $l = usort_rec(array_slice($v, 0, $m), $f); $r = usort_rec(array_slice($v, $m), $f); $o = []; $i = 0; $j = 0; $nl = count($l); $nr = count($r); while ($i < $nl && $j < $nr) { if ($f($l[$i], $r[$j]) <= 0) { $o[] = $l[$i]; $i++; } else { $o[] = $r[$j]; $j++; } } while ($i < $nl) { $o[] = $l[$i]; $i++; } while ($j < $nr) { $o[] = $r[$j]; $j++; } return $o; }');
  Z::$l = 26;
  return z_b_join($v_l, ' ');
  return null;
}
function f_Workspace_spreadlit__segment($v_line, $v_items) {
  Z::$l = 13;
  return [':Array', $v_line, $v_items];
  return null;
}
function f_Workspace_spreadlit__spreadCall($v_line, $v_a, $v_b) {
  Z::$l = 16;
  return [':Call', $v_line, [':Name', $v_line, 'zs_spread'], [[':Arg', 0, null, $v_a, false], [':Arg', 0, null, $v_b, false]]];
  return null;
}
function f_Workspace_spreadlit__rewriteArray($v_n) {
  $v_line = null;
  $v_has = null;
  $v_it = null;
  $v_cur = null;
  $v_items = null;
  $v_v = null;
  $v_seg = null;
  Z::$l = 20;
  ($v_line = z_index($v_n, 1));
  Z::$l = 21;
  ($v_has = false);
  Z::$l = 22;
  foreach (z_foreach(z_index($v_n, 2)) as $_k276 => $_v276) {
    $v_it = $_v276;
    Z::$l = 22;
    if (z_truthy((z_truthy(f_Workspace_parser__isNode(z_index($v_it, 3))) && z_truthy((z_index(z_index($v_it, 3), 0) === ':Spread'))))) {
      Z::$l = 22;
      ($v_has = true);
    }
  }
  Z::$l = 23;
  if (z_truthy(!z_truthy($v_has))) {
    Z::$l = 23;
    return null;
  }
  Z::$l = 24;
  ($v_cur = null);
  Z::$l = 25;
  ($v_items = []);
  Z::$l = 26;
  foreach (z_foreach(z_index($v_n, 2)) as $_k277 => $_v277) {
    $v_it = $_v277;
    Z::$l = 27;
    ($v_v = z_index($v_it, 3));
    Z::$l = 28;
    if (z_truthy((z_truthy(f_Workspace_parser__isNode($v_v)) && z_truthy((z_index($v_v, 0) === ':Spread'))))) {
      Z::$l = 29;
      ($v_seg = f_Workspace_spreadlit__segment($v_line, $v_items));
      Z::$l = 30;
      ($v_cur = (z_truthy(($v_cur === null)) ? $v_seg : f_Workspace_spreadlit__spreadCall($v_line, $v_cur, $v_seg)));
      Z::$l = 31;
      ($v_cur = f_Workspace_spreadlit__spreadCall($v_line, $v_cur, f_Workspace_spreadlit__rewrite(z_index($v_v, 2))));
      Z::$l = 32;
      ($v_items = []);
    } else {
      Z::$l = 34;
      z_apush($v_items, [':Item', 0, (z_truthy((z_index($v_it, 2) === null)) ? null : f_Workspace_spreadlit__rewrite(z_index($v_it, 2))), f_Workspace_spreadlit__rewrite($v_v)]);
    }
  }
  Z::$l = 37;
  if (z_truthy((z_cmp(z_b_count($v_items), 0) > 0))) {
    Z::$l = 37;
    ($v_cur = f_Workspace_spreadlit__spreadCall($v_line, $v_cur, f_Workspace_spreadlit__segment($v_line, $v_items)));
  }
  Z::$l = 38;
  return $v_cur;
  return null;
}
function f_Workspace_spreadlit__rewrite($v_x) {
  $v_r = null;
  $v_o = null;
  $v_i = null;
  $v_k = null;
  $v_v = null;
  Z::$l = 42;
  if (z_truthy(f_Workspace_parser__isNode($v_x))) {
    Z::$l = 43;
    if (z_truthy((z_index($v_x, 0) === ':Array'))) {
      Z::$l = 44;
      ($v_r = f_Workspace_spreadlit__rewriteArray($v_x));
      Z::$l = 45;
      if (z_truthy(($v_r !== null))) {
        Z::$l = 45;
        return $v_r;
      }
    }
    Z::$l = 47;
    ($v_o = [z_index($v_x, 0), z_index($v_x, 1)]);
    Z::$l = 48;
    ($v_i = 2);
    for (; z_truthy((z_cmp($v_i, z_b_count($v_x)) < 0)); z_last($_t62 = $v_i, $v_i = z_add($_t62, 1), $_t62)) {
      Z::$l = 48;
      z_apush($v_o, f_Workspace_spreadlit__rewrite(z_index($v_x, $v_i)));
    }
    Z::$l = 49;
    return $v_o;
  }
  Z::$l = 51;
  if (z_truthy(z_b_is_array($v_x))) {
    Z::$l = 52;
    ($v_o = []);
    Z::$l = 53;
    foreach (z_foreach($v_x) as $_k279 => $_v279) {
      $v_v = $_v279;
      $v_k = $_k279;
      Z::$l = 53;
      z_aset($v_o, $v_k, f_Workspace_spreadlit__rewrite($v_v));
    }
    Z::$l = 54;
    return $v_o;
  }
  Z::$l = 56;
  return $v_x;
  return null;
}
function f_Workspace_spreadlit__desugar($v_ast) {
  Z::$l = 62;
  return f_Workspace_spreadlit__rewrite($v_ast);
  return null;
}
function f_Workspace_matchlit__eqTest($v_line, $v_c) {
  Z::$l = 13;
  return [':Binary', $v_line, 'Identical', [':Var', $v_line, '__m'], $v_c];
  return null;
}
function f_Workspace_matchlit__rewriteMatch($v_n) {
  $v_line = null;
  $v_body = null;
  $v_hasDefault = null;
  $v_arm = null;
  $v_conds = null;
  $v_val = null;
  $v_c = null;
  $v_x = null;
  $v_t = null;
  $v_params = null;
  $v_fn = null;
  Z::$l = 17;
  ($v_line = z_index($v_n, 1));
  Z::$l = 18;
  ($v_body = []);
  Z::$l = 19;
  ($v_hasDefault = false);
  Z::$l = 20;
  foreach (z_foreach(z_index($v_n, 3)) as $_k280 => $_v280) {
    $v_arm = $_v280;
    Z::$l = 21;
    ($v_conds = z_index($v_arm, 2));
    Z::$l = 22;
    ($v_val = f_Workspace_matchlit__rewrite(z_index($v_arm, 3)));
    Z::$l = 23;
    if (z_truthy(($v_conds === null))) {
      Z::$l = 24;
      z_apush($v_body, [':Return', $v_line, $v_val]);
      Z::$l = 25;
      ($v_hasDefault = true);
      break 1;
    }
    Z::$l = 28;
    ($v_c = null);
    Z::$l = 29;
    foreach (z_foreach($v_conds) as $_k281 => $_v281) {
      $v_x = $_v281;
      Z::$l = 30;
      ($v_t = f_Workspace_matchlit__eqTest($v_line, f_Workspace_matchlit__rewrite($v_x)));
      Z::$l = 31;
      ($v_c = (z_truthy(($v_c === null)) ? $v_t : [':Binary', $v_line, 'Or', $v_c, $v_t]));
    }
    Z::$l = 33;
    z_apush($v_body, [':If', $v_line, $v_c, [[':Return', $v_line, $v_val]], null]);
  }
  Z::$l = 35;
  if (z_truthy(!z_truthy($v_hasDefault))) {
    Z::$l = 36;
    z_apush($v_body, [':Throw', $v_line, [':New', $v_line, 'Exception', [[':Arg', 0, null, [':Str', $v_line, 'brak dopasowania w match'], false]]]]);
  }
  Z::$l = 38;
  ($v_params = [[':Param', 0, '__m', [], null, false]]);
  Z::$l = 39;
  ($v_fn = [':Func', $v_line, null, $v_params, [], $v_body, false]);
  Z::$l = 40;
  return [':Call', $v_line, [':Closure', $v_line, $v_fn], [[':Arg', 0, null, f_Workspace_matchlit__rewrite(z_index($v_n, 2)), false]]];
  return null;
}
function f_Workspace_matchlit__rewrite($v_x) {
  $v_o = null;
  $v_i = null;
  $v_k = null;
  $v_v = null;
  Z::$l = 44;
  if (z_truthy(f_Workspace_parser__isNode($v_x))) {
    Z::$l = 45;
    if (z_truthy((z_index($v_x, 0) === ':Match'))) {
      Z::$l = 45;
      return f_Workspace_matchlit__rewriteMatch($v_x);
    }
    Z::$l = 46;
    ($v_o = [z_index($v_x, 0), z_index($v_x, 1)]);
    Z::$l = 47;
    ($v_i = 2);
    for (; z_truthy((z_cmp($v_i, z_b_count($v_x)) < 0)); z_last($_t63 = $v_i, $v_i = z_add($_t63, 1), $_t63)) {
      Z::$l = 47;
      z_apush($v_o, f_Workspace_matchlit__rewrite(z_index($v_x, $v_i)));
    }
    Z::$l = 48;
    return $v_o;
  }
  Z::$l = 50;
  if (z_truthy(z_b_is_array($v_x))) {
    Z::$l = 51;
    ($v_o = []);
    Z::$l = 52;
    foreach (z_foreach($v_x) as $_k283 => $_v283) {
      $v_v = $_v283;
      $v_k = $_k283;
      Z::$l = 52;
      z_aset($v_o, $v_k, f_Workspace_matchlit__rewrite($v_v));
    }
    Z::$l = 53;
    return $v_o;
  }
  Z::$l = 55;
  return $v_x;
  return null;
}
function f_Workspace_matchlit__desugar($v_ast) {
  Z::$l = 58;
  return f_Workspace_matchlit__rewrite($v_ast);
  return null;
}
function f_Workspace_link__builtin_modules() {
  Z::$l = 17;
  return ['System', 'Math', 'File', 'Directory', 'Process'];
  return null;
}
function f_Workspace_link__link($v_ast, $v_file) {
  $v_lk = null;
  $v_aliases = null;
  $v_main = null;
  $v_s = null;
  $v_f = null;
  $v_all = null;
  $v_ds = null;
  $v_e = null;
  $v___r222 = null;
  $v___w223 = null;
  $v_cl = null;
  $v___r224 = null;
  $v___w225 = null;
  $v_vr = null;
  $v___r226 = null;
  $v___w227 = null;
  Z::$l = 113;
  ($v_lk = f_Linker__new());
  Z::$l = 114;
  ($v_aliases = f_zs_invoke($v_lk, 'collectImports', [$v_ast, $v_file]));
  Z::$l = 115;
  ($v_main = []);
  Z::$l = 116;
  foreach (z_foreach($v_ast) as $_k284 => $_v284) {
    $v_s = $_v284;
    Z::$l = 117;
    if (z_truthy((z_truthy((z_index($v_s, 0) === ':Import')) && z_truthy(!z_truthy(z_b_in_array(z_index(z_index($v_s, 2), 0), f_Workspace_link__builtin_modules())))))) {
      continue 1;
    }
    Z::$l = 118;
    if (z_truthy((z_index($v_s, 0) === ':FuncStmt'))) {
      Z::$l = 119;
      ($v_f = z_index($v_s, 2));
      Z::$l = 120;
      z_aset($v_f, 5, f_zs_invoke($v_lk, 'rw', [z_index($v_f, 5), null, [], $v_aliases]));
      Z::$l = 121;
      z_aset($v_s, 2, $v_f);
      Z::$l = 122;
      z_apush($v_main, $v_s);
    } else {
      Z::$l = 124;
      z_apush($v_main, f_zs_invoke($v_lk, 'rw', [$v_s, null, [], $v_aliases]));
    }
  }
  Z::$l = 127;
  ($v_all = []);
  Z::$l = 128;
  foreach (z_foreach(z_b_zs_obj_get($v_lk, 'out')) as $_k285 => $_v285) {
    $v_s = $_v285;
    Z::$l = 128;
    z_apush($v_all, $v_s);
  }
  Z::$l = 129;
  foreach (z_foreach($v_main) as $_k286 => $_v286) {
    $v_s = $_v286;
    Z::$l = 129;
    z_apush($v_all, $v_s);
  }
  Z::$l = 130;
  ($v_all = f_Workspace_link__prelude_pass($v_all));
  Z::$l = 131;
  ($v_all = f_Workspace_spreadlit__desugar($v_all));
  Z::$l = 132;
  ($v_all = f_Workspace_matchlit__desugar($v_all));
  Z::$l = 133;
  ($v_ds = f_Workspace_classes__desugar($v_all));
  Z::$l = 134;
  foreach (z_foreach(z_index($v_ds, 'errors')) as $_k287 => $_v287) {
    $v_e = $_v287;
    Z::$l = 134;
    ($v___r222 = [z_index($v_e, 0), z_index($v_e, 1), z_index($v_e, 2), $v_file]);
    Z::$l = 134;
    ($v___w223 = z_b_zs_obj_take($v_lk, 'errors'));
    Z::$l = 134;
    z_apush($v___w223, $v___r222);
    Z::$l = 134;
    z_b_zs_obj_put($v_lk, 'errors', $v___w223);
  }
  Z::$l = 135;
  ($v_cl = f_Workspace_closures__lift(z_index($v_ds, 'ast')));
  Z::$l = 136;
  foreach (z_foreach(z_index($v_cl, 'errors')) as $_k288 => $_v288) {
    $v_e = $_v288;
    Z::$l = 136;
    ($v___r224 = [z_index($v_e, 0), z_index($v_e, 1), z_index($v_e, 2), $v_file]);
    Z::$l = 136;
    ($v___w225 = z_b_zs_obj_take($v_lk, 'errors'));
    Z::$l = 136;
    z_apush($v___w225, $v___r224);
    Z::$l = 136;
    z_b_zs_obj_put($v_lk, 'errors', $v___w225);
  }
  Z::$l = 137;
  ($v_vr = f_Workspace_link__variadic_pass(z_index($v_cl, 'ast')));
  Z::$l = 138;
  foreach (z_foreach(z_index($v_vr, 'errors')) as $_k289 => $_v289) {
    $v_e = $_v289;
    Z::$l = 138;
    ($v___r226 = [z_index($v_e, 0), z_index($v_e, 1), z_index($v_e, 2), $v_file]);
    Z::$l = 138;
    ($v___w227 = z_b_zs_obj_take($v_lk, 'errors'));
    Z::$l = 138;
    z_apush($v___w227, $v___r226);
    Z::$l = 138;
    z_b_zs_obj_put($v_lk, 'errors', $v___w227);
  }
  Z::$l = 139;
  return [z_k('ast') => z_index($v_vr, 'ast'), z_k('errors') => z_b_zs_obj_get($v_lk, 'errors')];
  return null;
}
function f_Workspace_link__variadic_pass($v_ast) {
  $v_vp = null;
  $v_s = null;
  $v_ps = null;
  $v_n = null;
  $v___k228 = null;
  $v___r229 = null;
  $v___w230 = null;
  $v___k231 = null;
  $v___r232 = null;
  $v___w233 = null;
  $v_out = null;
  $v_f = null;
  $v_p = null;
  Z::$l = 193;
  ($v_vp = f_VarPass__new());
  Z::$l = 194;
  foreach (z_foreach($v_ast) as $_k290 => $_v290) {
    $v_s = $_v290;
    Z::$l = 195;
    if (z_truthy((z_index($v_s, 0) !== ':FuncStmt'))) {
      continue 1;
    }
    Z::$l = 196;
    ($v_ps = z_index(z_index($v_s, 2), 3));
    Z::$l = 197;
    ($v_n = z_b_count($v_ps));
    Z::$l = 198;
    if (z_truthy((z_truthy((z_cmp($v_n, 0) > 0)) && z_truthy(z_index(z_index($v_ps, z_sub($v_n, 1)), 5))))) {
      Z::$l = 198;
      ($v___k228 = z_index(z_index($v_s, 2), 2));
      Z::$l = 198;
      ($v___r229 = z_sub($v_n, 1));
      Z::$l = 198;
      ($v___w230 = z_b_zs_obj_take($v_vp, 'fixed'));
      Z::$l = 198;
      z_aset($v___w230, $v___k228, $v___r229);
      Z::$l = 198;
      z_b_zs_obj_put($v_vp, 'fixed', $v___w230);
      Z::$l = 198;
      ($v___k231 = z_index(z_index($v_s, 2), 2));
      Z::$l = 198;
      ($v___r232 = $v_ps);
      Z::$l = 198;
      ($v___w233 = z_b_zs_obj_take($v_vp, 'defs'));
      Z::$l = 198;
      z_aset($v___w233, $v___k231, $v___r232);
      Z::$l = 198;
      z_b_zs_obj_put($v_vp, 'defs', $v___w233);
    }
  }
  Z::$l = 200;
  if (z_truthy((z_b_count(z_b_zs_obj_get($v_vp, 'fixed')) === 0))) {
    Z::$l = 200;
    return [z_k('ast') => $v_ast, z_k('errors') => []];
  }
  Z::$l = 201;
  ($v_out = []);
  Z::$l = 202;
  foreach (z_foreach($v_ast) as $_k291 => $_v291) {
    $v_s = $_v291;
    Z::$l = 203;
    ($v_s = f_zs_invoke($v_vp, 'rw', [$v_s]));
    Z::$l = 204;
    if (z_truthy((z_index($v_s, 0) === ':FuncStmt'))) {
      Z::$l = 205;
      ($v_f = z_index($v_s, 2));
      Z::$l = 206;
      ($v_ps = z_index($v_f, 3));
      Z::$l = 207;
      ($v_n = z_b_count($v_ps));
      Z::$l = 208;
      if (z_truthy((z_truthy((z_cmp($v_n, 0) > 0)) && z_truthy(z_index(z_index($v_ps, z_sub($v_n, 1)), 5))))) {
        Z::$l = 208;
        ($v_p = z_index($v_ps, z_sub($v_n, 1)));
        Z::$l = 208;
        z_aset($v_p, 5, false);
        Z::$l = 208;
        z_aset($v_ps, z_sub($v_n, 1), $v_p);
        Z::$l = 208;
        z_aset($v_f, 3, $v_ps);
        Z::$l = 208;
        z_aset($v_s, 2, $v_f);
      }
    }
    Z::$l = 210;
    z_apush($v_out, $v_s);
  }
  Z::$l = 212;
  return [z_k('ast') => $v_out, z_k('errors') => z_b_zs_obj_get($v_vp, 'errors')];
  return null;
}
function f_Workspace_link__calls_of($v_x, $v_acc) {
  $v_v = null;
  Z::$l = 216;
  if (z_truthy(!z_truthy(z_b_is_array($v_x)))) {
    Z::$l = 216;
    return $v_acc;
  }
  Z::$l = 217;
  if (z_truthy((z_truthy((z_truthy(f_Workspace_parser__isNode($v_x)) && z_truthy((z_index($v_x, 0) === ':Call')))) && z_truthy((z_index(z_index($v_x, 2), 0) === ':Name'))))) {
    Z::$l = 217;
    z_aset($v_acc, z_index(z_index($v_x, 2), 2), true);
  }
  Z::$l = 218;
  foreach (z_foreach($v_x) as $_k292 => $_v292) {
    $v_v = $_v292;
    Z::$l = 218;
    ($v_acc = f_Workspace_link__calls_of($v_v, $v_acc));
  }
  Z::$l = 219;
  return $v_acc;
  return null;
}
function f_Workspace_link__prelude_pass($v_ast) {
  $v_defined = null;
  $v_s = null;
  $v_used = null;
  $v_want = null;
  $v_n = null;
  $v_out = null;
  $v_nm = null;
  Z::$l = 226;
  ($v_defined = []);
  Z::$l = 227;
  foreach (z_foreach($v_ast) as $_k293 => $_v293) {
    $v_s = $_v293;
    Z::$l = 227;
    if (z_truthy((z_index($v_s, 0) === ':FuncStmt'))) {
      Z::$l = 227;
      z_aset($v_defined, z_index(z_index($v_s, 2), 2), true);
    }
  }
  Z::$l = 228;
  ($v_used = f_Workspace_link__calls_of($v_ast, []));
  Z::$l = 229;
  ($v_want = []);
  Z::$l = 230;
  foreach (z_foreach(f_Workspace_prelude__names()) as $_k294 => $_v294) {
    $v_n = $_v294;
    Z::$l = 230;
    if (z_truthy((z_truthy(z_b_has_key($v_used, $v_n)) && z_truthy(!z_truthy(z_b_has_key($v_defined, $v_n)))))) {
      Z::$l = 230;
      z_aset($v_want, $v_n, true);
    }
  }
  Z::$l = 231;
  if (z_truthy((z_b_count($v_want) === 0))) {
    Z::$l = 231;
    return $v_ast;
  }
  Z::$l = 232;
  ($v_out = []);
  Z::$l = 233;
  foreach (z_foreach(f_Workspace_parser__parse(f_Workspace_prelude__source())) as $_k295 => $_v295) {
    $v_s = $_v295;
    Z::$l = 234;
    ($v_nm = z_index(z_index($v_s, 2), 2));
    Z::$l = 235;
    if (z_truthy((z_truthy(z_b_has_key($v_want, $v_nm)) || z_truthy((z_truthy(($v_nm === 'usort_rec')) && z_truthy(z_b_has_key($v_want, 'usort'))))))) {
      Z::$l = 235;
      z_apush($v_out, $v_s);
    }
  }
  Z::$l = 237;
  foreach (z_foreach($v_ast) as $_k296 => $_v296) {
    $v_s = $_v296;
    Z::$l = 237;
    z_apush($v_out, $v_s);
  }
  Z::$l = 238;
  return $v_out;
  return null;
}
function f_Workspace_regions__var_counts($v_n, $v_acc) {
  $v_t = null;
  $v_c = null;
  Z::$l = 14;
  if (z_truthy(!z_truthy(z_b_is_array($v_n)))) {
    Z::$l = 14;
    return $v_acc;
  }
  Z::$l = 15;
  ($v_t = (($_t64 = z_indexopt($v_n, 0)) !== null ? $_t64 : null));
  Z::$l = 16;
  if (z_truthy((z_truthy(($v_t === ':Var')) && z_truthy(z_b_is_string((($_t65 = z_indexopt($v_n, 2)) !== null ? $_t65 : null)))))) {
    Z::$l = 16;
    z_aset($v_acc, z_index($v_n, 2), z_add((($_t66 = z_indexopt($v_acc, z_index($v_n, 2))) !== null ? $_t66 : 0), 1));
    Z::$l = 16;
    return $v_acc;
  }
  Z::$l = 17;
  if (z_truthy(($v_t === ':Foreach'))) {
    Z::$l = 18;
    if (z_truthy(z_b_is_string((($_t67 = z_indexopt($v_n, 3)) !== null ? $_t67 : null)))) {
      Z::$l = 18;
      z_aset($v_acc, z_index($v_n, 3), z_add((($_t68 = z_indexopt($v_acc, z_index($v_n, 3))) !== null ? $_t68 : 0), 1));
    }
    Z::$l = 19;
    if (z_truthy(z_b_is_string((($_t69 = z_indexopt($v_n, 4)) !== null ? $_t69 : null)))) {
      Z::$l = 19;
      z_aset($v_acc, z_index($v_n, 4), z_add((($_t70 = z_indexopt($v_acc, z_index($v_n, 4))) !== null ? $_t70 : 0), 1));
    }
  }
  Z::$l = 21;
  if (z_truthy(($v_t === ':Try'))) {
    Z::$l = 22;
    foreach (z_foreach((($_t71 = z_indexopt($v_n, 3)) !== null ? $_t71 : [])) as $_k297 => $_v297) {
      $v_c = $_v297;
      Z::$l = 22;
      if (z_truthy((z_truthy(z_b_is_array($v_c)) && z_truthy(z_b_is_string((($_t72 = z_indexopt($v_c, 3)) !== null ? $_t72 : null)))))) {
        Z::$l = 22;
        z_aset($v_acc, z_index($v_c, 3), z_add((($_t73 = z_indexopt($v_acc, z_index($v_c, 3))) !== null ? $_t73 : 0), 1));
      }
    }
  }
  Z::$l = 24;
  foreach (z_foreach($v_n) as $_k298 => $_v298) {
    $v_c = $_v298;
    Z::$l = 24;
    if (z_truthy(z_b_is_array($v_c))) {
      Z::$l = 24;
      ($v_acc = f_Workspace_regions__var_counts($v_c, $v_acc));
    }
  }
  Z::$l = 25;
  return $v_acc;
  return null;
}
function f_Workspace_regions__region_carry($v_loop, $v_body, $v_hdr, $v_pre, $v_fnCounts) {
  $v_cnt = null;
  $v_e = null;
  $v_v = null;
  $v_defined = null;
  $v_bad = null;
  $v_n = null;
  $v_c = null;
  $v_st = null;
  $v_simple = null;
  $v_out = null;
  $v_priv = null;
  Z::$l = 36;
  ($v_cnt = f_Workspace_regions__var_counts($v_body, []));
  Z::$l = 37;
  foreach (z_foreach($v_hdr) as $_k299 => $_v299) {
    $v_e = $_v299;
    Z::$l = 37;
    ($v_cnt = f_Workspace_regions__var_counts($v_e, $v_cnt));
  }
  Z::$l = 38;
  foreach (z_foreach($v_pre) as $_k300 => $_v300) {
    $v_v = $_v300;
    Z::$l = 38;
    if (z_truthy(z_b_is_string($v_v))) {
      Z::$l = 38;
      z_aset($v_cnt, $v_v, z_add((($_t74 = z_indexopt($v_cnt, $v_v)) !== null ? $_t74 : 0), 1));
    }
  }
  Z::$l = 39;
  ($v_defined = []);
  Z::$l = 40;
  foreach (z_foreach($v_pre) as $_k301 => $_v301) {
    $v_v = $_v301;
    Z::$l = 40;
    if (z_truthy(z_b_is_string($v_v))) {
      Z::$l = 40;
      z_aset($v_defined, $v_v, true);
    }
  }
  Z::$l = 41;
  ($v_bad = []);
  Z::$l = 42;
  foreach (z_foreach($v_hdr) as $_k302 => $_v302) {
    $v_e = $_v302;
    Z::$l = 42;
    foreach (z_foreach(f_Workspace_regions__var_counts($v_e, [])) as $_k303 => $_v303) {
      $v_c = $_v303;
      $v_n = $_k303;
      Z::$l = 42;
      z_aset($v_bad, $v_n, true);
    }
  }
  Z::$l = 43;
  foreach (z_foreach($v_body) as $_k304 => $_v304) {
    $v_st = $_v304;
    Z::$l = 44;
    ($v_simple = (z_truthy((z_truthy((z_truthy((z_truthy((z_truthy(z_b_is_array($v_st)) && z_truthy(((($_t75 = z_indexopt($v_st, 0)) !== null ? $_t75 : null) === ':Expr')))) && z_truthy(z_b_is_array((($_t76 = z_indexopt($v_st, 2)) !== null ? $_t76 : null))))) && z_truthy(((($_t77 = z_indexopt(z_indexopt($v_st, 2), 0)) !== null ? $_t77 : null) === ':Assign')))) && z_truthy(z_b_is_array((($_t78 = z_indexopt(z_indexopt($v_st, 2), 2)) !== null ? $_t78 : null))))) && z_truthy(((($_t79 = z_indexopt(z_indexopt(z_indexopt($v_st, 2), 2), 0)) !== null ? $_t79 : null) === ':Var'))));
    Z::$l = 46;
    if (z_truthy($v_simple)) {
      Z::$l = 47;
      foreach (z_foreach(f_Workspace_regions__var_counts(z_index(z_index($v_st, 2), 3), [])) as $_k305 => $_v305) {
        $v_c = $_v305;
        $v_n = $_k305;
        Z::$l = 47;
        if (z_truthy(!z_truthy(z_b_has_key($v_defined, $v_n)))) {
          Z::$l = 47;
          z_aset($v_bad, $v_n, true);
        }
      }
      Z::$l = 48;
      z_aset($v_defined, z_index(z_index(z_index($v_st, 2), 2), 2), true);
    } else {
      Z::$l = 50;
      foreach (z_foreach(f_Workspace_regions__var_counts($v_st, [])) as $_k306 => $_v306) {
        $v_c = $_v306;
        $v_n = $_k306;
        Z::$l = 50;
        if (z_truthy(!z_truthy(z_b_has_key($v_defined, $v_n)))) {
          Z::$l = 50;
          z_aset($v_bad, $v_n, true);
        }
      }
    }
  }
  Z::$l = 53;
  ($v_out = []);
  Z::$l = 54;
  ($v_priv = []);
  Z::$l = 55;
  foreach (z_foreach($v_cnt) as $_k307 => $_v307) {
    $v_c = $_v307;
    $v_n = $_k307;
    Z::$l = 56;
    if (z_truthy((z_truthy(z_b_has_key($v_bad, $v_n)) || z_truthy(((($_t80 = z_indexopt($v_fnCounts, $v_n)) !== null ? $_t80 : 0) !== $v_c))))) {
      Z::$l = 56;
      z_apush($v_out, $v_n);
    } else {
      Z::$l = 56;
      z_apush($v_priv, $v_n);
    }
  }
  Z::$l = 58;
  return [$v_out, $v_priv];
  return null;
}
function f_Workspace_emit_llvm__hex2($v_n) {
  $v_h = null;
  Z::$l = 1185;
  ($v_h = z_b_to_hex($v_n));
  Z::$l = 1186;
  return (z_truthy((z_cmp(z_b_strlen($v_h), 2) < 0)) ? z_concat('0', $v_h) : z_b_upper($v_h));
  return null;
}
function f_Workspace_emit_llvm__generate($v_ir, $v_triple) {
  $v_em = null;
  Z::$l = 1193;
  ($v_em = f_LlEmitter__new($v_ir));
  Z::$l = 1194;
  return f_zs_invoke($v_em, 'generate', [$v_triple]);
  return null;
}
function f_native__basename($v_p) {
  $v_i = null;
  Z::$l = 15;
  ($v_i = z_sub(z_b_strlen($v_p), 1));
  while (true) {
    Z::$l = 16;
    if (!z_truthy((z_truthy((z_cmp($v_i, 0) >= 0)) && z_truthy((z_b_substr($v_p, $v_i, 1) !== '/'))))) break;
    Z::$l = 16;
    z_last($_t81 = $v_i, $v_i = z_sub($_t81, 1), $_t81);
  }
  Z::$l = 17;
  return z_b_substr($v_p, z_add($v_i, 1));
  return null;
}
function f_native__stem($v_p) {
  $v_b = null;
  $v_dot = null;
  $v_i = null;
  Z::$l = 21;
  ($v_b = f_native__basename($v_p));
  Z::$l = 22;
  ($v_dot = z_neg(1));
  Z::$l = 23;
  ($v_i = 0);
  for (; z_truthy((z_cmp($v_i, z_b_strlen($v_b)) < 0)); z_last($_t82 = $v_i, $v_i = z_add($_t82, 1), $_t82)) {
    Z::$l = 23;
    if (z_truthy((z_b_substr($v_b, $v_i, 1) === '.'))) {
      Z::$l = 23;
      ($v_dot = $v_i);
    }
  }
  Z::$l = 24;
  return (z_truthy((z_cmp($v_dot, 0) > 0)) ? z_b_substr($v_b, 0, $v_dot) : $v_b);
  return null;
}
function f_native__zs_root($v_scriptDir) {
  $v_env = null;
  $v_d = null;
  $v_c = null;
  $v_f = null;
  Z::$l = 32;
  ($v_env = z_m_System_env('ZS_HOME'));
  Z::$l = 33;
  if (z_truthy((z_truthy(($v_env !== null)) && z_truthy(($v_env !== ''))))) {
    Z::$l = 33;
    return $v_env;
  }
  Z::$l = 34;
  ($v_d = $v_scriptDir);
  Z::$l = 35;
  if (z_truthy(!z_truthy(z_b_starts_with($v_d, '/')))) {
    Z::$l = 35;
    ($v_d = z_concat(z_concat((($_t83 = z_m_System_env('PWD')) !== null ? $_t83 : '.'), '/'), $v_d));
  }
  Z::$l = 36;
  foreach (z_foreach([z_concat($v_d, '/../share/z-sharp'), z_concat($v_d, '/share/z-sharp')]) as $_k310 => $_v310) {
    $v_c = $_v310;
    Z::$l = 37;
    if (z_truthy(z_m_File_exists(z_concat($v_c, '/runtime/native/zs_rt.c')))) {
      Z::$l = 37;
      return $v_c;
    }
  }
  Z::$l = 39;
  ($v_f = z_m_System_resolveImport(['Workspace', 'cli'], $v_scriptDir));
  Z::$l = 40;
  if (z_truthy(($v_f === null))) {
    Z::$l = 40;
    return null;
  }
  Z::$l = 41;
  return z_m_System_dirname(z_m_System_dirname($v_f));
  return null;
}
function f_native__frontend($v_file, $v_doLink) {
  $v_ast = null;
  $v___ex234 = null;
  $v_e = null;
  $v_r = null;
  $v_lk = null;
  Z::$l = 49;
  if (z_truthy(!z_truthy(z_m_File_exists($v_file)))) {
    Z::$l = 49;
    z_raise(new ZExc(0, z_concat('zsc: nie znaleziono pliku ', $v_file)));
  }
  try {
    Z::$l = 50;
    ($v_ast = f_Workspace_parser__parse(z_m_File_read($v_file)));
  } catch (ZEx $_ex311) {
    $_e311 = $_ex311->val;
    if (true) {
      $v___ex234 = $_e311;
      Z::$l = 50;
      if (z_truthy(f_zs_isa($v___ex234, 'Exception'))) {
        Z::$l = 50;
        ($v_e = $v___ex234);
        Z::$l = 53;
        z_raise(new ZExc(0, z_concat(z_concat($v_file, ':'), f_zs_invoke($v_e, 'getMessage', []))));
      } else {
        Z::$l = 50;
        z_throwv($v___ex234);
      }
    }
    else throw $_ex311;
  }
  Z::$l = 55;
  ($v_r = f_Workspace_sema__analyze($v_ast));
  Z::$l = 56;
  if (z_truthy(!z_truthy($v_doLink))) {
    Z::$l = 56;
    return [z_k('ast') => $v_ast, z_k('warnings') => z_index($v_r, 'warnings')];
  }
  Z::$l = 57;
  ($v_lk = f_Workspace_link__link($v_ast, $v_file));
  Z::$l = 58;
  if (z_truthy((z_cmp(z_b_count(z_index($v_lk, 'errors')), 0) > 0))) {
    Z::$l = 59;
    foreach (z_foreach(z_index($v_lk, 'errors')) as $_k312 => $_v312) {
      $v_e = $_v312;
      Z::$l = 59;
      z_eecho(z_concat(z_concat(z_concat(z_concat(z_concat(z_concat(z_index($v_e, 3), ':'), z_index($v_e, 0)), ': błąd ['), z_index($v_e, 1)), ']: '), z_index($v_e, 2)));
    }
    Z::$l = 60;
    z_raise(new ZExc(0, z_concat(z_concat('zsc: ', z_b_count(z_index($v_lk, 'errors'))), ' błędów linkowania modułów')));
  }
  Z::$l = 62;
  return [z_k('ast') => z_index($v_lk, 'ast'), z_k('warnings') => z_index($v_r, 'warnings')];
  return null;
}
function f_native__print_warnings($v_file, $v_warnings) {
  $v_w = null;
  Z::$l = 66;
  foreach (z_foreach($v_warnings) as $_k313 => $_v313) {
    $v_w = $_v313;
    Z::$l = 66;
    z_eecho(z_concat(z_concat(z_concat(z_concat($v_file, ':'), z_index($v_w, 0)), ': ostrzeżenie: '), z_index($v_w, 1)));
  }
  return null;
}
function f_native__lower_or_report($v_file, $v_ast) {
  $v_res = null;
  $v_e = null;
  Z::$l = 74;
  ($v_res = f_Workspace_ir__lower($v_ast));
  Z::$l = 75;
  if (z_truthy((z_b_count(z_index($v_res, 'errors')) === 0))) {
    Z::$l = 75;
    return $v_res;
  }
  Z::$l = 76;
  foreach (z_foreach(z_index($v_res, 'errors')) as $_k314 => $_v314) {
    $v_e = $_v314;
    Z::$l = 76;
    z_eecho(z_concat(z_concat(z_concat(z_concat(z_concat(z_concat($v_file, ':'), z_index($v_e, 0)), ': błąd ['), z_index($v_e, 1)), ']: '), z_index($v_e, 2)));
  }
  Z::$l = 77;
  z_eecho(z_concat(z_concat('zsc: ', z_b_count(z_index($v_res, 'errors'))), ' błędów — pełny język działa przez `zsc build --emit zbc` (uruchamianie: zsi)'));
  Z::$l = 78;
  return null;
  return null;
}
function f_native__opt_level($v_opts) {
  $v_o = null;
  Z::$l = 82;
  foreach (z_foreach(['-O0', '-O1', '-O2', '-O3', '-Os', '-Oz']) as $_k315 => $_v315) {
    $v_o = $_v315;
    Z::$l = 82;
    if (z_truthy(z_b_has_key(z_index($v_opts, 'flags'), $v_o))) {
      Z::$l = 82;
      return $v_o;
    }
  }
  Z::$l = 83;
  return '-O2';
  return null;
}
function f_native__toolchain($v_opts) {
  $v_tc = null;
  Z::$l = 90;
  ($v_tc = f_llvmtool__detect($v_opts));
  Z::$l = 91;
  if (z_truthy(!z_truthy(z_index($v_tc, 'ok')))) {
    Z::$l = 91;
    z_eecho(z_index($v_tc, 'err'));
    Z::$l = 91;
    return null;
  }
  Z::$l = 92;
  return $v_tc;
  return null;
}
function f_native__make_ll($v_file, $v_opts, $v_tc) {
  $v_fe = null;
  $v___ex235 = null;
  $v_e = null;
  $v_irr = null;
  $v_target = null;
  $v_explicit = null;
  $v_triple = null;
  $v_ll = null;
  $v___ex236 = null;
  try {
    Z::$l = 99;
    ($v_fe = f_native__frontend($v_file, true));
  } catch (ZEx $_ex316) {
    $_e316 = $_ex316->val;
    if (true) {
      $v___ex235 = $_e316;
      Z::$l = 99;
      if (z_truthy(f_zs_isa($v___ex235, 'Exception'))) {
        Z::$l = 99;
        ($v_e = $v___ex235);
        Z::$l = 100;
        z_eecho(f_zs_invoke($v_e, 'getMessage', []));
        Z::$l = 100;
        return null;
      } else {
        Z::$l = 99;
        z_throwv($v___ex235);
      }
    }
    else throw $_ex316;
  }
  Z::$l = 101;
  f_native__print_warnings($v_file, z_index($v_fe, 'warnings'));
  Z::$l = 102;
  ($v_irr = f_native__lower_or_report($v_file, z_index($v_fe, 'ast')));
  Z::$l = 103;
  if (z_truthy(($v_irr === null))) {
    Z::$l = 103;
    return null;
  }
  Z::$l = 104;
  ($v_target = (($_t84 = z_indexopt(z_indexopt($v_opts, 'options'), 'target')) !== null ? $_t84 : 'host'));
  Z::$l = 105;
  ($v_explicit = ($v_target !== 'host'));
  Z::$l = 106;
  ($v_triple = (z_truthy($v_explicit) ? $v_target : f_llvmtool__host_triple($v_tc)));
  try {
    Z::$l = 107;
    ($v_ll = f_Workspace_emit_llvm__generate($v_irr, $v_triple));
  } catch (ZEx $_ex317) {
    $_e317 = $_ex317->val;
    if (true) {
      $v___ex236 = $_e317;
      Z::$l = 107;
      if (z_truthy(f_zs_isa($v___ex236, 'Exception'))) {
        Z::$l = 107;
        ($v_e = $v___ex236);
        Z::$l = 108;
        z_eecho(z_concat('zsc: błąd wewnętrzny backendu LLVM: ', f_zs_invoke($v_e, 'getMessage', [])));
        Z::$l = 108;
        return null;
      } else {
        Z::$l = 107;
        z_throwv($v___ex236);
      }
    }
    else throw $_ex317;
  }
  Z::$l = 109;
  return [z_k('ll') => $v_ll, z_k('triple') => $v_triple, z_k('explicit') => $v_explicit];
  return null;
}
function f_native__compile($v_file, $v_kind, $v_out, $v_opts, $v_scriptDir) {
  $v_tc = null;
  $v_m = null;
  $v_level = null;
  $v_tmp = null;
  $v_keep = null;
  $v_ll = null;
  $v_bc = null;
  $v_bcOut = null;
  $v_r = null;
  $v_ft = null;
  $v_o1 = null;
  $v_root = null;
  $v_rt = null;
  Z::$l = 116;
  ($v_tc = f_native__toolchain($v_opts));
  Z::$l = 117;
  if (z_truthy(($v_tc === null))) {
    Z::$l = 117;
    return 3;
  }
  Z::$l = 118;
  ($v_m = f_native__make_ll($v_file, $v_opts, $v_tc));
  Z::$l = 119;
  if (z_truthy(($v_m === null))) {
    Z::$l = 119;
    return 1;
  }
  Z::$l = 120;
  if (z_truthy(($v_kind === 'll'))) {
    Z::$l = 120;
    z_m_File_write($v_out, z_index($v_m, 'll'));
    Z::$l = 120;
    return 0;
  }
  Z::$l = 121;
  ($v_level = f_native__opt_level($v_opts));
  Z::$l = 122;
  ($v_tmp = f_llvmtool__tmp_dir());
  Z::$l = 123;
  ($v_keep = z_b_has_key(z_index($v_opts, 'flags'), '--keep-temps'));
  Z::$l = 124;
  ($v_ll = z_concat($v_tmp, '/prog.ll'));
  Z::$l = 125;
  ($v_bc = z_concat($v_tmp, '/prog.bc'));
  Z::$l = 126;
  z_m_File_write($v_ll, z_index($v_m, 'll'));
  Z::$l = 127;
  ($v_bcOut = (z_truthy(($v_kind === 'bc')) ? $v_out : $v_bc));
  Z::$l = 128;
  ($v_r = f_llvmtool__optimize($v_tc, $v_ll, $v_bcOut, $v_level, z_index($v_m, 'triple')));
  Z::$l = 129;
  if (z_truthy(!z_truthy(z_index($v_r, 'ok')))) {
    Z::$l = 130;
    z_eecho(z_index($v_r, 'err'));
    Z::$l = 131;
    z_eecho(z_concat(z_concat('zsc: błąd wewnętrzny: wygenerowany LLVM IR nie przeszedł opt (zachowano ', $v_tmp), ')'));
    Z::$l = 132;
    return 1;
  }
  Z::$l = 134;
  if (z_truthy(($v_kind === 'bc'))) {
    Z::$l = 134;
    if (z_truthy(!z_truthy($v_keep))) {
      Z::$l = 134;
      f_llvmtool__cleanup($v_tmp);
    }
    Z::$l = 134;
    return 0;
  }
  Z::$l = 135;
  ($v_ft = (z_truthy(($v_kind === 'asm')) ? 'asm' : 'obj'));
  Z::$l = 136;
  ($v_o1 = (z_truthy((z_truthy(($v_kind === 'asm')) || z_truthy(($v_kind === 'obj')))) ? $v_out : z_concat($v_tmp, '/prog.o')));
  Z::$l = 137;
  ($v_r = f_llvmtool__codegen($v_tc, $v_bc, $v_o1, $v_level, z_index($v_m, 'triple'), $v_ft, z_index($v_m, 'explicit')));
  Z::$l = 138;
  if (z_truthy(!z_truthy(z_index($v_r, 'ok')))) {
    Z::$l = 138;
    z_eecho(z_index($v_r, 'err'));
    Z::$l = 138;
    return 1;
  }
  Z::$l = 139;
  if (z_truthy((z_truthy(($v_kind === 'asm')) || z_truthy(($v_kind === 'obj'))))) {
    Z::$l = 140;
    if (z_truthy(!z_truthy($v_keep))) {
      Z::$l = 140;
      f_llvmtool__cleanup($v_tmp);
    }
    Z::$l = 141;
    return 0;
  }
  Z::$l = 143;
  ($v_root = f_native__zs_root($v_scriptDir));
  Z::$l = 144;
  if (z_truthy(($v_root === null))) {
    Z::$l = 144;
    z_eecho('zsc: nie znaleziono Z-Sharp — ustaw ZS_HOME');
    Z::$l = 144;
    return 1;
  }
  Z::$l = 145;
  ($v_rt = f_llvmtool__runtime_obj($v_tc, $v_root, z_index($v_m, 'triple'), $v_opts, $v_level));
  Z::$l = 146;
  if (z_truthy(!z_truthy(z_index($v_rt, 'ok')))) {
    Z::$l = 146;
    z_eecho(z_index($v_rt, 'err'));
    Z::$l = 146;
    return 1;
  }
  Z::$l = 147;
  ($v_r = f_llvmtool__link($v_tc, [$v_o1, z_index($v_rt, 'path')], $v_out, z_index($v_m, 'triple'), z_index($v_m, 'explicit'), $v_opts));
  Z::$l = 148;
  if (z_truthy(!z_truthy(z_index($v_r, 'ok')))) {
    Z::$l = 148;
    z_eecho(z_index($v_r, 'err'));
    Z::$l = 148;
    return 1;
  }
  Z::$l = 149;
  if (z_truthy(!z_truthy($v_keep))) {
    Z::$l = 149;
    f_llvmtool__cleanup($v_tmp);
  }
  Z::$l = 150;
  return 0;
  return null;
}
function f_native__build_exe($v_file, $v_out, $v_opts, $v_scriptDir) {
  Z::$l = 154;
  return f_native__compile($v_file, 'exe', $v_out, $v_opts, $v_scriptDir);
  return null;
}
function f_usage() {
  Z::$l = 13;
  z_echo('zsc — kompilator Z# 0.0.1 (backend LLVM >= 21)');
  Z::$l = 14;
  z_echo('użycie:');
  Z::$l = 15;
  z_echo('  zsc build <plik.zs> [-o <wyjście>] [--emit exe|obj|asm|bc|ll|ir|zbc] [-O0|-O1|-O2|-O3|-Os|-Oz] [--target <triple>]');
  Z::$l = 16;
  z_echo('      Z# -> AST -> sema -> IR -> LLVM IR -> opt -> llc -> linker (+ runtime). Domyślnie: plik wykonywalny.');
  Z::$l = 17;
  z_echo('      -c = --emit obj, -S = --emit asm. --keep-temps zostawia pliki pośrednie.');
  Z::$l = 18;
  z_echo('  zsc run <plik.zs> [-- argumenty...]    zbuduj i uruchom (kod wyjścia programu = kod wyjścia zsc)');
  Z::$l = 19;
  z_echo('  zsc check [--strict] [--native] <plik.zs>   składnia + sema (--native: zgodność z backendem natywnym)');
  Z::$l = 20;
  z_echo('  zsc analyze <plik.zs>                  analiza ucieczki: klasy pamięci ZAMM dla alokacji');
  Z::$l = 21;
  z_echo('  zsc runtime [-o <plik.o>]              zbuduj obiekt runtime (zs_rt.c) i wypisz ścieżkę');
  Z::$l = 22;
  z_echo('  zsc toolchain                          wykryte narzędzia LLVM i ich wersje');
  Z::$l = 23;
  z_echo('  zsc stages | --tokens <plik> | --version | --help');
  Z::$l = 24;
  z_echo('opcje toolchaina: --llvm-bin <katalog>  --linker <sterownik>  --runtime-obj <plik.o>  --ldflags "..."  --allow-older-llvm');
  Z::$l = 25;
  z_echo('kody wyjścia: 0 ok, 1 błąd (składnia, konstrukcja spoza podzbioru, błąd narzędzia), 2 użycie, 3 brak/za stary toolchain LLVM');
  Z::$l = 26;
  z_echo('zmienne: ZS_HOME, ZS_LLVM_BIN, ZS_LINKER, ZS_RUNTIME_OBJ, ZS_CACHE, ZS_ALLOW_OLD_LLVM');
  return null;
}
function f_check($v_file, $v_strict, $v_nativeMode) {
  $v_fe = null;
  $v___ex237 = null;
  $v_e = null;
  $v_file = z_chk($v_file, 'string', 'argument $file funkcji check');
  $v_strict = z_chk($v_strict, 'bool', 'argument $strict funkcji check');
  $v_nativeMode = z_chk($v_nativeMode, 'bool', 'argument $nativeMode funkcji check');
  try {
    Z::$l = 30;
    ($v_fe = f_native__frontend($v_file, $v_nativeMode));
  } catch (ZEx $_ex318) {
    $_e318 = $_ex318->val;
    if (true) {
      $v___ex237 = $_e318;
      Z::$l = 30;
      if (z_truthy(f_zs_isa($v___ex237, 'Exception'))) {
        Z::$l = 30;
        ($v_e = $v___ex237);
        Z::$l = 31;
        z_eecho(f_zs_invoke($v_e, 'getMessage', []));
        Z::$l = 31;
        return z_chk(1, 'int', 'wartość zwracana funkcji check');
      } else {
        Z::$l = 30;
        z_throwv($v___ex237);
      }
    }
    else throw $_ex318;
  }
  Z::$l = 32;
  f_native__print_warnings($v_file, z_index($v_fe, 'warnings'));
  Z::$l = 33;
  if (z_truthy((z_truthy($v_strict) && z_truthy((z_cmp(z_b_count(z_index($v_fe, 'warnings')), 0) > 0))))) {
    Z::$l = 33;
    return z_chk(1, 'int', 'wartość zwracana funkcji check');
  }
  Z::$l = 34;
  if (z_truthy((z_truthy($v_nativeMode) && z_truthy((f_native__lower_or_report($v_file, z_index($v_fe, 'ast')) === null))))) {
    Z::$l = 34;
    return z_chk(1, 'int', 'wartość zwracana funkcji check');
  }
  Z::$l = 35;
  return z_chk(0, 'int', 'wartość zwracana funkcji check');
  return null;
}
function f_analyze($v_file) {
  $v_fe = null;
  $v___ex238 = null;
  $v_e = null;
  $v_file = z_chk($v_file, 'string', 'argument $file funkcji analyze');
  try {
    Z::$l = 39;
    ($v_fe = f_native__frontend($v_file, false));
  } catch (ZEx $_ex319) {
    $_e319 = $_ex319->val;
    if (true) {
      $v___ex238 = $_e319;
      Z::$l = 39;
      if (z_truthy(f_zs_isa($v___ex238, 'Exception'))) {
        Z::$l = 39;
        ($v_e = $v___ex238);
        Z::$l = 40;
        z_eecho(f_zs_invoke($v_e, 'getMessage', []));
        Z::$l = 40;
        return z_chk(1, 'int', 'wartość zwracana funkcji analyze');
      } else {
        Z::$l = 39;
        z_throwv($v___ex238);
      }
    }
    else throw $_ex319;
  }
  Z::$l = 41;
  z_echo(f_Workspace_sema__report(f_Workspace_sema__analyze(z_index($v_fe, 'ast'))));
  Z::$l = 42;
  return z_chk(0, 'int', 'wartość zwracana funkcji analyze');
  return null;
}
function f_build_zbc($v_file, $v_out) {
  $v_data = null;
  $v___ex239 = null;
  $v_e = null;
  $v_file = z_chk($v_file, 'string', 'argument $file funkcji build_zbc');
  $v_out = z_chk($v_out, 'string', 'argument $out funkcji build_zbc');
  Z::$l = 46;
  if (z_truthy((f_check($v_file, false, false) !== 0))) {
    Z::$l = 46;
    return z_chk(1, 'int', 'wartość zwracana funkcji build_zbc');
  }
  try {
    Z::$l = 47;
    ($v_data = f_Workspace_zbc__bundle($v_file));
  } catch (ZEx $_ex320) {
    $_e320 = $_ex320->val;
    if (true) {
      $v___ex239 = $_e320;
      Z::$l = 47;
      if (z_truthy(f_zs_isa($v___ex239, 'Exception'))) {
        Z::$l = 47;
        ($v_e = $v___ex239);
        Z::$l = 48;
        z_eecho(z_concat('zsc: ', f_zs_invoke($v_e, 'getMessage', [])));
        Z::$l = 48;
        return z_chk(1, 'int', 'wartość zwracana funkcji build_zbc');
      } else {
        Z::$l = 47;
        z_throwv($v___ex239);
      }
    }
    else throw $_ex320;
  }
  Z::$l = 49;
  z_m_File_write($v_out, $v_data);
  Z::$l = 50;
  z_echo(z_concat(z_concat(z_concat(z_concat('zsc: ', $v_out), ' ('), z_b_strlen($v_data)), ' B)'));
  Z::$l = 51;
  return z_chk(0, 'int', 'wartość zwracana funkcji build_zbc');
  return null;
}
function f_emit_kind($v_o, $v_flags) {
  $v_emit = null;
  Z::$l = 55;
  ($v_emit = (($_t85 = z_indexopt($v_o, 'emit')) !== null ? $_t85 : null));
  Z::$l = 56;
  if (z_truthy((z_truthy(($v_emit === null)) && z_truthy(z_b_has_key($v_flags, '-c'))))) {
    Z::$l = 56;
    ($v_emit = 'obj');
  }
  Z::$l = 57;
  if (z_truthy((z_truthy(($v_emit === null)) && z_truthy(z_b_has_key($v_flags, '-S'))))) {
    Z::$l = 57;
    ($v_emit = 'asm');
  }
  Z::$l = 58;
  return (($_t86 = $v_emit) !== null ? $_t86 : 'exe');
  return null;
}
function f_default_out($v_stem, $v_kind) {
  Z::$l = 62;
  if (z_truthy(($v_kind === 'll'))) {
    Z::$l = 62;
    return z_concat($v_stem, '.ll');
  }
  Z::$l = 63;
  if (z_truthy(($v_kind === 'bc'))) {
    Z::$l = 63;
    return z_concat($v_stem, '.bc');
  }
  Z::$l = 64;
  if (z_truthy(($v_kind === 'obj'))) {
    Z::$l = 64;
    return z_concat($v_stem, '.o');
  }
  Z::$l = 65;
  if (z_truthy(($v_kind === 'asm'))) {
    Z::$l = 65;
    return z_concat($v_stem, '.s');
  }
  Z::$l = 66;
  if (z_truthy(($v_kind === 'zbc'))) {
    Z::$l = 66;
    return z_concat($v_stem, '.zbc');
  }
  Z::$l = 67;
  return $v_stem;
  return null;
}
function f_build($v_file, $v_opts, $v_scriptDir) {
  $v_o = null;
  $v_kind = null;
  $v_stem = null;
  $v_fe = null;
  $v___ex240 = null;
  $v_e = null;
  $v_res = null;
  $v_out = null;
  $v_rc = null;
  $v_file = z_chk($v_file, 'string', 'argument $file funkcji build');
  Z::$l = 71;
  ($v_o = z_index($v_opts, 'options'));
  Z::$l = 72;
  ($v_kind = f_emit_kind($v_o, z_index($v_opts, 'flags')));
  Z::$l = 73;
  if (z_truthy(!z_truthy(z_b_in_array($v_kind, ['exe', 'obj', 'asm', 'bc', 'll', 'ir', 'zbc'])))) {
    Z::$l = 73;
    z_eecho(z_concat(z_concat('zsc: nieznany --emit ', $v_kind), ' (exe|obj|asm|bc|ll|ir|zbc)'));
    Z::$l = 73;
    return z_chk(2, 'int', 'wartość zwracana funkcji build');
  }
  Z::$l = 74;
  if (z_truthy((z_truthy(z_b_has_key($v_o, 'backend')) && z_truthy((z_index($v_o, 'backend') !== 'llvm'))))) {
    Z::$l = 75;
    z_eecho(z_concat(z_concat('zsc: jedynym backendem jest LLVM (--backend ', z_index($v_o, 'backend')), ' nie istnieje; transpilacja do C: zst, frontend gcc: zzc)'));
    Z::$l = 76;
    return z_chk(2, 'int', 'wartość zwracana funkcji build');
  }
  Z::$l = 78;
  ($v_stem = f_native__stem($v_file));
  Z::$l = 79;
  if (z_truthy(($v_kind === 'zbc'))) {
    Z::$l = 79;
    return z_chk(f_build_zbc($v_file, (($_t87 = z_indexopt($v_o, 'o')) !== null ? $_t87 : f_default_out($v_stem, 'zbc'))), 'int', 'wartość zwracana funkcji build');
  }
  Z::$l = 80;
  if (z_truthy(($v_kind === 'ir'))) {
    try {
      Z::$l = 81;
      ($v_fe = f_native__frontend($v_file, true));
    } catch (ZEx $_ex321) {
      $_e321 = $_ex321->val;
      if (true) {
        $v___ex240 = $_e321;
        Z::$l = 81;
        if (z_truthy(f_zs_isa($v___ex240, 'Exception'))) {
          Z::$l = 81;
          ($v_e = $v___ex240);
          Z::$l = 82;
          z_eecho(f_zs_invoke($v_e, 'getMessage', []));
          Z::$l = 82;
          return z_chk(1, 'int', 'wartość zwracana funkcji build');
        } else {
          Z::$l = 81;
          z_throwv($v___ex240);
        }
      }
      else throw $_ex321;
    }
    Z::$l = 83;
    ($v_res = f_Workspace_ir__lower(z_index($v_fe, 'ast')));
    Z::$l = 84;
    z_echo(f_Workspace_ir__report($v_res));
    Z::$l = 85;
    foreach (z_foreach(z_index($v_res, 'errors')) as $_k322 => $_v322) {
      $v_e = $_v322;
      Z::$l = 85;
      z_eecho(z_concat(z_concat(z_concat(z_concat(z_concat(z_concat($v_file, ':'), z_index($v_e, 0)), ': błąd ['), z_index($v_e, 1)), ']: '), z_index($v_e, 2)));
    }
    Z::$l = 86;
    return z_chk((z_truthy((z_cmp(z_b_count(z_index($v_res, 'errors')), 0) > 0)) ? 1 : 0), 'int', 'wartość zwracana funkcji build');
  }
  Z::$l = 88;
  ($v_out = (($_t88 = z_indexopt($v_o, 'o')) !== null ? $_t88 : f_default_out($v_stem, $v_kind)));
  Z::$l = 89;
  ($v_rc = f_native__compile($v_file, $v_kind, $v_out, $v_opts, $v_scriptDir));
  Z::$l = 90;
  if (z_truthy(($v_rc === 0))) {
    Z::$l = 90;
    z_echo(z_concat('zsc: ', $v_out));
  }
  Z::$l = 91;
  return z_chk($v_rc, 'int', 'wartość zwracana funkcji build');
  return null;
}
function f_run($v_file, $v_opts, $v_extra, $v_scriptDir) {
  $v_dir = null;
  $v_tmp = null;
  $v_exe = null;
  $v_rc = null;
  $v_status = null;
  $v_file = z_chk($v_file, 'string', 'argument $file funkcji run');
  Z::$l = 95;
  ($v_dir = (($_t89 = z_m_System_env('TMPDIR')) !== null ? $_t89 : '/tmp'));
  Z::$l = 96;
  ($v_tmp = z_concat(z_concat(z_concat(z_concat($v_dir, '/zsc-run-'), z_m_System_pid()), '-'), z_m_System_nowNanos()));
  Z::$l = 97;
  z_m_Directory_create($v_tmp);
  Z::$l = 98;
  ($v_exe = z_concat(z_concat($v_tmp, '/'), f_native__stem($v_file)));
  Z::$l = 99;
  ($v_rc = f_native__compile($v_file, 'exe', $v_exe, $v_opts, $v_scriptDir));
  Z::$l = 100;
  if (z_truthy(($v_rc !== 0))) {
    Z::$l = 100;
    f_llvmtool__cleanup($v_tmp);
    Z::$l = 100;
    return z_chk($v_rc, 'int', 'wartość zwracana funkcji run');
  }
  Z::$l = 101;
  ($v_status = z_m_Process_exec($v_exe, $v_extra));
  Z::$l = 102;
  f_llvmtool__cleanup($v_tmp);
  Z::$l = 103;
  return z_chk($v_status, 'int', 'wartość zwracana funkcji run');
  return null;
}
function f_toolchain_cmd($v_opts) {
  $v_tc = null;
  $v_l = null;
  Z::$l = 107;
  ($v_tc = f_llvmtool__detect($v_opts));
  Z::$l = 108;
  z_echo(z_concat('wymagany LLVM >= ', z_index($v_tc, 'min')));
  Z::$l = 109;
  foreach (z_foreach(z_index($v_tc, 'lines')) as $_k323 => $_v323) {
    $v_l = $_v323;
    Z::$l = 109;
    z_echo(z_concat('  ', $v_l));
  }
  Z::$l = 110;
  if (z_truthy(!z_truthy(z_index($v_tc, 'ok')))) {
    Z::$l = 110;
    z_eecho(z_index($v_tc, 'err'));
    Z::$l = 110;
    return z_chk(3, 'int', 'wartość zwracana funkcji toolchain_cmd');
  }
  Z::$l = 111;
  z_echo(z_concat('host: ', f_llvmtool__host_triple($v_tc)));
  Z::$l = 112;
  z_echo(z_concat('cache: ', f_llvmtool__cache_dir()));
  Z::$l = 113;
  return z_chk(0, 'int', 'wartość zwracana funkcji toolchain_cmd');
  return null;
}
function f_runtime_cmd($v_opts, $v_scriptDir) {
  $v_tc = null;
  $v_root = null;
  $v_target = null;
  $v_triple = null;
  $v_r = null;
  $v_dest = null;
  Z::$l = 117;
  ($v_tc = f_native__toolchain($v_opts));
  Z::$l = 118;
  if (z_truthy(($v_tc === null))) {
    Z::$l = 118;
    return z_chk(3, 'int', 'wartość zwracana funkcji runtime_cmd');
  }
  Z::$l = 119;
  ($v_root = f_native__zs_root($v_scriptDir));
  Z::$l = 120;
  if (z_truthy(($v_root === null))) {
    Z::$l = 120;
    z_eecho('zsc: nie znaleziono Z-Sharp — ustaw ZS_HOME');
    Z::$l = 120;
    return z_chk(1, 'int', 'wartość zwracana funkcji runtime_cmd');
  }
  Z::$l = 121;
  ($v_target = (($_t90 = z_indexopt(z_indexopt($v_opts, 'options'), 'target')) !== null ? $_t90 : 'host'));
  Z::$l = 122;
  ($v_triple = (z_truthy(($v_target === 'host')) ? f_llvmtool__host_triple($v_tc) : $v_target));
  Z::$l = 123;
  ($v_r = f_llvmtool__runtime_obj($v_tc, $v_root, $v_triple, $v_opts, f_native__opt_level($v_opts)));
  Z::$l = 124;
  if (z_truthy(!z_truthy(z_index($v_r, 'ok')))) {
    Z::$l = 124;
    z_eecho(z_index($v_r, 'err'));
    Z::$l = 124;
    return z_chk(1, 'int', 'wartość zwracana funkcji runtime_cmd');
  }
  Z::$l = 125;
  ($v_dest = (($_t91 = z_indexopt(z_indexopt($v_opts, 'options'), 'o')) !== null ? $_t91 : null));
  Z::$l = 126;
  if (z_truthy(($v_dest !== null))) {
    Z::$l = 126;
    z_m_File_write($v_dest, z_m_File_read(z_index($v_r, 'path')));
    Z::$l = 126;
    z_echo($v_dest);
    Z::$l = 126;
    return z_chk(0, 'int', 'wartość zwracana funkcji runtime_cmd');
  }
  Z::$l = 127;
  z_echo(z_index($v_r, 'path'));
  Z::$l = 128;
  return z_chk(0, 'int', 'wartość zwracana funkcji runtime_cmd');
  return null;
}
function f_main() {
  $v_argv = null;
  $v_scriptDir = null;
  $v_r = null;
  $v_pos = null;
  $v_flags = null;
  $v_t = null;
  $v_cmd = null;
  $v_s = null;
  Z::$l = 132;
  ($v_argv = z_m_System_args());
  Z::$l = 133;
  ($v_scriptDir = z_m_System_dirname(z_index($v_argv, 0)));
  Z::$l = 134;
  ($v_r = f_Workspace_cli__parse($v_argv, ['o', 'target', 'emit', 'backend', 'llvm-bin', 'linker', 'runtime-obj', 'ldflags']));
  Z::$l = 135;
  ($v_pos = z_index($v_r, 'positional'));
  Z::$l = 136;
  ($v_flags = z_index($v_r, 'flags'));
  Z::$l = 137;
  if (z_truthy(z_b_has_key($v_flags, '--version'))) {
    Z::$l = 137;
    z_echo(z_concat('zsc ', z_m_System_version()));
    Z::$l = 137;
    return z_chk(0, 'int', 'wartość zwracana funkcji main');
  }
  Z::$l = 138;
  if (z_truthy((z_truthy(z_b_has_key($v_flags, '--help')) || z_truthy(z_b_has_key($v_flags, '-h'))))) {
    Z::$l = 138;
    f_usage();
    Z::$l = 138;
    return z_chk(0, 'int', 'wartość zwracana funkcji main');
  }
  Z::$l = 139;
  if (z_truthy((z_truthy(z_b_has_key($v_flags, '--tokens')) && z_truthy((z_b_count($v_pos) === 1))))) {
    Z::$l = 140;
    foreach (z_foreach(f_Workspace_lexer__tokenize(z_m_File_read(z_index($v_pos, 0)), false)) as $_k324 => $_v324) {
      $v_t = $_v324;
      Z::$l = 140;
      z_echo(z_concat(z_concat(z_concat(z_concat(z_concat(z_concat(z_index($v_t, 'line'), ':'), z_index($v_t, 'col')), '	'), z_index($v_t, 'kind')), '	'), z_index($v_t, 'text')));
    }
    Z::$l = 141;
    return z_chk(0, 'int', 'wartość zwracana funkcji main');
  }
  Z::$l = 143;
  if (z_truthy((z_b_count($v_pos) === 0))) {
    Z::$l = 143;
    f_usage();
    Z::$l = 143;
    return z_chk(2, 'int', 'wartość zwracana funkcji main');
  }
  Z::$l = 144;
  ($v_cmd = z_index($v_pos, 0));
  Z::$l = 145;
  if (z_truthy(($v_cmd === 'stages'))) {
    Z::$l = 146;
    foreach (z_foreach(f_pipeline__stages()) as $_k325 => $_v325) {
      $v_s = $_v325;
      Z::$l = 146;
      z_echo(z_concat(z_concat(z_b_pad_right(z_index($v_s, 'name'), 20), z_b_pad_right(z_index($v_s, 'status'), 8)), z_index($v_s, 'impl')));
    }
    Z::$l = 147;
    return z_chk(0, 'int', 'wartość zwracana funkcji main');
  }
  Z::$l = 149;
  if (z_truthy(($v_cmd === 'toolchain'))) {
    Z::$l = 149;
    return z_chk(f_toolchain_cmd($v_r), 'int', 'wartość zwracana funkcji main');
  }
  Z::$l = 150;
  if (z_truthy(($v_cmd === 'runtime'))) {
    Z::$l = 150;
    return z_chk(f_runtime_cmd($v_r, $v_scriptDir), 'int', 'wartość zwracana funkcji main');
  }
  Z::$l = 151;
  if (z_truthy((z_cmp(z_b_count($v_pos), 2) < 0))) {
    Z::$l = 151;
    f_usage();
    Z::$l = 151;
    return z_chk(2, 'int', 'wartość zwracana funkcji main');
  }
  Z::$l = 152;
  if (z_truthy(($v_cmd === 'check'))) {
    Z::$l = 152;
    return z_chk(f_check(z_index($v_pos, 1), z_b_has_key($v_flags, '--strict'), z_b_has_key($v_flags, '--native')), 'int', 'wartość zwracana funkcji main');
  }
  Z::$l = 153;
  if (z_truthy(($v_cmd === 'analyze'))) {
    Z::$l = 153;
    return z_chk(f_analyze(z_index($v_pos, 1)), 'int', 'wartość zwracana funkcji main');
  }
  Z::$l = 154;
  if (z_truthy(($v_cmd === 'build'))) {
    Z::$l = 154;
    return z_chk(f_build(z_index($v_pos, 1), $v_r, $v_scriptDir), 'int', 'wartość zwracana funkcji main');
  }
  Z::$l = 155;
  if (z_truthy(($v_cmd === 'run'))) {
    Z::$l = 155;
    return z_chk(f_run(z_index($v_pos, 1), $v_r, z_b_array_slice($v_pos, 2, z_sub(z_b_count($v_pos), 2)), $v_scriptDir), 'int', 'wartość zwracana funkcji main');
  }
  Z::$l = 156;
  z_eecho(z_concat('zsc: nieznane polecenie ', $v_cmd));
  Z::$l = 157;
  f_usage();
  Z::$l = 158;
  return z_chk(2, 'int', 'wartość zwracana funkcji main');
  return null;
}
function zs_top() {
  Z::$l = 161;
  z_exit(f_main());
}
z_run('zs_top', 'f_main', true);
