// wygenerowane przez zst (cel js) — nie edytuj
"use strict";
const Z = (function(require){ const module = { exports: {} };
"use strict";
// Runtime Z# dla celu js (Node >= 16). Semantyka zgodna z runtime/native/zs_rt.c:
//  int = number (bezpieczny zakres) albo bigint (do int64, przepełnienie = błąd), float = Z.F, napisy = bajty UTF-8
//  (strlen/substr/index_of po bajtach), tablice uporządkowane z kopiowaniem przy zapisie (rc), wyjątki ZExc / ZObj.
const fs = require("fs");
const cp = require("child_process");
const nodePath = require("path");

class F { constructor(v) { this.v = v; } }
class ZExc { constructor(kind, msg) { this.kind = kind; this.msg = msg; this.line = 0; } }
class ZObj { constructor(cls) { this.cls = cls; this.f = new ZArr(); } }
class ZFn { constructor(id, cap) { this.id = id; this.cap = cap; } }
class ZArr {
  constructor() { this.keys = []; this.vals = []; this.map = new Map(); this.next = 0; this.rc = 1; }
}
const MIN64 = -(2n ** 63n), MAX64 = 2n ** 63n - 1n;

// ───── wyjście (buforowane, bajtowo-bezpieczne) ─────
let outBuf = [], outLen = 0;
function flush() { if (outLen) { const s = outBuf.join(""); outBuf = []; outLen = 0; writeAll(1, s); } }
function writeAll(fd, s) {
  const b = Buffer.from(s, "utf8"); let off = 0;
  while (off < b.length) {
    try { off += fs.writeSync(fd, b, off, b.length - off); }
    catch (e) { if (e.code === "EAGAIN") continue; if (e.code === "EPIPE") return; throw e; }
  }
}
function out(s) { outBuf.push(s); outLen += s.length; if (outLen > 65536) flush(); }
function err(s) { flush(); writeAll(2, s); }

let curLine = 0;
function setLine(n) { curLine = n; }
function raise(e) {
  if (e instanceof ZExc) { if (e.line === 0) e.line = curLine; }
  else if (e instanceof ZObj) { const l = e.f.get("line"); if (!(typeof l === "number") || l === 0) aset(e.f, "line", curLine); }
  throw e;
}
function die(msg) { const e = new ZExc(1, msg); e.line = curLine; throw e; }
function throwV(x) { if (!(x instanceof ZExc) && !(x instanceof ZObj)) die("throw wymaga obiektu typu Throwable"); raise(x); }
function toExc(e) {
  if (e instanceof ZExc || e instanceof ZObj) return e;
  if (e && e.__exit) throw e;
  if (e instanceof RangeError) { const x = new ZExc(1, "przepełnienie stosu: " + e.message); x.line = curLine; return x; }
  throw e;
}
function excIs(x, kind) { return x instanceof ZExc && (kind === 0 || x.kind === kind); }
function getMessage(x) { if (!(x instanceof ZExc)) die("wywołanie metody `getMessage` na wartości typu " + tn(x)); return x.msg; }

// ───── typy ─────
const isInt = v => typeof v === "number" || typeof v === "bigint";
const isNum = v => isInt(v) || v instanceof F;
function tn(v) {
  if (v === null) return "null"; if (typeof v === "boolean") return "bool"; if (isInt(v)) return "int";
  if (v instanceof F) return "float"; if (typeof v === "string") return "string"; if (v instanceof ZArr) return "array";
  if (v instanceof ZObj) return v.cls; if (v instanceof ZFn) return "function"; return "object";
}
const asF = v => v instanceof F ? v.v : Number(v);
const normI = b => (b >= -9007199254740991n && b <= 9007199254740991n) ? Number(b) : b;
function chkI(b) { if (b < MIN64 || b > MAX64) die("przepełnienie liczby całkowitej"); return normI(b); }

// ───── bajty UTF-8 ─────
const NONASCII = /[^\x00-\x7f]/;
const bl = s => NONASCII.test(s) ? Buffer.byteLength(s, "utf8") : s.length;
const toB = s => Buffer.from(s, "utf8");
const fromB = b => b.toString("utf8");

// ───── tekst ─────
function fmtFloat(f) {
  if (Number.isNaN(f)) return "NaN";
  if (!Number.isFinite(f)) return f > 0 ? "Infinity" : "-Infinity";
  if (Math.floor(f) === f && Math.abs(f) < 1e15) return (Object.is(f, -0) ? "-0" : String(f)) + ".0";
  let s = String(f);
  if (s.indexOf("e") < 0) return s;
  const neg = s[0] === "-"; if (neg) s = s.slice(1);
  const [m, ex] = s.split("e"); const e = parseInt(ex, 10);
  const dot = m.indexOf("."); const digits = m.replace(".", ""); const ip = dot < 0 ? m.length : dot; const point = ip + e;
  let r;
  if (point <= 0) r = "0." + "0".repeat(-point) + digits;
  else if (point >= digits.length) r = digits + "0".repeat(point - digits.length);
  else r = digits.slice(0, point) + "." + digits.slice(point);
  return (neg ? "-" : "") + r;
}
function dumpStr(s) {
  let o = '"';
  const b = toB(s);
  for (let i = 0; i < b.length; i++) {
    const c = b[i];
    if (c === 34) o += '\\"'; else if (c === 92) o += "\\\\"; else if (c === 10) o += "\\n"; else if (c === 13) o += "\\r";
    else if (c === 9) o += "\\t"; else if (c === 0) o += "\\0"; else if (c < 0x20 || c === 0x7f) o += "\\u{" + c.toString(16) + "}";
    else if (c < 0x80) o += String.fromCharCode(c);
    else { let j = i + 1; while (j < b.length && (b[j] & 0xC0) === 0x80) j++; o += fromB(b.subarray(i, j)); i = j - 1; }
  }
  return o + '"';
}
function text(v, dump) {
  if (v === null) return "null"; if (v === true) return "true"; if (v === false) return "false";
  if (typeof v === "number") return String(v); if (typeof v === "bigint") return v.toString();
  if (v instanceof F) return fmtFloat(v.v);
  if (typeof v === "string") return dump ? dumpStr(v) : v;
  if (v instanceof ZArr) {
    let seq = true; for (let i = 0; i < v.keys.length; i++) if (v.keys[i] !== i) { seq = false; break; }
    const p = [];
    for (let i = 0; i < v.keys.length; i++) {
      const k = v.keys[i];
      p.push((seq ? "" : (typeof k === "string" ? dumpStr(k) : String(k)) + " => ") + text(v.vals[i], true));
    }
    return "[" + p.join(", ") + "]";
  }
  if (v instanceof ZObj) return "<object " + v.cls + ">";
  if (v instanceof ZFn) return "<function>";
  if (v instanceof ZExc) return v.kind ? "<object Error>" : "<object Exception>";
  return "<object>";
}
function truthy(v) {
  if (v === null || v === false) return false; if (v === true) return true;
  if (typeof v === "number") return v !== 0; if (typeof v === "bigint") return v !== 0n;
  if (v instanceof F) return v.v !== 0; if (typeof v === "string") return !(v === "" || v === "0");
  if (v instanceof ZArr) return v.keys.length > 0; return true;
}

// ───── tablice ─────
const mk = k => typeof k === "string" ? "s" + k : (typeof k === "bigint" ? "b" + k : k);
function arrNew() { return new ZArr(); }
function dup(v) { if (v instanceof ZArr) v.rc++; return v; }
function arrCopy(o) {
  const a = new ZArr(); a.keys = o.keys.slice(); a.vals = o.vals.slice(); a.next = o.next;
  for (let i = 0; i < a.keys.length; i++) { a.map.set(mk(a.keys[i]), i); if (a.vals[i] instanceof ZArr) a.vals[i].rc++; }
  return a;
}
function wr(v) {
  if (v === null) return new ZArr();
  if (!(v instanceof ZArr)) die("nie można indeksować wartości typu " + tn(v) + " przy zapisie");
  if (v.rc > 1) { v.rc--; return arrCopy(v); }
  return v;
}
function normKey(k) {
  if (typeof k === "number" || typeof k === "bigint") return k;
  if (typeof k === "boolean") return k ? 1 : 0;
  if (k instanceof F) { if (Number.isFinite(k.v) && Math.floor(k.v) === k.v) return normI(BigInt(k.v)); }
  else if (typeof k === "string") {
    const n = k.length;
    if (n > 0 && n <= 20 && /^-?(0|[1-9][0-9]*)$/.test(k) && k !== "-0") { const b = BigInt(k); if (b >= MIN64 && b <= MAX64) return normI(b); }
    return k;
  }
  die("niepoprawny klucz tablicy typu " + tn(k));
}
function put(a, k, v) {
  const m = mk(k); const i = a.map.get(m);
  if (i !== undefined) { a.vals[i] = v; return; }
  a.map.set(m, a.keys.length); a.keys.push(k); a.vals.push(v);
  if (typeof k === "number" && k >= a.next) a.next = k + 1;
  else if (typeof k === "bigint" && k >= BigInt(a.next)) a.next = Number(k) + 1;
}
ZArr.prototype.get = function (k) { const i = this.map.get(mk(k)); return i === undefined ? null : this.vals[i]; };
function apush(a, v) { put(a, a.next, v); return v; }
function aset(a, k, v) { if (!(a instanceof ZArr)) die("nie można indeksować wartości typu " + tn(a) + " przy zapisie"); put(a, normKey(k), v); return v; }
function wrappend(p) { const n = new ZArr(); apush(p, n); return n; }
function wrelem(p, k) {
  const nk = normKey(k); const i = p.map.get(mk(nk));
  if (i === undefined) { const n = new ZArr(); put(p, nk, n); return n; }
  const cur = p.vals[i]; const w = wr(cur); if (w !== cur) p.vals[i] = w; return w;
}
function keyText(k) { return typeof k === "string" ? dumpStr(k) : String(k); }
function index(a, k, quiet) {
  if (a instanceof ZArr) {
    const nk = normKey(k); const i = a.map.get(mk(nk));
    if (i !== undefined) return a.vals[i];
    if (quiet) return null; die("brak klucza " + keyText(nk));
  }
  if (typeof a === "string") {
    if (!isInt(k)) die("indeks tekstu musi być liczbą całkowitą");
    const b = toB(a), len = b.length; let i = Number(k); if (i < 0) i = len + i;
    if (i < 0 || i >= len) { if (quiet) return null; die("indeks " + i + " poza zakresem tekstu (długość " + len + ")"); }
    const c = b[i];
    if ((c & 0xC0) === 0x80) { if (quiet) return null; die("indeks " + i + " wskazuje środek znaku UTF-8"); }
    let n = c < 0x80 ? 1 : c < 0xE0 ? 2 : c < 0xF0 ? 3 : 4; if (i + n > len) n = len - i;
    return fromB(b.subarray(i, i + n));
  }
  if (a === null) { if (quiet) return null; die("indeksowanie wartości null"); }
  die("typ " + tn(a) + " nie obsługuje indeksowania");
}
const indexFn = (a, k) => index(a, k, false);
const indexOpt = (a, k) => index(a, k, true);
function foreachArr(v) { if (!(v instanceof ZArr)) die("foreach wymaga tablicy, jest " + tn(v)); return v; }

// ───── porównania i operatory ─────
function ident(a, b) {
  if (a instanceof F) return b instanceof F && a.v === b.v;
  if (a === b) return true;
  if (a instanceof ZArr && b instanceof ZArr) {
    if (a.keys.length !== b.keys.length) return false;
    for (let i = 0; i < a.keys.length; i++) if (a.keys[i] !== b.keys[i] || !ident(a.vals[i], b.vals[i])) return false;
    return true;
  }
  return false;
}
function eq(a, b) { if (isNum(a) && isNum(b) && (a instanceof F) !== (b instanceof F)) return asF(a) === asF(b); return ident(a, b); }
function cmpStr(a, b) {
  if (a === b) return 0;
  if (!NONASCII.test(a) && !NONASCII.test(b)) return a < b ? -1 : 1;
  const c = Buffer.compare(toB(a), toB(b)); return c < 0 ? -1 : c > 0 ? 1 : 0;
}
function cmp(a, b) {
  if (isInt(a) && isInt(b)) return a < b ? -1 : a > b ? 1 : 0;
  if (isNum(a) && isNum(b)) { const x = asF(a), y = asF(b); return x < y ? -1 : x > y ? 1 : 0; }
  if (typeof a === "string" && typeof b === "string") return cmpStr(a, b);
  if (typeof a === "boolean" && typeof b === "boolean") return a === b ? 0 : (a ? 1 : -1);
  die("nie można porównać " + tn(a) + " z " + tn(b));
}
const badOp = (op, a, b) => die("operacja " + op + " niedostępna dla " + tn(a) + " i " + tn(b));
function add(a, b) {
  if (typeof a === "number" && typeof b === "number") { const r = a + b; if (Number.isSafeInteger(r)) return r; return chkI(BigInt(a) + BigInt(b)); }
  if (isInt(a) && isInt(b)) return chkI(BigInt(a) + BigInt(b));
  if (isNum(a) && isNum(b)) return new F(asF(a) + asF(b));
  if (a instanceof ZArr && b instanceof ZArr) {
    const r = arrCopy(a);
    for (let i = 0; i < b.keys.length; i++) if (!r.map.has(mk(b.keys[i]))) { if (b.vals[i] instanceof ZArr) b.vals[i].rc++; put(r, b.keys[i], b.vals[i]); }
    return r;
  }
  badOp("Add", a, b);
}
function sub(a, b) {
  if (typeof a === "number" && typeof b === "number") { const r = a - b; if (Number.isSafeInteger(r)) return r; return chkI(BigInt(a) - BigInt(b)); }
  if (isInt(a) && isInt(b)) return chkI(BigInt(a) - BigInt(b));
  if (isNum(a) && isNum(b)) return new F(asF(a) - asF(b));
  badOp("Sub", a, b);
}
function mul(a, b) {
  if (typeof a === "number" && typeof b === "number") { const r = a * b; if (Number.isSafeInteger(r)) return r; return chkI(BigInt(a) * BigInt(b)); }
  if (isInt(a) && isInt(b)) return chkI(BigInt(a) * BigInt(b));
  if (isNum(a) && isNum(b)) return new F(asF(a) * asF(b));
  badOp("Mul", a, b);
}
function div(a, b) {
  if (!(isNum(a) && isNum(b))) badOp("Div", a, b);
  if (asF(b) === 0) die("dzielenie przez zero");
  if (isInt(a) && isInt(b)) {
    if (typeof a === "number" && typeof b === "number") { if (a % b === 0) return a / b; }
    else { const x = BigInt(a), y = BigInt(b); if (x % y === 0n) return chkI(x / y); }
  }
  return new F(asF(a) / asF(b));
}
function mod(a, b) {
  if (isInt(a) && isInt(b)) {
    if (b === 0 || b === 0n) die("modulo przez zero");
    if (b === -1 || b === -1n) return 0;
    if (typeof a === "number" && typeof b === "number") return a % b === 0 ? 0 : a % b;
    return normI(BigInt(a) % BigInt(b));
  }
  badOp("Mod", a, b);
}
const small = v => typeof v === "number" && v >= -2147483648 && v <= 2147483647;
function bitand(a, b) { if (isInt(a) && isInt(b)) return small(a) && small(b) ? (a & b) : normI(BigInt.asIntN(64, BigInt(a) & BigInt(b))); badOp("BitAnd", a, b); }
function bitor(a, b) { if (isInt(a) && isInt(b)) return small(a) && small(b) ? (a | b) : normI(BigInt.asIntN(64, BigInt(a) | BigInt(b))); badOp("BitOr", a, b); }
function bitxor(a, b) { if (isInt(a) && isInt(b)) return small(a) && small(b) ? (a ^ b) : normI(BigInt.asIntN(64, BigInt(a) ^ BigInt(b))); badOp("BitXor", a, b); }
function shl(a, b) { if (isInt(a) && isInt(b)) return normI(BigInt.asIntN(64, BigInt(a) << (BigInt(b) & 63n))); badOp("Shl", a, b); }
function shr(a, b) { if (isInt(a) && isInt(b)) return normI(BigInt(a) >> (BigInt(b) & 63n)); badOp("Shr", a, b); }
function bitnot(a) { if (isInt(a)) return typeof a === "number" ? -a - 1 : normI(-a - 1n); die("operator jednoargumentowy BitNot niedostępny dla " + tn(a)); }
function pow(a, b) {
  if (isInt(a) && isInt(b) && b >= 0) {
    let r = 1n, base = BigInt(a), e = BigInt(b), ovf = false;
    while (e > 0n) {
      if (e & 1n) { r *= base; if (r < MIN64 || r > MAX64) { ovf = true; break; } }
      e >>= 1n; if (e > 0n) { base *= base; if (base < MIN64 || base > MAX64) { ovf = true; break; } }
    }
    if (!ovf) return normI(r);
    return new F(Math.pow(Number(a), Number(b)));
  }
  if (isNum(a) && isNum(b)) return new F(Math.pow(asF(a), asF(b)));
  badOp("Pow", a, b);
}
const concat = (a, b) => text(a) + text(b);
function neg(a) {
  if (isInt(a)) { if (typeof a === "number") return a === 0 ? 0 : -a; return chkI(-a); }
  if (a instanceof F) return new F(-a.v);
  die("operator jednoargumentowy Neg niedostępny dla " + tn(a));
}
function chk(v, type, what) {
  let ok = false;
  if (type === "int") ok = isInt(v);
  else if (type === "float") { ok = v instanceof F; if (!ok && isInt(v)) return new F(Number(v)); }
  else if (type === "string") ok = typeof v === "string"; else if (type === "bool") ok = typeof v === "boolean";
  else if (type === "array") ok = v instanceof ZArr; else if (v instanceof ZObj || v instanceof ZExc) ok = true;
  if (ok) return v;
  die(what + ": oczekiwano " + type + ", otrzymano " + tn(v));
}

// ───── wbudowane ─────
const needS = (v, f, n) => { if (typeof v !== "string") die(f + ": argument #" + n + " powinien być tekstem, jest " + tn(v)); return v; };
const needI = (v, f, n) => { if (!isInt(v)) die(f + ": argument #" + n + " powinien być liczbą całkowitą, jest " + tn(v)); return v; };
const needF = (v, f, n) => { if (!isNum(v)) die(f + ": argument #" + n + " powinien być liczbą, jest " + tn(v)); return asF(v); };
const needA = (v, f, n) => { if (!(v instanceof ZArr)) die(f + ": argument #" + n + " powinien być tablicą, jest " + tn(v)); return v; };
const WS = /^[ \t-\r]+|[ \t-\r]+$/g;
function toInt(v) {
  if (isInt(v)) return v;
  if (v instanceof F) { const f = v.v; return Number.isNaN(f) ? 0 : f >= 9.2233720368547758e18 ? normI(MAX64) : f <= -9.2233720368547758e18 ? normI(MIN64) : normI(BigInt(Math.trunc(f))); }
  if (typeof v === "boolean") return v ? 1 : 0; if (v === null) return 0;
  if (typeof v === "string") {
    const t = v.replace(WS, "");
    if (/^[+-]?[0-9]+$/.test(t)) { const b = BigInt(t); if (b >= MIN64 && b <= MAX64) return normI(b); }
    if (t !== "" && /^[+-]?(\d+\.?\d*([eE][+-]?\d+)?|\.\d+([eE][+-]?\d+)?)$/.test(t)) { const f = parseFloat(t); return Number.isNaN(f) ? 0 : normI(BigInt(Math.trunc(f))); }
    return 0;
  }
  die("intval: nie można przekonwertować " + tn(v));
}
function toFloat(v) {
  if (isInt(v)) return new F(Number(v)); if (v instanceof F) return v;
  if (typeof v === "string") { const t = v.replace(WS, ""); return new F(t !== "" && /^[+-]?(\d+\.?\d*([eE][+-]?\d+)?|\.\d+([eE][+-]?\d+)?|inf(inity)?|nan)$/i.test(t) ? parseFloat(t) : 0); }
  return new F(0);
}
function sliceBytes(s, st, n) { return fromB(toB(s).subarray(st, st + n)); }
function pad(a, n, p, left, f) {
  const s = needS(a, f, 1); let w = Number(needI(n, f, 2)); if (w < 0) w = 0;
  let pc = " "; if (typeof p === "string" && p.length > 0) pc = Array.from(p)[0];
  const l = Array.from(s).length; if (l >= w) return a;
  const padding = pc.repeat(w - l); return left ? padding + s : s + padding;
}
function u8chars(s) { return Array.from(s); }
const B = {
  count(v) { if (v instanceof ZArr) return v.keys.length; if (typeof v === "string") return bl(v); die("count: niedostępne dla " + tn(v)); },
  strlen(v) { return bl(needS(v, "strlen", 1)); },
  typeof(v) { if (v instanceof ZObj) return v.cls; if (v instanceof ZExc) return v.kind ? "Error" : "Exception"; return tn(v); },
  is_int: isInt, is_float: v => v instanceof F, is_string: v => typeof v === "string", is_bool: v => typeof v === "boolean",
  is_array: v => v instanceof ZArr, is_null: v => v === null,
  strval(v) { return text(v); }, boolval(v) { return truthy(v); }, intval: toInt, floatval: toFloat,
  ord(v) { const s = needS(v, "ord", 1); if (!s.length) die("ord: pusty tekst"); return toB(s)[0]; },
  chr(v) { const n = Number(needI(v, "chr", 1)); return (n >= 0 && n < 0x110000 && !(n >= 0xD800 && n < 0xE000)) ? String.fromCodePoint(n) : ""; },
  trim(v) { return needS(v, "trim", 1).replace(WS, ""); },
  contains(a, b) { return needS(a, "contains", 1).includes(needS(b, "contains", 2)); },
  starts_with(a, b) { return needS(a, "starts_with", 1).startsWith(needS(b, "starts_with", 2)); },
  ends_with(a, b) { return needS(a, "ends_with", 1).endsWith(needS(b, "ends_with", 2)); },
  index_of(a, b) {
    const x = needS(a, "index_of", 1), y = needS(b, "index_of", 2); const i = x.indexOf(y);
    return i < 0 ? -1 : (NONASCII.test(x) ? Buffer.byteLength(x.slice(0, i), "utf8") : i);
  },
  repeat(a, b) { const x = needS(a, "repeat", 1); let n = Number(needI(b, "repeat", 2)); if (n < 0) n = 0; return x.repeat(n); },
  substr(s, a, l) {
    const x = needS(s, "substr", 1); const len = bl(x); let st = Number(needI(a, "substr", 2));
    if (st < 0) { st = len + st; if (st < 0) st = 0; } if (st > len) st = len;
    let n; if (l !== undefined && isInt(l)) { n = Number(l) >= 0 ? Number(l) : len - st + Number(l); if (n < 0) n = 0; } else n = len - st;
    if (st + n > len) n = len - st;
    return NONASCII.test(x) ? sliceBytes(x, st, n) : x.substr(st, n);
  },
  join(a, sep) { const x = needA(a, "join", 1); return x.vals.map(v => text(v)).join(typeof sep === "string" ? sep : ""); },
  in_array(n, arr) { const x = needA(arr, "in_array", 2); for (const v of x.vals) if (ident(v, n)) return true; return false; },
  range(a, b) {
    const x = needI(a, "range", 1), y = needI(b, "range", 2); const r = new ZArr();
    if (x <= y) for (let i = x; ; i = add(i, 1)) { apush(r, i); if (i === y) break; } else for (let i = x; ; i = sub(i, 1)) { apush(r, i); if (i === y) break; }
    return r;
  },
  keys(a) { const x = needA(a, "keys", 1); const r = new ZArr(); for (const k of x.keys) apush(r, k); return r; },
  values(a) { const x = needA(a, "values", 1); const r = new ZArr(); for (const v of x.vals) apush(r, dup(v)); return r; },
  has_key(a, k) { return needA(a, "has_key", 1).map.has(mk(normKey(k))); },
  upper(v) { return needS(v, "upper", 1).replace(/[a-z]/g, c => c.toUpperCase()); },
  lower(v) { return needS(v, "lower", 1).replace(/[A-Z]/g, c => c.toLowerCase()); },
  replace(a, f, t) { const s = needS(a, "replace", 1), x = needS(f, "replace", 2), y = needS(t, "replace", 3); return x === "" ? s : s.split(x).join(y); },
  split(a, sep) {
    const s = needS(a, "split", 1), x = needS(sep, "split", 2); const r = new ZArr();
    if (x === "") { for (const c of u8chars(s)) apush(r, c); return r; }
    for (const p of s.split(x)) apush(r, p); return r;
  },
  chars(a) { return B.split(a, ""); },
  pad_left(a, n, p) { return pad(a, n, p, true, "pad_left"); }, pad_right(a, n, p) { return pad(a, n, p, false, "pad_right"); },
  array_slice(a, s, l) {
    const x = needA(a, "array_slice", 1); const len = x.keys.length; let st = Number(needI(s, "array_slice", 2));
    if (st < 0) { st = len + st; if (st < 0) st = 0; } if (st > len) st = len;
    let n = (l !== undefined && isInt(l)) ? Number(l) : len; if (n < 0) n = 0; let end = st + n; if (end > len) end = len;
    const r = new ZArr(); for (let i = st; i < end; i++) apush(r, dup(x.vals[i])); return r;
  },
  reverse(a) {
    if (typeof a === "string") return u8chars(a).reverse().join("");
    if (!(a instanceof ZArr)) die("reverse: niedostępne dla " + tn(a));
    const r = new ZArr(); for (let i = a.vals.length - 1; i >= 0; i--) apush(r, dup(a.vals[i])); return r;
  },
  sort(a) {
    const x = needA(a, "sort", 1); const idx = x.vals.map((v, i) => [v, i]);
    // sortowanie stabilne scalaniem; błąd porównania propaguje się jako wyjątek
    const ms = arr => { if (arr.length < 2) return arr; const m = arr.length >> 1, l = ms(arr.slice(0, m)), r = ms(arr.slice(m)); const o = []; let i = 0, j = 0; while (i < l.length && j < r.length) o.push(cmp(r[j][0], l[i][0]) < 0 ? r[j++] : l[i++]); while (i < l.length) o.push(l[i++]); while (j < r.length) o.push(r[j++]); return o; };
    const r = new ZArr(); for (const [v] of ms(idx)) apush(r, dup(v)); return r;
  },
  push(a, v) { needA(a, "push", 1); const r = wr(dup(a)); apush(r, v); return r; },
  dump(v) { out(text(v, true) + "\n"); return null; },
  is_digit: v => { const s = needS(v, "is_digit", 1); return s.length > 0 && /^[0-9]/.test(s); },
  is_alpha: v => { const s = needS(v, "is_alpha", 1); return s.length > 0 && /^[A-Za-z_\u0080-\uffff]/.test(s); },
  is_alnum: v => { const s = needS(v, "is_alnum", 1); return s.length > 0 && /^[A-Za-z0-9_\u0080-\uffff]/.test(s); },
  is_space: v => { const s = needS(v, "is_space", 1); return s.length > 0 && /^[ \t-\r]/.test(s); },
  is_hex_digit: v => { const s = needS(v, "is_hex_digit", 1); return s.length > 0 && /^[0-9A-Fa-f]/.test(s); },
  to_hex(v) { const n = needI(v, "to_hex", 1); return (BigInt.asUintN(64, BigInt(n))).toString(16); },
  read_line() {
    flush(); const buf = Buffer.alloc(1); const bytes = []; let any = false;
    for (;;) {
      let n = 0; try { n = fs.readSync(0, buf, 0, 1, null); } catch (e) { if (e.code === "EAGAIN") continue; if (e.code === "EOF") n = 0; else throw e; }
      if (n === 0) break; any = true; if (buf[0] === 10) break; bytes.push(buf[0]);
    }
    if (!any) return null; while (bytes.length && bytes[bytes.length - 1] === 13) bytes.pop();
    return fromB(Buffer.from(bytes));
  },
  // klasy / domknięcia
  zs_obj_new(cls) { return new ZObj(cls); },
  zs_obj_class(o) { return o instanceof ZObj ? o.cls : null; },
  zs_obj_get(o, name) {
    if (!(o instanceof ZObj)) { if (o === null) die("dostęp do właściwości `" + name + "` wartości null"); die("dostęp do właściwości `" + name + "` typu " + tn(o)); }
    const i = o.f.map.get(mk(name)); if (i === undefined) die("obiekt klasy " + o.cls + " nie ma właściwości " + name);
    return dup(o.f.vals[i]);
  },
  zs_obj_take(o, name) { const v = B.zs_obj_get(o, name); const i = o.f.map.get(mk(name)); if (v instanceof ZArr) v.rc--; o.f.vals[i] = null; return v; },
  zs_obj_set(o, name, v) { if (!(o instanceof ZObj)) die("zapis właściwości `" + name + "` na wartości typu " + tn(o)); put(o.f, name, dup(v)); return v; },
  zs_obj_put(o, name, v) { put(o.f, name, v); return v; },
  zs_no_method(o, name) { if (o instanceof ZObj) die("klasa " + o.cls + " nie ma metody " + name); die("wywołanie metody `" + name + "` na wartości typu " + tn(o)); },
  zs_no_class(name) { die("nieznana klasa " + name); },
  zs_mkfn(id, cap) { return new ZFn(id, cap); },
  zs_fn_id(f) { if (f instanceof ZFn) return f.id; if (typeof f === "string") return f; return null; },
  zs_fn_cap(f) { return f instanceof ZFn ? f.cap : null; },
  is_callable(f) { return f instanceof ZFn; },
  zs_sget(name) { return statics.has(name) ? dup(statics.get(name)) : null; },
  zs_sset(name, v) { statics.set(name, dup(v)); return v; },
};
const statics = new Map();

// ───── moduły ─────
function ioDie(p, e) { die(p + ": " + (e.code === "ENOENT" ? "No such file or directory" : e.code === "EACCES" ? "Permission denied" : e.code === "EISDIR" ? "Is a directory" : e.code === "EEXIST" ? "File exists" : e.code === "ENOTDIR" ? "Not a directory" : e.code === "ENOTEMPTY" ? "Directory not empty" : e.message)); }
function isFileP(p) { try { return fs.statSync(p).isFile(); } catch (e) { return false; } }
function dirnameZ(s) {
  let i = s.length; while (i > 1 && s[i - 1] === "/") i--; while (i > 0 && s[i - 1] !== "/") i--; while (i > 1 && s[i - 1] === "/") i--;
  if (i === 0) return "."; if (i === 1 && s[0] === "/") return "/"; return s.slice(0, i);
}
function withExt(base) { for (const e of [".zsharp", ".zs"]) if (isFileP(base + e)) return base + e; return null; }
function manifestMember(toml, name) {
  let t; try { t = fs.readFileSync(toml, "utf8"); } catch (e) { return null; }
  for (const ln of t.split("\n")) { const m = ln.match(/^[ \t]*([A-Za-z0-9_]+)[ \t]*=[ \t]*"([^"]*)"/); if (m && m[1] === name) return m[2]; }
  return null;
}
function resolveImport(segs, dir) {
  if (!(segs instanceof ZArr)) die("System.resolveImport: argument 1 musi być tablicą");
  needS(dir, "System.resolveImport", 2); const names = segs.vals.map(v => text(v)); if (!names.length) return null;
  if (names[0] === "Workspace" && names.length >= 2) {
    let cur = dir;
    for (let up = 0; up < 40; up++) {
      for (const sub of ["", "/Z-Sharp"]) {
        const mem = manifestMember(cur + sub + "/Z#.toml", names[1]);
        if (mem !== null) {
          let base = cur + sub + "/" + mem;
          if (isFileP(base)) {
            for (let k = 2; k < names.length; k++) { base = withExt(nodePath.dirname(base) + "/" + names[k]); if (base === null) return null; }
            return base;
          }
        }
      }
      const sl = cur.lastIndexOf("/");
      if (sl <= 0) { if (cur !== "/" && cur !== ".") cur = "."; else break; if (up > 0 && cur === ".") break; } else cur = cur.slice(0, sl);
      if (cur === "." && up > 0) cur = process.cwd();
    }
    return null;
  }
  if (names[0] === "Std" && names.length === 2) {
    const lo = names[1].toLowerCase();
    for (const p of [process.env.ZS_STD && process.env.ZS_STD + "/" + lo + ".zsharp", process.env.ZS_HOME && process.env.ZS_HOME + "/stdlib/" + lo + ".zsharp"]) if (p && isFileP(p)) return p;
    return null;
  }
  const dirs = [dir, process.cwd()]; if (process.env.ZS_PATH) for (const t of process.env.ZS_PATH.split(":")) if (t) dirs.push(t);
  for (const d of dirs) { const r = withExt(d + "/" + names.join("/")); if (r) return r; }
  return null;
}
function spawn(cmd, args, inherit) {
  needS(cmd, "Process", 1); const av = needA(args, "Process", 2).vals.map(v => text(v));
  flush();
  const r = cp.spawnSync(cmd, av, inherit ? { stdio: "inherit" } : { maxBuffer: 1 << 30 });
  if (r.error) { const msg = cmd + ": " + (r.error.code === "ENOENT" ? "No such file or directory" : r.error.message) + "\n"; return { status: 127, stdout: Buffer.alloc(0), stderr: Buffer.from(msg) }; }
  return { status: r.status === null ? -1 : r.status, stdout: r.stdout || Buffer.alloc(0), stderr: r.stderr || Buffer.alloc(0) };
}
function assoc(pairs) { const a = new ZArr(); for (const [k, v] of pairs) put(a, k, v); return a; }
const t0 = process.hrtime.bigint();
function noSocket(n) { return () => die("Socket." + n + ": niedostępne w celu js (użyj celu c / zsc)"); }
const M = {
  Math: {
    sqrt: v => new F(Math.sqrt(needF(v, "Math.sqrt", 1))),
    floor: v => normI(BigInt(Math.floor(needF(v, "Math.floor", 1)))), ceil: v => normI(BigInt(Math.ceil(needF(v, "Math.ceil", 1)))),
    round: v => { const x = needF(v, "Math.round", 1); return normI(BigInt(x < 0 ? -Math.round(-x) : Math.round(x))); },
    abs: v => { if (isInt(v)) return typeof v === "number" ? Math.abs(v) : chkI(v < 0n ? -v : v); if (v instanceof F) return new F(Math.abs(v.v)); die("Math.abs: " + tn(v)); },
    pow: (a, b) => pow(a, b), min: (a, b) => cmp(a, b) <= 0 ? a : b, max: (a, b) => cmp(a, b) <= 0 ? b : a,
  },
  System: {
    args: () => { const r = new ZArr(); for (const a of sysArgs) apush(r, a); return r; },
    env: k => { const e = process.env[needS(k, "System.env", 1)]; return e === undefined ? null : e; },
    os: () => process.platform === "darwin" ? "macos" : process.platform === "win32" ? "windows" : process.platform,
    architecture: () => process.arch === "x64" ? "x86_64" : process.arch === "arm64" ? "aarch64" : "unknown",
    time: () => new F(Date.now() / 1000), cpuCount: () => Math.max(1, require("os").cpus().length),
    version: () => "0.0.1", dirname: p => dirnameZ(needS(p, "System.dirname", 1)), resolveImport,
    setEnv: (k, v) => { process.env[needS(k, "System.setEnv", 1)] = text(v); return null; },
    unsetEnv: k => { delete process.env[needS(k, "System.unsetEnv", 1)]; return null; },
    environ: () => assoc(Object.keys(process.env).sort().map(k => [k, process.env[k]])),
    cwd: () => process.cwd(), chdir: p => { try { process.chdir(needS(p, "System.chdir", 1)); } catch (e) { ioDie(p, e); } return null; },
    pid: () => process.pid, hostname: () => require("os").hostname(),
    bytes: s => { const r = new ZArr(); for (const b of toB(needS(s, "System.bytes", 1))) apush(r, b); return r; },
    fromBytes: a => fromB(Buffer.from(needA(a, "System.fromBytes", 1).vals.map(v => Number(v) & 255))),
    nowNanos: () => normI(BigInt(Date.now()) * 1000000n), monotonic: () => normI(process.hrtime.bigint() - t0 + 1000000000n),
    sleep: ms => { flush(); const m = Number(needI(ms, "System.sleep", 1)); if (m > 0) Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, m); return null; },
    localOffset: t => -new Date(Number(needI(t, "System.localOffset", 1)) * 1000).getTimezoneOffset() * 60,
    gc: () => null, gcStats: () => new ZArr(),
  },
  File: {
    read: p => { try { return fromB(fs.readFileSync(needS(p, "File.read", 1))); } catch (e) { ioDie(p, e); } },
    write: (p, d) => { needS(p, "File.write", 1); try { fs.writeFileSync(p, text(d)); } catch (e) { ioDie(p, e); } return null; },
    append: (p, d) => { needS(p, "File.append", 1); try { fs.appendFileSync(p, text(d)); } catch (e) { ioDie(p, e); } return null; },
    exists: p => isFileP(needS(p, "File.exists", 1)),
    delete: p => { try { fs.unlinkSync(needS(p, "File.delete", 1)); } catch (e) { ioDie(p, e); } return null; },
    stat: p => { let st; try { st = fs.lstatSync(needS(p, "File.stat", 1)); } catch (e) { return null; } return assoc([["kind", st.isSymbolicLink() ? "link" : st.isDirectory() ? "dir" : st.isFile() ? "file" : "other"], ["size", st.size], ["mtime", Math.floor(st.mtimeMs / 1000)], ["mode", st.mode & 0o7777]]); },
    rename: (a, b) => { try { fs.renameSync(needS(a, "File.rename", 1), needS(b, "File.rename", 2)); } catch (e) { ioDie(a, e); } return null; },
    realpath: p => { try { return fs.realpathSync(needS(p, "File.realpath", 1)); } catch (e) { ioDie(p, e); } },
    chmod: (p, m) => { try { fs.chmodSync(needS(p, "File.chmod", 1), Number(needI(m, "File.chmod", 2))); } catch (e) { ioDie(p, e); } return null; },
    symlink: (t, l) => { try { fs.symlinkSync(needS(t, "File.symlink", 1), needS(l, "File.symlink", 2)); } catch (e) { ioDie(l, e); } return null; },
    readlink: p => { try { return fs.readlinkSync(needS(p, "File.readlink", 1)); } catch (e) { ioDie(p, e); } },
  },
  Directory: {
    create: p => { try { fs.mkdirSync(needS(p, "Directory.create", 1), { recursive: true }); } catch (e) { ioDie(p, e); } return null; },
    exists: p => { try { return fs.statSync(needS(p, "Directory.exists", 1)).isDirectory(); } catch (e) { return false; } },
    list: p => { let n; try { n = fs.readdirSync(needS(p, "Directory.list", 1)); } catch (e) { ioDie(p, e); } n.sort((a, b) => cmpStr(a, b)); const r = new ZArr(); for (const x of n) apush(r, x); return r; },
    remove: p => { try { fs.rmdirSync(needS(p, "Directory.remove", 1)); } catch (e) { ioDie(p, e); } return null; },
  },
  Process: {
    run: (c, a) => { const r = spawn(c, a, false); return assoc([["status", r.status], ["stdout", fromB(r.stdout)], ["stderr", fromB(r.stderr)]]); },
    exec: (c, a) => spawn(c, a, true).status,
  },
  Socket: Object.fromEntries(["tcpConnect", "tcpListen", "accept", "read", "write", "close", "setTimeout", "udpBind", "sendTo", "recvFrom", "resolve", "localAddr", "peerAddr"].map(n => [n, noSocket(n)])),
};
let sysArgs = [process.argv[1] || "zs"];
function setArgs(a) { sysArgs = a; }

// ───── wejście/wyjście programu ─────
class Exit { constructor(c) { this.__exit = true; this.code = c; } }
function echo(...a) { out(a.map(x => text(x)).join(" ") + "\n"); return null; }
function necho(...a) { out(a.map(x => text(x)).join("")); return null; }
function eecho(...a) { err(a.map(x => text(x)).join(" ") + "\n"); return null; }
function exit(c) { throw new Exit(c === undefined || !isInt(c) ? 0 : Number(c)); }
function run(top, main, callsMain) {
  sysArgs = [process.argv[1] || "zs"].concat(process.argv.slice(2));
  let rc = 0;
  try {
    top();
    if (main && !callsMain) { const r = main(); if (isInt(r)) rc = Number(r); }
  } catch (e) {
    if (e instanceof Exit) rc = e.code;
    else if (e instanceof ZExc || e instanceof ZObj) {
      flush();
      if (e instanceof ZObj) { const l = e.f.get("line"); err("Nieobsłużony wyjątek " + e.cls + ": " + text(e.f.get("message")) + " (linia " + (isInt(l) ? l : 0) + ")\n"); }
      else err("Nieobsłużony wyjątek " + (e.kind ? "Error" : "Exception") + ": " + text(e.msg) + " (linia " + e.line + ")\n");
      rc = 1;
    } else if (e instanceof RangeError) { flush(); err("Nieobsłużony wyjątek Error: przepełnienie stosu (linia " + curLine + ")\n"); rc = 1; }
    else throw e;
  }
  flush();
  process.exitCode = rc;
}

module.exports = {
  F, ZExc, ZObj, ZFn, ZArr, B, M, setLine, raise, throwV, toExc, excIs, getMessage, truthy, dup, wr, wrappend, wrelem, apush, aset,
  arrNew, index: indexFn, indexOpt, foreachArr, eq, ident, cmp, add, sub, mul, div, mod, pow, concat, neg, bitand, bitor, bitxor, shl, shr, bitnot, chk,
  echo, necho, eecho, exit, dump: v => B.dump(v), run, setArgs, text, die,
};

return module.exports; })(typeof require === 'function' ? require : null);
function f_LexError____construct(v_this, v_message, v_line, v_col) {
  Z.setLine(7);
  f_Exception____construct(Z.dup(v_this), Z.concat(Z.concat(Z.concat(Z.concat(Z.concat(v_message, " ("), v_line), ":"), v_col), ")"));
  Z.setLine(8);
  Z.B.zs_obj_set(v_this, "lineNo", v_line);
  Z.setLine(9);
  Z.B.zs_obj_set(v_this, "colNo", v_col);
  return null;
}
function f_LexError__new(v_message, v_line, v_col) {
  let v___o = null;
  Z.setLine(3);
  (v___o = Z.B.zs_obj_new("LexError"));
  Z.setLine(3);
  Z.B.zs_obj_set(v___o, "message", "");
  Z.setLine(3);
  Z.B.zs_obj_set(v___o, "line", 0);
  Z.setLine(3);
  Z.B.zs_obj_set(v___o, "lineNo", null);
  Z.setLine(3);
  Z.B.zs_obj_set(v___o, "colNo", null);
  Z.setLine(3);
  f_LexError____construct(Z.dup(v___o), Z.dup(v_message), Z.dup(v_line), Z.dup(v_col));
  Z.setLine(3);
  return Z.dup(v___o);
  return null;
}
function f_LexTables__new() {
  let v___o = null;
  Z.setLine(13);
  (v___o = Z.B.zs_obj_new("LexTables"));
  Z.setLine(13);
  return Z.dup(v___o);
  return null;
}
function f_Lexer____construct(v_this, v_src, v_keep) {
  let _t1 = null;
  Z.setLine(45);
  Z.B.zs_obj_set(v_this, "src", v_src);
  Z.setLine(46);
  Z.B.zs_obj_set(v_this, "n", Z.B.strlen(v_src));
  Z.setLine(47);
  Z.B.zs_obj_set(v_this, "pos", 0);
  Z.setLine(48);
  Z.B.zs_obj_set(v_this, "line", 1);
  Z.setLine(49);
  Z.B.zs_obj_set(v_this, "col", 1);
  Z.setLine(50);
  Z.B.zs_obj_set(v_this, "out", ((_t1 = Z.arrNew()), _t1));
  Z.setLine(51);
  Z.B.zs_obj_set(v_this, "keep", v_keep);
  return null;
}
function f_Lexer__peek(v_this, v_k) {
  let _t2 = null;
  Z.setLine(55);
  return (((_t2 = Z.indexOpt(Z.B.zs_obj_get(v_this, "src"), Z.add(Z.B.zs_obj_get(v_this, "pos"), v_k))) !== null) ? _t2 : "");
  return null;
}
function f_Lexer__bump(v_this) {
  let v_c = null;
  Z.setLine(59);
  (v_c = Z.dup(Z.index(Z.B.zs_obj_get(v_this, "src"), Z.B.zs_obj_get(v_this, "pos"))));
  Z.setLine(60);
  Z.B.zs_obj_set(v_this, "pos", Z.add(Z.B.zs_obj_get(v_this, "pos"), Z.B.strlen(v_c)));
  Z.setLine(61);
  if (Z.truthy(Z.ident(v_c, "\n"))) {
    Z.setLine(62);
    Z.B.zs_obj_set(v_this, "line", Z.add(Z.B.zs_obj_get(v_this, "line"), 1));
    Z.setLine(63);
    Z.B.zs_obj_set(v_this, "col", 1);
  } else {
    Z.setLine(65);
    Z.B.zs_obj_set(v_this, "col", Z.add(Z.B.zs_obj_get(v_this, "col"), 1));
  }
  Z.setLine(67);
  return Z.dup(v_c);
  return null;
}
function f_Lexer__fail(v_this, v_msg, v_line, v_col) {
  Z.setLine(70);
  Z.throwV(f_LexError__new(Z.dup(v_msg), Z.dup(v_line), Z.dup(v_col)));
  return null;
}
function f_Lexer__emit(v_this, v_kind, v_text, v_start, v_line, v_col, v_value) {
  let v___r1 = null, v___w2 = null;
  let _t3 = null;
  Z.setLine(73);
  (v___r1 = ((_t3 = Z.arrNew()), Z.aset(_t3, "kind", Z.dup(v_kind)), Z.aset(_t3, "text", Z.dup(v_text)), Z.aset(_t3, "value", Z.dup(v_value)), Z.aset(_t3, "line", Z.dup(v_line)), Z.aset(_t3, "col", Z.dup(v_col)), Z.aset(_t3, "start", Z.dup(v_start)), Z.aset(_t3, "end", Z.B.zs_obj_get(v_this, "pos")), _t3));
  Z.setLine(73);
  (v___w2 = Z.B.zs_obj_take(v_this, "out"));
  Z.setLine(73);
  Z.apush((v___w2 = Z.wr(v___w2)), Z.dup(v___r1));
  Z.setLine(73);
  Z.B.zs_obj_put(v_this, "out", v___w2);
  return null;
}
function f_Lexer__run(v_this) {
  let v_line = null, v_col = null, v_c = null, v_start = null;
  let _t4 = null, _t5 = null, _t6 = null, _t7 = null, _t8 = null, _t9 = null, _t10 = null, _t11 = null, _t12 = null, _t13 = null, _t14 = null;
  Z.setLine(78);
  if (Z.truthy(Z.B.starts_with(Z.B.zs_obj_get(v_this, "src"), "#!"))) {
    Z.setLine(79);
    (v_line = Z.B.zs_obj_get(v_this, "line"));
    Z.setLine(79);
    (v_col = Z.B.zs_obj_get(v_this, "col"));
    L1: while (true) {
      Z.setLine(80);
      if (!Z.truthy((Z.truthy((Z.cmp(Z.B.zs_obj_get(v_this, "pos"), Z.B.zs_obj_get(v_this, "n")) < 0)) && Z.truthy(!Z.ident(f_zs_invoke(Z.dup(v_this), "peek", ((_t4 = Z.arrNew()), _t4)), "\n"))))) break;
      Z.setLine(80);
      f_zs_invoke(Z.dup(v_this), "bump", ((_t5 = Z.arrNew()), _t5));
    }
    Z.setLine(81);
    f_zs_invoke(Z.dup(v_this), "emit", ((_t6 = Z.arrNew()), Z.apush(_t6, "shebang"), Z.apush(_t6, Z.B.substr(Z.B.zs_obj_get(v_this, "src"), 2, Z.sub(Z.B.zs_obj_get(v_this, "pos"), 2))), Z.apush(_t6, 0), Z.apush(_t6, Z.dup(v_line)), Z.apush(_t6, Z.dup(v_col)), _t6));
  }
  L2: while (true) {
    Z.setLine(83);
    if (!Z.truthy(true)) break;
    Z.setLine(84);
    f_zs_invoke(Z.dup(v_this), "skipTrivia", ((_t7 = Z.arrNew()), _t7));
    Z.setLine(85);
    if (Z.truthy((Z.cmp(Z.B.zs_obj_get(v_this, "pos"), Z.B.zs_obj_get(v_this, "n")) >= 0))) {
      break L2;
    }
    Z.setLine(86);
    (v_c = f_zs_invoke(Z.dup(v_this), "peek", ((_t8 = Z.arrNew()), _t8)));
    Z.setLine(87);
    (v_start = Z.B.zs_obj_get(v_this, "pos"));
    Z.setLine(87);
    (v_line = Z.B.zs_obj_get(v_this, "line"));
    Z.setLine(87);
    (v_col = Z.B.zs_obj_get(v_this, "col"));
    Z.setLine(88);
    if (Z.truthy(Z.ident(v_c, "$"))) {
      Z.setLine(88);
      f_zs_invoke(Z.dup(v_this), "variable", ((_t9 = Z.arrNew()), Z.apush(_t9, Z.dup(v_start)), Z.apush(_t9, Z.dup(v_line)), Z.apush(_t9, Z.dup(v_col)), _t9));
    } else {
      Z.setLine(89);
      if (Z.truthy((Z.truthy(Z.ident(v_c, "\"")) || Z.truthy(Z.ident(v_c, "'"))))) {
        Z.setLine(89);
        f_zs_invoke(Z.dup(v_this), "string", ((_t10 = Z.arrNew()), Z.apush(_t10, Z.dup(v_c)), Z.apush(_t10, Z.dup(v_start)), Z.apush(_t10, Z.dup(v_line)), Z.apush(_t10, Z.dup(v_col)), _t10));
      } else {
        Z.setLine(90);
        if (Z.truthy(Z.B.is_digit(v_c))) {
          Z.setLine(90);
          f_zs_invoke(Z.dup(v_this), "number", ((_t11 = Z.arrNew()), Z.apush(_t11, Z.dup(v_start)), Z.apush(_t11, Z.dup(v_line)), Z.apush(_t11, Z.dup(v_col)), _t11));
        } else {
          Z.setLine(91);
          if (Z.truthy(Z.B.is_alpha(v_c))) {
            Z.setLine(91);
            f_zs_invoke(Z.dup(v_this), "ident", ((_t12 = Z.arrNew()), Z.apush(_t12, Z.dup(v_start)), Z.apush(_t12, Z.dup(v_line)), Z.apush(_t12, Z.dup(v_col)), _t12));
          } else {
            Z.setLine(92);
            f_zs_invoke(Z.dup(v_this), "op", ((_t13 = Z.arrNew()), Z.apush(_t13, Z.dup(v_start)), Z.apush(_t13, Z.dup(v_line)), Z.apush(_t13, Z.dup(v_col)), _t13));
          }
        }
      }
    }
  }
  Z.setLine(94);
  f_zs_invoke(Z.dup(v_this), "emit", ((_t14 = Z.arrNew()), Z.apush(_t14, "eof"), Z.apush(_t14, ""), Z.apush(_t14, Z.B.zs_obj_get(v_this, "pos")), Z.apush(_t14, Z.B.zs_obj_get(v_this, "line")), Z.apush(_t14, Z.B.zs_obj_get(v_this, "col")), _t14));
  Z.setLine(95);
  return Z.B.zs_obj_get(v_this, "out");
  return null;
}
function f_Lexer__skipTrivia(v_this) {
  let v_c = null, v_start = null, v_line = null, v_col = null, v_c1 = null, v_e = null, v_alone = null, v_textStart = null, v_text = null;
  let _t15 = null, _t16 = null, _t17 = null, _t18 = null, _t19 = null, _t20 = null, _t21 = null, _t22 = null, _t23 = null, _t24 = null, _t25 = null, _t26 = null, _t27 = null, _t28 = null, _t29 = null, _t30 = null, _t31 = null, _t32 = null, _t33 = null, _t34 = null, _t35 = null, _t36 = null, _t37 = null, _t38 = null, _t39 = null, _t40 = null, _t41 = null;
  L3: while (true) {
    Z.setLine(99);
    if (!Z.truthy((Z.cmp(Z.B.zs_obj_get(v_this, "pos"), Z.B.zs_obj_get(v_this, "n")) < 0))) break;
    Z.setLine(100);
    (v_c = f_zs_invoke(Z.dup(v_this), "peek", ((_t15 = Z.arrNew()), _t15)));
    Z.setLine(101);
    if (Z.truthy((Z.truthy((Z.truthy((Z.truthy(Z.ident(v_c, " ")) || Z.truthy(Z.ident(v_c, "\t")))) || Z.truthy(Z.ident(v_c, "\r")))) || Z.truthy(Z.ident(v_c, "\n"))))) {
      Z.setLine(101);
      f_zs_invoke(Z.dup(v_this), "bump", ((_t16 = Z.arrNew()), _t16));
      continue L3;
    }
    Z.setLine(102);
    if (Z.truthy(!Z.ident(v_c, "#"))) {
      Z.setLine(102);
      return null;
    }
    Z.setLine(103);
    (v_start = Z.B.zs_obj_get(v_this, "pos"));
    Z.setLine(103);
    (v_line = Z.B.zs_obj_get(v_this, "line"));
    Z.setLine(103);
    (v_col = Z.B.zs_obj_get(v_this, "col"));
    Z.setLine(104);
    (v_c1 = f_zs_invoke(Z.dup(v_this), "peek", ((_t17 = Z.arrNew()), Z.apush(_t17, 1), _t17)));
    Z.setLine(105);
    if (Z.truthy(Z.ident(v_c1, "("))) {
      Z.setLine(106);
      f_zs_invoke(Z.dup(v_this), "bump", ((_t18 = Z.arrNew()), _t18));
      Z.setLine(106);
      f_zs_invoke(Z.dup(v_this), "bump", ((_t19 = Z.arrNew()), _t19));
      L4: while (true) {
        Z.setLine(107);
        if (!Z.truthy(true)) break;
        Z.setLine(108);
        if (Z.truthy((Z.cmp(Z.B.zs_obj_get(v_this, "pos"), Z.B.zs_obj_get(v_this, "n")) >= 0))) {
          Z.setLine(108);
          f_zs_invoke(Z.dup(v_this), "fail", ((_t20 = Z.arrNew()), Z.apush(_t20, "niezamknięty komentarz #( ... )#"), Z.apush(_t20, Z.dup(v_line)), Z.apush(_t20, Z.dup(v_col)), _t20));
        }
        Z.setLine(109);
        if (Z.truthy((Z.truthy(Z.ident(f_zs_invoke(Z.dup(v_this), "peek", ((_t21 = Z.arrNew()), _t21)), ")")) && Z.truthy(Z.ident(f_zs_invoke(Z.dup(v_this), "peek", ((_t22 = Z.arrNew()), Z.apush(_t22, 1), _t22)), "#"))))) {
          Z.setLine(109);
          f_zs_invoke(Z.dup(v_this), "bump", ((_t23 = Z.arrNew()), _t23));
          Z.setLine(109);
          f_zs_invoke(Z.dup(v_this), "bump", ((_t24 = Z.arrNew()), _t24));
          break L4;
        }
        Z.setLine(110);
        f_zs_invoke(Z.dup(v_this), "bump", ((_t25 = Z.arrNew()), _t25));
      }
      Z.setLine(112);
      if (Z.truthy(Z.B.zs_obj_get(v_this, "keep"))) {
        Z.setLine(112);
        f_zs_invoke(Z.dup(v_this), "emit", ((_t26 = Z.arrNew()), Z.apush(_t26, "comment"), Z.apush(_t26, Z.B.substr(Z.B.zs_obj_get(v_this, "src"), v_start, Z.sub(Z.B.zs_obj_get(v_this, "pos"), v_start))), Z.apush(_t26, Z.dup(v_start)), Z.apush(_t26, Z.dup(v_line)), Z.apush(_t26, Z.dup(v_col)), _t26));
      }
    } else {
      Z.setLine(113);
      if (Z.truthy(Z.ident(v_c1, "#"))) {
        Z.setLine(114);
        f_zs_invoke(Z.dup(v_this), "bump", ((_t27 = Z.arrNew()), _t27));
        Z.setLine(114);
        f_zs_invoke(Z.dup(v_this), "bump", ((_t28 = Z.arrNew()), _t28));
        Z.setLine(115);
        (v_e = Z.B.zs_obj_get(v_this, "pos"));
        L5: while (true) {
          Z.setLine(116);
          if (!Z.truthy((Z.truthy((Z.cmp(v_e, Z.B.zs_obj_get(v_this, "n")) < 0)) && Z.truthy(!Z.ident((((_t29 = Z.indexOpt(Z.B.zs_obj_get(v_this, "src"), v_e)) !== null) ? _t29 : ""), "\n"))))) break;
          Z.setLine(116);
          ((_t30 = v_e), (v_e = Z.add(_t30, 1)), _t30);
        }
        Z.setLine(117);
        (v_alone = Z.ident(Z.B.trim(Z.B.substr(Z.B.zs_obj_get(v_this, "src"), Z.B.zs_obj_get(v_this, "pos"), Z.sub(v_e, Z.B.zs_obj_get(v_this, "pos")))), ""));
        Z.setLine(118);
        (v_textStart = Z.B.zs_obj_get(v_this, "pos"));
        Z.setLine(119);
        if (Z.truthy(v_alone)) {
          L6: while (true) {
            Z.setLine(120);
            if (!Z.truthy(true)) break;
            Z.setLine(121);
            if (Z.truthy((Z.cmp(Z.B.zs_obj_get(v_this, "pos"), Z.B.zs_obj_get(v_this, "n")) >= 0))) {
              Z.setLine(121);
              f_zs_invoke(Z.dup(v_this), "fail", ((_t31 = Z.arrNew()), Z.apush(_t31, "niezamknięty blok dokumentacyjny ##"), Z.apush(_t31, Z.dup(v_line)), Z.apush(_t31, Z.dup(v_col)), _t31));
            }
            Z.setLine(122);
            if (Z.truthy((Z.truthy(Z.ident(f_zs_invoke(Z.dup(v_this), "peek", ((_t32 = Z.arrNew()), _t32)), "#")) && Z.truthy(Z.ident(f_zs_invoke(Z.dup(v_this), "peek", ((_t33 = Z.arrNew()), Z.apush(_t33, 1), _t33)), "#"))))) {
              break L6;
            }
            Z.setLine(123);
            f_zs_invoke(Z.dup(v_this), "bump", ((_t34 = Z.arrNew()), _t34));
          }
          Z.setLine(125);
          (v_text = Z.B.substr(Z.B.zs_obj_get(v_this, "src"), v_textStart, Z.sub(Z.B.zs_obj_get(v_this, "pos"), v_textStart)));
          Z.setLine(126);
          f_zs_invoke(Z.dup(v_this), "bump", ((_t35 = Z.arrNew()), _t35));
          Z.setLine(126);
          f_zs_invoke(Z.dup(v_this), "bump", ((_t36 = Z.arrNew()), _t36));
        } else {
          L7: while (true) {
            Z.setLine(128);
            if (!Z.truthy((Z.cmp(Z.B.zs_obj_get(v_this, "pos"), v_e) < 0))) break;
            Z.setLine(128);
            f_zs_invoke(Z.dup(v_this), "bump", ((_t37 = Z.arrNew()), _t37));
          }
          Z.setLine(129);
          (v_text = Z.B.trim(Z.B.substr(Z.B.zs_obj_get(v_this, "src"), v_textStart, Z.sub(Z.B.zs_obj_get(v_this, "pos"), v_textStart))));
        }
        Z.setLine(131);
        f_zs_invoke(Z.dup(v_this), "emit", ((_t38 = Z.arrNew()), Z.apush(_t38, "doc"), Z.apush(_t38, Z.dup(v_text)), Z.apush(_t38, Z.dup(v_start)), Z.apush(_t38, Z.dup(v_line)), Z.apush(_t38, Z.dup(v_col)), Z.apush(_t38, Z.dup(v_text)), _t38));
      } else {
        L8: while (true) {
          Z.setLine(133);
          if (!Z.truthy((Z.truthy((Z.cmp(Z.B.zs_obj_get(v_this, "pos"), Z.B.zs_obj_get(v_this, "n")) < 0)) && Z.truthy(!Z.ident(f_zs_invoke(Z.dup(v_this), "peek", ((_t39 = Z.arrNew()), _t39)), "\n"))))) break;
          Z.setLine(133);
          f_zs_invoke(Z.dup(v_this), "bump", ((_t40 = Z.arrNew()), _t40));
        }
        Z.setLine(134);
        if (Z.truthy(Z.B.zs_obj_get(v_this, "keep"))) {
          Z.setLine(134);
          f_zs_invoke(Z.dup(v_this), "emit", ((_t41 = Z.arrNew()), Z.apush(_t41, "comment"), Z.apush(_t41, Z.B.substr(Z.B.zs_obj_get(v_this, "src"), v_start, Z.sub(Z.B.zs_obj_get(v_this, "pos"), v_start))), Z.apush(_t41, Z.dup(v_start)), Z.apush(_t41, Z.dup(v_line)), Z.apush(_t41, Z.dup(v_col)), _t41));
        }
      }
    }
  }
  return null;
}
function f_Lexer__variable(v_this, v_start, v_line, v_col) {
  let v_s = null, v_name = null;
  let _t42 = null, _t43 = null, _t44 = null, _t45 = null, _t46 = null, _t47 = null;
  Z.setLine(140);
  f_zs_invoke(Z.dup(v_this), "bump", ((_t42 = Z.arrNew()), _t42));
  Z.setLine(141);
  if (Z.truthy(!Z.truthy(Z.B.is_alpha(f_zs_invoke(Z.dup(v_this), "peek", ((_t43 = Z.arrNew()), _t43)))))) {
    Z.setLine(141);
    f_zs_invoke(Z.dup(v_this), "fail", ((_t44 = Z.arrNew()), Z.apush(_t44, "po `$` oczekiwano nazwy zmiennej"), Z.apush(_t44, Z.dup(v_line)), Z.apush(_t44, Z.dup(v_col)), _t44));
  }
  Z.setLine(142);
  (v_s = Z.B.zs_obj_get(v_this, "pos"));
  L9: while (true) {
    Z.setLine(143);
    if (!Z.truthy(Z.B.is_alnum(f_zs_invoke(Z.dup(v_this), "peek", ((_t45 = Z.arrNew()), _t45))))) break;
    Z.setLine(143);
    f_zs_invoke(Z.dup(v_this), "bump", ((_t46 = Z.arrNew()), _t46));
  }
  Z.setLine(144);
  (v_name = Z.B.substr(Z.B.zs_obj_get(v_this, "src"), v_s, Z.sub(Z.B.zs_obj_get(v_this, "pos"), v_s)));
  Z.setLine(145);
  f_zs_invoke(Z.dup(v_this), "emit", ((_t47 = Z.arrNew()), Z.apush(_t47, "var"), Z.apush(_t47, Z.concat("$", v_name)), Z.apush(_t47, Z.dup(v_start)), Z.apush(_t47, Z.dup(v_line)), Z.apush(_t47, Z.dup(v_col)), Z.apush(_t47, Z.dup(v_name)), _t47));
  return null;
}
function f_Lexer__ident(v_this, v_start, v_line, v_col) {
  let v_word = null;
  let _t48 = null, _t49 = null, _t50 = null, _t51 = null;
  L10: while (true) {
    Z.setLine(149);
    if (!Z.truthy(Z.B.is_alnum(f_zs_invoke(Z.dup(v_this), "peek", ((_t48 = Z.arrNew()), _t48))))) break;
    Z.setLine(149);
    f_zs_invoke(Z.dup(v_this), "bump", ((_t49 = Z.arrNew()), _t49));
  }
  Z.setLine(150);
  (v_word = Z.B.substr(Z.B.zs_obj_get(v_this, "src"), v_start, Z.sub(Z.B.zs_obj_get(v_this, "pos"), v_start)));
  Z.setLine(151);
  f_zs_invoke(Z.dup(v_this), "emit", ((_t50 = Z.arrNew()), Z.apush(_t50, (Z.truthy(Z.B.has_key(((_t51 = Z.arrNew()), Z.aset(_t51, "func", true), Z.aset(_t51, "fn", true), Z.aset(_t51, "return", true), Z.aset(_t51, "if", true), Z.aset(_t51, "elseif", true), Z.aset(_t51, "else", true), Z.aset(_t51, "switch", true), Z.aset(_t51, "case", true), Z.aset(_t51, "default", true), Z.aset(_t51, "match", true), Z.aset(_t51, "for", true), Z.aset(_t51, "foreach", true), Z.aset(_t51, "while", true), Z.aset(_t51, "do", true), Z.aset(_t51, "break", true), Z.aset(_t51, "continue", true), Z.aset(_t51, "as", true), Z.aset(_t51, "import", true), Z.aset(_t51, "namespace", true), Z.aset(_t51, "extern", true), Z.aset(_t51, "class", true), Z.aset(_t51, "interface", true), Z.aset(_t51, "trait", true), Z.aset(_t51, "extends", true), Z.aset(_t51, "implements", true), Z.aset(_t51, "new", true), Z.aset(_t51, "public", true), Z.aset(_t51, "private", true), Z.aset(_t51, "protected", true), Z.aset(_t51, "static", true), Z.aset(_t51, "abstract", true), Z.aset(_t51, "try", true), Z.aset(_t51, "catch", true), Z.aset(_t51, "finally", true), Z.aset(_t51, "throw", true), Z.aset(_t51, "using", true), Z.aset(_t51, "await", true), Z.aset(_t51, "echo", true), Z.aset(_t51, "true", true), Z.aset(_t51, "false", true), Z.aset(_t51, "null", true), Z.aset(_t51, "and", true), Z.aset(_t51, "or", true), Z.aset(_t51, "xor", true), _t51), v_word)) ? "kw" : "ident")), Z.apush(_t50, Z.dup(v_word)), Z.apush(_t50, Z.dup(v_start)), Z.apush(_t50, Z.dup(v_line)), Z.apush(_t50, Z.dup(v_col)), Z.apush(_t50, Z.dup(v_word)), _t50));
  return null;
}
function f_Lexer__digitValue(v_this, v_c) {
  let v_o = null;
  Z.setLine(155);
  if (Z.truthy(Z.ident(v_c, ""))) {
    Z.setLine(155);
    return Z.neg(1);
  }
  Z.setLine(156);
  (v_o = Z.B.ord(v_c));
  Z.setLine(157);
  if (Z.truthy((Z.truthy((Z.cmp(v_o, 48) >= 0)) && Z.truthy((Z.cmp(v_o, 57) <= 0))))) {
    Z.setLine(157);
    return Z.sub(v_o, 48);
  }
  Z.setLine(158);
  if (Z.truthy((Z.truthy((Z.cmp(v_o, 97) >= 0)) && Z.truthy((Z.cmp(v_o, 102) <= 0))))) {
    Z.setLine(158);
    return Z.sub(v_o, 87);
  }
  Z.setLine(159);
  if (Z.truthy((Z.truthy((Z.cmp(v_o, 65) >= 0)) && Z.truthy((Z.cmp(v_o, 70) <= 0))))) {
    Z.setLine(159);
    return Z.sub(v_o, 55);
  }
  Z.setLine(160);
  return Z.neg(1);
  return null;
}
function f_Lexer__digits(v_this) {
  let _t52 = null, _t53 = null, _t54 = null;
  L11: while (true) {
    Z.setLine(164);
    if (!Z.truthy((Z.truthy(Z.B.is_digit(f_zs_invoke(Z.dup(v_this), "peek", ((_t52 = Z.arrNew()), _t52)))) || Z.truthy(Z.ident(f_zs_invoke(Z.dup(v_this), "peek", ((_t53 = Z.arrNew()), _t53)), "_"))))) break;
    Z.setLine(164);
    f_zs_invoke(Z.dup(v_this), "bump", ((_t54 = Z.arrNew()), _t54));
  }
  return null;
}
function f_Lexer__number(v_this, v_start, v_line, v_col) {
  let v_p = null, v_radix = null, v_v = null, v_count = null, v_c = null, v_d = null, v_isFloat = null, v_e = null, v_sign = null, v_i = null, v_text = null, v_clean = null;
  let _t55 = null, _t56 = null, _t57 = null, _t58 = null, _t59 = null, _t60 = null, _t61 = null, _t62 = null, _t63 = null, _t64 = null, _t65 = null, _t66 = null, _t67 = null, _t68 = null, _t69 = null, _t70 = null, _t71 = null, _t72 = null, _t73 = null, _t74 = null, _t75 = null, _t76 = null, _t77 = null, _t78 = null, _t79 = null;
  Z.setLine(168);
  if (Z.truthy(Z.ident(f_zs_invoke(Z.dup(v_this), "peek", ((_t55 = Z.arrNew()), _t55)), "0"))) {
    Z.setLine(169);
    (v_p = f_zs_invoke(Z.dup(v_this), "peek", ((_t56 = Z.arrNew()), Z.apush(_t56, 1), _t56)));
    Z.setLine(170);
    (v_radix = 0);
    Z.setLine(171);
    if (Z.truthy((Z.truthy(Z.ident(v_p, "x")) || Z.truthy(Z.ident(v_p, "X"))))) {
      Z.setLine(171);
      (v_radix = 16);
    } else {
      Z.setLine(172);
      if (Z.truthy((Z.truthy(Z.ident(v_p, "b")) || Z.truthy(Z.ident(v_p, "B"))))) {
        Z.setLine(172);
        (v_radix = 2);
      } else {
        Z.setLine(173);
        if (Z.truthy((Z.truthy(Z.ident(v_p, "o")) || Z.truthy(Z.ident(v_p, "O"))))) {
          Z.setLine(173);
          (v_radix = 8);
        }
      }
    }
    Z.setLine(174);
    if (Z.truthy(!Z.ident(v_radix, 0))) {
      Z.setLine(175);
      f_zs_invoke(Z.dup(v_this), "bump", ((_t57 = Z.arrNew()), _t57));
      Z.setLine(175);
      f_zs_invoke(Z.dup(v_this), "bump", ((_t58 = Z.arrNew()), _t58));
      Z.setLine(176);
      (v_v = 0);
      Z.setLine(176);
      (v_count = 0);
      L12: while (true) {
        Z.setLine(177);
        if (!Z.truthy(true)) break;
        Z.setLine(178);
        (v_c = f_zs_invoke(Z.dup(v_this), "peek", ((_t59 = Z.arrNew()), _t59)));
        Z.setLine(179);
        if (Z.truthy(Z.ident(v_c, "_"))) {
          Z.setLine(179);
          f_zs_invoke(Z.dup(v_this), "bump", ((_t60 = Z.arrNew()), _t60));
          continue L12;
        }
        Z.setLine(180);
        (v_d = f_zs_invoke(Z.dup(v_this), "digitValue", ((_t61 = Z.arrNew()), Z.apush(_t61, Z.dup(v_c)), _t61)));
        Z.setLine(181);
        if (Z.truthy((Z.truthy((Z.cmp(v_d, 0) < 0)) || Z.truthy((Z.cmp(v_d, v_radix) >= 0))))) {
          break L12;
        }
        Z.setLine(182);
        (v_v = Z.add(Z.mul(v_v, v_radix), v_d));
        Z.setLine(182);
        ((_t62 = v_count), (v_count = Z.add(_t62, 1)), _t62);
        Z.setLine(183);
        f_zs_invoke(Z.dup(v_this), "bump", ((_t63 = Z.arrNew()), _t63));
      }
      Z.setLine(185);
      if (Z.truthy(Z.ident(v_count, 0))) {
        Z.setLine(185);
        f_zs_invoke(Z.dup(v_this), "fail", ((_t64 = Z.arrNew()), Z.apush(_t64, "niepoprawny literał całkowity"), Z.apush(_t64, Z.dup(v_line)), Z.apush(_t64, Z.dup(v_col)), _t64));
      }
      Z.setLine(186);
      f_zs_invoke(Z.dup(v_this), "emit", ((_t65 = Z.arrNew()), Z.apush(_t65, "int"), Z.apush(_t65, Z.B.substr(Z.B.zs_obj_get(v_this, "src"), v_start, Z.sub(Z.B.zs_obj_get(v_this, "pos"), v_start))), Z.apush(_t65, Z.dup(v_start)), Z.apush(_t65, Z.dup(v_line)), Z.apush(_t65, Z.dup(v_col)), Z.apush(_t65, Z.dup(v_v)), _t65));
      Z.setLine(187);
      return null;
    }
  }
  Z.setLine(190);
  f_zs_invoke(Z.dup(v_this), "digits", ((_t66 = Z.arrNew()), _t66));
  Z.setLine(191);
  (v_isFloat = false);
  Z.setLine(192);
  if (Z.truthy((Z.truthy(Z.ident(f_zs_invoke(Z.dup(v_this), "peek", ((_t67 = Z.arrNew()), _t67)), ".")) && Z.truthy(Z.B.is_digit(f_zs_invoke(Z.dup(v_this), "peek", ((_t68 = Z.arrNew()), Z.apush(_t68, 1), _t68))))))) {
    Z.setLine(193);
    (v_isFloat = true);
    Z.setLine(193);
    f_zs_invoke(Z.dup(v_this), "bump", ((_t69 = Z.arrNew()), _t69));
    Z.setLine(193);
    f_zs_invoke(Z.dup(v_this), "digits", ((_t70 = Z.arrNew()), _t70));
  }
  Z.setLine(195);
  (v_e = f_zs_invoke(Z.dup(v_this), "peek", ((_t71 = Z.arrNew()), _t71)));
  Z.setLine(196);
  if (Z.truthy((Z.truthy(Z.ident(v_e, "e")) || Z.truthy(Z.ident(v_e, "E"))))) {
    Z.setLine(197);
    (v_sign = (Z.truthy((Z.truthy(Z.ident(f_zs_invoke(Z.dup(v_this), "peek", ((_t72 = Z.arrNew()), Z.apush(_t72, 1), _t72)), "+")) || Z.truthy(Z.ident(f_zs_invoke(Z.dup(v_this), "peek", ((_t73 = Z.arrNew()), Z.apush(_t73, 1), _t73)), "-")))) ? 1 : 0));
    Z.setLine(198);
    if (Z.truthy(Z.B.is_digit(f_zs_invoke(Z.dup(v_this), "peek", ((_t74 = Z.arrNew()), Z.apush(_t74, Z.add(1, v_sign)), _t74))))) {
      Z.setLine(199);
      (v_isFloat = true);
      Z.setLine(200);
      (v_i = 0);
      L13: for (; Z.truthy((Z.cmp(v_i, v_sign) <= 0)); ((_t75 = v_i), (v_i = Z.add(_t75, 1)), _t75)) {
        Z.setLine(200);
        f_zs_invoke(Z.dup(v_this), "bump", ((_t76 = Z.arrNew()), _t76));
      }
      Z.setLine(201);
      f_zs_invoke(Z.dup(v_this), "digits", ((_t77 = Z.arrNew()), _t77));
    }
  }
  Z.setLine(204);
  (v_text = Z.B.substr(Z.B.zs_obj_get(v_this, "src"), v_start, Z.sub(Z.B.zs_obj_get(v_this, "pos"), v_start)));
  Z.setLine(205);
  (v_clean = Z.B.replace(v_text, "_", ""));
  Z.setLine(206);
  if (Z.truthy(v_isFloat)) {
    Z.setLine(206);
    f_zs_invoke(Z.dup(v_this), "emit", ((_t78 = Z.arrNew()), Z.apush(_t78, "float"), Z.apush(_t78, Z.dup(v_text)), Z.apush(_t78, Z.dup(v_start)), Z.apush(_t78, Z.dup(v_line)), Z.apush(_t78, Z.dup(v_col)), Z.apush(_t78, Z.B.floatval(v_clean)), _t78));
  } else {
    Z.setLine(207);
    f_zs_invoke(Z.dup(v_this), "emit", ((_t79 = Z.arrNew()), Z.apush(_t79, "int"), Z.apush(_t79, Z.dup(v_text)), Z.apush(_t79, Z.dup(v_start)), Z.apush(_t79, Z.dup(v_line)), Z.apush(_t79, Z.dup(v_col)), Z.apush(_t79, Z.B.intval(v_clean)), _t79));
  }
  return null;
}
function f_Lexer__string(v_this, v_q, v_start, v_line, v_col) {
  let v_buf = null, v_c = null, v_e = null;
  let _t80 = null, _t81 = null, _t82 = null, _t83 = null, _t84 = null, _t85 = null;
  Z.setLine(211);
  f_zs_invoke(Z.dup(v_this), "bump", ((_t80 = Z.arrNew()), _t80));
  Z.setLine(212);
  (v_buf = "");
  L14: while (true) {
    Z.setLine(213);
    if (!Z.truthy(true)) break;
    Z.setLine(214);
    if (Z.truthy((Z.cmp(Z.B.zs_obj_get(v_this, "pos"), Z.B.zs_obj_get(v_this, "n")) >= 0))) {
      Z.setLine(214);
      f_zs_invoke(Z.dup(v_this), "fail", ((_t81 = Z.arrNew()), Z.apush(_t81, "niezamknięty literał tekstowy"), Z.apush(_t81, Z.dup(v_line)), Z.apush(_t81, Z.dup(v_col)), _t81));
    }
    Z.setLine(215);
    (v_c = f_zs_invoke(Z.dup(v_this), "bump", ((_t82 = Z.arrNew()), _t82)));
    Z.setLine(216);
    if (Z.truthy(Z.ident(v_c, v_q))) {
      break L14;
    }
    Z.setLine(217);
    if (Z.truthy(!Z.ident(v_c, "\\"))) {
      Z.setLine(217);
      (v_buf = Z.concat(v_buf, v_c));
      continue L14;
    }
    Z.setLine(218);
    if (Z.truthy((Z.cmp(Z.B.zs_obj_get(v_this, "pos"), Z.B.zs_obj_get(v_this, "n")) >= 0))) {
      Z.setLine(218);
      f_zs_invoke(Z.dup(v_this), "fail", ((_t83 = Z.arrNew()), Z.apush(_t83, "niezamknięty literał tekstowy"), Z.apush(_t83, Z.dup(v_line)), Z.apush(_t83, Z.dup(v_col)), _t83));
    }
    Z.setLine(219);
    (v_e = f_zs_invoke(Z.dup(v_this), "bump", ((_t84 = Z.arrNew()), _t84)));
    Z.setLine(220);
    if (Z.truthy(Z.ident(v_e, "\\"))) {
      Z.setLine(220);
      (v_buf = Z.concat(v_buf, "\\"));
    } else {
      Z.setLine(221);
      if (Z.truthy(Z.ident(v_e, v_q))) {
        Z.setLine(221);
        (v_buf = Z.concat(v_buf, v_q));
      } else {
        Z.setLine(222);
        if (Z.truthy((Z.truthy(Z.ident(v_q, "\"")) && Z.truthy(Z.ident(v_e, "n"))))) {
          Z.setLine(222);
          (v_buf = Z.concat(v_buf, "\n"));
        } else {
          Z.setLine(223);
          if (Z.truthy((Z.truthy(Z.ident(v_q, "\"")) && Z.truthy(Z.ident(v_e, "t"))))) {
            Z.setLine(223);
            (v_buf = Z.concat(v_buf, "\t"));
          } else {
            Z.setLine(224);
            if (Z.truthy((Z.truthy(Z.ident(v_q, "\"")) && Z.truthy(Z.ident(v_e, "r"))))) {
              Z.setLine(224);
              (v_buf = Z.concat(v_buf, "\r"));
            } else {
              Z.setLine(225);
              if (Z.truthy((Z.truthy(Z.ident(v_q, "\"")) && Z.truthy(Z.ident(v_e, "0"))))) {
                Z.setLine(225);
                (v_buf = Z.concat(v_buf, Z.B.chr(0)));
              } else {
                Z.setLine(226);
                if (Z.truthy((Z.truthy(Z.ident(v_q, "\"")) && Z.truthy(Z.ident(v_e, "$"))))) {
                  Z.setLine(226);
                  (v_buf = Z.concat(v_buf, "$"));
                } else {
                  Z.setLine(227);
                  (v_buf = Z.concat(v_buf, Z.concat("\\", v_e)));
                }
              }
            }
          }
        }
      }
    }
  }
  Z.setLine(229);
  f_zs_invoke(Z.dup(v_this), "emit", ((_t85 = Z.arrNew()), Z.apush(_t85, "str"), Z.apush(_t85, Z.B.substr(Z.B.zs_obj_get(v_this, "src"), v_start, Z.sub(Z.B.zs_obj_get(v_this, "pos"), v_start))), Z.apush(_t85, Z.dup(v_start)), Z.apush(_t85, Z.dup(v_line)), Z.apush(_t85, Z.dup(v_col)), Z.apush(_t85, Z.dup(v_buf)), _t85));
  return null;
}
function f_Lexer__op(v_this, v_start, v_line, v_col) {
  let v_s3 = null, v_s2 = null, v_s1 = null, v_len = null, v_i = null, v_text = null;
  let _t86 = null, _t87 = null, _t88 = null, _t89 = null, _t90 = null, _t91 = null;
  Z.setLine(233);
  (v_s3 = Z.B.substr(Z.B.zs_obj_get(v_this, "src"), Z.B.zs_obj_get(v_this, "pos"), 3));
  Z.setLine(234);
  (v_s2 = Z.B.substr(Z.B.zs_obj_get(v_this, "src"), Z.B.zs_obj_get(v_this, "pos"), 2));
  Z.setLine(235);
  (v_s1 = Z.B.substr(Z.B.zs_obj_get(v_this, "src"), Z.B.zs_obj_get(v_this, "pos"), 1));
  Z.setLine(236);
  (v_len = 0);
  Z.setLine(237);
  if (Z.truthy(Z.B.has_key(((_t86 = Z.arrNew()), Z.aset(_t86, "===", true), Z.aset(_t86, "!==", true), Z.aset(_t86, "??=", true), Z.aset(_t86, "...", true), _t86), v_s3))) {
    Z.setLine(237);
    (v_len = 3);
  } else {
    Z.setLine(238);
    if (Z.truthy(Z.B.has_key(((_t87 = Z.arrNew()), Z.aset(_t87, "**", true), Z.aset(_t87, "==", true), Z.aset(_t87, "!=", true), Z.aset(_t87, "<=", true), Z.aset(_t87, ">=", true), Z.aset(_t87, "&&", true), Z.aset(_t87, "||", true), Z.aset(_t87, "??", true), Z.aset(_t87, "->", true), Z.aset(_t87, "=>", true), Z.aset(_t87, "++", true), Z.aset(_t87, "--", true), Z.aset(_t87, "+=", true), Z.aset(_t87, "-=", true), Z.aset(_t87, "*=", true), Z.aset(_t87, "/=", true), Z.aset(_t87, "%=", true), Z.aset(_t87, ".=", true), Z.aset(_t87, "<<", true), Z.aset(_t87, ">>", true), _t87), v_s2))) {
      Z.setLine(238);
      (v_len = 2);
    } else {
      Z.setLine(239);
      if (Z.truthy(Z.B.contains("+-*/%.=<>!?:,;(){}[]&|^~", v_s1))) {
        Z.setLine(239);
        (v_len = 1);
      }
    }
  }
  Z.setLine(240);
  if (Z.truthy(Z.ident(v_len, 0))) {
    Z.setLine(240);
    f_zs_invoke(Z.dup(v_this), "fail", ((_t88 = Z.arrNew()), Z.apush(_t88, Z.concat(Z.concat("nieoczekiwany znak `", v_s1), "`")), Z.apush(_t88, Z.dup(v_line)), Z.apush(_t88, Z.dup(v_col)), _t88));
  }
  Z.setLine(241);
  (v_i = 0);
  L15: for (; Z.truthy((Z.cmp(v_i, v_len) < 0)); ((_t89 = v_i), (v_i = Z.add(_t89, 1)), _t89)) {
    Z.setLine(241);
    f_zs_invoke(Z.dup(v_this), "bump", ((_t90 = Z.arrNew()), _t90));
  }
  Z.setLine(242);
  (v_text = Z.B.substr(Z.B.zs_obj_get(v_this, "src"), v_start, v_len));
  Z.setLine(243);
  f_zs_invoke(Z.dup(v_this), "emit", ((_t91 = Z.arrNew()), Z.apush(_t91, "op"), Z.apush(_t91, Z.dup(v_text)), Z.apush(_t91, Z.dup(v_start)), Z.apush(_t91, Z.dup(v_line)), Z.apush(_t91, Z.dup(v_col)), Z.apush(_t91, Z.dup(v_text)), _t91));
  return null;
}
function f_Lexer__new(v_src, v_keep) {
  let v___o = null;
  Z.setLine(35);
  (v___o = Z.B.zs_obj_new("Lexer"));
  Z.setLine(35);
  Z.B.zs_obj_set(v___o, "src", null);
  Z.setLine(35);
  Z.B.zs_obj_set(v___o, "n", null);
  Z.setLine(35);
  Z.B.zs_obj_set(v___o, "pos", null);
  Z.setLine(35);
  Z.B.zs_obj_set(v___o, "line", null);
  Z.setLine(35);
  Z.B.zs_obj_set(v___o, "col", null);
  Z.setLine(35);
  Z.B.zs_obj_set(v___o, "out", null);
  Z.setLine(35);
  Z.B.zs_obj_set(v___o, "keep", null);
  Z.setLine(35);
  f_Lexer____construct(Z.dup(v___o), Z.dup(v_src), Z.dup(v_keep));
  Z.setLine(35);
  return Z.dup(v___o);
  return null;
}
function f_ParseError____construct(v_this, v_message, v_line, v_col) {
  Z.setLine(9);
  f_Exception____construct(Z.dup(v_this), Z.concat(Z.concat(Z.concat(Z.concat(v_line, ":"), v_col), ": "), v_message));
  Z.setLine(10);
  Z.B.zs_obj_set(v_this, "lineNo", v_line);
  Z.setLine(11);
  Z.B.zs_obj_set(v_this, "colNo", v_col);
  return null;
}
function f_ParseError__new(v_message, v_line, v_col) {
  let v___o = null;
  Z.setLine(5);
  (v___o = Z.B.zs_obj_new("ParseError"));
  Z.setLine(5);
  Z.B.zs_obj_set(v___o, "message", "");
  Z.setLine(5);
  Z.B.zs_obj_set(v___o, "line", 0);
  Z.setLine(5);
  Z.B.zs_obj_set(v___o, "lineNo", null);
  Z.setLine(5);
  Z.B.zs_obj_set(v___o, "colNo", null);
  Z.setLine(5);
  f_ParseError____construct(Z.dup(v___o), Z.dup(v_message), Z.dup(v_line), Z.dup(v_col));
  Z.setLine(5);
  return Z.dup(v___o);
  return null;
}
function f_Tables__new() {
  let v___o = null;
  Z.setLine(15);
  (v___o = Z.B.zs_obj_new("Tables"));
  Z.setLine(15);
  return Z.dup(v___o);
  return null;
}
function f_Parser____construct(v_this, v_toks) {
  Z.setLine(62);
  Z.B.zs_obj_set(v_this, "toks", v_toks);
  Z.setLine(63);
  Z.B.zs_obj_set(v_this, "pos", 0);
  Z.setLine(64);
  Z.B.zs_obj_set(v_this, "last", Z.sub(Z.B.count(v_toks), 1));
  return null;
}
function f_Parser__cur(v_this) {
  Z.setLine(68);
  return Z.dup(Z.index(Z.B.zs_obj_get(v_this, "toks"), (Z.truthy((Z.cmp(Z.B.zs_obj_get(v_this, "pos"), Z.B.zs_obj_get(v_this, "last")) < 0)) ? Z.B.zs_obj_get(v_this, "pos") : Z.B.zs_obj_get(v_this, "last"))));
  return null;
}
function f_Parser__at(v_this, v_n) {
  let v_i = null;
  Z.setLine(69);
  (v_i = Z.add(Z.B.zs_obj_get(v_this, "pos"), v_n));
  Z.setLine(69);
  return Z.dup(Z.index(Z.B.zs_obj_get(v_this, "toks"), (Z.truthy((Z.cmp(v_i, Z.B.zs_obj_get(v_this, "last")) < 0)) ? v_i : Z.B.zs_obj_get(v_this, "last"))));
  return null;
}
function f_Parser__line(v_this) {
  let _t92 = null;
  Z.setLine(70);
  return Z.dup(Z.index(f_zs_invoke(Z.dup(v_this), "cur", ((_t92 = Z.arrNew()), _t92)), "line"));
  return null;
}
function f_Parser__atEof(v_this) {
  let _t93 = null;
  Z.setLine(71);
  return Z.ident(Z.index(f_zs_invoke(Z.dup(v_this), "cur", ((_t93 = Z.arrNew()), _t93)), "kind"), "eof");
  return null;
}
function f_Parser__bump(v_this) {
  let v_t = null;
  let _t94 = null;
  Z.setLine(72);
  (v_t = f_zs_invoke(Z.dup(v_this), "cur", ((_t94 = Z.arrNew()), _t94)));
  Z.setLine(72);
  if (Z.truthy((Z.cmp(Z.B.zs_obj_get(v_this, "pos"), Z.B.zs_obj_get(v_this, "last")) < 0))) {
    Z.setLine(72);
    Z.B.zs_obj_set(v_this, "pos", Z.add(Z.B.zs_obj_get(v_this, "pos"), 1));
  }
  Z.setLine(72);
  return Z.dup(v_t);
  return null;
}
function f_Parser__back(v_this) {
  Z.setLine(73);
  Z.B.zs_obj_set(v_this, "pos", Z.sub(Z.B.zs_obj_get(v_this, "pos"), 1));
  return null;
}
function f_Parser__fail(v_this, v_msg) {
  let v_t = null;
  let _t95 = null;
  Z.setLine(74);
  (v_t = f_zs_invoke(Z.dup(v_this), "cur", ((_t95 = Z.arrNew()), _t95)));
  Z.setLine(74);
  Z.throwV(f_ParseError__new(Z.dup(v_msg), Z.dup(Z.index(v_t, "line")), Z.dup(Z.index(v_t, "col"))));
  return null;
}
function f_Parser__isOp(v_this, v_s) {
  let v_t = null;
  let _t96 = null;
  Z.setLine(75);
  (v_t = f_zs_invoke(Z.dup(v_this), "cur", ((_t96 = Z.arrNew()), _t96)));
  Z.setLine(75);
  return (Z.truthy(Z.ident(Z.index(v_t, "kind"), "op")) && Z.truthy(Z.ident(Z.index(v_t, "text"), v_s)));
  return null;
}
function f_Parser__isKw(v_this, v_s) {
  let v_t = null;
  let _t97 = null;
  Z.setLine(76);
  (v_t = f_zs_invoke(Z.dup(v_this), "cur", ((_t97 = Z.arrNew()), _t97)));
  Z.setLine(76);
  return (Z.truthy(Z.ident(Z.index(v_t, "kind"), "kw")) && Z.truthy(Z.ident(Z.index(v_t, "text"), v_s)));
  return null;
}
function f_Parser__isWord(v_this, v_s) {
  let v_t = null;
  let _t98 = null;
  Z.setLine(77);
  (v_t = f_zs_invoke(Z.dup(v_this), "cur", ((_t98 = Z.arrNew()), _t98)));
  Z.setLine(77);
  return (Z.truthy(Z.ident(Z.index(v_t, "kind"), "ident")) && Z.truthy(Z.ident(Z.index(v_t, "text"), v_s)));
  return null;
}
function f_Parser__isVar(v_this) {
  let _t99 = null;
  Z.setLine(78);
  return Z.ident(Z.index(f_zs_invoke(Z.dup(v_this), "cur", ((_t99 = Z.arrNew()), _t99)), "kind"), "var");
  return null;
}
function f_Parser__eatOp(v_this, v_s) {
  let _t100 = null, _t101 = null;
  Z.setLine(79);
  if (Z.truthy(f_zs_invoke(Z.dup(v_this), "isOp", ((_t100 = Z.arrNew()), Z.apush(_t100, Z.dup(v_s)), _t100)))) {
    Z.setLine(79);
    f_zs_invoke(Z.dup(v_this), "bump", ((_t101 = Z.arrNew()), _t101));
    Z.setLine(79);
    return true;
  }
  Z.setLine(79);
  return false;
  return null;
}
function f_Parser__eatKw(v_this, v_s) {
  let _t102 = null, _t103 = null;
  Z.setLine(80);
  if (Z.truthy(f_zs_invoke(Z.dup(v_this), "isKw", ((_t102 = Z.arrNew()), Z.apush(_t102, Z.dup(v_s)), _t102)))) {
    Z.setLine(80);
    f_zs_invoke(Z.dup(v_this), "bump", ((_t103 = Z.arrNew()), _t103));
    Z.setLine(80);
    return true;
  }
  Z.setLine(80);
  return false;
  return null;
}
function f_Parser__eatWord(v_this, v_s) {
  let _t104 = null, _t105 = null;
  Z.setLine(81);
  if (Z.truthy(f_zs_invoke(Z.dup(v_this), "isWord", ((_t104 = Z.arrNew()), Z.apush(_t104, Z.dup(v_s)), _t104)))) {
    Z.setLine(81);
    f_zs_invoke(Z.dup(v_this), "bump", ((_t105 = Z.arrNew()), _t105));
    Z.setLine(81);
    return true;
  }
  Z.setLine(81);
  return false;
  return null;
}
function f_Parser__expectOp(v_this, v_s) {
  let _t106 = null, _t107 = null, _t108 = null;
  Z.setLine(83);
  if (Z.truthy(!Z.truthy(f_zs_invoke(Z.dup(v_this), "eatOp", ((_t106 = Z.arrNew()), Z.apush(_t106, Z.dup(v_s)), _t106))))) {
    Z.setLine(83);
    f_zs_invoke(Z.dup(v_this), "fail", ((_t107 = Z.arrNew()), Z.apush(_t107, Z.concat(Z.concat(Z.concat(Z.concat("oczekiwano `", v_s), "`, jest `"), Z.index(f_zs_invoke(Z.dup(v_this), "cur", ((_t108 = Z.arrNew()), _t108)), "text")), "`")), _t107));
  }
  return null;
}
function f_Parser__ident(v_this) {
  let v_t = null;
  let _t109 = null, _t110 = null, _t111 = null, _t112 = null;
  Z.setLine(86);
  (v_t = f_zs_invoke(Z.dup(v_this), "bump", ((_t109 = Z.arrNew()), _t109)));
  Z.setLine(87);
  if (Z.truthy(!Z.ident(Z.index(v_t, "kind"), "ident"))) {
    Z.setLine(87);
    f_zs_invoke(Z.dup(v_this), "back", ((_t110 = Z.arrNew()), _t110));
    Z.setLine(87);
    f_zs_invoke(Z.dup(v_this), "fail", ((_t111 = Z.arrNew()), Z.apush(_t111, Z.concat(Z.concat("oczekiwano identyfikatora, jest `", Z.index(f_zs_invoke(Z.dup(v_this), "cur", ((_t112 = Z.arrNew()), _t112)), "text")), "`")), _t111));
  }
  Z.setLine(88);
  return Z.dup(Z.index(v_t, "text"));
  return null;
}
function f_Parser__varName(v_this) {
  let v_t = null;
  let _t113 = null, _t114 = null, _t115 = null;
  Z.setLine(91);
  (v_t = f_zs_invoke(Z.dup(v_this), "bump", ((_t113 = Z.arrNew()), _t113)));
  Z.setLine(92);
  if (Z.truthy(!Z.ident(Z.index(v_t, "kind"), "var"))) {
    Z.setLine(92);
    f_zs_invoke(Z.dup(v_this), "back", ((_t114 = Z.arrNew()), _t114));
    Z.setLine(92);
    f_zs_invoke(Z.dup(v_this), "fail", ((_t115 = Z.arrNew()), Z.apush(_t115, "oczekiwano zmiennej"), _t115));
  }
  Z.setLine(93);
  return Z.dup(Z.index(v_t, "value"));
  return null;
}
function f_Parser__isFuncKw(v_this) {
  let _t116 = null, _t117 = null;
  Z.setLine(95);
  return (Z.truthy(f_zs_invoke(Z.dup(v_this), "isKw", ((_t116 = Z.arrNew()), Z.apush(_t116, "func"), _t116))) || Z.truthy(f_zs_invoke(Z.dup(v_this), "isWord", ((_t117 = Z.arrNew()), Z.apush(_t117, "function"), _t117))));
  return null;
}
function f_Parser__block(v_this) {
  let v_v = null;
  let _t118 = null, _t119 = null, _t120 = null, _t121 = null, _t122 = null, _t123 = null, _t124 = null;
  Z.setLine(99);
  f_zs_invoke(Z.dup(v_this), "expectOp", ((_t118 = Z.arrNew()), Z.apush(_t118, "{"), _t118));
  Z.setLine(100);
  (v_v = ((_t119 = Z.arrNew()), _t119));
  L16: while (true) {
    Z.setLine(101);
    if (!Z.truthy(!Z.truthy(f_zs_invoke(Z.dup(v_this), "isOp", ((_t120 = Z.arrNew()), Z.apush(_t120, "}"), _t120))))) break;
    Z.setLine(102);
    if (Z.truthy(f_zs_invoke(Z.dup(v_this), "atEof", ((_t121 = Z.arrNew()), _t121)))) {
      Z.setLine(102);
      f_zs_invoke(Z.dup(v_this), "fail", ((_t122 = Z.arrNew()), Z.apush(_t122, "niezamknięty blok `{`"), _t122));
    }
    Z.setLine(103);
    Z.apush((v_v = Z.wr(v_v)), f_zs_invoke(Z.dup(v_this), "stmt", ((_t123 = Z.arrNew()), _t123)));
  }
  Z.setLine(105);
  f_zs_invoke(Z.dup(v_this), "bump", ((_t124 = Z.arrNew()), _t124));
  Z.setLine(106);
  return Z.dup(v_v);
  return null;
}
function f_Parser__body(v_this) {
  let _t125 = null, _t126 = null, _t127 = null, _t128 = null;
  Z.setLine(110);
  if (Z.truthy(f_zs_invoke(Z.dup(v_this), "isOp", ((_t125 = Z.arrNew()), Z.apush(_t125, "{"), _t125)))) {
    Z.setLine(110);
    return f_zs_invoke(Z.dup(v_this), "block", ((_t126 = Z.arrNew()), _t126));
  }
  Z.setLine(111);
  return ((_t127 = Z.arrNew()), Z.apush(_t127, f_zs_invoke(Z.dup(v_this), "stmt", ((_t128 = Z.arrNew()), _t128))), _t127);
  return null;
}
function f_Parser__parenExpr(v_this) {
  let v_e = null;
  let _t129 = null, _t130 = null, _t131 = null;
  Z.setLine(115);
  f_zs_invoke(Z.dup(v_this), "expectOp", ((_t129 = Z.arrNew()), Z.apush(_t129, "("), _t129));
  Z.setLine(116);
  (v_e = f_zs_invoke(Z.dup(v_this), "expr", ((_t130 = Z.arrNew()), _t130)));
  Z.setLine(117);
  f_zs_invoke(Z.dup(v_this), "expectOp", ((_t131 = Z.arrNew()), Z.apush(_t131, ")"), _t131));
  Z.setLine(118);
  return Z.dup(v_e);
  return null;
}
function f_Parser__path(v_this) {
  let v_v = null;
  let _t132 = null, _t133 = null, _t134 = null, _t135 = null;
  Z.setLine(122);
  (v_v = ((_t132 = Z.arrNew()), Z.apush(_t132, f_zs_invoke(Z.dup(v_this), "ident", ((_t133 = Z.arrNew()), _t133))), _t132));
  L17: while (true) {
    Z.setLine(123);
    if (!Z.truthy(f_zs_invoke(Z.dup(v_this), "eatOp", ((_t134 = Z.arrNew()), Z.apush(_t134, "."), _t134)))) break;
    Z.setLine(123);
    Z.apush((v_v = Z.wr(v_v)), f_zs_invoke(Z.dup(v_this), "ident", ((_t135 = Z.arrNew()), _t135)));
  }
  Z.setLine(124);
  return Z.dup(v_v);
  return null;
}
function f_Parser__stmt(v_this) {
  let v_line = null, v_t = null, v_k = null, v_x = null, v_c = null, v_b = null, v_e = null, v_n = null, v_v = null, v_p = null, v_r = null, v_t2 = null;
  let _t136 = null, _t137 = null, _t138 = null, _t139 = null, _t140 = null, _t141 = null, _t142 = null, _t143 = null, _t144 = null, _t145 = null, _t146 = null, _t147 = null, _t148 = null, _t149 = null, _t150 = null, _t151 = null, _t152 = null, _t153 = null, _t154 = null, _t155 = null, _t156 = null, _t157 = null, _t158 = null, _t159 = null, _t160 = null, _t161 = null, _t162 = null, _t163 = null, _t164 = null, _t165 = null, _t166 = null, _t167 = null, _t168 = null, _t169 = null, _t170 = null, _t171 = null, _t172 = null, _t173 = null, _t174 = null, _t175 = null, _t176 = null, _t177 = null, _t178 = null, _t179 = null, _t180 = null, _t181 = null, _t182 = null, _t183 = null, _t184 = null, _t185 = null, _t186 = null, _t187 = null, _t188 = null, _t189 = null, _t190 = null, _t191 = null, _t192 = null, _t193 = null, _t194 = null, _t195 = null, _t196 = null, _t197 = null, _t198 = null, _t199 = null, _t200 = null, _t201 = null, _t202 = null, _t203 = null, _t204 = null, _t205 = null, _t206 = null, _t207 = null;
  Z.setLine(128);
  (v_line = f_zs_invoke(Z.dup(v_this), "line", ((_t136 = Z.arrNew()), _t136)));
  Z.setLine(129);
  (v_t = f_zs_invoke(Z.dup(v_this), "cur", ((_t137 = Z.arrNew()), _t137)));
  Z.setLine(130);
  (v_k = Z.dup(Z.index(v_t, "kind")));
  Z.setLine(131);
  (v_x = Z.dup(Z.index(v_t, "text")));
  Z.setLine(132);
  if (Z.truthy((Z.truthy(Z.ident(v_k, "op")) && Z.truthy(Z.ident(v_x, "{"))))) {
    Z.setLine(132);
    return f_Workspace_parser__node("Block", Z.dup(v_line), ((_t138 = Z.arrNew()), Z.apush(_t138, f_zs_invoke(Z.dup(v_this), "block", ((_t139 = Z.arrNew()), _t139))), _t138));
  }
  Z.setLine(133);
  if (Z.truthy((Z.truthy(Z.ident(v_k, "op")) && Z.truthy(Z.ident(v_x, ";"))))) {
    Z.setLine(133);
    f_zs_invoke(Z.dup(v_this), "bump", ((_t140 = Z.arrNew()), _t140));
    Z.setLine(133);
    return f_Workspace_parser__node("Block", Z.dup(v_line), ((_t141 = Z.arrNew()), Z.apush(_t141, ((_t142 = Z.arrNew()), _t142)), _t141));
  }
  Z.setLine(134);
  if (Z.truthy(Z.ident(v_k, "kw"))) {
    Z.setLine(135);
    if (Z.truthy(Z.ident(v_x, "if"))) {
      Z.setLine(135);
      f_zs_invoke(Z.dup(v_this), "bump", ((_t143 = Z.arrNew()), _t143));
      Z.setLine(135);
      return f_zs_invoke(Z.dup(v_this), "ifRest", ((_t144 = Z.arrNew()), Z.apush(_t144, Z.dup(v_line)), _t144));
    }
    Z.setLine(136);
    if (Z.truthy(Z.ident(v_x, "while"))) {
      Z.setLine(137);
      f_zs_invoke(Z.dup(v_this), "bump", ((_t145 = Z.arrNew()), _t145));
      Z.setLine(137);
      (v_c = f_zs_invoke(Z.dup(v_this), "parenExpr", ((_t146 = Z.arrNew()), _t146)));
      Z.setLine(137);
      (v_b = f_zs_invoke(Z.dup(v_this), "body", ((_t147 = Z.arrNew()), _t147)));
      Z.setLine(138);
      return f_Workspace_parser__node("While", Z.dup(v_line), ((_t148 = Z.arrNew()), Z.apush(_t148, Z.dup(v_c)), Z.apush(_t148, Z.dup(v_b)), _t148));
    }
    Z.setLine(140);
    if (Z.truthy(Z.ident(v_x, "do"))) {
      Z.setLine(141);
      f_zs_invoke(Z.dup(v_this), "bump", ((_t149 = Z.arrNew()), _t149));
      Z.setLine(141);
      (v_b = f_zs_invoke(Z.dup(v_this), "body", ((_t150 = Z.arrNew()), _t150)));
      Z.setLine(142);
      if (Z.truthy(!Z.truthy(f_zs_invoke(Z.dup(v_this), "eatKw", ((_t151 = Z.arrNew()), Z.apush(_t151, "while"), _t151))))) {
        Z.setLine(142);
        f_zs_invoke(Z.dup(v_this), "fail", ((_t152 = Z.arrNew()), Z.apush(_t152, "oczekiwano `while` po `do`"), _t152));
      }
      Z.setLine(143);
      (v_c = f_zs_invoke(Z.dup(v_this), "parenExpr", ((_t153 = Z.arrNew()), _t153)));
      Z.setLine(143);
      f_zs_invoke(Z.dup(v_this), "eatOp", ((_t154 = Z.arrNew()), Z.apush(_t154, ";"), _t154));
      Z.setLine(144);
      return f_Workspace_parser__node("DoWhile", Z.dup(v_line), ((_t155 = Z.arrNew()), Z.apush(_t155, Z.dup(v_b)), Z.apush(_t155, Z.dup(v_c)), _t155));
    }
    Z.setLine(146);
    if (Z.truthy(Z.ident(v_x, "for"))) {
      Z.setLine(146);
      return f_zs_invoke(Z.dup(v_this), "forStmt", ((_t156 = Z.arrNew()), Z.apush(_t156, Z.dup(v_line)), _t156));
    }
    Z.setLine(147);
    if (Z.truthy(Z.ident(v_x, "foreach"))) {
      Z.setLine(147);
      return f_zs_invoke(Z.dup(v_this), "foreachStmt", ((_t157 = Z.arrNew()), Z.apush(_t157, Z.dup(v_line)), _t157));
    }
    Z.setLine(148);
    if (Z.truthy(Z.ident(v_x, "switch"))) {
      Z.setLine(148);
      return f_zs_invoke(Z.dup(v_this), "switchStmt", ((_t158 = Z.arrNew()), Z.apush(_t158, Z.dup(v_line)), _t158));
    }
    Z.setLine(149);
    if (Z.truthy(Z.ident(v_x, "return"))) {
      Z.setLine(150);
      f_zs_invoke(Z.dup(v_this), "bump", ((_t159 = Z.arrNew()), _t159));
      Z.setLine(151);
      (v_e = (Z.truthy(f_zs_invoke(Z.dup(v_this), "isOp", ((_t160 = Z.arrNew()), Z.apush(_t160, ";"), _t160))) ? null : f_zs_invoke(Z.dup(v_this), "expr", ((_t161 = Z.arrNew()), _t161))));
      Z.setLine(152);
      f_zs_invoke(Z.dup(v_this), "expectOp", ((_t162 = Z.arrNew()), Z.apush(_t162, ";"), _t162));
      Z.setLine(153);
      return f_Workspace_parser__node("Return", Z.dup(v_line), ((_t163 = Z.arrNew()), Z.apush(_t163, Z.dup(v_e)), _t163));
    }
    Z.setLine(155);
    if (Z.truthy((Z.truthy(Z.ident(v_x, "break")) || Z.truthy(Z.ident(v_x, "continue"))))) {
      Z.setLine(156);
      f_zs_invoke(Z.dup(v_this), "bump", ((_t164 = Z.arrNew()), _t164));
      Z.setLine(157);
      (v_n = 1);
      Z.setLine(158);
      if (Z.truthy(Z.ident(Z.index(f_zs_invoke(Z.dup(v_this), "cur", ((_t165 = Z.arrNew()), _t165)), "kind"), "int"))) {
        Z.setLine(158);
        (v_n = Z.dup(Z.index(f_zs_invoke(Z.dup(v_this), "bump", ((_t166 = Z.arrNew()), _t166)), "value")));
      }
      Z.setLine(159);
      f_zs_invoke(Z.dup(v_this), "expectOp", ((_t167 = Z.arrNew()), Z.apush(_t167, ";"), _t167));
      Z.setLine(160);
      return f_Workspace_parser__node((Z.truthy(Z.ident(v_x, "break")) ? "Break" : "Continue"), Z.dup(v_line), ((_t168 = Z.arrNew()), Z.apush(_t168, Z.dup(v_n)), _t168));
    }
    Z.setLine(162);
    if (Z.truthy(Z.ident(v_x, "throw"))) {
      Z.setLine(162);
      f_zs_invoke(Z.dup(v_this), "bump", ((_t169 = Z.arrNew()), _t169));
      Z.setLine(162);
      (v_e = f_zs_invoke(Z.dup(v_this), "expr", ((_t170 = Z.arrNew()), _t170)));
      Z.setLine(162);
      f_zs_invoke(Z.dup(v_this), "expectOp", ((_t171 = Z.arrNew()), Z.apush(_t171, ";"), _t171));
      Z.setLine(162);
      return f_Workspace_parser__node("Throw", Z.dup(v_line), ((_t172 = Z.arrNew()), Z.apush(_t172, Z.dup(v_e)), _t172));
    }
    Z.setLine(163);
    if (Z.truthy(Z.ident(v_x, "try"))) {
      Z.setLine(163);
      return f_zs_invoke(Z.dup(v_this), "tryStmt", ((_t173 = Z.arrNew()), Z.apush(_t173, Z.dup(v_line)), _t173));
    }
    Z.setLine(164);
    if (Z.truthy(Z.ident(v_x, "echo"))) {
      Z.setLine(165);
      f_zs_invoke(Z.dup(v_this), "bump", ((_t174 = Z.arrNew()), _t174));
      Z.setLine(166);
      (v_v = ((_t175 = Z.arrNew()), Z.apush(_t175, f_zs_invoke(Z.dup(v_this), "expr", ((_t176 = Z.arrNew()), _t176))), _t175));
      L18: while (true) {
        Z.setLine(167);
        if (!Z.truthy(f_zs_invoke(Z.dup(v_this), "eatOp", ((_t177 = Z.arrNew()), Z.apush(_t177, ","), _t177)))) break;
        Z.setLine(167);
        Z.apush((v_v = Z.wr(v_v)), f_zs_invoke(Z.dup(v_this), "expr", ((_t178 = Z.arrNew()), _t178)));
      }
      Z.setLine(168);
      f_zs_invoke(Z.dup(v_this), "expectOp", ((_t179 = Z.arrNew()), Z.apush(_t179, ";"), _t179));
      Z.setLine(169);
      return f_Workspace_parser__node("Echo", Z.dup(v_line), ((_t180 = Z.arrNew()), Z.apush(_t180, Z.dup(v_v)), _t180));
    }
    Z.setLine(171);
    if (Z.truthy(Z.ident(v_x, "import"))) {
      Z.setLine(171);
      f_zs_invoke(Z.dup(v_this), "bump", ((_t181 = Z.arrNew()), _t181));
      Z.setLine(171);
      (v_p = f_zs_invoke(Z.dup(v_this), "path", ((_t182 = Z.arrNew()), _t182)));
      Z.setLine(171);
      f_zs_invoke(Z.dup(v_this), "expectOp", ((_t183 = Z.arrNew()), Z.apush(_t183, ";"), _t183));
      Z.setLine(171);
      return f_Workspace_parser__node("Import", Z.dup(v_line), ((_t184 = Z.arrNew()), Z.apush(_t184, Z.dup(v_p)), _t184));
    }
    Z.setLine(172);
    if (Z.truthy(Z.ident(v_x, "namespace"))) {
      Z.setLine(172);
      f_zs_invoke(Z.dup(v_this), "bump", ((_t185 = Z.arrNew()), _t185));
      Z.setLine(172);
      (v_p = f_zs_invoke(Z.dup(v_this), "path", ((_t186 = Z.arrNew()), _t186)));
      Z.setLine(172);
      f_zs_invoke(Z.dup(v_this), "expectOp", ((_t187 = Z.arrNew()), Z.apush(_t187, ";"), _t187));
      Z.setLine(172);
      return f_Workspace_parser__node("Namespace", Z.dup(v_line), ((_t188 = Z.arrNew()), Z.apush(_t188, Z.dup(v_p)), _t188));
    }
    Z.setLine(173);
    if (Z.truthy(Z.ident(v_x, "using"))) {
      Z.setLine(174);
      f_zs_invoke(Z.dup(v_this), "bump", ((_t189 = Z.arrNew()), _t189));
      Z.setLine(175);
      (v_r = f_zs_invoke(Z.dup(v_this), "expr", ((_t190 = Z.arrNew()), _t190)));
      Z.setLine(176);
      if (Z.truthy(!Z.truthy(f_zs_invoke(Z.dup(v_this), "eatKw", ((_t191 = Z.arrNew()), Z.apush(_t191, "as"), _t191))))) {
        Z.setLine(176);
        f_zs_invoke(Z.dup(v_this), "fail", ((_t192 = Z.arrNew()), Z.apush(_t192, "oczekiwano `as` w `using`"), _t192));
      }
      Z.setLine(177);
      (v_t2 = f_zs_invoke(Z.dup(v_this), "bump", ((_t193 = Z.arrNew()), _t193)));
      Z.setLine(178);
      if (Z.truthy(!Z.ident(Z.index(v_t2, "kind"), "var"))) {
        Z.setLine(178);
        f_zs_invoke(Z.dup(v_this), "back", ((_t194 = Z.arrNew()), _t194));
        Z.setLine(178);
        f_zs_invoke(Z.dup(v_this), "fail", ((_t195 = Z.arrNew()), Z.apush(_t195, "oczekiwano zmiennej po `as`"), _t195));
      }
      Z.setLine(179);
      (v_b = f_zs_invoke(Z.dup(v_this), "block", ((_t196 = Z.arrNew()), _t196)));
      Z.setLine(180);
      return f_Workspace_parser__node("Using", Z.dup(v_line), ((_t197 = Z.arrNew()), Z.apush(_t197, Z.dup(v_r)), Z.apush(_t197, Z.dup(Z.index(v_t2, "value"))), Z.apush(_t197, Z.dup(v_b)), _t197));
    }
    Z.setLine(182);
    if (Z.truthy(Z.ident(v_x, "extern"))) {
      Z.setLine(182);
      return f_zs_invoke(Z.dup(v_this), "externStmt", ((_t198 = Z.arrNew()), Z.apush(_t198, Z.dup(v_line)), _t198));
    }
    Z.setLine(183);
    if (Z.truthy((Z.truthy((Z.truthy(Z.ident(v_x, "class")) || Z.truthy(Z.ident(v_x, "interface")))) || Z.truthy(Z.ident(v_x, "abstract"))))) {
      Z.setLine(183);
      return f_zs_invoke(Z.dup(v_this), "classDecl", ((_t199 = Z.arrNew()), Z.apush(_t199, Z.dup(v_line)), _t199));
    }
  }
  Z.setLine(185);
  if (Z.truthy((Z.truthy(f_zs_invoke(Z.dup(v_this), "isFuncKw", ((_t200 = Z.arrNew()), _t200))) && Z.truthy(Z.ident(Z.index(f_zs_invoke(Z.dup(v_this), "at", ((_t201 = Z.arrNew()), Z.apush(_t201, 1), _t201)), "kind"), "ident"))))) {
    Z.setLine(186);
    f_zs_invoke(Z.dup(v_this), "bump", ((_t202 = Z.arrNew()), _t202));
    Z.setLine(187);
    return f_Workspace_parser__node("FuncStmt", Z.dup(v_line), ((_t203 = Z.arrNew()), Z.apush(_t203, f_zs_invoke(Z.dup(v_this), "funcRest", ((_t204 = Z.arrNew()), Z.apush(_t204, true), _t204))), _t203));
  }
  Z.setLine(189);
  (v_e = f_zs_invoke(Z.dup(v_this), "expr", ((_t205 = Z.arrNew()), _t205)));
  Z.setLine(190);
  f_zs_invoke(Z.dup(v_this), "expectOp", ((_t206 = Z.arrNew()), Z.apush(_t206, ";"), _t206));
  Z.setLine(191);
  return f_Workspace_parser__node("Expr", Z.dup(v_line), ((_t207 = Z.arrNew()), Z.apush(_t207, Z.dup(v_e)), _t207));
  return null;
}
function f_Parser__ifRest(v_this, v_line) {
  let v_c = null, v_then = null, v_els = null, v_l = null;
  let _t208 = null, _t209 = null, _t210 = null, _t211 = null, _t212 = null, _t213 = null, _t214 = null, _t215 = null, _t216 = null, _t217 = null, _t218 = null, _t219 = null, _t220 = null, _t221 = null, _t222 = null, _t223 = null;
  Z.setLine(195);
  (v_c = f_zs_invoke(Z.dup(v_this), "parenExpr", ((_t208 = Z.arrNew()), _t208)));
  Z.setLine(196);
  (v_then = f_zs_invoke(Z.dup(v_this), "body", ((_t209 = Z.arrNew()), _t209)));
  Z.setLine(197);
  (v_els = null);
  Z.setLine(198);
  if (Z.truthy(f_zs_invoke(Z.dup(v_this), "isKw", ((_t210 = Z.arrNew()), Z.apush(_t210, "elseif"), _t210)))) {
    Z.setLine(199);
    (v_l = f_zs_invoke(Z.dup(v_this), "line", ((_t211 = Z.arrNew()), _t211)));
    Z.setLine(199);
    f_zs_invoke(Z.dup(v_this), "bump", ((_t212 = Z.arrNew()), _t212));
    Z.setLine(199);
    (v_els = ((_t213 = Z.arrNew()), Z.apush(_t213, f_zs_invoke(Z.dup(v_this), "ifRest", ((_t214 = Z.arrNew()), Z.apush(_t214, Z.dup(v_l)), _t214))), _t213));
  } else {
    Z.setLine(200);
    if (Z.truthy(f_zs_invoke(Z.dup(v_this), "isKw", ((_t215 = Z.arrNew()), Z.apush(_t215, "else"), _t215)))) {
      Z.setLine(201);
      f_zs_invoke(Z.dup(v_this), "bump", ((_t216 = Z.arrNew()), _t216));
      Z.setLine(202);
      if (Z.truthy(f_zs_invoke(Z.dup(v_this), "isKw", ((_t217 = Z.arrNew()), Z.apush(_t217, "if"), _t217)))) {
        Z.setLine(202);
        (v_l = f_zs_invoke(Z.dup(v_this), "line", ((_t218 = Z.arrNew()), _t218)));
        Z.setLine(202);
        f_zs_invoke(Z.dup(v_this), "bump", ((_t219 = Z.arrNew()), _t219));
        Z.setLine(202);
        (v_els = ((_t220 = Z.arrNew()), Z.apush(_t220, f_zs_invoke(Z.dup(v_this), "ifRest", ((_t221 = Z.arrNew()), Z.apush(_t221, Z.dup(v_l)), _t221))), _t220));
      } else {
        Z.setLine(203);
        (v_els = f_zs_invoke(Z.dup(v_this), "body", ((_t222 = Z.arrNew()), _t222)));
      }
    }
  }
  Z.setLine(205);
  return f_Workspace_parser__node("If", Z.dup(v_line), ((_t223 = Z.arrNew()), Z.apush(_t223, Z.dup(v_c)), Z.apush(_t223, Z.dup(v_then)), Z.apush(_t223, Z.dup(v_els)), _t223));
  return null;
}
function f_Parser__exprList(v_this, v_close) {
  let v_v = null;
  let _t224 = null, _t225 = null, _t226 = null, _t227 = null, _t228 = null;
  Z.setLine(209);
  (v_v = ((_t224 = Z.arrNew()), _t224));
  Z.setLine(210);
  if (Z.truthy(!Z.truthy(f_zs_invoke(Z.dup(v_this), "isOp", ((_t225 = Z.arrNew()), Z.apush(_t225, Z.dup(v_close)), _t225))))) {
    Z.setLine(211);
    Z.apush((v_v = Z.wr(v_v)), f_zs_invoke(Z.dup(v_this), "expr", ((_t226 = Z.arrNew()), _t226)));
    L19: while (true) {
      Z.setLine(212);
      if (!Z.truthy(f_zs_invoke(Z.dup(v_this), "eatOp", ((_t227 = Z.arrNew()), Z.apush(_t227, ","), _t227)))) break;
      Z.setLine(212);
      Z.apush((v_v = Z.wr(v_v)), f_zs_invoke(Z.dup(v_this), "expr", ((_t228 = Z.arrNew()), _t228)));
    }
  }
  Z.setLine(214);
  return Z.dup(v_v);
  return null;
}
function f_Parser__forStmt(v_this, v_line) {
  let v_init = null, v_cond = null, v_step = null, v_b = null;
  let _t229 = null, _t230 = null, _t231 = null, _t232 = null, _t233 = null, _t234 = null, _t235 = null, _t236 = null, _t237 = null, _t238 = null, _t239 = null;
  Z.setLine(218);
  f_zs_invoke(Z.dup(v_this), "bump", ((_t229 = Z.arrNew()), _t229));
  Z.setLine(218);
  f_zs_invoke(Z.dup(v_this), "expectOp", ((_t230 = Z.arrNew()), Z.apush(_t230, "("), _t230));
  Z.setLine(219);
  (v_init = f_zs_invoke(Z.dup(v_this), "exprList", ((_t231 = Z.arrNew()), Z.apush(_t231, ";"), _t231)));
  Z.setLine(220);
  f_zs_invoke(Z.dup(v_this), "expectOp", ((_t232 = Z.arrNew()), Z.apush(_t232, ";"), _t232));
  Z.setLine(221);
  (v_cond = (Z.truthy(f_zs_invoke(Z.dup(v_this), "isOp", ((_t233 = Z.arrNew()), Z.apush(_t233, ";"), _t233))) ? null : f_zs_invoke(Z.dup(v_this), "expr", ((_t234 = Z.arrNew()), _t234))));
  Z.setLine(222);
  f_zs_invoke(Z.dup(v_this), "expectOp", ((_t235 = Z.arrNew()), Z.apush(_t235, ";"), _t235));
  Z.setLine(223);
  (v_step = f_zs_invoke(Z.dup(v_this), "exprList", ((_t236 = Z.arrNew()), Z.apush(_t236, ")"), _t236)));
  Z.setLine(224);
  f_zs_invoke(Z.dup(v_this), "expectOp", ((_t237 = Z.arrNew()), Z.apush(_t237, ")"), _t237));
  Z.setLine(225);
  (v_b = f_zs_invoke(Z.dup(v_this), "body", ((_t238 = Z.arrNew()), _t238)));
  Z.setLine(226);
  return f_Workspace_parser__node("For", Z.dup(v_line), ((_t239 = Z.arrNew()), Z.apush(_t239, Z.dup(v_init)), Z.apush(_t239, Z.dup(v_cond)), Z.apush(_t239, Z.dup(v_step)), Z.apush(_t239, Z.dup(v_b)), _t239));
  return null;
}
function f_Parser__foreachStmt(v_this, v_line) {
  let v_iter = null, v_first = null, v_key = null, v_value = null, v_b = null;
  let _t240 = null, _t241 = null, _t242 = null, _t243 = null, _t244 = null, _t245 = null, _t246 = null, _t247 = null, _t248 = null, _t249 = null, _t250 = null;
  Z.setLine(230);
  f_zs_invoke(Z.dup(v_this), "bump", ((_t240 = Z.arrNew()), _t240));
  Z.setLine(230);
  f_zs_invoke(Z.dup(v_this), "expectOp", ((_t241 = Z.arrNew()), Z.apush(_t241, "("), _t241));
  Z.setLine(231);
  (v_iter = f_zs_invoke(Z.dup(v_this), "expr", ((_t242 = Z.arrNew()), _t242)));
  Z.setLine(232);
  if (Z.truthy(!Z.truthy(f_zs_invoke(Z.dup(v_this), "eatKw", ((_t243 = Z.arrNew()), Z.apush(_t243, "as"), _t243))))) {
    Z.setLine(232);
    f_zs_invoke(Z.dup(v_this), "fail", ((_t244 = Z.arrNew()), Z.apush(_t244, "oczekiwano `as` w foreach"), _t244));
  }
  Z.setLine(233);
  (v_first = f_zs_invoke(Z.dup(v_this), "varName", ((_t245 = Z.arrNew()), _t245)));
  Z.setLine(234);
  (v_key = null);
  Z.setLine(235);
  (v_value = Z.dup(v_first));
  Z.setLine(236);
  if (Z.truthy(f_zs_invoke(Z.dup(v_this), "eatOp", ((_t246 = Z.arrNew()), Z.apush(_t246, "=>"), _t246)))) {
    Z.setLine(236);
    (v_key = Z.dup(v_first));
    Z.setLine(236);
    (v_value = f_zs_invoke(Z.dup(v_this), "varName", ((_t247 = Z.arrNew()), _t247)));
  }
  Z.setLine(237);
  f_zs_invoke(Z.dup(v_this), "expectOp", ((_t248 = Z.arrNew()), Z.apush(_t248, ")"), _t248));
  Z.setLine(238);
  (v_b = f_zs_invoke(Z.dup(v_this), "body", ((_t249 = Z.arrNew()), _t249)));
  Z.setLine(239);
  return f_Workspace_parser__node("Foreach", Z.dup(v_line), ((_t250 = Z.arrNew()), Z.apush(_t250, Z.dup(v_iter)), Z.apush(_t250, Z.dup(v_key)), Z.apush(_t250, Z.dup(v_value)), Z.apush(_t250, Z.dup(v_b)), _t250));
  return null;
}
function f_Parser__switchStmt(v_this, v_line) {
  let v_subject = null, v_cases = null, v_cond = null, v_body = null;
  let _t251 = null, _t252 = null, _t253 = null, _t254 = null, _t255 = null, _t256 = null, _t257 = null, _t258 = null, _t259 = null, _t260 = null, _t261 = null, _t262 = null, _t263 = null, _t264 = null, _t265 = null, _t266 = null, _t267 = null, _t268 = null, _t269 = null, _t270 = null, _t271 = null;
  Z.setLine(243);
  f_zs_invoke(Z.dup(v_this), "bump", ((_t251 = Z.arrNew()), _t251));
  Z.setLine(244);
  (v_subject = f_zs_invoke(Z.dup(v_this), "parenExpr", ((_t252 = Z.arrNew()), _t252)));
  Z.setLine(245);
  f_zs_invoke(Z.dup(v_this), "expectOp", ((_t253 = Z.arrNew()), Z.apush(_t253, "{"), _t253));
  Z.setLine(246);
  (v_cases = ((_t254 = Z.arrNew()), _t254));
  L20: while (true) {
    Z.setLine(247);
    if (!Z.truthy(!Z.truthy(f_zs_invoke(Z.dup(v_this), "isOp", ((_t255 = Z.arrNew()), Z.apush(_t255, "}"), _t255))))) break;
    Z.setLine(248);
    (v_cond = null);
    Z.setLine(249);
    if (Z.truthy(f_zs_invoke(Z.dup(v_this), "eatKw", ((_t256 = Z.arrNew()), Z.apush(_t256, "case"), _t256)))) {
      Z.setLine(249);
      (v_cond = f_zs_invoke(Z.dup(v_this), "expr", ((_t257 = Z.arrNew()), _t257)));
    } else {
      Z.setLine(250);
      if (Z.truthy(f_zs_invoke(Z.dup(v_this), "eatKw", ((_t258 = Z.arrNew()), Z.apush(_t258, "default"), _t258)))) {
        Z.setLine(250);
        (v_cond = null);
      } else {
        Z.setLine(251);
        f_zs_invoke(Z.dup(v_this), "fail", ((_t259 = Z.arrNew()), Z.apush(_t259, "oczekiwano `case` lub `default`"), _t259));
      }
    }
    Z.setLine(252);
    if (Z.truthy(!Z.truthy(f_zs_invoke(Z.dup(v_this), "eatOp", ((_t260 = Z.arrNew()), Z.apush(_t260, ":"), _t260))))) {
      Z.setLine(252);
      f_zs_invoke(Z.dup(v_this), "expectOp", ((_t261 = Z.arrNew()), Z.apush(_t261, ";"), _t261));
    }
    Z.setLine(253);
    (v_body = ((_t262 = Z.arrNew()), _t262));
    L21: while (true) {
      Z.setLine(254);
      if (!Z.truthy((Z.truthy((Z.truthy(!Z.truthy(f_zs_invoke(Z.dup(v_this), "isKw", ((_t263 = Z.arrNew()), Z.apush(_t263, "case"), _t263)))) && Z.truthy(!Z.truthy(f_zs_invoke(Z.dup(v_this), "isKw", ((_t264 = Z.arrNew()), Z.apush(_t264, "default"), _t264)))))) && Z.truthy(!Z.truthy(f_zs_invoke(Z.dup(v_this), "isOp", ((_t265 = Z.arrNew()), Z.apush(_t265, "}"), _t265))))))) break;
      Z.setLine(255);
      if (Z.truthy(f_zs_invoke(Z.dup(v_this), "atEof", ((_t266 = Z.arrNew()), _t266)))) {
        Z.setLine(255);
        f_zs_invoke(Z.dup(v_this), "fail", ((_t267 = Z.arrNew()), Z.apush(_t267, "niezamknięty switch"), _t267));
      }
      Z.setLine(256);
      Z.apush((v_body = Z.wr(v_body)), f_zs_invoke(Z.dup(v_this), "stmt", ((_t268 = Z.arrNew()), _t268)));
    }
    Z.setLine(258);
    Z.apush((v_cases = Z.wr(v_cases)), f_Workspace_parser__node("Case", 0, ((_t269 = Z.arrNew()), Z.apush(_t269, Z.dup(v_cond)), Z.apush(_t269, Z.dup(v_body)), _t269)));
  }
  Z.setLine(260);
  f_zs_invoke(Z.dup(v_this), "bump", ((_t270 = Z.arrNew()), _t270));
  Z.setLine(261);
  return f_Workspace_parser__node("Switch", Z.dup(v_line), ((_t271 = Z.arrNew()), Z.apush(_t271, Z.dup(v_subject)), Z.apush(_t271, Z.dup(v_cases)), _t271));
  return null;
}
function f_Parser__tryStmt(v_this, v_line) {
  let v_body = null, v_catches = null, v_types = null, v_var = null, v_b = null, v_finally = null;
  let _t272 = null, _t273 = null, _t274 = null, _t275 = null, _t276 = null, _t277 = null, _t278 = null, _t279 = null, _t280 = null, _t281 = null, _t282 = null, _t283 = null, _t284 = null, _t285 = null, _t286 = null, _t287 = null, _t288 = null, _t289 = null;
  Z.setLine(265);
  f_zs_invoke(Z.dup(v_this), "bump", ((_t272 = Z.arrNew()), _t272));
  Z.setLine(266);
  (v_body = f_zs_invoke(Z.dup(v_this), "block", ((_t273 = Z.arrNew()), _t273)));
  Z.setLine(267);
  (v_catches = ((_t274 = Z.arrNew()), _t274));
  L22: while (true) {
    Z.setLine(268);
    if (!Z.truthy(f_zs_invoke(Z.dup(v_this), "eatKw", ((_t275 = Z.arrNew()), Z.apush(_t275, "catch"), _t275)))) break;
    Z.setLine(269);
    f_zs_invoke(Z.dup(v_this), "expectOp", ((_t276 = Z.arrNew()), Z.apush(_t276, "("), _t276));
    Z.setLine(270);
    (v_types = ((_t277 = Z.arrNew()), Z.apush(_t277, f_zs_invoke(Z.dup(v_this), "ident", ((_t278 = Z.arrNew()), _t278))), _t277));
    L23: while (true) {
      Z.setLine(271);
      if (!Z.truthy(f_zs_invoke(Z.dup(v_this), "eatOp", ((_t279 = Z.arrNew()), Z.apush(_t279, "|"), _t279)))) break;
      Z.setLine(271);
      Z.apush((v_types = Z.wr(v_types)), f_zs_invoke(Z.dup(v_this), "ident", ((_t280 = Z.arrNew()), _t280)));
    }
    Z.setLine(272);
    (v_var = null);
    Z.setLine(273);
    if (Z.truthy(f_zs_invoke(Z.dup(v_this), "isVar", ((_t281 = Z.arrNew()), _t281)))) {
      Z.setLine(273);
      (v_var = f_zs_invoke(Z.dup(v_this), "varName", ((_t282 = Z.arrNew()), _t282)));
    }
    Z.setLine(274);
    f_zs_invoke(Z.dup(v_this), "expectOp", ((_t283 = Z.arrNew()), Z.apush(_t283, ")"), _t283));
    Z.setLine(275);
    (v_b = f_zs_invoke(Z.dup(v_this), "block", ((_t284 = Z.arrNew()), _t284)));
    Z.setLine(276);
    Z.apush((v_catches = Z.wr(v_catches)), f_Workspace_parser__node("Catch", 0, ((_t285 = Z.arrNew()), Z.apush(_t285, Z.dup(v_types)), Z.apush(_t285, Z.dup(v_var)), Z.apush(_t285, Z.dup(v_b)), _t285)));
  }
  Z.setLine(278);
  (v_finally = null);
  Z.setLine(279);
  if (Z.truthy(f_zs_invoke(Z.dup(v_this), "eatKw", ((_t286 = Z.arrNew()), Z.apush(_t286, "finally"), _t286)))) {
    Z.setLine(279);
    (v_finally = f_zs_invoke(Z.dup(v_this), "block", ((_t287 = Z.arrNew()), _t287)));
  }
  Z.setLine(280);
  if (Z.truthy((Z.truthy(Z.ident(Z.B.count(v_catches), 0)) && Z.truthy(Z.ident(v_finally, null))))) {
    Z.setLine(280);
    f_zs_invoke(Z.dup(v_this), "fail", ((_t288 = Z.arrNew()), Z.apush(_t288, "try wymaga catch lub finally"), _t288));
  }
  Z.setLine(281);
  return f_Workspace_parser__node("Try", Z.dup(v_line), ((_t289 = Z.arrNew()), Z.apush(_t289, Z.dup(v_body)), Z.apush(_t289, Z.dup(v_catches)), Z.apush(_t289, Z.dup(v_finally)), _t289));
  return null;
}
function f_Parser__externStmt(v_this, v_line) {
  let v_t = null, v_lib = null, v_items = null, v_name = null, v_params = null, v_ret = null;
  let _t290 = null, _t291 = null, _t292 = null, _t293 = null, _t294 = null, _t295 = null, _t296 = null, _t297 = null, _t298 = null, _t299 = null, _t300 = null, _t301 = null, _t302 = null, _t303 = null, _t304 = null, _t305 = null, _t306 = null, _t307 = null, _t308 = null, _t309 = null, _t310 = null;
  Z.setLine(285);
  f_zs_invoke(Z.dup(v_this), "bump", ((_t290 = Z.arrNew()), _t290));
  Z.setLine(286);
  (v_t = f_zs_invoke(Z.dup(v_this), "bump", ((_t291 = Z.arrNew()), _t291)));
  Z.setLine(287);
  if (Z.truthy(!Z.ident(Z.index(v_t, "kind"), "str"))) {
    Z.setLine(287);
    f_zs_invoke(Z.dup(v_this), "back", ((_t292 = Z.arrNew()), _t292));
    Z.setLine(287);
    f_zs_invoke(Z.dup(v_this), "fail", ((_t293 = Z.arrNew()), Z.apush(_t293, "extern wymaga nazwy biblioteki w cudzysłowie"), _t293));
  }
  Z.setLine(288);
  (v_lib = Z.dup(Z.index(v_t, "value")));
  Z.setLine(289);
  (v_items = ((_t294 = Z.arrNew()), _t294));
  Z.setLine(290);
  if (Z.truthy(f_zs_invoke(Z.dup(v_this), "eatOp", ((_t295 = Z.arrNew()), Z.apush(_t295, ";"), _t295)))) {
    Z.setLine(290);
    return f_Workspace_parser__node("Extern", Z.dup(v_line), ((_t296 = Z.arrNew()), Z.apush(_t296, Z.dup(v_lib)), Z.apush(_t296, Z.dup(v_items)), _t296));
  }
  Z.setLine(291);
  f_zs_invoke(Z.dup(v_this), "expectOp", ((_t297 = Z.arrNew()), Z.apush(_t297, "{"), _t297));
  L24: while (true) {
    Z.setLine(292);
    if (!Z.truthy(!Z.truthy(f_zs_invoke(Z.dup(v_this), "isOp", ((_t298 = Z.arrNew()), Z.apush(_t298, "}"), _t298))))) break;
    Z.setLine(293);
    if (Z.truthy(!Z.truthy(f_zs_invoke(Z.dup(v_this), "isFuncKw", ((_t299 = Z.arrNew()), _t299))))) {
      Z.setLine(293);
      f_zs_invoke(Z.dup(v_this), "fail", ((_t300 = Z.arrNew()), Z.apush(_t300, "w extern oczekiwano `func`"), _t300));
    }
    Z.setLine(294);
    f_zs_invoke(Z.dup(v_this), "bump", ((_t301 = Z.arrNew()), _t301));
    Z.setLine(295);
    (v_name = f_zs_invoke(Z.dup(v_this), "ident", ((_t302 = Z.arrNew()), _t302)));
    Z.setLine(296);
    (v_params = f_zs_invoke(Z.dup(v_this), "params", ((_t303 = Z.arrNew()), _t303)));
    Z.setLine(297);
    (v_ret = (Z.truthy(f_zs_invoke(Z.dup(v_this), "eatOp", ((_t304 = Z.arrNew()), Z.apush(_t304, ":"), _t304))) ? f_zs_invoke(Z.dup(v_this), "types", ((_t305 = Z.arrNew()), _t305)) : ((_t306 = Z.arrNew()), _t306)));
    Z.setLine(298);
    f_zs_invoke(Z.dup(v_this), "expectOp", ((_t307 = Z.arrNew()), Z.apush(_t307, ";"), _t307));
    Z.setLine(299);
    Z.apush((v_items = Z.wr(v_items)), f_Workspace_parser__node("ExternItem", 0, ((_t308 = Z.arrNew()), Z.apush(_t308, Z.dup(v_name)), Z.apush(_t308, Z.dup(v_params)), Z.apush(_t308, Z.dup(v_ret)), _t308)));
  }
  Z.setLine(301);
  f_zs_invoke(Z.dup(v_this), "bump", ((_t309 = Z.arrNew()), _t309));
  Z.setLine(302);
  return f_Workspace_parser__node("Extern", Z.dup(v_line), ((_t310 = Z.arrNew()), Z.apush(_t310, Z.dup(v_lib)), Z.apush(_t310, Z.dup(v_items)), _t310));
  return null;
}
function f_Parser__types(v_this) {
  let v_v = null, v_t = null;
  let _t311 = null, _t312 = null, _t313 = null, _t314 = null, _t315 = null, _t316 = null;
  Z.setLine(307);
  (v_v = ((_t311 = Z.arrNew()), _t311));
  Z.setLine(308);
  if (Z.truthy(f_zs_invoke(Z.dup(v_this), "eatOp", ((_t312 = Z.arrNew()), Z.apush(_t312, "?"), _t312)))) {
    Z.setLine(308);
    Z.apush((v_v = Z.wr(v_v)), "null");
  }
  L25: while (true) {
    Z.setLine(309);
    if (!Z.truthy(true)) break;
    Z.setLine(310);
    (v_t = f_zs_invoke(Z.dup(v_this), "bump", ((_t313 = Z.arrNew()), _t313)));
    Z.setLine(311);
    if (Z.truthy(Z.ident(Z.index(v_t, "kind"), "ident"))) {
      Z.setLine(311);
      Z.apush((v_v = Z.wr(v_v)), Z.dup(Z.index(v_t, "text")));
    } else {
      Z.setLine(312);
      if (Z.truthy((Z.truthy(Z.ident(Z.index(v_t, "kind"), "kw")) && Z.truthy(Z.ident(Z.index(v_t, "text"), "null"))))) {
        Z.setLine(312);
        Z.apush((v_v = Z.wr(v_v)), "null");
      } else {
        Z.setLine(313);
        if (Z.truthy((Z.truthy(Z.ident(Z.index(v_t, "kind"), "kw")) && Z.truthy(Z.ident(Z.index(v_t, "text"), "static"))))) {
          Z.setLine(313);
          Z.apush((v_v = Z.wr(v_v)), "static");
        } else {
          Z.setLine(314);
          if (Z.truthy((Z.truthy(Z.ident(Z.index(v_t, "kind"), "kw")) && Z.truthy((Z.truthy(Z.ident(Z.index(v_t, "text"), "fn")) || Z.truthy(Z.ident(Z.index(v_t, "text"), "func"))))))) {
            Z.setLine(314);
            Z.apush((v_v = Z.wr(v_v)), "function");
          } else {
            Z.setLine(315);
            f_zs_invoke(Z.dup(v_this), "back", ((_t314 = Z.arrNew()), _t314));
            Z.setLine(315);
            f_zs_invoke(Z.dup(v_this), "fail", ((_t315 = Z.arrNew()), Z.apush(_t315, "oczekiwano nazwy typu"), _t315));
          }
        }
      }
    }
    Z.setLine(316);
    if (Z.truthy(!Z.truthy(f_zs_invoke(Z.dup(v_this), "eatOp", ((_t316 = Z.arrNew()), Z.apush(_t316, "|"), _t316))))) {
      break L25;
    }
  }
  Z.setLine(318);
  return Z.dup(v_v);
  return null;
}
function f_Parser__params(v_this) {
  let v_ps = null, v_types = null, v_variadic = null, v_name = null, v_default = null;
  let _t317 = null, _t318 = null, _t319 = null, _t320 = null, _t321 = null, _t322 = null, _t323 = null, _t324 = null, _t325 = null, _t326 = null, _t327 = null, _t328 = null, _t329 = null, _t330 = null;
  Z.setLine(322);
  f_zs_invoke(Z.dup(v_this), "expectOp", ((_t317 = Z.arrNew()), Z.apush(_t317, "("), _t317));
  Z.setLine(323);
  (v_ps = ((_t318 = Z.arrNew()), _t318));
  L26: while (true) {
    Z.setLine(324);
    if (!Z.truthy(!Z.truthy(f_zs_invoke(Z.dup(v_this), "isOp", ((_t319 = Z.arrNew()), Z.apush(_t319, ")"), _t319))))) break;
    Z.setLine(325);
    (v_types = (Z.truthy((Z.truthy(f_zs_invoke(Z.dup(v_this), "isVar", ((_t320 = Z.arrNew()), _t320))) || Z.truthy(f_zs_invoke(Z.dup(v_this), "isOp", ((_t321 = Z.arrNew()), Z.apush(_t321, "..."), _t321))))) ? ((_t322 = Z.arrNew()), _t322) : f_zs_invoke(Z.dup(v_this), "types", ((_t323 = Z.arrNew()), _t323))));
    Z.setLine(326);
    (v_variadic = f_zs_invoke(Z.dup(v_this), "eatOp", ((_t324 = Z.arrNew()), Z.apush(_t324, "..."), _t324)));
    Z.setLine(327);
    (v_name = f_zs_invoke(Z.dup(v_this), "varName", ((_t325 = Z.arrNew()), _t325)));
    Z.setLine(328);
    (v_default = (Z.truthy(f_zs_invoke(Z.dup(v_this), "eatOp", ((_t326 = Z.arrNew()), Z.apush(_t326, "="), _t326))) ? f_zs_invoke(Z.dup(v_this), "expr", ((_t327 = Z.arrNew()), _t327)) : null));
    Z.setLine(329);
    Z.apush((v_ps = Z.wr(v_ps)), f_Workspace_parser__node("Param", 0, ((_t328 = Z.arrNew()), Z.apush(_t328, Z.dup(v_name)), Z.apush(_t328, Z.dup(v_types)), Z.apush(_t328, Z.dup(v_default)), Z.apush(_t328, Z.dup(v_variadic)), _t328)));
    Z.setLine(330);
    if (Z.truthy(!Z.truthy(f_zs_invoke(Z.dup(v_this), "eatOp", ((_t329 = Z.arrNew()), Z.apush(_t329, ","), _t329))))) {
      break L26;
    }
  }
  Z.setLine(332);
  f_zs_invoke(Z.dup(v_this), "expectOp", ((_t330 = Z.arrNew()), Z.apush(_t330, ")"), _t330));
  Z.setLine(333);
  return Z.dup(v_ps);
  return null;
}
function f_Parser__funcRest(v_this, v_named) {
  let v_line = null, v_name = null, v_params = null, v_ret = null, v_body = null;
  let _t331 = null, _t332 = null, _t333 = null, _t334 = null, _t335 = null, _t336 = null, _t337 = null, _t338 = null;
  Z.setLine(337);
  (v_line = f_zs_invoke(Z.dup(v_this), "line", ((_t331 = Z.arrNew()), _t331)));
  Z.setLine(338);
  (v_name = (Z.truthy(v_named) ? f_zs_invoke(Z.dup(v_this), "ident", ((_t332 = Z.arrNew()), _t332)) : null));
  Z.setLine(339);
  (v_params = f_zs_invoke(Z.dup(v_this), "params", ((_t333 = Z.arrNew()), _t333)));
  Z.setLine(340);
  (v_ret = (Z.truthy(f_zs_invoke(Z.dup(v_this), "eatOp", ((_t334 = Z.arrNew()), Z.apush(_t334, ":"), _t334))) ? f_zs_invoke(Z.dup(v_this), "types", ((_t335 = Z.arrNew()), _t335)) : ((_t336 = Z.arrNew()), _t336)));
  Z.setLine(341);
  (v_body = f_zs_invoke(Z.dup(v_this), "block", ((_t337 = Z.arrNew()), _t337)));
  Z.setLine(342);
  return f_Workspace_parser__node("Func", Z.dup(v_line), ((_t338 = Z.arrNew()), Z.apush(_t338, Z.dup(v_name)), Z.apush(_t338, Z.dup(v_params)), Z.apush(_t338, Z.dup(v_ret)), Z.apush(_t338, Z.dup(v_body)), Z.apush(_t338, false), _t338));
  return null;
}
function f_Parser__classDecl(v_this, v_line) {
  let v_isAbstract = null, v_isInterface = null, v_name = null, v_parent = null, v_ifaces = null, v_props = null, v_consts = null, v_methods = null, v_isStatic = null, v_abs = null, v_n = null, v_e = null, v_l = null, v_params = null, v_ret = null, v_isAbs = null, v_mbody = null, v_decl = null, v_default = null;
  let _t339 = null, _t340 = null, _t341 = null, _t342 = null, _t343 = null, _t344 = null, _t345 = null, _t346 = null, _t347 = null, _t348 = null, _t349 = null, _t350 = null, _t351 = null, _t352 = null, _t353 = null, _t354 = null, _t355 = null, _t356 = null, _t357 = null, _t358 = null, _t359 = null, _t360 = null, _t361 = null, _t362 = null, _t363 = null, _t364 = null, _t365 = null, _t366 = null, _t367 = null, _t368 = null, _t369 = null, _t370 = null, _t371 = null, _t372 = null, _t373 = null, _t374 = null, _t375 = null, _t376 = null, _t377 = null, _t378 = null, _t379 = null, _t380 = null, _t381 = null, _t382 = null, _t383 = null, _t384 = null, _t385 = null, _t386 = null, _t387 = null, _t388 = null, _t389 = null, _t390 = null, _t391 = null, _t392 = null, _t393 = null, _t394 = null, _t395 = null;
  Z.setLine(346);
  (v_isAbstract = f_zs_invoke(Z.dup(v_this), "eatKw", ((_t339 = Z.arrNew()), Z.apush(_t339, "abstract"), _t339)));
  Z.setLine(347);
  (v_isInterface = false);
  Z.setLine(348);
  if (Z.truthy(f_zs_invoke(Z.dup(v_this), "eatKw", ((_t340 = Z.arrNew()), Z.apush(_t340, "interface"), _t340)))) {
    Z.setLine(348);
    (v_isInterface = true);
  } else {
    Z.setLine(349);
    if (Z.truthy(!Z.truthy(f_zs_invoke(Z.dup(v_this), "eatKw", ((_t341 = Z.arrNew()), Z.apush(_t341, "class"), _t341))))) {
      Z.setLine(349);
      f_zs_invoke(Z.dup(v_this), "fail", ((_t342 = Z.arrNew()), Z.apush(_t342, "oczekiwano `class`"), _t342));
    }
  }
  Z.setLine(350);
  (v_name = f_zs_invoke(Z.dup(v_this), "ident", ((_t343 = Z.arrNew()), _t343)));
  Z.setLine(351);
  (v_parent = null);
  Z.setLine(352);
  (v_ifaces = ((_t344 = Z.arrNew()), _t344));
  Z.setLine(353);
  if (Z.truthy(f_zs_invoke(Z.dup(v_this), "eatKw", ((_t345 = Z.arrNew()), Z.apush(_t345, "extends"), _t345)))) {
    Z.setLine(354);
    if (Z.truthy(v_isInterface)) {
      Z.setLine(355);
      Z.apush((v_ifaces = Z.wr(v_ifaces)), f_zs_invoke(Z.dup(v_this), "ident", ((_t346 = Z.arrNew()), _t346)));
      L27: while (true) {
        Z.setLine(356);
        if (!Z.truthy(f_zs_invoke(Z.dup(v_this), "eatOp", ((_t347 = Z.arrNew()), Z.apush(_t347, ","), _t347)))) break;
        Z.setLine(356);
        Z.apush((v_ifaces = Z.wr(v_ifaces)), f_zs_invoke(Z.dup(v_this), "ident", ((_t348 = Z.arrNew()), _t348)));
      }
    } else {
      Z.setLine(357);
      (v_parent = f_zs_invoke(Z.dup(v_this), "ident", ((_t349 = Z.arrNew()), _t349)));
    }
  }
  Z.setLine(359);
  if (Z.truthy(f_zs_invoke(Z.dup(v_this), "eatKw", ((_t350 = Z.arrNew()), Z.apush(_t350, "implements"), _t350)))) {
    Z.setLine(360);
    Z.apush((v_ifaces = Z.wr(v_ifaces)), f_zs_invoke(Z.dup(v_this), "ident", ((_t351 = Z.arrNew()), _t351)));
    L28: while (true) {
      Z.setLine(361);
      if (!Z.truthy(f_zs_invoke(Z.dup(v_this), "eatOp", ((_t352 = Z.arrNew()), Z.apush(_t352, ","), _t352)))) break;
      Z.setLine(361);
      Z.apush((v_ifaces = Z.wr(v_ifaces)), f_zs_invoke(Z.dup(v_this), "ident", ((_t353 = Z.arrNew()), _t353)));
    }
  }
  Z.setLine(363);
  f_zs_invoke(Z.dup(v_this), "expectOp", ((_t354 = Z.arrNew()), Z.apush(_t354, "{"), _t354));
  Z.setLine(364);
  (v_props = ((_t355 = Z.arrNew()), _t355));
  Z.setLine(365);
  (v_consts = ((_t356 = Z.arrNew()), _t356));
  Z.setLine(366);
  (v_methods = ((_t357 = Z.arrNew()), _t357));
  L29: while (true) {
    Z.setLine(367);
    if (!Z.truthy(!Z.truthy(f_zs_invoke(Z.dup(v_this), "isOp", ((_t358 = Z.arrNew()), Z.apush(_t358, "}"), _t358))))) break;
    Z.setLine(368);
    if (Z.truthy(f_zs_invoke(Z.dup(v_this), "atEof", ((_t359 = Z.arrNew()), _t359)))) {
      Z.setLine(368);
      f_zs_invoke(Z.dup(v_this), "fail", ((_t360 = Z.arrNew()), Z.apush(_t360, "niezamknięta klasa"), _t360));
    }
    Z.setLine(369);
    (v_isStatic = false);
    Z.setLine(370);
    (v_abs = false);
    L30: while (true) {
      Z.setLine(371);
      if (!Z.truthy(true)) break;
      Z.setLine(372);
      if (Z.truthy((Z.truthy((Z.truthy((Z.truthy(f_zs_invoke(Z.dup(v_this), "eatKw", ((_t361 = Z.arrNew()), Z.apush(_t361, "public"), _t361))) || Z.truthy(f_zs_invoke(Z.dup(v_this), "eatKw", ((_t362 = Z.arrNew()), Z.apush(_t362, "private"), _t362))))) || Z.truthy(f_zs_invoke(Z.dup(v_this), "eatKw", ((_t363 = Z.arrNew()), Z.apush(_t363, "protected"), _t363))))) || Z.truthy(f_zs_invoke(Z.dup(v_this), "eatWord", ((_t364 = Z.arrNew()), Z.apush(_t364, "final"), _t364)))))) {
      } else {
        Z.setLine(373);
        if (Z.truthy(f_zs_invoke(Z.dup(v_this), "eatKw", ((_t365 = Z.arrNew()), Z.apush(_t365, "static"), _t365)))) {
          Z.setLine(373);
          (v_isStatic = true);
        } else {
          Z.setLine(374);
          if (Z.truthy(f_zs_invoke(Z.dup(v_this), "eatKw", ((_t366 = Z.arrNew()), Z.apush(_t366, "abstract"), _t366)))) {
            Z.setLine(374);
            (v_abs = true);
          } else {
            break L30;
          }
        }
      }
    }
    Z.setLine(377);
    if (Z.truthy(f_zs_invoke(Z.dup(v_this), "eatWord", ((_t367 = Z.arrNew()), Z.apush(_t367, "const"), _t367)))) {
      Z.setLine(378);
      (v_n = f_zs_invoke(Z.dup(v_this), "ident", ((_t368 = Z.arrNew()), _t368)));
      Z.setLine(378);
      f_zs_invoke(Z.dup(v_this), "expectOp", ((_t369 = Z.arrNew()), Z.apush(_t369, "="), _t369));
      Z.setLine(378);
      (v_e = f_zs_invoke(Z.dup(v_this), "expr", ((_t370 = Z.arrNew()), _t370)));
      Z.setLine(378);
      f_zs_invoke(Z.dup(v_this), "expectOp", ((_t371 = Z.arrNew()), Z.apush(_t371, ";"), _t371));
      Z.setLine(379);
      Z.apush((v_consts = Z.wr(v_consts)), f_Workspace_parser__node("Const", 0, ((_t372 = Z.arrNew()), Z.apush(_t372, Z.dup(v_n)), Z.apush(_t372, Z.dup(v_e)), _t372)));
    } else {
      Z.setLine(380);
      if (Z.truthy(f_zs_invoke(Z.dup(v_this), "isFuncKw", ((_t373 = Z.arrNew()), _t373)))) {
        Z.setLine(381);
        f_zs_invoke(Z.dup(v_this), "bump", ((_t374 = Z.arrNew()), _t374));
        Z.setLine(382);
        (v_l = f_zs_invoke(Z.dup(v_this), "line", ((_t375 = Z.arrNew()), _t375)));
        Z.setLine(383);
        (v_n = f_zs_invoke(Z.dup(v_this), "ident", ((_t376 = Z.arrNew()), _t376)));
        Z.setLine(384);
        (v_params = f_zs_invoke(Z.dup(v_this), "params", ((_t377 = Z.arrNew()), _t377)));
        Z.setLine(385);
        (v_ret = (Z.truthy(f_zs_invoke(Z.dup(v_this), "eatOp", ((_t378 = Z.arrNew()), Z.apush(_t378, ":"), _t378))) ? f_zs_invoke(Z.dup(v_this), "types", ((_t379 = Z.arrNew()), _t379)) : ((_t380 = Z.arrNew()), _t380)));
        Z.setLine(386);
        (v_isAbs = false);
        Z.setLine(387);
        (v_mbody = ((_t381 = Z.arrNew()), _t381));
        Z.setLine(388);
        if (Z.truthy(f_zs_invoke(Z.dup(v_this), "eatOp", ((_t382 = Z.arrNew()), Z.apush(_t382, ";"), _t382)))) {
          Z.setLine(388);
          (v_isAbs = true);
        } else {
          Z.setLine(388);
          (v_mbody = f_zs_invoke(Z.dup(v_this), "block", ((_t383 = Z.arrNew()), _t383)));
        }
        Z.setLine(389);
        (v_decl = f_Workspace_parser__node("Func", Z.dup(v_l), ((_t384 = Z.arrNew()), Z.apush(_t384, Z.dup(v_n)), Z.apush(_t384, Z.dup(v_params)), Z.apush(_t384, Z.dup(v_ret)), Z.apush(_t384, Z.dup(v_mbody)), Z.apush(_t384, false), _t384)));
        Z.setLine(390);
        Z.apush((v_methods = Z.wr(v_methods)), f_Workspace_parser__node("Method", 0, ((_t385 = Z.arrNew()), Z.apush(_t385, Z.dup(v_decl)), Z.apush(_t385, Z.dup(v_isStatic)), Z.apush(_t385, (Z.truthy(v_abs) || Z.truthy(v_isAbs))), _t385)));
      } else {
        Z.setLine(392);
        if (Z.truthy(!Z.truthy(f_zs_invoke(Z.dup(v_this), "isVar", ((_t386 = Z.arrNew()), _t386))))) {
          Z.setLine(392);
          f_zs_invoke(Z.dup(v_this), "types", ((_t387 = Z.arrNew()), _t387));
        }
        Z.setLine(393);
        (v_n = f_zs_invoke(Z.dup(v_this), "varName", ((_t388 = Z.arrNew()), _t388)));
        Z.setLine(394);
        (v_default = (Z.truthy(f_zs_invoke(Z.dup(v_this), "eatOp", ((_t389 = Z.arrNew()), Z.apush(_t389, "="), _t389))) ? f_zs_invoke(Z.dup(v_this), "expr", ((_t390 = Z.arrNew()), _t390)) : null));
        Z.setLine(395);
        f_zs_invoke(Z.dup(v_this), "expectOp", ((_t391 = Z.arrNew()), Z.apush(_t391, ";"), _t391));
        Z.setLine(396);
        Z.apush((v_props = Z.wr(v_props)), f_Workspace_parser__node("Prop", 0, ((_t392 = Z.arrNew()), Z.apush(_t392, Z.dup(v_n)), Z.apush(_t392, Z.dup(v_default)), Z.apush(_t392, Z.dup(v_isStatic)), _t392)));
      }
    }
  }
  Z.setLine(399);
  f_zs_invoke(Z.dup(v_this), "bump", ((_t393 = Z.arrNew()), _t393));
  Z.setLine(400);
  return f_Workspace_parser__node("ClassStmt", Z.dup(v_line), ((_t394 = Z.arrNew()), Z.apush(_t394, f_Workspace_parser__node("Class", Z.dup(v_line), ((_t395 = Z.arrNew()), Z.apush(_t395, Z.dup(v_name)), Z.apush(_t395, Z.dup(v_parent)), Z.apush(_t395, Z.dup(v_ifaces)), Z.apush(_t395, Z.dup(v_isInterface)), Z.apush(_t395, Z.dup(v_isAbstract)), Z.apush(_t395, Z.dup(v_props)), Z.apush(_t395, Z.dup(v_consts)), Z.apush(_t395, Z.dup(v_methods)), _t395))), _t394));
  return null;
}
function f_Parser__expr(v_this) {
  let _t396 = null;
  Z.setLine(404);
  return f_zs_invoke(Z.dup(v_this), "exprBp", ((_t396 = Z.arrNew()), Z.apush(_t396, 0), _t396));
  return null;
}
function f_Parser__checkLvalue(v_this, v_e) {
  let v_k = null;
  let _t397 = null;
  Z.setLine(407);
  (v_k = Z.dup(Z.index(v_e, 0)));
  Z.setLine(408);
  if (Z.truthy((Z.truthy((Z.truthy((Z.truthy(Z.ident(v_k, ":Var")) || Z.truthy(Z.ident(v_k, ":Index")))) || Z.truthy(Z.ident(v_k, ":Prop")))) || Z.truthy(Z.ident(v_k, ":Dot"))))) {
    Z.setLine(408);
    return null;
  }
  Z.setLine(409);
  f_zs_invoke(Z.dup(v_this), "fail", ((_t397 = Z.arrNew()), Z.apush(_t397, "lewa strona przypisania nie jest l-wartością"), _t397));
  return null;
}
function f_Parser__exprBp(v_this, v_min) {
  let v_lhs = null, v_line = null, v_t = null, v_ent = null, v_lbp = null, v_rbp = null, v_kind = null, v_r = null, v_then = null, v_els = null, v_n = null;
  let _t398 = null, _t399 = null, _t400 = null, _t401 = null, _t402 = null, _t403 = null, _t404 = null, _t405 = null, _t406 = null, _t407 = null, _t408 = null, _t409 = null, _t410 = null, _t411 = null, _t412 = null, _t413 = null, _t414 = null, _t415 = null, _t416 = null, _t417 = null, _t418 = null, _t419 = null, _t420 = null, _t421 = null, _t422 = null, _t423 = null, _t424 = null, _t425 = null, _t426 = null, _t427 = null, _t428 = null, _t429 = null, _t430 = null, _t431 = null, _t432 = null, _t433 = null, _t434 = null, _t435 = null, _t436 = null, _t437 = null, _t438 = null, _t439 = null, _t440 = null, _t441 = null, _t442 = null, _t443 = null, _t444 = null, _t445 = null, _t446 = null, _t447 = null, _t448 = null, _t449 = null, _t450 = null, _t451 = null, _t452 = null, _t453 = null, _t454 = null, _t455 = null, _t456 = null;
  Z.setLine(413);
  (v_lhs = f_zs_invoke(Z.dup(v_this), "unary", ((_t398 = Z.arrNew()), _t398)));
  L31: while (true) {
    Z.setLine(414);
    if (!Z.truthy(true)) break;
    Z.setLine(415);
    (v_line = f_zs_invoke(Z.dup(v_this), "line", ((_t399 = Z.arrNew()), _t399)));
    Z.setLine(416);
    (v_t = f_zs_invoke(Z.dup(v_this), "cur", ((_t400 = Z.arrNew()), _t400)));
    Z.setLine(417);
    (v_ent = null);
    Z.setLine(418);
    if (Z.truthy(Z.ident(Z.index(v_t, "kind"), "op"))) {
      Z.setLine(418);
      (v_ent = (((_t401 = Z.indexOpt(((_t402 = Z.arrNew()), Z.aset(_t402, "=", ((_t403 = Z.arrNew()), Z.apush(_t403, 5), Z.apush(_t403, 5), Z.apush(_t403, "assign"), Z.apush(_t403, null), _t403)), Z.aset(_t402, "+=", ((_t404 = Z.arrNew()), Z.apush(_t404, 5), Z.apush(_t404, 5), Z.apush(_t404, "assignop"), Z.apush(_t404, "Add"), _t404)), Z.aset(_t402, "-=", ((_t405 = Z.arrNew()), Z.apush(_t405, 5), Z.apush(_t405, 5), Z.apush(_t405, "assignop"), Z.apush(_t405, "Sub"), _t405)), Z.aset(_t402, "*=", ((_t406 = Z.arrNew()), Z.apush(_t406, 5), Z.apush(_t406, 5), Z.apush(_t406, "assignop"), Z.apush(_t406, "Mul"), _t406)), Z.aset(_t402, "/=", ((_t407 = Z.arrNew()), Z.apush(_t407, 5), Z.apush(_t407, 5), Z.apush(_t407, "assignop"), Z.apush(_t407, "Div"), _t407)), Z.aset(_t402, "%=", ((_t408 = Z.arrNew()), Z.apush(_t408, 5), Z.apush(_t408, 5), Z.apush(_t408, "assignop"), Z.apush(_t408, "Mod"), _t408)), Z.aset(_t402, ".=", ((_t409 = Z.arrNew()), Z.apush(_t409, 5), Z.apush(_t409, 5), Z.apush(_t409, "assignop"), Z.apush(_t409, "Concat"), _t409)), Z.aset(_t402, "??=", ((_t410 = Z.arrNew()), Z.apush(_t410, 5), Z.apush(_t410, 5), Z.apush(_t410, "assignop"), Z.apush(_t410, "Coalesce"), _t410)), Z.aset(_t402, "?", ((_t411 = Z.arrNew()), Z.apush(_t411, 6), Z.apush(_t411, 7), Z.apush(_t411, "ternary"), Z.apush(_t411, null), _t411)), Z.aset(_t402, "??", ((_t412 = Z.arrNew()), Z.apush(_t412, 8), Z.apush(_t412, 8), Z.apush(_t412, "bin"), Z.apush(_t412, "Coalesce"), _t412)), Z.aset(_t402, "||", ((_t413 = Z.arrNew()), Z.apush(_t413, 9), Z.apush(_t413, 10), Z.apush(_t413, "bin"), Z.apush(_t413, "Or"), _t413)), Z.aset(_t402, "&&", ((_t414 = Z.arrNew()), Z.apush(_t414, 10), Z.apush(_t414, 11), Z.apush(_t414, "bin"), Z.apush(_t414, "And"), _t414)), Z.aset(_t402, "|", ((_t415 = Z.arrNew()), Z.apush(_t415, 11), Z.apush(_t415, 12), Z.apush(_t415, "bin"), Z.apush(_t415, "BitOr"), _t415)), Z.aset(_t402, "^", ((_t416 = Z.arrNew()), Z.apush(_t416, 12), Z.apush(_t416, 13), Z.apush(_t416, "bin"), Z.apush(_t416, "BitXor"), _t416)), Z.aset(_t402, "&", ((_t417 = Z.arrNew()), Z.apush(_t417, 13), Z.apush(_t417, 14), Z.apush(_t417, "bin"), Z.apush(_t417, "BitAnd"), _t417)), Z.aset(_t402, "==", ((_t418 = Z.arrNew()), Z.apush(_t418, 14), Z.apush(_t418, 15), Z.apush(_t418, "bin"), Z.apush(_t418, "Eq"), _t418)), Z.aset(_t402, "!=", ((_t419 = Z.arrNew()), Z.apush(_t419, 14), Z.apush(_t419, 15), Z.apush(_t419, "bin"), Z.apush(_t419, "NotEq"), _t419)), Z.aset(_t402, "===", ((_t420 = Z.arrNew()), Z.apush(_t420, 14), Z.apush(_t420, 15), Z.apush(_t420, "bin"), Z.apush(_t420, "Identical"), _t420)), Z.aset(_t402, "!==", ((_t421 = Z.arrNew()), Z.apush(_t421, 14), Z.apush(_t421, 15), Z.apush(_t421, "bin"), Z.apush(_t421, "NotIdentical"), _t421)), Z.aset(_t402, "<", ((_t422 = Z.arrNew()), Z.apush(_t422, 15), Z.apush(_t422, 16), Z.apush(_t422, "bin"), Z.apush(_t422, "Lt"), _t422)), Z.aset(_t402, ">", ((_t423 = Z.arrNew()), Z.apush(_t423, 15), Z.apush(_t423, 16), Z.apush(_t423, "bin"), Z.apush(_t423, "Gt"), _t423)), Z.aset(_t402, "<=", ((_t424 = Z.arrNew()), Z.apush(_t424, 15), Z.apush(_t424, 16), Z.apush(_t424, "bin"), Z.apush(_t424, "Le"), _t424)), Z.aset(_t402, ">=", ((_t425 = Z.arrNew()), Z.apush(_t425, 15), Z.apush(_t425, 16), Z.apush(_t425, "bin"), Z.apush(_t425, "Ge"), _t425)), Z.aset(_t402, ".", ((_t426 = Z.arrNew()), Z.apush(_t426, 16), Z.apush(_t426, 17), Z.apush(_t426, "bin"), Z.apush(_t426, "Concat"), _t426)), Z.aset(_t402, "<<", ((_t427 = Z.arrNew()), Z.apush(_t427, 17), Z.apush(_t427, 18), Z.apush(_t427, "bin"), Z.apush(_t427, "Shl"), _t427)), Z.aset(_t402, ">>", ((_t428 = Z.arrNew()), Z.apush(_t428, 17), Z.apush(_t428, 18), Z.apush(_t428, "bin"), Z.apush(_t428, "Shr"), _t428)), Z.aset(_t402, "+", ((_t429 = Z.arrNew()), Z.apush(_t429, 18), Z.apush(_t429, 19), Z.apush(_t429, "bin"), Z.apush(_t429, "Add"), _t429)), Z.aset(_t402, "-", ((_t430 = Z.arrNew()), Z.apush(_t430, 18), Z.apush(_t430, 19), Z.apush(_t430, "bin"), Z.apush(_t430, "Sub"), _t430)), Z.aset(_t402, "*", ((_t431 = Z.arrNew()), Z.apush(_t431, 19), Z.apush(_t431, 20), Z.apush(_t431, "bin"), Z.apush(_t431, "Mul"), _t431)), Z.aset(_t402, "/", ((_t432 = Z.arrNew()), Z.apush(_t432, 19), Z.apush(_t432, 20), Z.apush(_t432, "bin"), Z.apush(_t432, "Div"), _t432)), Z.aset(_t402, "%", ((_t433 = Z.arrNew()), Z.apush(_t433, 19), Z.apush(_t433, 20), Z.apush(_t433, "bin"), Z.apush(_t433, "Mod"), _t433)), Z.aset(_t402, "**", ((_t434 = Z.arrNew()), Z.apush(_t434, 23), Z.apush(_t434, 22), Z.apush(_t434, "bin"), Z.apush(_t434, "Pow"), _t434)), _t402), Z.index(v_t, "text"))) !== null) ? _t401 : null));
    } else {
      Z.setLine(419);
      if (Z.truthy(Z.ident(Z.index(v_t, "kind"), "kw"))) {
        Z.setLine(419);
        (v_ent = (((_t435 = Z.indexOpt(((_t436 = Z.arrNew()), Z.aset(_t436, "or", ((_t437 = Z.arrNew()), Z.apush(_t437, 1), Z.apush(_t437, 2), Z.apush(_t437, "bin"), Z.apush(_t437, "Or"), _t437)), Z.aset(_t436, "xor", ((_t438 = Z.arrNew()), Z.apush(_t438, 2), Z.apush(_t438, 3), Z.apush(_t438, "bin"), Z.apush(_t438, "Xor"), _t438)), Z.aset(_t436, "and", ((_t439 = Z.arrNew()), Z.apush(_t439, 3), Z.apush(_t439, 4), Z.apush(_t439, "bin"), Z.apush(_t439, "And"), _t439)), _t436), Z.index(v_t, "text"))) !== null) ? _t435 : null));
      } else {
        Z.setLine(420);
        if (Z.truthy((Z.truthy(Z.ident(Z.index(v_t, "kind"), "ident")) && Z.truthy(Z.ident(Z.index(v_t, "text"), "instanceof"))))) {
          Z.setLine(420);
          (v_ent = ((_t440 = Z.arrNew()), Z.apush(_t440, 16), Z.apush(_t440, 17), Z.apush(_t440, "instanceof"), Z.apush(_t440, null), _t440));
        }
      }
    }
    Z.setLine(421);
    if (Z.truthy(Z.ident(v_ent, null))) {
      break L31;
    }
    Z.setLine(422);
    (v_lbp = Z.dup(Z.index(v_ent, 0)));
    Z.setLine(423);
    (v_rbp = Z.dup(Z.index(v_ent, 1)));
    Z.setLine(424);
    (v_kind = Z.dup(Z.index(v_ent, 2)));
    Z.setLine(425);
    if (Z.truthy((Z.cmp(v_lbp, v_min) < 0))) {
      break L31;
    }
    Z.setLine(426);
    f_zs_invoke(Z.dup(v_this), "bump", ((_t441 = Z.arrNew()), _t441));
    Z.setLine(427);
    if (Z.truthy(Z.ident(v_kind, "bin"))) {
      Z.setLine(428);
      (v_r = f_zs_invoke(Z.dup(v_this), "exprBp", ((_t442 = Z.arrNew()), Z.apush(_t442, Z.dup(v_rbp)), _t442)));
      Z.setLine(429);
      (v_lhs = f_Workspace_parser__node("Binary", Z.dup(v_line), ((_t443 = Z.arrNew()), Z.apush(_t443, Z.dup(Z.index(v_ent, 3))), Z.apush(_t443, Z.dup(v_lhs)), Z.apush(_t443, Z.dup(v_r)), _t443)));
    } else {
      Z.setLine(430);
      if (Z.truthy(Z.ident(v_kind, "assign"))) {
        Z.setLine(431);
        f_zs_invoke(Z.dup(v_this), "checkLvalue", ((_t444 = Z.arrNew()), Z.apush(_t444, Z.dup(v_lhs)), _t444));
        Z.setLine(432);
        (v_r = f_zs_invoke(Z.dup(v_this), "exprBp", ((_t445 = Z.arrNew()), Z.apush(_t445, Z.dup(v_rbp)), _t445)));
        Z.setLine(433);
        (v_lhs = f_Workspace_parser__node("Assign", Z.dup(v_line), ((_t446 = Z.arrNew()), Z.apush(_t446, Z.dup(v_lhs)), Z.apush(_t446, Z.dup(v_r)), _t446)));
      } else {
        Z.setLine(434);
        if (Z.truthy(Z.ident(v_kind, "assignop"))) {
          Z.setLine(435);
          f_zs_invoke(Z.dup(v_this), "checkLvalue", ((_t447 = Z.arrNew()), Z.apush(_t447, Z.dup(v_lhs)), _t447));
          Z.setLine(436);
          (v_r = f_zs_invoke(Z.dup(v_this), "exprBp", ((_t448 = Z.arrNew()), Z.apush(_t448, Z.dup(v_rbp)), _t448)));
          Z.setLine(437);
          (v_lhs = f_Workspace_parser__node("AssignOp", Z.dup(v_line), ((_t449 = Z.arrNew()), Z.apush(_t449, Z.dup(Z.index(v_ent, 3))), Z.apush(_t449, Z.dup(v_lhs)), Z.apush(_t449, Z.dup(v_r)), _t449)));
        } else {
          Z.setLine(438);
          if (Z.truthy(Z.ident(v_kind, "ternary"))) {
            Z.setLine(439);
            (v_then = (Z.truthy(f_zs_invoke(Z.dup(v_this), "isOp", ((_t450 = Z.arrNew()), Z.apush(_t450, ":"), _t450))) ? null : f_zs_invoke(Z.dup(v_this), "exprBp", ((_t451 = Z.arrNew()), Z.apush(_t451, 0), _t451))));
            Z.setLine(440);
            f_zs_invoke(Z.dup(v_this), "expectOp", ((_t452 = Z.arrNew()), Z.apush(_t452, ":"), _t452));
            Z.setLine(441);
            (v_els = f_zs_invoke(Z.dup(v_this), "exprBp", ((_t453 = Z.arrNew()), Z.apush(_t453, Z.dup(v_rbp)), _t453)));
            Z.setLine(442);
            (v_lhs = f_Workspace_parser__node("Ternary", Z.dup(v_line), ((_t454 = Z.arrNew()), Z.apush(_t454, Z.dup(v_lhs)), Z.apush(_t454, Z.dup(v_then)), Z.apush(_t454, Z.dup(v_els)), _t454)));
          } else {
            Z.setLine(444);
            (v_n = f_zs_invoke(Z.dup(v_this), "ident", ((_t455 = Z.arrNew()), _t455)));
            Z.setLine(445);
            (v_lhs = f_Workspace_parser__node("InstanceOf", Z.dup(v_line), ((_t456 = Z.arrNew()), Z.apush(_t456, Z.dup(v_lhs)), Z.apush(_t456, Z.dup(v_n)), _t456)));
          }
        }
      }
    }
  }
  Z.setLine(448);
  return Z.dup(v_lhs);
  return null;
}
function f_Parser__unary(v_this) {
  let v_line = null, v_t = null, v_x = null, v_e = null, v_name = null;
  let _t457 = null, _t458 = null, _t459 = null, _t460 = null, _t461 = null, _t462 = null, _t463 = null, _t464 = null, _t465 = null, _t466 = null, _t467 = null, _t468 = null, _t469 = null;
  Z.setLine(452);
  (v_line = f_zs_invoke(Z.dup(v_this), "line", ((_t457 = Z.arrNew()), _t457)));
  Z.setLine(453);
  (v_t = f_zs_invoke(Z.dup(v_this), "cur", ((_t458 = Z.arrNew()), _t458)));
  Z.setLine(454);
  if (Z.truthy(Z.ident(Z.index(v_t, "kind"), "op"))) {
    Z.setLine(455);
    (v_x = Z.dup(Z.index(v_t, "text")));
    Z.setLine(456);
    if (Z.truthy((Z.truthy((Z.truthy((Z.truthy(Z.ident(v_x, "!")) || Z.truthy(Z.ident(v_x, "-")))) || Z.truthy(Z.ident(v_x, "+")))) || Z.truthy(Z.ident(v_x, "~"))))) {
      Z.setLine(457);
      f_zs_invoke(Z.dup(v_this), "bump", ((_t459 = Z.arrNew()), _t459));
      Z.setLine(458);
      (v_e = f_zs_invoke(Z.dup(v_this), "exprBp", ((_t460 = Z.arrNew()), Z.apush(_t460, 21), _t460)));
      Z.setLine(459);
      (v_name = (Z.truthy(Z.ident(v_x, "!")) ? "Not" : (Z.truthy(Z.ident(v_x, "-")) ? "Neg" : (Z.truthy(Z.ident(v_x, "+")) ? "Plus" : "BitNot"))));
      Z.setLine(460);
      return f_Workspace_parser__node("Unary", Z.dup(v_line), ((_t461 = Z.arrNew()), Z.apush(_t461, Z.dup(v_name)), Z.apush(_t461, Z.dup(v_e)), _t461));
    }
    Z.setLine(462);
    if (Z.truthy((Z.truthy(Z.ident(v_x, "++")) || Z.truthy(Z.ident(v_x, "--"))))) {
      Z.setLine(463);
      f_zs_invoke(Z.dup(v_this), "bump", ((_t462 = Z.arrNew()), _t462));
      Z.setLine(464);
      (v_e = f_zs_invoke(Z.dup(v_this), "unary", ((_t463 = Z.arrNew()), _t463)));
      Z.setLine(465);
      f_zs_invoke(Z.dup(v_this), "checkLvalue", ((_t464 = Z.arrNew()), Z.apush(_t464, Z.dup(v_e)), _t464));
      Z.setLine(466);
      return f_Workspace_parser__node("IncDec", Z.dup(v_line), ((_t465 = Z.arrNew()), Z.apush(_t465, Z.dup(v_e)), Z.apush(_t465, Z.ident(v_x, "++")), Z.apush(_t465, true), _t465));
    }
  }
  Z.setLine(469);
  if (Z.truthy((Z.truthy(Z.ident(Z.index(v_t, "kind"), "kw")) && Z.truthy(Z.ident(Z.index(v_t, "text"), "await"))))) {
    Z.setLine(470);
    f_zs_invoke(Z.dup(v_this), "bump", ((_t466 = Z.arrNew()), _t466));
    Z.setLine(471);
    (v_e = f_zs_invoke(Z.dup(v_this), "unary", ((_t467 = Z.arrNew()), _t467)));
    Z.setLine(472);
    return f_Workspace_parser__node("Await", Z.dup(v_line), ((_t468 = Z.arrNew()), Z.apush(_t468, Z.dup(v_e)), _t468));
  }
  Z.setLine(474);
  return f_zs_invoke(Z.dup(v_this), "postfix", ((_t469 = Z.arrNew()), _t469));
  return null;
}
function f_Parser__args(v_this) {
  let v_v = null, v_spread = null, v_name = null;
  let _t470 = null, _t471 = null, _t472 = null, _t473 = null, _t474 = null, _t475 = null, _t476 = null, _t477 = null, _t478 = null, _t479 = null, _t480 = null, _t481 = null, _t482 = null;
  Z.setLine(478);
  f_zs_invoke(Z.dup(v_this), "expectOp", ((_t470 = Z.arrNew()), Z.apush(_t470, "("), _t470));
  Z.setLine(479);
  (v_v = ((_t471 = Z.arrNew()), _t471));
  L32: while (true) {
    Z.setLine(480);
    if (!Z.truthy(!Z.truthy(f_zs_invoke(Z.dup(v_this), "isOp", ((_t472 = Z.arrNew()), Z.apush(_t472, ")"), _t472))))) break;
    Z.setLine(481);
    (v_spread = f_zs_invoke(Z.dup(v_this), "eatOp", ((_t473 = Z.arrNew()), Z.apush(_t473, "..."), _t473)));
    Z.setLine(482);
    (v_name = null);
    Z.setLine(483);
    if (Z.truthy((Z.truthy((Z.truthy(Z.ident(Z.index(f_zs_invoke(Z.dup(v_this), "cur", ((_t474 = Z.arrNew()), _t474)), "kind"), "ident")) && Z.truthy(Z.ident(Z.index(f_zs_invoke(Z.dup(v_this), "at", ((_t475 = Z.arrNew()), Z.apush(_t475, 1), _t475)), "kind"), "op")))) && Z.truthy(Z.ident(Z.index(f_zs_invoke(Z.dup(v_this), "at", ((_t476 = Z.arrNew()), Z.apush(_t476, 1), _t476)), "text"), ":"))))) {
      Z.setLine(484);
      (v_name = f_zs_invoke(Z.dup(v_this), "ident", ((_t477 = Z.arrNew()), _t477)));
      Z.setLine(485);
      f_zs_invoke(Z.dup(v_this), "bump", ((_t478 = Z.arrNew()), _t478));
    }
    Z.setLine(487);
    Z.apush((v_v = Z.wr(v_v)), f_Workspace_parser__node("Arg", 0, ((_t479 = Z.arrNew()), Z.apush(_t479, Z.dup(v_name)), Z.apush(_t479, f_zs_invoke(Z.dup(v_this), "expr", ((_t480 = Z.arrNew()), _t480))), Z.apush(_t479, Z.dup(v_spread)), _t479)));
    Z.setLine(488);
    if (Z.truthy(!Z.truthy(f_zs_invoke(Z.dup(v_this), "eatOp", ((_t481 = Z.arrNew()), Z.apush(_t481, ","), _t481))))) {
      break L32;
    }
  }
  Z.setLine(490);
  f_zs_invoke(Z.dup(v_this), "expectOp", ((_t482 = Z.arrNew()), Z.apush(_t482, ")"), _t482));
  Z.setLine(491);
  return Z.dup(v_v);
  return null;
}
function f_Parser__postfix(v_this) {
  let v_e = null, v_line = null, v_t = null, v_x = null, v_a = null, v_idx = null, v_n = null;
  let _t483 = null, _t484 = null, _t485 = null, _t486 = null, _t487 = null, _t488 = null, _t489 = null, _t490 = null, _t491 = null, _t492 = null, _t493 = null, _t494 = null, _t495 = null, _t496 = null, _t497 = null, _t498 = null, _t499 = null, _t500 = null, _t501 = null, _t502 = null;
  Z.setLine(495);
  (v_e = f_zs_invoke(Z.dup(v_this), "primary", ((_t483 = Z.arrNew()), _t483)));
  L33: while (true) {
    Z.setLine(496);
    if (!Z.truthy(true)) break;
    Z.setLine(497);
    (v_line = f_zs_invoke(Z.dup(v_this), "line", ((_t484 = Z.arrNew()), _t484)));
    Z.setLine(498);
    (v_t = f_zs_invoke(Z.dup(v_this), "cur", ((_t485 = Z.arrNew()), _t485)));
    Z.setLine(499);
    if (Z.truthy(!Z.ident(Z.index(v_t, "kind"), "op"))) {
      break L33;
    }
    Z.setLine(500);
    (v_x = Z.dup(Z.index(v_t, "text")));
    Z.setLine(501);
    if (Z.truthy(Z.ident(v_x, "("))) {
      Z.setLine(502);
      (v_a = f_zs_invoke(Z.dup(v_this), "args", ((_t486 = Z.arrNew()), _t486)));
      Z.setLine(503);
      (v_e = f_Workspace_parser__node("Call", Z.dup(v_line), ((_t487 = Z.arrNew()), Z.apush(_t487, Z.dup(v_e)), Z.apush(_t487, Z.dup(v_a)), _t487)));
    } else {
      Z.setLine(504);
      if (Z.truthy(Z.ident(v_x, "["))) {
        Z.setLine(505);
        f_zs_invoke(Z.dup(v_this), "bump", ((_t488 = Z.arrNew()), _t488));
        Z.setLine(506);
        (v_idx = (Z.truthy(f_zs_invoke(Z.dup(v_this), "isOp", ((_t489 = Z.arrNew()), Z.apush(_t489, "]"), _t489))) ? null : f_zs_invoke(Z.dup(v_this), "expr", ((_t490 = Z.arrNew()), _t490))));
        Z.setLine(507);
        f_zs_invoke(Z.dup(v_this), "expectOp", ((_t491 = Z.arrNew()), Z.apush(_t491, "]"), _t491));
        Z.setLine(508);
        (v_e = f_Workspace_parser__node("Index", Z.dup(v_line), ((_t492 = Z.arrNew()), Z.apush(_t492, Z.dup(v_e)), Z.apush(_t492, Z.dup(v_idx)), _t492)));
      } else {
        Z.setLine(509);
        if (Z.truthy(Z.ident(v_x, "->"))) {
          Z.setLine(510);
          f_zs_invoke(Z.dup(v_this), "bump", ((_t493 = Z.arrNew()), _t493));
          Z.setLine(511);
          (v_n = f_zs_invoke(Z.dup(v_this), "ident", ((_t494 = Z.arrNew()), _t494)));
          Z.setLine(512);
          (v_e = f_Workspace_parser__node("Prop", Z.dup(v_line), ((_t495 = Z.arrNew()), Z.apush(_t495, Z.dup(v_e)), Z.apush(_t495, Z.dup(v_n)), _t495)));
        } else {
          Z.setLine(513);
          if (Z.truthy((Z.truthy((Z.truthy(Z.ident(v_x, ".")) && Z.truthy(f_Workspace_parser__isNamePath(Z.dup(v_e))))) && Z.truthy(Z.ident(Z.index(f_zs_invoke(Z.dup(v_this), "at", ((_t496 = Z.arrNew()), Z.apush(_t496, 1), _t496)), "kind"), "ident"))))) {
            Z.setLine(514);
            f_zs_invoke(Z.dup(v_this), "bump", ((_t497 = Z.arrNew()), _t497));
            Z.setLine(515);
            (v_n = f_zs_invoke(Z.dup(v_this), "ident", ((_t498 = Z.arrNew()), _t498)));
            Z.setLine(516);
            (v_e = f_Workspace_parser__node("Dot", Z.dup(v_line), ((_t499 = Z.arrNew()), Z.apush(_t499, Z.dup(v_e)), Z.apush(_t499, Z.dup(v_n)), _t499)));
          } else {
            Z.setLine(517);
            if (Z.truthy((Z.truthy(Z.ident(v_x, "++")) || Z.truthy(Z.ident(v_x, "--"))))) {
              Z.setLine(518);
              f_zs_invoke(Z.dup(v_this), "bump", ((_t500 = Z.arrNew()), _t500));
              Z.setLine(519);
              f_zs_invoke(Z.dup(v_this), "checkLvalue", ((_t501 = Z.arrNew()), Z.apush(_t501, Z.dup(v_e)), _t501));
              Z.setLine(520);
              (v_e = f_Workspace_parser__node("IncDec", Z.dup(v_line), ((_t502 = Z.arrNew()), Z.apush(_t502, Z.dup(v_e)), Z.apush(_t502, Z.ident(v_x, "++")), Z.apush(_t502, false), _t502)));
            } else {
              break L33;
            }
          }
        }
      }
    }
  }
  Z.setLine(523);
  return Z.dup(v_e);
  return null;
}
function f_Parser__primary(v_this) {
  let v_line = null, v_t = null, v_k = null, v_x = null, v_n = null, v_a = null, v_params = null, v_ret = null, v_body = null, v_d = null, v_e = null, v_items = null, v_sl = null, v_first = null, v_v = null;
  let _t503 = null, _t504 = null, _t505 = null, _t506 = null, _t507 = null, _t508 = null, _t509 = null, _t510 = null, _t511 = null, _t512 = null, _t513 = null, _t514 = null, _t515 = null, _t516 = null, _t517 = null, _t518 = null, _t519 = null, _t520 = null, _t521 = null, _t522 = null, _t523 = null, _t524 = null, _t525 = null, _t526 = null, _t527 = null, _t528 = null, _t529 = null, _t530 = null, _t531 = null, _t532 = null, _t533 = null, _t534 = null, _t535 = null, _t536 = null, _t537 = null, _t538 = null, _t539 = null, _t540 = null, _t541 = null, _t542 = null, _t543 = null, _t544 = null, _t545 = null, _t546 = null, _t547 = null, _t548 = null, _t549 = null, _t550 = null, _t551 = null, _t552 = null, _t553 = null, _t554 = null, _t555 = null;
  Z.setLine(527);
  (v_line = f_zs_invoke(Z.dup(v_this), "line", ((_t503 = Z.arrNew()), _t503)));
  Z.setLine(528);
  (v_t = f_zs_invoke(Z.dup(v_this), "bump", ((_t504 = Z.arrNew()), _t504)));
  Z.setLine(529);
  (v_k = Z.dup(Z.index(v_t, "kind")));
  Z.setLine(530);
  (v_x = Z.dup(Z.index(v_t, "text")));
  Z.setLine(531);
  if (Z.truthy(Z.ident(v_k, "int"))) {
    Z.setLine(531);
    return f_Workspace_parser__node("Int", Z.dup(v_line), ((_t505 = Z.arrNew()), Z.apush(_t505, Z.dup(Z.index(v_t, "value"))), _t505));
  }
  Z.setLine(532);
  if (Z.truthy(Z.ident(v_k, "float"))) {
    Z.setLine(532);
    return f_Workspace_parser__node("Float", Z.dup(v_line), ((_t506 = Z.arrNew()), Z.apush(_t506, Z.dup(Z.index(v_t, "value"))), _t506));
  }
  Z.setLine(533);
  if (Z.truthy(Z.ident(v_k, "str"))) {
    Z.setLine(533);
    return f_Workspace_parser__node("Str", Z.dup(v_line), ((_t507 = Z.arrNew()), Z.apush(_t507, Z.dup(Z.index(v_t, "value"))), _t507));
  }
  Z.setLine(534);
  if (Z.truthy(Z.ident(v_k, "var"))) {
    Z.setLine(534);
    return f_Workspace_parser__node("Var", Z.dup(v_line), ((_t508 = Z.arrNew()), Z.apush(_t508, Z.dup(Z.index(v_t, "value"))), _t508));
  }
  Z.setLine(535);
  if (Z.truthy(Z.ident(v_k, "kw"))) {
    Z.setLine(536);
    if (Z.truthy(Z.ident(v_x, "true"))) {
      Z.setLine(536);
      return f_Workspace_parser__node("Bool", Z.dup(v_line), ((_t509 = Z.arrNew()), Z.apush(_t509, true), _t509));
    }
    Z.setLine(537);
    if (Z.truthy(Z.ident(v_x, "false"))) {
      Z.setLine(537);
      return f_Workspace_parser__node("Bool", Z.dup(v_line), ((_t510 = Z.arrNew()), Z.apush(_t510, false), _t510));
    }
    Z.setLine(538);
    if (Z.truthy(Z.ident(v_x, "null"))) {
      Z.setLine(538);
      return f_Workspace_parser__node("Null", Z.dup(v_line), ((_t511 = Z.arrNew()), _t511));
    }
    Z.setLine(539);
    if (Z.truthy(Z.ident(v_x, "static"))) {
      Z.setLine(539);
      return f_Workspace_parser__node("Name", Z.dup(v_line), ((_t512 = Z.arrNew()), Z.apush(_t512, "static"), _t512));
    }
    Z.setLine(540);
    if (Z.truthy(Z.ident(v_x, "new"))) {
      Z.setLine(541);
      (v_n = f_zs_invoke(Z.dup(v_this), "ident", ((_t513 = Z.arrNew()), _t513)));
      Z.setLine(542);
      (v_a = (Z.truthy(f_zs_invoke(Z.dup(v_this), "isOp", ((_t514 = Z.arrNew()), Z.apush(_t514, "("), _t514))) ? f_zs_invoke(Z.dup(v_this), "args", ((_t515 = Z.arrNew()), _t515)) : ((_t516 = Z.arrNew()), _t516)));
      Z.setLine(543);
      return f_Workspace_parser__node("New", Z.dup(v_line), ((_t517 = Z.arrNew()), Z.apush(_t517, Z.dup(v_n)), Z.apush(_t517, Z.dup(v_a)), _t517));
    }
    Z.setLine(545);
    if (Z.truthy(Z.ident(v_x, "match"))) {
      Z.setLine(545);
      return f_zs_invoke(Z.dup(v_this), "matchExpr", ((_t518 = Z.arrNew()), Z.apush(_t518, Z.dup(v_line)), _t518));
    }
    Z.setLine(546);
    if (Z.truthy(Z.ident(v_x, "fn"))) {
      Z.setLine(547);
      (v_params = f_zs_invoke(Z.dup(v_this), "params", ((_t519 = Z.arrNew()), _t519)));
      Z.setLine(548);
      (v_ret = (Z.truthy(f_zs_invoke(Z.dup(v_this), "eatOp", ((_t520 = Z.arrNew()), Z.apush(_t520, ":"), _t520))) ? f_zs_invoke(Z.dup(v_this), "types", ((_t521 = Z.arrNew()), _t521)) : ((_t522 = Z.arrNew()), _t522)));
      Z.setLine(549);
      f_zs_invoke(Z.dup(v_this), "expectOp", ((_t523 = Z.arrNew()), Z.apush(_t523, "=>"), _t523));
      Z.setLine(550);
      (v_body = f_zs_invoke(Z.dup(v_this), "exprBp", ((_t524 = Z.arrNew()), Z.apush(_t524, 5), _t524)));
      Z.setLine(551);
      (v_d = f_Workspace_parser__node("Func", Z.dup(v_line), ((_t525 = Z.arrNew()), Z.apush(_t525, null), Z.apush(_t525, Z.dup(v_params)), Z.apush(_t525, Z.dup(v_ret)), Z.apush(_t525, ((_t526 = Z.arrNew()), Z.apush(_t526, f_Workspace_parser__node("Return", Z.dup(Z.index(v_body, 1)), ((_t527 = Z.arrNew()), Z.apush(_t527, Z.dup(v_body)), _t527))), _t526)), Z.apush(_t525, true), _t525)));
      Z.setLine(552);
      return f_Workspace_parser__node("Closure", Z.dup(v_line), ((_t528 = Z.arrNew()), Z.apush(_t528, Z.dup(v_d)), _t528));
    }
    Z.setLine(554);
    if (Z.truthy(Z.ident(v_x, "func"))) {
      Z.setLine(554);
      return f_Workspace_parser__node("Closure", Z.dup(v_line), ((_t529 = Z.arrNew()), Z.apush(_t529, f_zs_invoke(Z.dup(v_this), "funcRest", ((_t530 = Z.arrNew()), Z.apush(_t530, false), _t530))), _t529));
    }
  }
  Z.setLine(556);
  if (Z.truthy(Z.ident(v_k, "ident"))) {
    Z.setLine(557);
    if (Z.truthy((Z.truthy(Z.ident(v_x, "function")) && Z.truthy(f_zs_invoke(Z.dup(v_this), "isOp", ((_t531 = Z.arrNew()), Z.apush(_t531, "("), _t531)))))) {
      Z.setLine(557);
      return f_Workspace_parser__node("Closure", Z.dup(v_line), ((_t532 = Z.arrNew()), Z.apush(_t532, f_zs_invoke(Z.dup(v_this), "funcRest", ((_t533 = Z.arrNew()), Z.apush(_t533, false), _t533))), _t532));
    }
    Z.setLine(558);
    return f_Workspace_parser__node("Name", Z.dup(v_line), ((_t534 = Z.arrNew()), Z.apush(_t534, Z.dup(v_x)), _t534));
  }
  Z.setLine(560);
  if (Z.truthy((Z.truthy(Z.ident(v_k, "op")) && Z.truthy(Z.ident(v_x, "("))))) {
    Z.setLine(561);
    (v_e = f_zs_invoke(Z.dup(v_this), "expr", ((_t535 = Z.arrNew()), _t535)));
    Z.setLine(562);
    f_zs_invoke(Z.dup(v_this), "expectOp", ((_t536 = Z.arrNew()), Z.apush(_t536, ")"), _t536));
    Z.setLine(563);
    return Z.dup(v_e);
  }
  Z.setLine(565);
  if (Z.truthy((Z.truthy(Z.ident(v_k, "op")) && Z.truthy(Z.ident(v_x, "["))))) {
    Z.setLine(566);
    (v_items = ((_t537 = Z.arrNew()), _t537));
    L34: while (true) {
      Z.setLine(567);
      if (!Z.truthy(!Z.truthy(f_zs_invoke(Z.dup(v_this), "isOp", ((_t538 = Z.arrNew()), Z.apush(_t538, "]"), _t538))))) break;
      Z.setLine(568);
      if (Z.truthy(f_zs_invoke(Z.dup(v_this), "isOp", ((_t539 = Z.arrNew()), Z.apush(_t539, "..."), _t539)))) {
        Z.setLine(569);
        (v_sl = f_zs_invoke(Z.dup(v_this), "line", ((_t540 = Z.arrNew()), _t540)));
        Z.setLine(570);
        f_zs_invoke(Z.dup(v_this), "bump", ((_t541 = Z.arrNew()), _t541));
        Z.setLine(571);
        Z.apush((v_items = Z.wr(v_items)), f_Workspace_parser__node("Item", 0, ((_t542 = Z.arrNew()), Z.apush(_t542, null), Z.apush(_t542, f_Workspace_parser__node("Spread", Z.dup(v_sl), ((_t543 = Z.arrNew()), Z.apush(_t543, f_zs_invoke(Z.dup(v_this), "expr", ((_t544 = Z.arrNew()), _t544))), _t543))), _t542)));
        Z.setLine(572);
        if (Z.truthy(!Z.truthy(f_zs_invoke(Z.dup(v_this), "eatOp", ((_t545 = Z.arrNew()), Z.apush(_t545, ","), _t545))))) {
          break L34;
        }
        continue L34;
      }
      Z.setLine(575);
      (v_first = f_zs_invoke(Z.dup(v_this), "expr", ((_t546 = Z.arrNew()), _t546)));
      Z.setLine(576);
      if (Z.truthy(f_zs_invoke(Z.dup(v_this), "eatOp", ((_t547 = Z.arrNew()), Z.apush(_t547, "=>"), _t547)))) {
        Z.setLine(576);
        (v_v = f_zs_invoke(Z.dup(v_this), "expr", ((_t548 = Z.arrNew()), _t548)));
        Z.setLine(576);
        Z.apush((v_items = Z.wr(v_items)), f_Workspace_parser__node("Item", 0, ((_t549 = Z.arrNew()), Z.apush(_t549, Z.dup(v_first)), Z.apush(_t549, Z.dup(v_v)), _t549)));
      } else {
        Z.setLine(577);
        Z.apush((v_items = Z.wr(v_items)), f_Workspace_parser__node("Item", 0, ((_t550 = Z.arrNew()), Z.apush(_t550, null), Z.apush(_t550, Z.dup(v_first)), _t550)));
      }
      Z.setLine(578);
      if (Z.truthy(!Z.truthy(f_zs_invoke(Z.dup(v_this), "eatOp", ((_t551 = Z.arrNew()), Z.apush(_t551, ","), _t551))))) {
        break L34;
      }
    }
    Z.setLine(580);
    f_zs_invoke(Z.dup(v_this), "expectOp", ((_t552 = Z.arrNew()), Z.apush(_t552, "]"), _t552));
    Z.setLine(581);
    return f_Workspace_parser__node("Array", Z.dup(v_line), ((_t553 = Z.arrNew()), Z.apush(_t553, Z.dup(v_items)), _t553));
  }
  Z.setLine(583);
  f_zs_invoke(Z.dup(v_this), "back", ((_t554 = Z.arrNew()), _t554));
  Z.setLine(584);
  f_zs_invoke(Z.dup(v_this), "fail", ((_t555 = Z.arrNew()), Z.apush(_t555, Z.concat(Z.concat("nieoczekiwany token w wyrażeniu: `", v_x), "`")), _t555));
  return null;
}
function f_Parser__matchExpr(v_this, v_line) {
  let v_subj = null, v_arms = null, v_conds = null, v_body = null;
  let _t556 = null, _t557 = null, _t558 = null, _t559 = null, _t560 = null, _t561 = null, _t562 = null, _t563 = null, _t564 = null, _t565 = null, _t566 = null, _t567 = null, _t568 = null, _t569 = null, _t570 = null, _t571 = null;
  Z.setLine(588);
  (v_subj = f_zs_invoke(Z.dup(v_this), "parenExpr", ((_t556 = Z.arrNew()), _t556)));
  Z.setLine(589);
  f_zs_invoke(Z.dup(v_this), "expectOp", ((_t557 = Z.arrNew()), Z.apush(_t557, "{"), _t557));
  Z.setLine(590);
  (v_arms = ((_t558 = Z.arrNew()), _t558));
  L35: while (true) {
    Z.setLine(591);
    if (!Z.truthy(!Z.truthy(f_zs_invoke(Z.dup(v_this), "isOp", ((_t559 = Z.arrNew()), Z.apush(_t559, "}"), _t559))))) break;
    Z.setLine(592);
    (v_conds = null);
    Z.setLine(593);
    if (Z.truthy(!Z.truthy(f_zs_invoke(Z.dup(v_this), "eatKw", ((_t560 = Z.arrNew()), Z.apush(_t560, "default"), _t560))))) {
      Z.setLine(594);
      (v_conds = ((_t561 = Z.arrNew()), Z.apush(_t561, f_zs_invoke(Z.dup(v_this), "expr", ((_t562 = Z.arrNew()), _t562))), _t561));
      L36: while (true) {
        Z.setLine(595);
        if (!Z.truthy(f_zs_invoke(Z.dup(v_this), "eatOp", ((_t563 = Z.arrNew()), Z.apush(_t563, ","), _t563)))) break;
        Z.setLine(596);
        if (Z.truthy(f_zs_invoke(Z.dup(v_this), "isOp", ((_t564 = Z.arrNew()), Z.apush(_t564, "=>"), _t564)))) {
          break L36;
        }
        Z.setLine(597);
        Z.apush((v_conds = Z.wr(v_conds)), f_zs_invoke(Z.dup(v_this), "expr", ((_t565 = Z.arrNew()), _t565)));
      }
    }
    Z.setLine(600);
    f_zs_invoke(Z.dup(v_this), "expectOp", ((_t566 = Z.arrNew()), Z.apush(_t566, "=>"), _t566));
    Z.setLine(601);
    (v_body = f_zs_invoke(Z.dup(v_this), "expr", ((_t567 = Z.arrNew()), _t567)));
    Z.setLine(602);
    Z.apush((v_arms = Z.wr(v_arms)), f_Workspace_parser__node("Arm", 0, ((_t568 = Z.arrNew()), Z.apush(_t568, Z.dup(v_conds)), Z.apush(_t568, Z.dup(v_body)), _t568)));
    Z.setLine(603);
    if (Z.truthy(!Z.truthy(f_zs_invoke(Z.dup(v_this), "eatOp", ((_t569 = Z.arrNew()), Z.apush(_t569, ","), _t569))))) {
      break L35;
    }
  }
  Z.setLine(605);
  f_zs_invoke(Z.dup(v_this), "expectOp", ((_t570 = Z.arrNew()), Z.apush(_t570, "}"), _t570));
  Z.setLine(606);
  return f_Workspace_parser__node("Match", Z.dup(v_line), ((_t571 = Z.arrNew()), Z.apush(_t571, Z.dup(v_subj)), Z.apush(_t571, Z.dup(v_arms)), _t571));
  return null;
}
function f_Parser__new(v_toks) {
  let v___o = null;
  Z.setLine(56);
  (v___o = Z.B.zs_obj_new("Parser"));
  Z.setLine(56);
  Z.B.zs_obj_set(v___o, "toks", null);
  Z.setLine(56);
  Z.B.zs_obj_set(v___o, "pos", null);
  Z.setLine(56);
  Z.B.zs_obj_set(v___o, "last", null);
  Z.setLine(56);
  f_Parser____construct(Z.dup(v___o), Z.dup(v_toks));
  Z.setLine(56);
  return Z.dup(v___o);
  return null;
}
function f_ZbcTables__new() {
  let v___o = null;
  Z.setLine(5);
  (v___o = Z.B.zs_obj_new("ZbcTables"));
  Z.setLine(5);
  return Z.dup(v___o);
  return null;
}
function f_Bundler____construct(v_this) {
  let _t572 = null, _t573 = null;
  Z.setLine(14);
  Z.B.zs_obj_set(v_this, "mods", ((_t572 = Z.arrNew()), _t572));
  Z.setLine(15);
  Z.B.zs_obj_set(v_this, "files", ((_t573 = Z.arrNew()), _t573));
  return null;
}
function f_Bundler__scan(v_this, v_stmts, v_dir) {
  let v_s = null, v_path = null, v_key = null, v_file = null, v___k3 = null, v___r4 = null, v___w5 = null, v___k6 = null, v___r7 = null, v___w8 = null, v_ast = null, v___k9 = null, v___r10 = null, v___w11 = null;
  let _t574 = null, _t575 = null, _t576 = null;
  Z.setLine(19);
  {
    const _it37 = Z.foreachArr(Z.dup(v_stmts));
    L37: for (let _i37 = 0; _i37 < _it37.keys.length; _i37++) {
      v_s = _it37.vals[_i37];
      Z.setLine(20);
      if (Z.truthy(!Z.ident(Z.index(v_s, 0), ":Import"))) {
        continue L37;
      }
      Z.setLine(21);
      (v_path = Z.dup(Z.index(v_s, 2)));
      Z.setLine(22);
      if (Z.truthy(Z.B.in_array(Z.index(v_path, 0), ((_t574 = Z.arrNew()), Z.apush(_t574, "System"), Z.apush(_t574, "Math"), Z.apush(_t574, "File"), Z.apush(_t574, "Directory"), Z.apush(_t574, "Process"), Z.apush(_t574, "Task"), _t574)))) {
        continue L37;
      }
      Z.setLine(23);
      (v_key = Z.B.join(v_path, "."));
      Z.setLine(24);
      (v_file = Z.M.System.resolveImport(v_path, v_dir));
      Z.setLine(25);
      if (Z.truthy(Z.ident(v_file, null))) {
        Z.setLine(25);
        Z.raise(new Z.ZExc(0, Z.concat(Z.concat(Z.concat(Z.concat("nie znaleziono modułu ", v_key), " (import w "), v_dir), ")")));
      }
      Z.setLine(26);
      if (Z.truthy(Z.B.has_key(Z.B.zs_obj_get(v_this, "mods"), v_key))) {
        Z.setLine(27);
        if (Z.truthy(!Z.ident(Z.index(Z.B.zs_obj_get(v_this, "files"), v_key), v_file))) {
          Z.setLine(28);
          Z.raise(new Z.ZExc(0, Z.concat(Z.concat(Z.concat(Z.concat(Z.concat("niejednoznaczny import `", v_key), "`: "), Z.index(Z.B.zs_obj_get(v_this, "files"), v_key)), " oraz "), v_file)));
        }
        continue L37;
      }
      Z.setLine(32);
      (v___k3 = Z.dup(v_key));
      Z.setLine(32);
      (v___r4 = Z.dup(v_file));
      Z.setLine(32);
      (v___w5 = Z.B.zs_obj_take(v_this, "files"));
      Z.setLine(32);
      Z.aset((v___w5 = Z.wr(v___w5)), v___k3, Z.dup(v___r4));
      Z.setLine(32);
      Z.B.zs_obj_put(v_this, "files", v___w5);
      Z.setLine(33);
      (v___k6 = Z.dup(v_key));
      Z.setLine(33);
      (v___r7 = ((_t575 = Z.arrNew()), _t575));
      Z.setLine(33);
      (v___w8 = Z.B.zs_obj_take(v_this, "mods"));
      Z.setLine(33);
      Z.aset((v___w8 = Z.wr(v___w8)), v___k6, Z.dup(v___r7));
      Z.setLine(33);
      Z.B.zs_obj_put(v_this, "mods", v___w8);
      Z.setLine(34);
      (v_ast = f_Workspace_parser__parse(Z.M.File.read(v_file)));
      Z.setLine(35);
      (v___k9 = Z.dup(v_key));
      Z.setLine(35);
      (v___r10 = Z.dup(v_ast));
      Z.setLine(35);
      (v___w11 = Z.B.zs_obj_take(v_this, "mods"));
      Z.setLine(35);
      Z.aset((v___w11 = Z.wr(v___w11)), v___k9, Z.dup(v___r10));
      Z.setLine(35);
      Z.B.zs_obj_put(v_this, "mods", v___w11);
      Z.setLine(36);
      f_zs_invoke(Z.dup(v_this), "scan", ((_t576 = Z.arrNew()), Z.apush(_t576, Z.dup(v_ast)), Z.apush(_t576, Z.M.System.dirname(v_file)), _t576));
    }
  }
  return null;
}
function f_Bundler__new() {
  let v___o = null;
  Z.setLine(9);
  (v___o = Z.B.zs_obj_new("Bundler"));
  Z.setLine(9);
  Z.B.zs_obj_set(v___o, "mods", null);
  Z.setLine(9);
  Z.B.zs_obj_set(v___o, "files", null);
  Z.setLine(9);
  f_Bundler____construct(Z.dup(v___o));
  Z.setLine(9);
  return Z.dup(v___o);
  return null;
}
function f_SemaTables__new() {
  let v___o = null;
  Z.setLine(5);
  (v___o = Z.B.zs_obj_new("SemaTables"));
  Z.setLine(5);
  return Z.dup(v___o);
  return null;
}
function f_SemaScope____construct(v_this, v_name, v_line, v_isClosure) {
  let _t577 = null, _t578 = null, _t579 = null, _t580 = null, _t581 = null, _t582 = null;
  Z.setLine(31);
  Z.B.zs_obj_set(v_this, "name", v_name);
  Z.setLine(32);
  Z.B.zs_obj_set(v_this, "line", v_line);
  Z.setLine(33);
  Z.B.zs_obj_set(v_this, "assigned", ((_t577 = Z.arrNew()), _t577));
  Z.setLine(34);
  Z.B.zs_obj_set(v_this, "reads", ((_t578 = Z.arrNew()), _t578));
  Z.setLine(35);
  Z.B.zs_obj_set(v_this, "sites", ((_t579 = Z.arrNew()), _t579));
  Z.setLine(36);
  Z.B.zs_obj_set(v_this, "level", ((_t580 = Z.arrNew()), _t580));
  Z.setLine(37);
  Z.B.zs_obj_set(v_this, "edges", ((_t581 = Z.arrNew()), _t581));
  Z.setLine(38);
  Z.B.zs_obj_set(v_this, "children", ((_t582 = Z.arrNew()), _t582));
  Z.setLine(39);
  Z.B.zs_obj_set(v_this, "isClosure", v_isClosure);
  return null;
}
function f_SemaScope__raise(v_this, v_v, v_lv) {
  let v_cur = null, v___k12 = null, v___r13 = null, v___w14 = null;
  let _t583 = null;
  Z.setLine(43);
  (v_cur = (((_t583 = Z.indexOpt(Z.B.zs_obj_get(v_this, "level"), v_v)) !== null) ? _t583 : 0));
  Z.setLine(44);
  if (Z.truthy((Z.cmp(v_lv, v_cur) > 0))) {
    Z.setLine(44);
    (v___k12 = Z.dup(v_v));
    Z.setLine(44);
    (v___r13 = Z.dup(v_lv));
    Z.setLine(44);
    (v___w14 = Z.B.zs_obj_take(v_this, "level"));
    Z.setLine(44);
    Z.aset((v___w14 = Z.wr(v___w14)), v___k12, Z.dup(v___r13));
    Z.setLine(44);
    Z.B.zs_obj_put(v_this, "level", v___w14);
  }
  return null;
}
function f_SemaScope__new(v_name, v_line, v_isClosure) {
  let v___o = null;
  Z.setLine(19);
  (v___o = Z.B.zs_obj_new("SemaScope"));
  Z.setLine(19);
  Z.B.zs_obj_set(v___o, "name", null);
  Z.setLine(19);
  Z.B.zs_obj_set(v___o, "line", null);
  Z.setLine(19);
  Z.B.zs_obj_set(v___o, "assigned", null);
  Z.setLine(19);
  Z.B.zs_obj_set(v___o, "reads", null);
  Z.setLine(19);
  Z.B.zs_obj_set(v___o, "sites", null);
  Z.setLine(19);
  Z.B.zs_obj_set(v___o, "level", null);
  Z.setLine(19);
  Z.B.zs_obj_set(v___o, "edges", null);
  Z.setLine(19);
  Z.B.zs_obj_set(v___o, "children", null);
  Z.setLine(19);
  Z.B.zs_obj_set(v___o, "isClosure", null);
  Z.setLine(19);
  f_SemaScope____construct(Z.dup(v___o), Z.dup(v_name), Z.dup(v_line), Z.dup(v_isClosure));
  Z.setLine(19);
  return Z.dup(v___o);
  return null;
}
function f_Analyzer____construct(v_this) {
  let _t584 = null, _t585 = null;
  Z.setLine(53);
  Z.B.zs_obj_set(v_this, "warnings", ((_t584 = Z.arrNew()), _t584));
  Z.setLine(54);
  Z.B.zs_obj_set(v_this, "functions", ((_t585 = Z.arrNew()), _t585));
  return null;
}
function f_Analyzer__baseVar(v_this, v_e) {
  L38: while (true) {
    Z.setLine(58);
    if (!Z.truthy((Z.truthy(Z.ident(Z.index(v_e, 0), ":Index")) || Z.truthy(Z.ident(Z.index(v_e, 0), ":Prop"))))) break;
    Z.setLine(58);
    (v_e = Z.dup(Z.index(v_e, 2)));
  }
  Z.setLine(59);
  return (Z.truthy(Z.ident(Z.index(v_e, 0), ":Var")) ? Z.index(v_e, 2) : null);
  return null;
}
function f_Analyzer__allocKind(v_this, v_e) {
  Z.setLine(63);
  if (Z.truthy(Z.ident(Z.index(v_e, 0), ":Array"))) {
    Z.setLine(63);
    return "array";
  }
  Z.setLine(64);
  if (Z.truthy(Z.ident(Z.index(v_e, 0), ":New"))) {
    Z.setLine(64);
    return Z.concat("object ", Z.index(v_e, 2));
  }
  Z.setLine(65);
  if (Z.truthy(Z.ident(Z.index(v_e, 0), ":Closure"))) {
    Z.setLine(65);
    return "closure";
  }
  Z.setLine(66);
  return null;
  return null;
}
function f_Analyzer__valueVars(v_this, v_e) {
  let v_out = null, v_it = null, v_x = null;
  let _t586 = null, _t587 = null, _t588 = null, _t589 = null, _t590 = null, _t591 = null, _t592 = null;
  Z.setLine(71);
  (v_out = ((_t586 = Z.arrNew()), _t586));
  Z.setLine(72);
  if (Z.truthy(Z.ident(Z.index(v_e, 0), ":Var"))) {
    Z.setLine(72);
    Z.apush((v_out = Z.wr(v_out)), Z.dup(Z.index(v_e, 2)));
  } else {
    Z.setLine(73);
    if (Z.truthy(Z.ident(Z.index(v_e, 0), ":Array"))) {
      Z.setLine(74);
      {
        const _it39 = Z.foreachArr(Z.dup(Z.index(v_e, 2)));
        L39: for (let _i39 = 0; _i39 < _it39.keys.length; _i39++) {
          v_it = _it39.vals[_i39];
          Z.setLine(74);
          {
            const _it40 = Z.foreachArr(f_zs_invoke(Z.dup(v_this), "valueVars", ((_t587 = Z.arrNew()), Z.apush(_t587, Z.dup(Z.index(v_it, 3))), _t587)));
            L40: for (let _i40 = 0; _i40 < _it40.keys.length; _i40++) {
              v_x = _it40.vals[_i40];
              Z.setLine(74);
              Z.apush((v_out = Z.wr(v_out)), Z.dup(v_x));
            }
          }
        }
      }
    } else {
      Z.setLine(75);
      if (Z.truthy(Z.ident(Z.index(v_e, 0), ":Spread"))) {
        Z.setLine(76);
        {
          const _it41 = Z.foreachArr(f_zs_invoke(Z.dup(v_this), "valueVars", ((_t588 = Z.arrNew()), Z.apush(_t588, Z.dup(Z.index(v_e, 2))), _t588)));
          L41: for (let _i41 = 0; _i41 < _it41.keys.length; _i41++) {
            v_x = _it41.vals[_i41];
            Z.setLine(76);
            Z.apush((v_out = Z.wr(v_out)), Z.dup(v_x));
          }
        }
      } else {
        Z.setLine(77);
        if (Z.truthy(Z.ident(Z.index(v_e, 0), ":Ternary"))) {
          Z.setLine(78);
          if (Z.truthy(!Z.ident(Z.index(v_e, 3), null))) {
            Z.setLine(78);
            {
              const _it42 = Z.foreachArr(f_zs_invoke(Z.dup(v_this), "valueVars", ((_t589 = Z.arrNew()), Z.apush(_t589, Z.dup(Z.index(v_e, 3))), _t589)));
              L42: for (let _i42 = 0; _i42 < _it42.keys.length; _i42++) {
                v_x = _it42.vals[_i42];
                Z.setLine(78);
                Z.apush((v_out = Z.wr(v_out)), Z.dup(v_x));
              }
            }
          }
          Z.setLine(79);
          {
            const _it43 = Z.foreachArr(f_zs_invoke(Z.dup(v_this), "valueVars", ((_t590 = Z.arrNew()), Z.apush(_t590, Z.dup(Z.index(v_e, 4))), _t590)));
            L43: for (let _i43 = 0; _i43 < _it43.keys.length; _i43++) {
              v_x = _it43.vals[_i43];
              Z.setLine(79);
              Z.apush((v_out = Z.wr(v_out)), Z.dup(v_x));
            }
          }
        } else {
          Z.setLine(80);
          if (Z.truthy((Z.truthy(Z.ident(Z.index(v_e, 0), ":Binary")) && Z.truthy(Z.ident(Z.index(v_e, 2), "Coalesce"))))) {
            Z.setLine(81);
            {
              const _it44 = Z.foreachArr(f_zs_invoke(Z.dup(v_this), "valueVars", ((_t591 = Z.arrNew()), Z.apush(_t591, Z.dup(Z.index(v_e, 3))), _t591)));
              L44: for (let _i44 = 0; _i44 < _it44.keys.length; _i44++) {
                v_x = _it44.vals[_i44];
                Z.setLine(81);
                Z.apush((v_out = Z.wr(v_out)), Z.dup(v_x));
              }
            }
            Z.setLine(82);
            {
              const _it45 = Z.foreachArr(f_zs_invoke(Z.dup(v_this), "valueVars", ((_t592 = Z.arrNew()), Z.apush(_t592, Z.dup(Z.index(v_e, 4))), _t592)));
              L45: for (let _i45 = 0; _i45 < _it45.keys.length; _i45++) {
                v_x = _it45.vals[_i45];
                Z.setLine(82);
                Z.apush((v_out = Z.wr(v_out)), Z.dup(v_x));
              }
            }
          }
        }
      }
    }
  }
  Z.setLine(84);
  return Z.dup(v_out);
  return null;
}
function f_Analyzer__visitAny(v_this, v_x, v_sc, v_prefix) {
  let v_y = null;
  let _t593 = null, _t594 = null;
  Z.setLine(88);
  if (Z.truthy(f_Workspace_parser__isNode(Z.dup(v_x)))) {
    Z.setLine(88);
    f_zs_invoke(Z.dup(v_this), "visit", ((_t593 = Z.arrNew()), Z.apush(_t593, Z.dup(v_x)), Z.apush(_t593, Z.dup(v_sc)), Z.apush(_t593, Z.dup(v_prefix)), _t593));
  } else {
    Z.setLine(89);
    if (Z.truthy(Z.B.is_array(v_x))) {
      Z.setLine(89);
      {
        const _it46 = Z.foreachArr(Z.dup(v_x));
        L46: for (let _i46 = 0; _i46 < _it46.keys.length; _i46++) {
          v_y = _it46.vals[_i46];
          Z.setLine(89);
          f_zs_invoke(Z.dup(v_this), "visitAny", ((_t594 = Z.arrNew()), Z.apush(_t594, Z.dup(v_y)), Z.apush(_t594, Z.dup(v_sc)), Z.apush(_t594, Z.dup(v_prefix)), _t594));
        }
      }
    }
  }
  return null;
}
function f_Analyzer__visitChildren(v_this, v_n, v_sc, v_prefix) {
  let v_i = null;
  let _t595 = null, _t596 = null;
  Z.setLine(93);
  (v_i = 2);
  L47: for (; Z.truthy((Z.cmp(v_i, Z.B.count(v_n)) < 0)); ((_t595 = v_i), (v_i = Z.add(_t595, 1)), _t595)) {
    Z.setLine(93);
    f_zs_invoke(Z.dup(v_this), "visitAny", ((_t596 = Z.arrNew()), Z.apush(_t596, Z.dup(Z.index(v_n, v_i))), Z.apush(_t596, Z.dup(v_sc)), Z.apush(_t596, Z.dup(v_prefix)), _t596));
  }
  return null;
}
function f_Analyzer__visit(v_this, v_n, v_sc, v_prefix) {
  let v_k = null, v___r15 = null, v___w16 = null, v_lhs = null, v_rhs = null, v_name = null, v___k17 = null, v___r18 = null, v___w19 = null, v_ak = null, v___r20 = null, v___w21 = null, v_v = null, v___r22 = null, v___w23 = null, v___r24 = null, v___w25 = null, v___r26 = null, v___w27 = null, v_b = null, v___k28 = null, v___r29 = null, v___w30 = null, v___r31 = null, v___w32 = null, v___r33 = null, v___w34 = null, v_e = null, v_t = null, v___k35 = null, v___r36 = null, v___w37 = null, v___r38 = null, v___w39 = null, v___r40 = null, v___w41 = null, v___k42 = null, v___r43 = null, v___w44 = null, v_callee = null, v_args = null, v_pure = null, v_c = null, v_a = null, v___k45 = null, v___r46 = null, v___w47 = null, v___k48 = null, v___r49 = null, v___w50 = null, v___k51 = null, v___r52 = null, v___w53 = null, v___k54 = null, v___r55 = null, v___w56 = null, v_m = null;
  let _t597 = null, _t598 = null, _t599 = null, _t600 = null, _t601 = null, _t602 = null, _t603 = null, _t604 = null, _t605 = null, _t606 = null, _t607 = null, _t608 = null, _t609 = null, _t610 = null, _t611 = null, _t612 = null, _t613 = null, _t614 = null, _t615 = null, _t616 = null, _t617 = null, _t618 = null, _t619 = null, _t620 = null, _t621 = null, _t622 = null, _t623 = null, _t624 = null, _t625 = null, _t626 = null, _t627 = null, _t628 = null, _t629 = null, _t630 = null, _t631 = null, _t632 = null, _t633 = null, _t634 = null, _t635 = null, _t636 = null, _t637 = null, _t638 = null;
  Z.setLine(97);
  (v_k = Z.dup(Z.index(v_n, 0)));
  Z.setLine(98);
  if (Z.truthy(Z.ident(v_k, ":Var"))) {
    Z.setLine(98);
    (v___r15 = ((_t597 = Z.arrNew()), Z.apush(_t597, Z.dup(Z.index(v_n, 2))), Z.apush(_t597, Z.dup(Z.index(v_n, 1))), _t597));
    Z.setLine(98);
    (v___w16 = Z.B.zs_obj_take(v_sc, "reads"));
    Z.setLine(98);
    Z.apush((v___w16 = Z.wr(v___w16)), Z.dup(v___r15));
    Z.setLine(98);
    Z.B.zs_obj_put(v_sc, "reads", v___w16);
    Z.setLine(98);
    return null;
  }
  Z.setLine(99);
  if (Z.truthy(Z.ident(v_k, ":Assign"))) {
    Z.setLine(100);
    (v_lhs = Z.dup(Z.index(v_n, 2)));
    Z.setLine(101);
    (v_rhs = Z.dup(Z.index(v_n, 3)));
    Z.setLine(102);
    if (Z.truthy(Z.ident(Z.index(v_lhs, 0), ":Var"))) {
      Z.setLine(103);
      (v_name = Z.dup(Z.index(v_lhs, 2)));
      Z.setLine(104);
      (v___k17 = Z.dup(v_name));
      Z.setLine(104);
      (v___r18 = true);
      Z.setLine(104);
      (v___w19 = Z.B.zs_obj_take(v_sc, "assigned"));
      Z.setLine(104);
      Z.aset((v___w19 = Z.wr(v___w19)), v___k17, Z.dup(v___r18));
      Z.setLine(104);
      Z.B.zs_obj_put(v_sc, "assigned", v___w19);
      Z.setLine(105);
      (v_ak = f_zs_invoke(Z.dup(v_this), "allocKind", ((_t598 = Z.arrNew()), Z.apush(_t598, Z.dup(v_rhs)), _t598)));
      Z.setLine(106);
      if (Z.truthy(!Z.ident(v_ak, null))) {
        Z.setLine(106);
        (v___r20 = ((_t599 = Z.arrNew()), Z.apush(_t599, Z.dup(v_name)), Z.apush(_t599, Z.dup(v_ak)), Z.apush(_t599, Z.dup(Z.index(v_n, 1))), _t599));
        Z.setLine(106);
        (v___w21 = Z.B.zs_obj_take(v_sc, "sites"));
        Z.setLine(106);
        Z.apush((v___w21 = Z.wr(v___w21)), Z.dup(v___r20));
        Z.setLine(106);
        Z.B.zs_obj_put(v_sc, "sites", v___w21);
      }
      Z.setLine(107);
      {
        const _it48 = Z.foreachArr(f_zs_invoke(Z.dup(v_this), "valueVars", ((_t600 = Z.arrNew()), Z.apush(_t600, Z.dup(v_rhs)), _t600)));
        L48: for (let _i48 = 0; _i48 < _it48.keys.length; _i48++) {
          v_v = _it48.vals[_i48];
          Z.setLine(108);
          if (Z.truthy(Z.ident(Z.index(v_rhs, 0), ":Var"))) {
            Z.setLine(108);
            (v___r22 = ((_t601 = Z.arrNew()), Z.apush(_t601, Z.dup(v_v)), Z.apush(_t601, Z.dup(v_name)), _t601));
            Z.setLine(108);
            (v___w23 = Z.B.zs_obj_take(v_sc, "edges"));
            Z.setLine(108);
            Z.apush((v___w23 = Z.wr(v___w23)), Z.dup(v___r22));
            Z.setLine(108);
            Z.B.zs_obj_put(v_sc, "edges", v___w23);
            Z.setLine(108);
            (v___r24 = ((_t602 = Z.arrNew()), Z.apush(_t602, Z.dup(v_name)), Z.apush(_t602, Z.dup(v_v)), _t602));
            Z.setLine(108);
            (v___w25 = Z.B.zs_obj_take(v_sc, "edges"));
            Z.setLine(108);
            Z.apush((v___w25 = Z.wr(v___w25)), Z.dup(v___r24));
            Z.setLine(108);
            Z.B.zs_obj_put(v_sc, "edges", v___w25);
          } else {
            Z.setLine(109);
            (v___r26 = ((_t603 = Z.arrNew()), Z.apush(_t603, Z.dup(v_v)), Z.apush(_t603, Z.dup(v_name)), _t603));
            Z.setLine(109);
            (v___w27 = Z.B.zs_obj_take(v_sc, "edges"));
            Z.setLine(109);
            Z.apush((v___w27 = Z.wr(v___w27)), Z.dup(v___r26));
            Z.setLine(109);
            Z.B.zs_obj_put(v_sc, "edges", v___w27);
          }
        }
      }
    } else {
      Z.setLine(112);
      (v_b = f_zs_invoke(Z.dup(v_this), "baseVar", ((_t604 = Z.arrNew()), Z.apush(_t604, Z.dup(v_lhs)), _t604)));
      Z.setLine(113);
      if (Z.truthy(!Z.ident(v_b, null))) {
        Z.setLine(114);
        if (Z.truthy(Z.ident(Z.index(v_lhs, 0), ":Index"))) {
          Z.setLine(114);
          (v___k28 = Z.dup(v_b));
          Z.setLine(114);
          (v___r29 = true);
          Z.setLine(114);
          (v___w30 = Z.B.zs_obj_take(v_sc, "assigned"));
          Z.setLine(114);
          Z.aset((v___w30 = Z.wr(v___w30)), v___k28, Z.dup(v___r29));
          Z.setLine(114);
          Z.B.zs_obj_put(v_sc, "assigned", v___w30);
        } else {
          Z.setLine(115);
          (v___r31 = ((_t605 = Z.arrNew()), Z.apush(_t605, Z.dup(v_b)), Z.apush(_t605, Z.dup(Z.index(v_n, 1))), _t605));
          Z.setLine(115);
          (v___w32 = Z.B.zs_obj_take(v_sc, "reads"));
          Z.setLine(115);
          Z.apush((v___w32 = Z.wr(v___w32)), Z.dup(v___r31));
          Z.setLine(115);
          Z.B.zs_obj_put(v_sc, "reads", v___w32);
        }
        Z.setLine(116);
        {
          const _it49 = Z.foreachArr(f_zs_invoke(Z.dup(v_this), "valueVars", ((_t606 = Z.arrNew()), Z.apush(_t606, Z.dup(v_rhs)), _t606)));
          L49: for (let _i49 = 0; _i49 < _it49.keys.length; _i49++) {
            v_v = _it49.vals[_i49];
            Z.setLine(116);
            (v___r33 = ((_t607 = Z.arrNew()), Z.apush(_t607, Z.dup(v_v)), Z.apush(_t607, Z.dup(v_b)), _t607));
            Z.setLine(116);
            (v___w34 = Z.B.zs_obj_take(v_sc, "edges"));
            Z.setLine(116);
            Z.apush((v___w34 = Z.wr(v___w34)), Z.dup(v___r33));
            Z.setLine(116);
            Z.B.zs_obj_put(v_sc, "edges", v___w34);
          }
        }
      }
      Z.setLine(119);
      (v_e = Z.dup(v_lhs));
      L50: while (true) {
        Z.setLine(120);
        if (!Z.truthy((Z.truthy(Z.ident(Z.index(v_e, 0), ":Index")) || Z.truthy(Z.ident(Z.index(v_e, 0), ":Prop"))))) break;
        Z.setLine(121);
        if (Z.truthy((Z.truthy(Z.ident(Z.index(v_e, 0), ":Index")) && Z.truthy(!Z.ident(Z.index(v_e, 3), null))))) {
          Z.setLine(121);
          f_zs_invoke(Z.dup(v_this), "visit", ((_t608 = Z.arrNew()), Z.apush(_t608, Z.dup(Z.index(v_e, 3))), Z.apush(_t608, Z.dup(v_sc)), Z.apush(_t608, Z.dup(v_prefix)), _t608));
        }
        Z.setLine(122);
        (v_e = Z.dup(Z.index(v_e, 2)));
      }
      Z.setLine(124);
      if (Z.truthy(!Z.ident(Z.index(v_e, 0), ":Var"))) {
        Z.setLine(124);
        f_zs_invoke(Z.dup(v_this), "visit", ((_t609 = Z.arrNew()), Z.apush(_t609, Z.dup(v_e)), Z.apush(_t609, Z.dup(v_sc)), Z.apush(_t609, Z.dup(v_prefix)), _t609));
      }
    }
    Z.setLine(126);
    f_zs_invoke(Z.dup(v_this), "visit", ((_t610 = Z.arrNew()), Z.apush(_t610, Z.dup(v_rhs)), Z.apush(_t610, Z.dup(v_sc)), Z.apush(_t610, Z.dup(v_prefix)), _t610));
    Z.setLine(127);
    return null;
  }
  Z.setLine(129);
  if (Z.truthy((Z.truthy(Z.ident(v_k, ":AssignOp")) || Z.truthy(Z.ident(v_k, ":IncDec"))))) {
    Z.setLine(130);
    (v_t = (Z.truthy(Z.ident(v_k, ":AssignOp")) ? Z.index(v_n, 3) : Z.index(v_n, 2)));
    Z.setLine(131);
    (v_b = f_zs_invoke(Z.dup(v_this), "baseVar", ((_t611 = Z.arrNew()), Z.apush(_t611, Z.dup(v_t)), _t611)));
    Z.setLine(132);
    if (Z.truthy(!Z.ident(v_b, null))) {
      Z.setLine(132);
      (v___k35 = Z.dup(v_b));
      Z.setLine(132);
      (v___r36 = true);
      Z.setLine(132);
      (v___w37 = Z.B.zs_obj_take(v_sc, "assigned"));
      Z.setLine(132);
      Z.aset((v___w37 = Z.wr(v___w37)), v___k35, Z.dup(v___r36));
      Z.setLine(132);
      Z.B.zs_obj_put(v_sc, "assigned", v___w37);
      Z.setLine(132);
      (v___r38 = ((_t612 = Z.arrNew()), Z.apush(_t612, Z.dup(v_b)), Z.apush(_t612, Z.dup(Z.index(v_n, 1))), _t612));
      Z.setLine(132);
      (v___w39 = Z.B.zs_obj_take(v_sc, "reads"));
      Z.setLine(132);
      Z.apush((v___w39 = Z.wr(v___w39)), Z.dup(v___r38));
      Z.setLine(132);
      Z.B.zs_obj_put(v_sc, "reads", v___w39);
    }
    Z.setLine(133);
    if (Z.truthy(Z.ident(v_k, ":AssignOp"))) {
      Z.setLine(133);
      f_zs_invoke(Z.dup(v_this), "visit", ((_t613 = Z.arrNew()), Z.apush(_t613, Z.dup(Z.index(v_n, 4))), Z.apush(_t613, Z.dup(v_sc)), Z.apush(_t613, Z.dup(v_prefix)), _t613));
    }
    Z.setLine(134);
    return null;
  }
  Z.setLine(136);
  if (Z.truthy(Z.ident(v_k, ":Return"))) {
    Z.setLine(137);
    if (Z.truthy(!Z.ident(Z.index(v_n, 2), null))) {
      Z.setLine(138);
      (v_ak = f_zs_invoke(Z.dup(v_this), "allocKind", ((_t614 = Z.arrNew()), Z.apush(_t614, Z.dup(Z.index(v_n, 2))), _t614)));
      Z.setLine(139);
      if (Z.truthy(!Z.ident(v_ak, null))) {
        Z.setLine(139);
        (v___r40 = ((_t615 = Z.arrNew()), Z.apush(_t615, "<return>"), Z.apush(_t615, Z.dup(v_ak)), Z.apush(_t615, Z.dup(Z.index(v_n, 1))), _t615));
        Z.setLine(139);
        (v___w41 = Z.B.zs_obj_take(v_sc, "sites"));
        Z.setLine(139);
        Z.apush((v___w41 = Z.wr(v___w41)), Z.dup(v___r40));
        Z.setLine(139);
        Z.B.zs_obj_put(v_sc, "sites", v___w41);
        Z.setLine(139);
        (v___k42 = "<return>");
        Z.setLine(139);
        (v___r43 = 1);
        Z.setLine(139);
        (v___w44 = Z.B.zs_obj_take(v_sc, "level"));
        Z.setLine(139);
        Z.aset((v___w44 = Z.wr(v___w44)), v___k42, Z.dup(v___r43));
        Z.setLine(139);
        Z.B.zs_obj_put(v_sc, "level", v___w44);
      }
      Z.setLine(140);
      {
        const _it51 = Z.foreachArr(f_zs_invoke(Z.dup(v_this), "valueVars", ((_t616 = Z.arrNew()), Z.apush(_t616, Z.dup(Z.index(v_n, 2))), _t616)));
        L51: for (let _i51 = 0; _i51 < _it51.keys.length; _i51++) {
          v_v = _it51.vals[_i51];
          Z.setLine(140);
          f_zs_invoke(Z.dup(v_sc), "raise", ((_t617 = Z.arrNew()), Z.apush(_t617, Z.dup(v_v)), Z.apush(_t617, 1), _t617));
        }
      }
      Z.setLine(141);
      f_zs_invoke(Z.dup(v_this), "visit", ((_t618 = Z.arrNew()), Z.apush(_t618, Z.dup(Z.index(v_n, 2))), Z.apush(_t618, Z.dup(v_sc)), Z.apush(_t618, Z.dup(v_prefix)), _t618));
    }
    Z.setLine(143);
    return null;
  }
  Z.setLine(145);
  if (Z.truthy(Z.ident(v_k, ":Throw"))) {
    Z.setLine(146);
    {
      const _it52 = Z.foreachArr(f_zs_invoke(Z.dup(v_this), "valueVars", ((_t619 = Z.arrNew()), Z.apush(_t619, Z.dup(Z.index(v_n, 2))), _t619)));
      L52: for (let _i52 = 0; _i52 < _it52.keys.length; _i52++) {
        v_v = _it52.vals[_i52];
        Z.setLine(146);
        f_zs_invoke(Z.dup(v_sc), "raise", ((_t620 = Z.arrNew()), Z.apush(_t620, Z.dup(v_v)), Z.apush(_t620, 2), _t620));
      }
    }
    Z.setLine(147);
    f_zs_invoke(Z.dup(v_this), "visit", ((_t621 = Z.arrNew()), Z.apush(_t621, Z.dup(Z.index(v_n, 2))), Z.apush(_t621, Z.dup(v_sc)), Z.apush(_t621, Z.dup(v_prefix)), _t621));
    Z.setLine(148);
    return null;
  }
  Z.setLine(150);
  if (Z.truthy((Z.truthy(Z.ident(v_k, ":Call")) || Z.truthy(Z.ident(v_k, ":New"))))) {
    Z.setLine(151);
    (v_callee = (Z.truthy(Z.ident(v_k, ":Call")) ? Z.index(v_n, 2) : null));
    Z.setLine(152);
    (v_args = (Z.truthy(Z.ident(v_k, ":Call")) ? Z.index(v_n, 3) : Z.index(v_n, 3)));
    Z.setLine(153);
    (v_pure = false);
    Z.setLine(154);
    if (Z.truthy((Z.truthy(!Z.ident(v_callee, null)) && Z.truthy(Z.ident(Z.index(v_callee, 0), ":Name"))))) {
      Z.setLine(154);
      (v_pure = Z.B.has_key(((_t622 = Z.arrNew()), Z.aset(_t622, "necho", true), Z.aset(_t622, "eecho", true), Z.aset(_t622, "count", true), Z.aset(_t622, "strlen", true), Z.aset(_t622, "has_key", true), Z.aset(_t622, "keys", true), Z.aset(_t622, "join", true), Z.aset(_t622, "in_array", true), Z.aset(_t622, "index_of", true), Z.aset(_t622, "starts_with", true), Z.aset(_t622, "ends_with", true), Z.aset(_t622, "trim", true), Z.aset(_t622, "substr", true), Z.aset(_t622, "intval", true), Z.aset(_t622, "typeof", true), Z.aset(_t622, "is_int", true), Z.aset(_t622, "is_float", true), Z.aset(_t622, "is_string", true), Z.aset(_t622, "is_bool", true), Z.aset(_t622, "is_array", true), Z.aset(_t622, "is_null", true), Z.aset(_t622, "is_object", true), Z.aset(_t622, "is_callable", true), Z.aset(_t622, "replace", true), Z.aset(_t622, "pad_left", true), Z.aset(_t622, "pad_right", true), Z.aset(_t622, "ord", true), Z.aset(_t622, "chr", true), Z.aset(_t622, "floatval", true), _t622), Z.index(v_callee, 2)));
    }
    Z.setLine(155);
    if (Z.truthy(!Z.ident(v_callee, null))) {
      Z.setLine(156);
      if (Z.truthy(Z.ident(Z.index(v_callee, 0), ":Name"))) {
      } else {
        Z.setLine(157);
        if (Z.truthy(Z.ident(Z.index(v_callee, 0), ":Dot"))) {
          Z.setLine(157);
          (v_c = Z.dup(v_callee));
          L53: while (true) {
            Z.setLine(157);
            if (!Z.truthy(Z.ident(Z.index(v_c, 0), ":Dot"))) break;
            Z.setLine(157);
            (v_c = Z.dup(Z.index(v_c, 2)));
          }
          Z.setLine(157);
          if (Z.truthy(!Z.ident(Z.index(v_c, 0), ":Name"))) {
            Z.setLine(157);
            f_zs_invoke(Z.dup(v_this), "visit", ((_t623 = Z.arrNew()), Z.apush(_t623, Z.dup(v_c)), Z.apush(_t623, Z.dup(v_sc)), Z.apush(_t623, Z.dup(v_prefix)), _t623));
          }
        } else {
          Z.setLine(158);
          f_zs_invoke(Z.dup(v_this), "visit", ((_t624 = Z.arrNew()), Z.apush(_t624, Z.dup(v_callee)), Z.apush(_t624, Z.dup(v_sc)), Z.apush(_t624, Z.dup(v_prefix)), _t624));
        }
      }
    }
    Z.setLine(160);
    {
      const _it54 = Z.foreachArr(Z.dup(v_args));
      L54: for (let _i54 = 0; _i54 < _it54.keys.length; _i54++) {
        v_a = _it54.vals[_i54];
        Z.setLine(161);
        if (Z.truthy(!Z.truthy(v_pure))) {
          Z.setLine(161);
          {
            const _it55 = Z.foreachArr(f_zs_invoke(Z.dup(v_this), "valueVars", ((_t625 = Z.arrNew()), Z.apush(_t625, Z.dup(Z.index(v_a, 3))), _t625)));
            L55: for (let _i55 = 0; _i55 < _it55.keys.length; _i55++) {
              v_v = _it55.vals[_i55];
              Z.setLine(161);
              f_zs_invoke(Z.dup(v_sc), "raise", ((_t626 = Z.arrNew()), Z.apush(_t626, Z.dup(v_v)), Z.apush(_t626, 2), _t626));
            }
          }
        }
        Z.setLine(162);
        f_zs_invoke(Z.dup(v_this), "visit", ((_t627 = Z.arrNew()), Z.apush(_t627, Z.dup(Z.index(v_a, 3))), Z.apush(_t627, Z.dup(v_sc)), Z.apush(_t627, Z.dup(v_prefix)), _t627));
      }
    }
    Z.setLine(164);
    return null;
  }
  Z.setLine(166);
  if (Z.truthy(Z.ident(v_k, ":Foreach"))) {
    Z.setLine(167);
    f_zs_invoke(Z.dup(v_this), "visit", ((_t628 = Z.arrNew()), Z.apush(_t628, Z.dup(Z.index(v_n, 2))), Z.apush(_t628, Z.dup(v_sc)), Z.apush(_t628, Z.dup(v_prefix)), _t628));
    Z.setLine(168);
    if (Z.truthy(!Z.ident(Z.index(v_n, 3), null))) {
      Z.setLine(168);
      (v___k45 = Z.dup(Z.index(v_n, 3)));
      Z.setLine(168);
      (v___r46 = true);
      Z.setLine(168);
      (v___w47 = Z.B.zs_obj_take(v_sc, "assigned"));
      Z.setLine(168);
      Z.aset((v___w47 = Z.wr(v___w47)), v___k45, Z.dup(v___r46));
      Z.setLine(168);
      Z.B.zs_obj_put(v_sc, "assigned", v___w47);
    }
    Z.setLine(169);
    (v___k48 = Z.dup(Z.index(v_n, 4)));
    Z.setLine(169);
    (v___r49 = true);
    Z.setLine(169);
    (v___w50 = Z.B.zs_obj_take(v_sc, "assigned"));
    Z.setLine(169);
    Z.aset((v___w50 = Z.wr(v___w50)), v___k48, Z.dup(v___r49));
    Z.setLine(169);
    Z.B.zs_obj_put(v_sc, "assigned", v___w50);
    Z.setLine(170);
    f_zs_invoke(Z.dup(v_this), "visitAny", ((_t629 = Z.arrNew()), Z.apush(_t629, Z.dup(Z.index(v_n, 5))), Z.apush(_t629, Z.dup(v_sc)), Z.apush(_t629, Z.dup(v_prefix)), _t629));
    Z.setLine(171);
    return null;
  }
  Z.setLine(173);
  if (Z.truthy(Z.ident(v_k, ":Try"))) {
    Z.setLine(174);
    f_zs_invoke(Z.dup(v_this), "visitAny", ((_t630 = Z.arrNew()), Z.apush(_t630, Z.dup(Z.index(v_n, 2))), Z.apush(_t630, Z.dup(v_sc)), Z.apush(_t630, Z.dup(v_prefix)), _t630));
    Z.setLine(175);
    {
      const _it56 = Z.foreachArr(Z.dup(Z.index(v_n, 3)));
      L56: for (let _i56 = 0; _i56 < _it56.keys.length; _i56++) {
        v_c = _it56.vals[_i56];
        Z.setLine(176);
        if (Z.truthy(!Z.ident(Z.index(v_c, 3), null))) {
          Z.setLine(176);
          (v___k51 = Z.dup(Z.index(v_c, 3)));
          Z.setLine(176);
          (v___r52 = true);
          Z.setLine(176);
          (v___w53 = Z.B.zs_obj_take(v_sc, "assigned"));
          Z.setLine(176);
          Z.aset((v___w53 = Z.wr(v___w53)), v___k51, Z.dup(v___r52));
          Z.setLine(176);
          Z.B.zs_obj_put(v_sc, "assigned", v___w53);
        }
        Z.setLine(177);
        f_zs_invoke(Z.dup(v_this), "visitAny", ((_t631 = Z.arrNew()), Z.apush(_t631, Z.dup(Z.index(v_c, 4))), Z.apush(_t631, Z.dup(v_sc)), Z.apush(_t631, Z.dup(v_prefix)), _t631));
      }
    }
    Z.setLine(179);
    if (Z.truthy(!Z.ident(Z.index(v_n, 4), null))) {
      Z.setLine(179);
      f_zs_invoke(Z.dup(v_this), "visitAny", ((_t632 = Z.arrNew()), Z.apush(_t632, Z.dup(Z.index(v_n, 4))), Z.apush(_t632, Z.dup(v_sc)), Z.apush(_t632, Z.dup(v_prefix)), _t632));
    }
    Z.setLine(180);
    return null;
  }
  Z.setLine(182);
  if (Z.truthy(Z.ident(v_k, ":Using"))) {
    Z.setLine(183);
    f_zs_invoke(Z.dup(v_this), "visit", ((_t633 = Z.arrNew()), Z.apush(_t633, Z.dup(Z.index(v_n, 2))), Z.apush(_t633, Z.dup(v_sc)), Z.apush(_t633, Z.dup(v_prefix)), _t633));
    Z.setLine(184);
    (v___k54 = Z.dup(Z.index(v_n, 3)));
    Z.setLine(184);
    (v___r55 = true);
    Z.setLine(184);
    (v___w56 = Z.B.zs_obj_take(v_sc, "assigned"));
    Z.setLine(184);
    Z.aset((v___w56 = Z.wr(v___w56)), v___k54, Z.dup(v___r55));
    Z.setLine(184);
    Z.B.zs_obj_put(v_sc, "assigned", v___w56);
    Z.setLine(185);
    f_zs_invoke(Z.dup(v_this), "visitAny", ((_t634 = Z.arrNew()), Z.apush(_t634, Z.dup(Z.index(v_n, 4))), Z.apush(_t634, Z.dup(v_sc)), Z.apush(_t634, Z.dup(v_prefix)), _t634));
    Z.setLine(186);
    return null;
  }
  Z.setLine(188);
  if (Z.truthy(Z.ident(v_k, ":FuncStmt"))) {
    Z.setLine(188);
    f_zs_invoke(Z.dup(v_this), "fnScope", ((_t635 = Z.arrNew()), Z.apush(_t635, Z.dup(Z.index(v_n, 2))), Z.apush(_t635, Z.dup(v_prefix)), Z.apush(_t635, false), Z.apush(_t635, null), _t635));
    Z.setLine(188);
    return null;
  }
  Z.setLine(189);
  if (Z.truthy(Z.ident(v_k, ":Closure"))) {
    Z.setLine(189);
    f_zs_invoke(Z.dup(v_this), "fnScope", ((_t636 = Z.arrNew()), Z.apush(_t636, Z.dup(Z.index(v_n, 2))), Z.apush(_t636, Z.dup(v_prefix)), Z.apush(_t636, true), Z.apush(_t636, Z.dup(v_sc)), _t636));
    Z.setLine(189);
    return null;
  }
  Z.setLine(190);
  if (Z.truthy(Z.ident(v_k, ":ClassStmt"))) {
    Z.setLine(191);
    (v_c = Z.dup(Z.index(v_n, 2)));
    Z.setLine(192);
    {
      const _it57 = Z.foreachArr(Z.dup(Z.index(v_c, 9)));
      L57: for (let _i57 = 0; _i57 < _it57.keys.length; _i57++) {
        v_m = _it57.vals[_i57];
        Z.setLine(192);
        f_zs_invoke(Z.dup(v_this), "fnScope", ((_t637 = Z.arrNew()), Z.apush(_t637, Z.dup(Z.index(v_m, 2))), Z.apush(_t637, Z.dup(Z.index(v_c, 2))), Z.apush(_t637, false), Z.apush(_t637, null), _t637));
      }
    }
    Z.setLine(193);
    return null;
  }
  Z.setLine(195);
  f_zs_invoke(Z.dup(v_this), "visitChildren", ((_t638 = Z.arrNew()), Z.apush(_t638, Z.dup(v_n)), Z.apush(_t638, Z.dup(v_sc)), Z.apush(_t638, Z.dup(v_prefix)), _t638));
  return null;
}
function f_Analyzer__fnScope(v_this, v_decl, v_prefix, v_isClosure, v_parent) {
  let v_name = null, v_label = null, v_sc = null, v_p = null, v___k57 = null, v___r58 = null, v___w59 = null, v___k60 = null, v___r61 = null, v___w62 = null, v_free = null, v_r = null, v___r63 = null, v___w64 = null;
  let _t639 = null, _t640 = null, _t641 = null, _t642 = null, _t643 = null, _t644 = null;
  Z.setLine(200);
  (v_name = Z.dup(Z.index(v_decl, 2)));
  Z.setLine(201);
  (v_label = (Z.truthy(v_isClosure) ? "{closure}" : (Z.truthy((Z.truthy(!Z.ident(v_prefix, "")) && Z.truthy(!Z.ident(v_name, null)))) ? Z.concat(Z.concat(v_prefix, "."), v_name) : (((_t639 = v_name) !== null) ? _t639 : "{anon}"))));
  Z.setLine(202);
  (v_sc = f_SemaScope__new(Z.dup(v_label), Z.dup(Z.index(v_decl, 1)), Z.dup(v_isClosure)));
  Z.setLine(203);
  {
    const _it58 = Z.foreachArr(Z.dup(Z.index(v_decl, 3)));
    L58: for (let _i58 = 0; _i58 < _it58.keys.length; _i58++) {
      v_p = _it58.vals[_i58];
      Z.setLine(203);
      (v___k57 = Z.dup(Z.index(v_p, 2)));
      Z.setLine(203);
      (v___r58 = true);
      Z.setLine(203);
      (v___w59 = Z.B.zs_obj_take(v_sc, "assigned"));
      Z.setLine(203);
      Z.aset((v___w59 = Z.wr(v___w59)), v___k57, Z.dup(v___r58));
      Z.setLine(203);
      Z.B.zs_obj_put(v_sc, "assigned", v___w59);
    }
  }
  Z.setLine(204);
  (v___k60 = "this");
  Z.setLine(204);
  (v___r61 = true);
  Z.setLine(204);
  (v___w62 = Z.B.zs_obj_take(v_sc, "assigned"));
  Z.setLine(204);
  Z.aset((v___w62 = Z.wr(v___w62)), v___k60, Z.dup(v___r61));
  Z.setLine(204);
  Z.B.zs_obj_put(v_sc, "assigned", v___w62);
  Z.setLine(205);
  f_zs_invoke(Z.dup(v_this), "visitAny", ((_t640 = Z.arrNew()), Z.apush(_t640, Z.dup(Z.index(v_decl, 5))), Z.apush(_t640, Z.dup(v_sc)), Z.apush(_t640, Z.dup(v_prefix)), _t640));
  Z.setLine(206);
  if (Z.truthy(v_isClosure)) {
    Z.setLine(207);
    (v_free = ((_t641 = Z.arrNew()), _t641));
    Z.setLine(208);
    {
      const _it59 = Z.foreachArr(Z.B.zs_obj_get(v_sc, "reads"));
      L59: for (let _i59 = 0; _i59 < _it59.keys.length; _i59++) {
        v_r = _it59.vals[_i59];
        Z.setLine(208);
        if (Z.truthy(!Z.truthy(Z.B.has_key(Z.B.zs_obj_get(v_sc, "assigned"), Z.index(v_r, 0))))) {
          Z.setLine(208);
          Z.apush((v_free = Z.wr(v_free)), Z.dup(v_r));
        }
      }
    }
    Z.setLine(209);
    (v___r63 = ((_t642 = Z.arrNew()), Z.apush(_t642, Z.dup(v_free)), Z.apush(_t642, Z.dup(Z.index(v_decl, 1))), _t642));
    Z.setLine(209);
    (v___w64 = Z.B.zs_obj_take(v_parent, "children"));
    Z.setLine(209);
    Z.apush((v___w64 = Z.wr(v___w64)), Z.dup(v___r63));
    Z.setLine(209);
    Z.B.zs_obj_put(v_parent, "children", v___w64);
    Z.setLine(210);
    f_zs_invoke(Z.dup(v_this), "finish", ((_t643 = Z.arrNew()), Z.apush(_t643, Z.dup(v_sc)), Z.apush(_t643, false), _t643));
  } else {
    Z.setLine(212);
    f_zs_invoke(Z.dup(v_this), "finish", ((_t644 = Z.arrNew()), Z.apush(_t644, Z.dup(v_sc)), Z.apush(_t644, true), _t644));
  }
  return null;
}
function f_Analyzer__resolveChildren(v_this, v_sc) {
  let v_ch = null, v_r = null, v___r65 = null, v___w66 = null, v___r67 = null, v___w68 = null;
  let _t645 = null, _t646 = null;
  Z.setLine(218);
  {
    const _it60 = Z.foreachArr(Z.B.zs_obj_get(v_sc, "children"));
    L60: for (let _i60 = 0; _i60 < _it60.keys.length; _i60++) {
      v_ch = _it60.vals[_i60];
      Z.setLine(219);
      {
        const _it61 = Z.foreachArr(Z.dup(Z.index(v_ch, 0)));
        L61: for (let _i61 = 0; _i61 < _it61.keys.length; _i61++) {
          v_r = _it61.vals[_i61];
          Z.setLine(220);
          if (Z.truthy(Z.B.has_key(Z.B.zs_obj_get(v_sc, "assigned"), Z.index(v_r, 0)))) {
            Z.setLine(220);
            f_zs_invoke(Z.dup(v_sc), "raise", ((_t645 = Z.arrNew()), Z.apush(_t645, Z.dup(Z.index(v_r, 0))), Z.apush(_t645, 2), _t645));
          } else {
            Z.setLine(221);
            if (Z.truthy(Z.B.zs_obj_get(v_sc, "isClosure"))) {
              Z.setLine(221);
              (v___r65 = Z.dup(v_r));
              Z.setLine(221);
              (v___w66 = Z.B.zs_obj_take(v_sc, "reads"));
              Z.setLine(221);
              Z.apush((v___w66 = Z.wr(v___w66)), Z.dup(v___r65));
              Z.setLine(221);
              Z.B.zs_obj_put(v_sc, "reads", v___w66);
            } else {
              Z.setLine(222);
              (v___r67 = ((_t646 = Z.arrNew()), Z.apush(_t646, Z.dup(Z.index(v_r, 1))), Z.apush(_t646, Z.concat(Z.concat("zmienna $", Z.index(v_r, 0)), " w domknięciu nie jest przypisana w otaczającej funkcji")), _t646));
              Z.setLine(222);
              (v___w68 = Z.B.zs_obj_take(v_this, "warnings"));
              Z.setLine(222);
              Z.apush((v___w68 = Z.wr(v___w68)), Z.dup(v___r67));
              Z.setLine(222);
              Z.B.zs_obj_put(v_this, "warnings", v___w68);
            }
          }
        }
      }
    }
  }
  return null;
}
function f_Analyzer__finish(v_this, v_sc, v_report) {
  let v_r = null, v___r69 = null, v___w70 = null, v_changed = null, v_guard = null, v_e = null, v_a = null, v_b = null, v___k71 = null, v___r72 = null, v___w73 = null, v_sites = null, v_s = null, v_lv = null, v___r74 = null, v___w75 = null;
  let _t647 = null, _t648 = null, _t649 = null, _t650 = null, _t651 = null, _t652 = null, _t653 = null, _t654 = null, _t655 = null, _t656 = null, _t657 = null;
  Z.setLine(228);
  f_zs_invoke(Z.dup(v_this), "resolveChildren", ((_t647 = Z.arrNew()), Z.apush(_t647, Z.dup(v_sc)), _t647));
  Z.setLine(229);
  if (Z.truthy(v_report)) {
    Z.setLine(230);
    {
      const _it62 = Z.foreachArr(Z.B.zs_obj_get(v_sc, "reads"));
      L62: for (let _i62 = 0; _i62 < _it62.keys.length; _i62++) {
        v_r = _it62.vals[_i62];
        Z.setLine(231);
        if (Z.truthy(!Z.truthy(Z.B.has_key(Z.B.zs_obj_get(v_sc, "assigned"), Z.index(v_r, 0))))) {
          Z.setLine(232);
          (v___r69 = ((_t648 = Z.arrNew()), Z.apush(_t648, Z.dup(Z.index(v_r, 1))), Z.apush(_t648, Z.concat(Z.concat(Z.concat("zmienna $", Z.index(v_r, 0)), " jest czytana, ale nigdy nie przypisana w "), Z.B.zs_obj_get(v_sc, "name"))), _t648));
          Z.setLine(232);
          (v___w70 = Z.B.zs_obj_take(v_this, "warnings"));
          Z.setLine(232);
          Z.apush((v___w70 = Z.wr(v___w70)), Z.dup(v___r69));
          Z.setLine(232);
          Z.B.zs_obj_put(v_this, "warnings", v___w70);
        }
      }
    }
  }
  Z.setLine(237);
  (v_changed = true);
  Z.setLine(238);
  (v_guard = 0);
  L63: while (true) {
    Z.setLine(239);
    if (!Z.truthy((Z.truthy(v_changed) && Z.truthy((Z.cmp(v_guard, 64) < 0))))) break;
    Z.setLine(240);
    (v_changed = false);
    Z.setLine(241);
    ((_t649 = v_guard), (v_guard = Z.add(_t649, 1)), _t649);
    Z.setLine(242);
    {
      const _it64 = Z.foreachArr(Z.B.zs_obj_get(v_sc, "edges"));
      L64: for (let _i64 = 0; _i64 < _it64.keys.length; _i64++) {
        v_e = _it64.vals[_i64];
        Z.setLine(243);
        (v_a = (((_t650 = Z.indexOpt(Z.B.zs_obj_get(v_sc, "level"), Z.index(v_e, 0))) !== null) ? _t650 : 0));
        Z.setLine(244);
        (v_b = (((_t651 = Z.indexOpt(Z.B.zs_obj_get(v_sc, "level"), Z.index(v_e, 1))) !== null) ? _t651 : 0));
        Z.setLine(245);
        if (Z.truthy((Z.cmp(v_b, v_a) > 0))) {
          Z.setLine(245);
          (v___k71 = Z.dup(Z.index(v_e, 0)));
          Z.setLine(245);
          (v___r72 = Z.dup(v_b));
          Z.setLine(245);
          (v___w73 = Z.B.zs_obj_take(v_sc, "level"));
          Z.setLine(245);
          Z.aset((v___w73 = Z.wr(v___w73)), v___k71, Z.dup(v___r72));
          Z.setLine(245);
          Z.B.zs_obj_put(v_sc, "level", v___w73);
          Z.setLine(245);
          (v_changed = true);
        }
      }
    }
  }
  Z.setLine(248);
  (v_sites = ((_t652 = Z.arrNew()), _t652));
  Z.setLine(249);
  {
    const _it65 = Z.foreachArr(Z.B.zs_obj_get(v_sc, "sites"));
    L65: for (let _i65 = 0; _i65 < _it65.keys.length; _i65++) {
      v_s = _it65.vals[_i65];
      Z.setLine(250);
      (v_lv = (((_t653 = Z.indexOpt(Z.B.zs_obj_get(v_sc, "level"), Z.index(v_s, 0))) !== null) ? _t653 : 0));
      Z.setLine(251);
      Z.apush((v_sites = Z.wr(v_sites)), ((_t654 = Z.arrNew()), Z.aset(_t654, "var", Z.dup(Z.index(v_s, 0))), Z.aset(_t654, "kind", Z.dup(Z.index(v_s, 1))), Z.aset(_t654, "line", Z.dup(Z.index(v_s, 2))), Z.aset(_t654, "escape", Z.dup(Z.index(((_t655 = Z.arrNew()), Z.apush(_t655, "No"), Z.apush(_t655, "Caller"), Z.apush(_t655, "Unknown"), _t655), v_lv))), Z.aset(_t654, "zamm", Z.dup(Z.index(((_t656 = Z.arrNew()), Z.apush(_t656, "Frame"), Z.apush(_t656, "Frame + przeniesienie przy return"), Z.apush(_t656, "Persistent"), _t656), v_lv))), _t654));
    }
  }
  Z.setLine(253);
  if (Z.truthy((Z.truthy((Z.cmp(Z.B.count(v_sites), 0) > 0)) || Z.truthy(!Z.truthy(Z.B.zs_obj_get(v_sc, "isClosure")))))) {
    Z.setLine(254);
    (v___r74 = ((_t657 = Z.arrNew()), Z.aset(_t657, "name", Z.B.zs_obj_get(v_sc, "name")), Z.aset(_t657, "line", Z.B.zs_obj_get(v_sc, "line")), Z.aset(_t657, "sites", Z.dup(v_sites)), _t657));
    Z.setLine(254);
    (v___w75 = Z.B.zs_obj_take(v_this, "functions"));
    Z.setLine(254);
    Z.apush((v___w75 = Z.wr(v___w75)), Z.dup(v___r74));
    Z.setLine(254);
    Z.B.zs_obj_put(v_this, "functions", v___w75);
  }
  return null;
}
function f_Analyzer__new() {
  let v___o = null;
  Z.setLine(48);
  (v___o = Z.B.zs_obj_new("Analyzer"));
  Z.setLine(48);
  Z.B.zs_obj_set(v___o, "warnings", null);
  Z.setLine(48);
  Z.B.zs_obj_set(v___o, "functions", null);
  Z.setLine(48);
  f_Analyzer____construct(Z.dup(v___o));
  Z.setLine(48);
  return Z.dup(v___o);
  return null;
}
function f_IrTables__new() {
  let v___o = null;
  Z.setLine(12);
  (v___o = Z.B.zs_obj_new("IrTables"));
  Z.setLine(12);
  return Z.dup(v___o);
  return null;
}
function f_Lowerer____construct(v_this) {
  let _t658 = null, _t659 = null, _t660 = null;
  Z.setLine(50);
  Z.B.zs_obj_set(v_this, "funcs", ((_t658 = Z.arrNew()), _t658));
  Z.setLine(51);
  Z.B.zs_obj_set(v_this, "order", ((_t659 = Z.arrNew()), _t659));
  Z.setLine(52);
  Z.B.zs_obj_set(v_this, "errors", ((_t660 = Z.arrNew()), _t660));
  return null;
}
function f_Lowerer__err(v_this, v_line, v_code, v_msg) {
  let v___r76 = null, v___w77 = null;
  let _t661 = null;
  Z.setLine(55);
  (v___r76 = ((_t661 = Z.arrNew()), Z.apush(_t661, Z.dup(v_line)), Z.apush(_t661, Z.dup(v_code)), Z.apush(_t661, Z.dup(v_msg)), _t661));
  Z.setLine(55);
  (v___w77 = Z.B.zs_obj_take(v_this, "errors"));
  Z.setLine(55);
  Z.apush((v___w77 = Z.wr(v___w77)), Z.dup(v___r76));
  Z.setLine(55);
  Z.B.zs_obj_put(v_this, "errors", v___w77);
  return null;
}
function f_Lowerer__addLocal(v_this, v_locals, v_name) {
  Z.setLine(59);
  if (Z.truthy(!Z.truthy(Z.B.in_array(v_name, v_locals)))) {
    Z.setLine(59);
    Z.apush((v_locals = Z.wr(v_locals)), Z.dup(v_name));
  }
  Z.setLine(60);
  return Z.dup(v_locals);
  return null;
}
function f_Lowerer__collectExpr(v_this, v_e, v_locals) {
  let v_k = null, v_i = null;
  let _t662 = null, _t663 = null, _t664 = null, _t665 = null, _t666 = null;
  Z.setLine(64);
  if (Z.truthy(!Z.truthy(f_Workspace_parser__isNode(Z.dup(v_e))))) {
    Z.setLine(64);
    return Z.dup(v_locals);
  }
  Z.setLine(65);
  (v_k = Z.dup(Z.index(v_e, 0)));
  Z.setLine(66);
  if (Z.truthy(Z.ident(v_k, ":Assign"))) {
    Z.setLine(66);
    (v_locals = f_zs_invoke(Z.dup(v_this), "collectTarget", ((_t662 = Z.arrNew()), Z.apush(_t662, Z.dup(Z.index(v_e, 2))), Z.apush(_t662, Z.dup(v_locals)), _t662)));
  } else {
    Z.setLine(67);
    if (Z.truthy(Z.ident(v_k, ":AssignOp"))) {
      Z.setLine(67);
      (v_locals = f_zs_invoke(Z.dup(v_this), "collectTarget", ((_t663 = Z.arrNew()), Z.apush(_t663, Z.dup(Z.index(v_e, 3))), Z.apush(_t663, Z.dup(v_locals)), _t663)));
    } else {
      Z.setLine(68);
      if (Z.truthy(Z.ident(v_k, ":IncDec"))) {
        Z.setLine(68);
        (v_locals = f_zs_invoke(Z.dup(v_this), "collectTarget", ((_t664 = Z.arrNew()), Z.apush(_t664, Z.dup(Z.index(v_e, 2))), Z.apush(_t664, Z.dup(v_locals)), _t664)));
      }
    }
  }
  Z.setLine(69);
  (v_i = 2);
  L66: for (; Z.truthy((Z.cmp(v_i, Z.B.count(v_e)) < 0)); ((_t665 = v_i), (v_i = Z.add(_t665, 1)), _t665)) {
    Z.setLine(69);
    (v_locals = f_zs_invoke(Z.dup(v_this), "collectAny", ((_t666 = Z.arrNew()), Z.apush(_t666, Z.dup(Z.index(v_e, v_i))), Z.apush(_t666, Z.dup(v_locals)), _t666)));
  }
  Z.setLine(70);
  return Z.dup(v_locals);
  return null;
}
function f_Lowerer__collectTarget(v_this, v_t, v_locals) {
  let _t667 = null;
  L67: while (true) {
    Z.setLine(74);
    if (!Z.truthy((Z.truthy(Z.ident(Z.index(v_t, 0), ":Index")) || Z.truthy(Z.ident(Z.index(v_t, 0), ":Prop"))))) break;
    Z.setLine(74);
    (v_t = Z.dup(Z.index(v_t, 2)));
  }
  Z.setLine(75);
  if (Z.truthy(Z.ident(Z.index(v_t, 0), ":Var"))) {
    Z.setLine(75);
    (v_locals = f_zs_invoke(Z.dup(v_this), "addLocal", ((_t667 = Z.arrNew()), Z.apush(_t667, Z.dup(v_locals)), Z.apush(_t667, Z.dup(Z.index(v_t, 2))), _t667)));
  }
  Z.setLine(76);
  return Z.dup(v_locals);
  return null;
}
function f_Lowerer__collectAny(v_this, v_x, v_locals) {
  let v_y = null;
  let _t668 = null, _t669 = null, _t670 = null, _t671 = null, _t672 = null;
  Z.setLine(80);
  if (Z.truthy(f_Workspace_parser__isNode(Z.dup(v_x)))) {
    Z.setLine(81);
    if (Z.truthy((Z.truthy(Z.ident(Z.index(v_x, 0), ":Catch")) && Z.truthy(!Z.ident(Z.index(v_x, 3), null))))) {
      Z.setLine(81);
      (v_locals = f_zs_invoke(Z.dup(v_this), "addLocal", ((_t668 = Z.arrNew()), Z.apush(_t668, Z.dup(v_locals)), Z.apush(_t668, Z.dup(Z.index(v_x, 3))), _t668)));
    }
    Z.setLine(82);
    if (Z.truthy(Z.ident(Z.index(v_x, 0), ":Foreach"))) {
      Z.setLine(83);
      if (Z.truthy(!Z.ident(Z.index(v_x, 3), null))) {
        Z.setLine(83);
        (v_locals = f_zs_invoke(Z.dup(v_this), "addLocal", ((_t669 = Z.arrNew()), Z.apush(_t669, Z.dup(v_locals)), Z.apush(_t669, Z.dup(Z.index(v_x, 3))), _t669)));
      }
      Z.setLine(84);
      (v_locals = f_zs_invoke(Z.dup(v_this), "addLocal", ((_t670 = Z.arrNew()), Z.apush(_t670, Z.dup(v_locals)), Z.apush(_t670, Z.dup(Z.index(v_x, 4))), _t670)));
    }
    Z.setLine(86);
    return f_zs_invoke(Z.dup(v_this), "collectExpr", ((_t671 = Z.arrNew()), Z.apush(_t671, Z.dup(v_x)), Z.apush(_t671, Z.dup(v_locals)), _t671));
  }
  Z.setLine(88);
  if (Z.truthy(Z.B.is_array(v_x))) {
    Z.setLine(88);
    {
      const _it68 = Z.foreachArr(Z.dup(v_x));
      L68: for (let _i68 = 0; _i68 < _it68.keys.length; _i68++) {
        v_y = _it68.vals[_i68];
        Z.setLine(88);
        (v_locals = f_zs_invoke(Z.dup(v_this), "collectAny", ((_t672 = Z.arrNew()), Z.apush(_t672, Z.dup(v_y)), Z.apush(_t672, Z.dup(v_locals)), _t672)));
      }
    }
  }
  Z.setLine(89);
  return Z.dup(v_locals);
  return null;
}
function f_Lowerer__checkStmts(v_this, v_list, v_depth) {
  let v_s = null;
  let _t673 = null;
  Z.setLine(93);
  {
    const _it69 = Z.foreachArr(Z.dup(v_list));
    L69: for (let _i69 = 0; _i69 < _it69.keys.length; _i69++) {
      v_s = _it69.vals[_i69];
      Z.setLine(93);
      f_zs_invoke(Z.dup(v_this), "checkStmt", ((_t673 = Z.arrNew()), Z.apush(_t673, Z.dup(v_s)), Z.apush(_t673, Z.dup(v_depth)), _t673));
    }
  }
  return null;
}
function f_Lowerer__checkStmt(v_this, v_s, v_depth) {
  let v_k = null, v_line = null, v_e = null, v_c = null, v_t = null, v_x = null;
  let _t674 = null, _t675 = null, _t676 = null, _t677 = null, _t678 = null, _t679 = null, _t680 = null, _t681 = null, _t682 = null, _t683 = null, _t684 = null, _t685 = null, _t686 = null, _t687 = null, _t688 = null, _t689 = null, _t690 = null, _t691 = null, _t692 = null, _t693 = null, _t694 = null, _t695 = null, _t696 = null, _t697 = null, _t698 = null, _t699 = null, _t700 = null, _t701 = null, _t702 = null;
  Z.setLine(96);
  (v_k = Z.dup(Z.index(v_s, 0)));
  Z.setLine(97);
  (v_line = Z.dup(Z.index(v_s, 1)));
  Z.setLine(98);
  if (Z.truthy(Z.ident(v_k, ":Expr"))) {
    Z.setLine(98);
    f_zs_invoke(Z.dup(v_this), "checkExpr", ((_t674 = Z.arrNew()), Z.apush(_t674, Z.dup(Z.index(v_s, 2))), _t674));
  } else {
    Z.setLine(99);
    if (Z.truthy(Z.ident(v_k, ":Echo"))) {
      Z.setLine(99);
      {
        const _it70 = Z.foreachArr(Z.dup(Z.index(v_s, 2)));
        L70: for (let _i70 = 0; _i70 < _it70.keys.length; _i70++) {
          v_e = _it70.vals[_i70];
          Z.setLine(99);
          f_zs_invoke(Z.dup(v_this), "checkExpr", ((_t675 = Z.arrNew()), Z.apush(_t675, Z.dup(v_e)), _t675));
        }
      }
    } else {
      Z.setLine(100);
      if (Z.truthy(Z.ident(v_k, ":Block"))) {
        Z.setLine(100);
        f_zs_invoke(Z.dup(v_this), "checkStmts", ((_t676 = Z.arrNew()), Z.apush(_t676, Z.dup(Z.index(v_s, 2))), Z.apush(_t676, Z.dup(v_depth)), _t676));
      } else {
        Z.setLine(101);
        if (Z.truthy(Z.ident(v_k, ":If"))) {
          Z.setLine(102);
          f_zs_invoke(Z.dup(v_this), "checkExpr", ((_t677 = Z.arrNew()), Z.apush(_t677, Z.dup(Z.index(v_s, 2))), _t677));
          Z.setLine(103);
          f_zs_invoke(Z.dup(v_this), "checkStmts", ((_t678 = Z.arrNew()), Z.apush(_t678, Z.dup(Z.index(v_s, 3))), Z.apush(_t678, Z.dup(v_depth)), _t678));
          Z.setLine(104);
          if (Z.truthy(!Z.ident(Z.index(v_s, 4), null))) {
            Z.setLine(104);
            f_zs_invoke(Z.dup(v_this), "checkStmts", ((_t679 = Z.arrNew()), Z.apush(_t679, Z.dup(Z.index(v_s, 4))), Z.apush(_t679, Z.dup(v_depth)), _t679));
          }
        } else {
          Z.setLine(106);
          if (Z.truthy(Z.ident(v_k, ":While"))) {
            Z.setLine(106);
            f_zs_invoke(Z.dup(v_this), "checkExpr", ((_t680 = Z.arrNew()), Z.apush(_t680, Z.dup(Z.index(v_s, 2))), _t680));
            Z.setLine(106);
            f_zs_invoke(Z.dup(v_this), "checkStmts", ((_t681 = Z.arrNew()), Z.apush(_t681, Z.dup(Z.index(v_s, 3))), Z.apush(_t681, Z.dup(v_depth)), _t681));
          } else {
            Z.setLine(107);
            if (Z.truthy(Z.ident(v_k, ":DoWhile"))) {
              Z.setLine(107);
              f_zs_invoke(Z.dup(v_this), "checkStmts", ((_t682 = Z.arrNew()), Z.apush(_t682, Z.dup(Z.index(v_s, 2))), Z.apush(_t682, Z.dup(v_depth)), _t682));
              Z.setLine(107);
              f_zs_invoke(Z.dup(v_this), "checkExpr", ((_t683 = Z.arrNew()), Z.apush(_t683, Z.dup(Z.index(v_s, 3))), _t683));
            } else {
              Z.setLine(108);
              if (Z.truthy(Z.ident(v_k, ":For"))) {
                Z.setLine(109);
                {
                  const _it71 = Z.foreachArr(Z.dup(Z.index(v_s, 2)));
                  L71: for (let _i71 = 0; _i71 < _it71.keys.length; _i71++) {
                    v_e = _it71.vals[_i71];
                    Z.setLine(109);
                    f_zs_invoke(Z.dup(v_this), "checkExpr", ((_t684 = Z.arrNew()), Z.apush(_t684, Z.dup(v_e)), _t684));
                  }
                }
                Z.setLine(110);
                if (Z.truthy(!Z.ident(Z.index(v_s, 3), null))) {
                  Z.setLine(110);
                  f_zs_invoke(Z.dup(v_this), "checkExpr", ((_t685 = Z.arrNew()), Z.apush(_t685, Z.dup(Z.index(v_s, 3))), _t685));
                }
                Z.setLine(111);
                {
                  const _it72 = Z.foreachArr(Z.dup(Z.index(v_s, 4)));
                  L72: for (let _i72 = 0; _i72 < _it72.keys.length; _i72++) {
                    v_e = _it72.vals[_i72];
                    Z.setLine(111);
                    f_zs_invoke(Z.dup(v_this), "checkExpr", ((_t686 = Z.arrNew()), Z.apush(_t686, Z.dup(v_e)), _t686));
                  }
                }
                Z.setLine(112);
                f_zs_invoke(Z.dup(v_this), "checkStmts", ((_t687 = Z.arrNew()), Z.apush(_t687, Z.dup(Z.index(v_s, 5))), Z.apush(_t687, Z.dup(v_depth)), _t687));
              } else {
                Z.setLine(114);
                if (Z.truthy(Z.ident(v_k, ":Foreach"))) {
                  Z.setLine(114);
                  f_zs_invoke(Z.dup(v_this), "checkExpr", ((_t688 = Z.arrNew()), Z.apush(_t688, Z.dup(Z.index(v_s, 2))), _t688));
                  Z.setLine(114);
                  f_zs_invoke(Z.dup(v_this), "checkStmts", ((_t689 = Z.arrNew()), Z.apush(_t689, Z.dup(Z.index(v_s, 5))), Z.apush(_t689, Z.dup(v_depth)), _t689));
                } else {
                  Z.setLine(115);
                  if (Z.truthy(Z.ident(v_k, ":Switch"))) {
                    Z.setLine(116);
                    f_zs_invoke(Z.dup(v_this), "checkExpr", ((_t690 = Z.arrNew()), Z.apush(_t690, Z.dup(Z.index(v_s, 2))), _t690));
                    Z.setLine(117);
                    {
                      const _it73 = Z.foreachArr(Z.dup(Z.index(v_s, 3)));
                      L73: for (let _i73 = 0; _i73 < _it73.keys.length; _i73++) {
                        v_c = _it73.vals[_i73];
                        Z.setLine(118);
                        if (Z.truthy(!Z.ident(Z.index(v_c, 2), null))) {
                          Z.setLine(118);
                          f_zs_invoke(Z.dup(v_this), "checkExpr", ((_t691 = Z.arrNew()), Z.apush(_t691, Z.dup(Z.index(v_c, 2))), _t691));
                        }
                        Z.setLine(119);
                        f_zs_invoke(Z.dup(v_this), "checkStmts", ((_t692 = Z.arrNew()), Z.apush(_t692, Z.dup(Z.index(v_c, 3))), Z.apush(_t692, Z.dup(v_depth)), _t692));
                      }
                    }
                  } else {
                    Z.setLine(122);
                    if (Z.truthy(Z.ident(v_k, ":Return"))) {
                      Z.setLine(122);
                      if (Z.truthy(!Z.ident(Z.index(v_s, 2), null))) {
                        Z.setLine(122);
                        f_zs_invoke(Z.dup(v_this), "checkExpr", ((_t693 = Z.arrNew()), Z.apush(_t693, Z.dup(Z.index(v_s, 2))), _t693));
                      }
                    } else {
                      Z.setLine(123);
                      if (Z.truthy((Z.truthy(Z.ident(v_k, ":Break")) || Z.truthy(Z.ident(v_k, ":Continue"))))) {
                      } else {
                        Z.setLine(124);
                        if (Z.truthy(Z.ident(v_k, ":Try"))) {
                          Z.setLine(125);
                          f_zs_invoke(Z.dup(v_this), "checkStmts", ((_t694 = Z.arrNew()), Z.apush(_t694, Z.dup(Z.index(v_s, 2))), Z.apush(_t694, Z.dup(v_depth)), _t694));
                          Z.setLine(126);
                          {
                            const _it74 = Z.foreachArr(Z.dup(Z.index(v_s, 3)));
                            L74: for (let _i74 = 0; _i74 < _it74.keys.length; _i74++) {
                              v_c = _it74.vals[_i74];
                              Z.setLine(127);
                              {
                                const _it75 = Z.foreachArr(Z.dup(Z.index(v_c, 2)));
                                L75: for (let _i75 = 0; _i75 < _it75.keys.length; _i75++) {
                                  v_t = _it75.vals[_i75];
                                  Z.setLine(128);
                                  if (Z.truthy(!Z.truthy(Z.B.in_array(v_t, ((_t695 = Z.arrNew()), Z.apush(_t695, "Exception"), Z.apush(_t695, "Error"), Z.apush(_t695, "Throwable"), _t695))))) {
                                    Z.setLine(128);
                                    f_zs_invoke(Z.dup(v_this), "err", ((_t696 = Z.arrNew()), Z.apush(_t696, Z.dup(v_line)), Z.apush(_t696, "E0107"), Z.apush(_t696, Z.concat(Z.concat("klasa wyjątku `", v_t), "` niedostępna w backendzie natywnym 0.0.1 (obsługiwane: Exception, Error, Throwable)")), _t696));
                                  }
                                }
                              }
                              Z.setLine(130);
                              f_zs_invoke(Z.dup(v_this), "checkStmts", ((_t697 = Z.arrNew()), Z.apush(_t697, Z.dup(Z.index(v_c, 4))), Z.apush(_t697, Z.dup(v_depth)), _t697));
                            }
                          }
                          Z.setLine(132);
                          if (Z.truthy(!Z.ident(Z.index(v_s, 4), null))) {
                            Z.setLine(132);
                            f_zs_invoke(Z.dup(v_this), "checkStmts", ((_t698 = Z.arrNew()), Z.apush(_t698, Z.dup(Z.index(v_s, 4))), Z.apush(_t698, Z.dup(v_depth)), _t698));
                          }
                        } else {
                          Z.setLine(134);
                          if (Z.truthy(Z.ident(v_k, ":Throw"))) {
                            Z.setLine(135);
                            (v_x = Z.dup(Z.index(v_s, 2)));
                            Z.setLine(136);
                            if (Z.truthy(Z.ident(Z.index(v_x, 0), ":New"))) {
                              Z.setLine(136);
                              f_zs_invoke(Z.dup(v_this), "checkNew", ((_t699 = Z.arrNew()), Z.apush(_t699, Z.dup(v_x)), _t699));
                            } else {
                              Z.setLine(137);
                              if (Z.truthy(Z.ident(Z.index(v_x, 0), ":Var"))) {
                              } else {
                                Z.setLine(138);
                                f_zs_invoke(Z.dup(v_this), "checkExpr", ((_t700 = Z.arrNew()), Z.apush(_t700, Z.dup(v_x)), _t700));
                              }
                            }
                          } else {
                            Z.setLine(140);
                            if (Z.truthy(Z.ident(v_k, ":FuncStmt"))) {
                              Z.setLine(140);
                              f_zs_invoke(Z.dup(v_this), "err", ((_t701 = Z.arrNew()), Z.apush(_t701, Z.dup(v_line)), Z.apush(_t701, "E0101"), Z.apush(_t701, "funkcje zagnieżdżone nie są obsługiwane (deklaruj funkcje na najwyższym poziomie)"), _t701));
                            } else {
                              Z.setLine(141);
                              f_zs_invoke(Z.dup(v_this), "err", ((_t702 = Z.arrNew()), Z.apush(_t702, Z.dup(v_line)), Z.apush(_t702, "E0101"), Z.apush(_t702, Z.concat(Z.concat("instrukcja ", Z.B.substr(v_k, 1)), " niedostępna w backendzie natywnym 0.0.1")), _t702));
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
  return null;
}
function f_Lowerer__checkNew(v_this, v_x) {
  let v_a = null;
  let _t703 = null, _t704 = null, _t705 = null, _t706 = null;
  Z.setLine(145);
  if (Z.truthy(!Z.truthy(Z.B.in_array(Z.index(v_x, 2), ((_t703 = Z.arrNew()), Z.apush(_t703, "Exception"), Z.apush(_t703, "Error"), _t703))))) {
    Z.setLine(145);
    f_zs_invoke(Z.dup(v_this), "err", ((_t704 = Z.arrNew()), Z.apush(_t704, Z.dup(Z.index(v_x, 1))), Z.apush(_t704, "E0107"), Z.apush(_t704, Z.concat(Z.concat("new ", Z.index(v_x, 2)), ": tylko Exception i Error w backendzie natywnym 0.0.1")), _t704));
  }
  Z.setLine(146);
  if (Z.truthy((Z.cmp(Z.B.count(Z.index(v_x, 3)), 1) > 0))) {
    Z.setLine(146);
    f_zs_invoke(Z.dup(v_this), "err", ((_t705 = Z.arrNew()), Z.apush(_t705, Z.dup(Z.index(v_x, 1))), Z.apush(_t705, "E0104"), Z.apush(_t705, Z.concat(Z.concat("new ", Z.index(v_x, 2)), ": oczekiwano co najwyżej 1 argumentu")), _t705));
  }
  Z.setLine(147);
  {
    const _it76 = Z.foreachArr(Z.dup(Z.index(v_x, 3)));
    L76: for (let _i76 = 0; _i76 < _it76.keys.length; _i76++) {
      v_a = _it76.vals[_i76];
      Z.setLine(147);
      f_zs_invoke(Z.dup(v_this), "checkExpr", ((_t706 = Z.arrNew()), Z.apush(_t706, Z.dup(Z.index(v_a, 3))), _t706));
    }
  }
  return null;
}
function f_Lowerer__containsTry(v_this, v_x) {
  let v_i = null, v_y = null;
  let _t707 = null, _t708 = null, _t709 = null;
  Z.setLine(151);
  if (Z.truthy(f_Workspace_parser__isNode(Z.dup(v_x)))) {
    Z.setLine(152);
    if (Z.truthy(Z.ident(Z.index(v_x, 0), ":Try"))) {
      Z.setLine(152);
      return true;
    }
    Z.setLine(153);
    if (Z.truthy(Z.ident(Z.index(v_x, 0), ":FuncStmt"))) {
      Z.setLine(153);
      return false;
    }
    Z.setLine(154);
    (v_i = 2);
    L77: for (; Z.truthy((Z.cmp(v_i, Z.B.count(v_x)) < 0)); ((_t707 = v_i), (v_i = Z.add(_t707, 1)), _t707)) {
      Z.setLine(154);
      if (Z.truthy(f_zs_invoke(Z.dup(v_this), "containsTry", ((_t708 = Z.arrNew()), Z.apush(_t708, Z.dup(Z.index(v_x, v_i))), _t708)))) {
        Z.setLine(154);
        return true;
      }
    }
    Z.setLine(155);
    return false;
  }
  Z.setLine(157);
  if (Z.truthy(Z.B.is_array(v_x))) {
    Z.setLine(157);
    {
      const _it78 = Z.foreachArr(Z.dup(v_x));
      L78: for (let _i78 = 0; _i78 < _it78.keys.length; _i78++) {
        v_y = _it78.vals[_i78];
        Z.setLine(157);
        if (Z.truthy(f_zs_invoke(Z.dup(v_this), "containsTry", ((_t709 = Z.arrNew()), Z.apush(_t709, Z.dup(v_y)), _t709)))) {
          Z.setLine(157);
          return true;
        }
      }
    }
  }
  Z.setLine(158);
  return false;
  return null;
}
function f_Lowerer__calleeName(v_this, v_c) {
  Z.setLine(162);
  if (Z.truthy(Z.ident(Z.index(v_c, 0), ":Name"))) {
    Z.setLine(162);
    return Z.dup(Z.index(v_c, 2));
  }
  Z.setLine(163);
  return null;
  return null;
}
function f_Lowerer__checkExpr(v_this, v_e) {
  let v_k = null, v_line = null, v_it = null, v_op = null;
  let _t710 = null, _t711 = null, _t712 = null, _t713 = null, _t714 = null, _t715 = null, _t716 = null, _t717 = null, _t718 = null, _t719 = null, _t720 = null, _t721 = null, _t722 = null, _t723 = null, _t724 = null, _t725 = null, _t726 = null, _t727 = null;
  Z.setLine(167);
  if (Z.truthy(!Z.truthy(f_Workspace_parser__isNode(Z.dup(v_e))))) {
    Z.setLine(167);
    return null;
  }
  Z.setLine(168);
  (v_k = Z.dup(Z.index(v_e, 0)));
  Z.setLine(169);
  (v_line = Z.dup(Z.index(v_e, 1)));
  Z.setLine(170);
  if (Z.truthy((Z.truthy((Z.truthy((Z.truthy((Z.truthy((Z.truthy(Z.ident(v_k, ":Null")) || Z.truthy(Z.ident(v_k, ":Bool")))) || Z.truthy(Z.ident(v_k, ":Int")))) || Z.truthy(Z.ident(v_k, ":Float")))) || Z.truthy(Z.ident(v_k, ":Str")))) || Z.truthy(Z.ident(v_k, ":Var"))))) {
    Z.setLine(170);
    return null;
  }
  Z.setLine(171);
  if (Z.truthy(Z.ident(v_k, ":Array"))) {
    Z.setLine(172);
    {
      const _it79 = Z.foreachArr(Z.dup(Z.index(v_e, 2)));
      L79: for (let _i79 = 0; _i79 < _it79.keys.length; _i79++) {
        v_it = _it79.vals[_i79];
        Z.setLine(173);
        if (Z.truthy(!Z.ident(Z.index(v_it, 2), null))) {
          Z.setLine(173);
          f_zs_invoke(Z.dup(v_this), "checkExpr", ((_t710 = Z.arrNew()), Z.apush(_t710, Z.dup(Z.index(v_it, 2))), _t710));
        }
        Z.setLine(174);
        f_zs_invoke(Z.dup(v_this), "checkExpr", ((_t711 = Z.arrNew()), Z.apush(_t711, Z.dup(Z.index(v_it, 3))), _t711));
      }
    }
    Z.setLine(176);
    return null;
  }
  Z.setLine(178);
  if (Z.truthy(Z.ident(v_k, ":Index"))) {
    Z.setLine(179);
    f_zs_invoke(Z.dup(v_this), "checkExpr", ((_t712 = Z.arrNew()), Z.apush(_t712, Z.dup(Z.index(v_e, 2))), _t712));
    Z.setLine(180);
    if (Z.truthy(!Z.ident(Z.index(v_e, 3), null))) {
      Z.setLine(180);
      f_zs_invoke(Z.dup(v_this), "checkExpr", ((_t713 = Z.arrNew()), Z.apush(_t713, Z.dup(Z.index(v_e, 3))), _t713));
    }
    Z.setLine(181);
    return null;
  }
  Z.setLine(183);
  if (Z.truthy(Z.ident(v_k, ":Unary"))) {
    Z.setLine(184);
    f_zs_invoke(Z.dup(v_this), "checkExpr", ((_t714 = Z.arrNew()), Z.apush(_t714, Z.dup(Z.index(v_e, 3))), _t714));
    Z.setLine(185);
    return null;
  }
  Z.setLine(187);
  if (Z.truthy(Z.ident(v_k, ":Binary"))) {
    Z.setLine(188);
    (v_op = Z.dup(Z.index(v_e, 2)));
    Z.setLine(189);
    f_zs_invoke(Z.dup(v_this), "checkExpr", ((_t715 = Z.arrNew()), Z.apush(_t715, Z.dup(Z.index(v_e, 3))), _t715));
    Z.setLine(190);
    f_zs_invoke(Z.dup(v_this), "checkExpr", ((_t716 = Z.arrNew()), Z.apush(_t716, Z.dup(Z.index(v_e, 4))), _t716));
    Z.setLine(191);
    return null;
  }
  Z.setLine(193);
  if (Z.truthy(Z.ident(v_k, ":Assign"))) {
    Z.setLine(193);
    f_zs_invoke(Z.dup(v_this), "checkLvalue", ((_t717 = Z.arrNew()), Z.apush(_t717, Z.dup(Z.index(v_e, 2))), _t717));
    Z.setLine(193);
    f_zs_invoke(Z.dup(v_this), "checkExpr", ((_t718 = Z.arrNew()), Z.apush(_t718, Z.dup(Z.index(v_e, 3))), _t718));
    Z.setLine(193);
    return null;
  }
  Z.setLine(194);
  if (Z.truthy(Z.ident(v_k, ":AssignOp"))) {
    Z.setLine(194);
    f_zs_invoke(Z.dup(v_this), "checkLvalue", ((_t719 = Z.arrNew()), Z.apush(_t719, Z.dup(Z.index(v_e, 3))), _t719));
    Z.setLine(194);
    f_zs_invoke(Z.dup(v_this), "checkExpr", ((_t720 = Z.arrNew()), Z.apush(_t720, Z.dup(Z.index(v_e, 4))), _t720));
    Z.setLine(194);
    return null;
  }
  Z.setLine(195);
  if (Z.truthy(Z.ident(v_k, ":IncDec"))) {
    Z.setLine(195);
    f_zs_invoke(Z.dup(v_this), "checkLvalue", ((_t721 = Z.arrNew()), Z.apush(_t721, Z.dup(Z.index(v_e, 2))), _t721));
    Z.setLine(195);
    return null;
  }
  Z.setLine(196);
  if (Z.truthy(Z.ident(v_k, ":Ternary"))) {
    Z.setLine(197);
    f_zs_invoke(Z.dup(v_this), "checkExpr", ((_t722 = Z.arrNew()), Z.apush(_t722, Z.dup(Z.index(v_e, 2))), _t722));
    Z.setLine(198);
    if (Z.truthy(!Z.ident(Z.index(v_e, 3), null))) {
      Z.setLine(198);
      f_zs_invoke(Z.dup(v_this), "checkExpr", ((_t723 = Z.arrNew()), Z.apush(_t723, Z.dup(Z.index(v_e, 3))), _t723));
    }
    Z.setLine(199);
    f_zs_invoke(Z.dup(v_this), "checkExpr", ((_t724 = Z.arrNew()), Z.apush(_t724, Z.dup(Z.index(v_e, 4))), _t724));
    Z.setLine(200);
    return null;
  }
  Z.setLine(202);
  if (Z.truthy(Z.ident(v_k, ":Call"))) {
    Z.setLine(202);
    f_zs_invoke(Z.dup(v_this), "checkCall", ((_t725 = Z.arrNew()), Z.apush(_t725, Z.dup(v_e)), _t725));
    Z.setLine(202);
    return null;
  }
  Z.setLine(203);
  if (Z.truthy(Z.ident(v_k, ":New"))) {
    Z.setLine(203);
    f_zs_invoke(Z.dup(v_this), "checkNew", ((_t726 = Z.arrNew()), Z.apush(_t726, Z.dup(v_e)), _t726));
    Z.setLine(203);
    return null;
  }
  Z.setLine(204);
  f_zs_invoke(Z.dup(v_this), "err", ((_t727 = Z.arrNew()), Z.apush(_t727, Z.dup(v_line)), Z.apush(_t727, "E0102"), Z.apush(_t727, Z.concat(Z.concat("wyrażenie ", Z.B.substr(v_k, 1)), " niedostępne w backendzie natywnym 0.0.1")), _t727));
  return null;
}
function f_Lowerer__checkLvalue(v_this, v_t) {
  let _t728 = null, _t729 = null, _t730 = null;
  Z.setLine(208);
  if (Z.truthy(Z.ident(Z.index(v_t, 0), ":Var"))) {
    Z.setLine(208);
    return null;
  }
  Z.setLine(209);
  if (Z.truthy(Z.ident(Z.index(v_t, 0), ":Index"))) {
    Z.setLine(209);
    f_zs_invoke(Z.dup(v_this), "checkExpr", ((_t728 = Z.arrNew()), Z.apush(_t728, Z.dup(Z.index(v_t, 2))), _t728));
    Z.setLine(209);
    if (Z.truthy(!Z.ident(Z.index(v_t, 3), null))) {
      Z.setLine(209);
      f_zs_invoke(Z.dup(v_this), "checkExpr", ((_t729 = Z.arrNew()), Z.apush(_t729, Z.dup(Z.index(v_t, 3))), _t729));
    }
    Z.setLine(209);
    return null;
  }
  Z.setLine(210);
  f_zs_invoke(Z.dup(v_this), "err", ((_t730 = Z.arrNew()), Z.apush(_t730, Z.dup(Z.index(v_t, 1))), Z.apush(_t730, "E0102"), Z.apush(_t730, Z.concat(Z.concat("przypisanie do ", Z.B.substr(Z.index(v_t, 0), 1)), " niedostępne w backendzie natywnym 0.0.1")), _t730));
  return null;
}
function f_Lowerer__checkCall(v_this, v_e) {
  let v_line = null, v_callee = null, v_args = null, v_a = null, v_n = null, v_name = null, v_f = null, v_min = null, v_p = null, v_ar = null, v_m = null;
  let _t731 = null, _t732 = null, _t733 = null, _t734 = null, _t735 = null, _t736 = null, _t737 = null, _t738 = null, _t739 = null, _t740 = null, _t741 = null, _t742 = null, _t743 = null, _t744 = null, _t745 = null, _t746 = null, _t747 = null, _t748 = null, _t749 = null, _t750 = null, _t751 = null, _t752 = null, _t753 = null, _t754 = null, _t755 = null, _t756 = null, _t757 = null, _t758 = null, _t759 = null, _t760 = null, _t761 = null, _t762 = null, _t763 = null, _t764 = null, _t765 = null, _t766 = null, _t767 = null, _t768 = null, _t769 = null, _t770 = null, _t771 = null, _t772 = null, _t773 = null, _t774 = null, _t775 = null, _t776 = null, _t777 = null, _t778 = null, _t779 = null, _t780 = null, _t781 = null, _t782 = null, _t783 = null, _t784 = null, _t785 = null, _t786 = null, _t787 = null, _t788 = null, _t789 = null, _t790 = null, _t791 = null, _t792 = null, _t793 = null, _t794 = null, _t795 = null, _t796 = null, _t797 = null, _t798 = null, _t799 = null, _t800 = null, _t801 = null, _t802 = null, _t803 = null, _t804 = null, _t805 = null, _t806 = null, _t807 = null, _t808 = null, _t809 = null, _t810 = null, _t811 = null, _t812 = null, _t813 = null, _t814 = null, _t815 = null, _t816 = null, _t817 = null, _t818 = null, _t819 = null, _t820 = null, _t821 = null, _t822 = null, _t823 = null, _t824 = null, _t825 = null, _t826 = null, _t827 = null, _t828 = null, _t829 = null, _t830 = null, _t831 = null, _t832 = null, _t833 = null, _t834 = null, _t835 = null, _t836 = null, _t837 = null, _t838 = null, _t839 = null, _t840 = null, _t841 = null, _t842 = null, _t843 = null, _t844 = null, _t845 = null, _t846 = null, _t847 = null, _t848 = null, _t849 = null, _t850 = null, _t851 = null, _t852 = null, _t853 = null, _t854 = null, _t855 = null, _t856 = null, _t857 = null, _t858 = null, _t859 = null, _t860 = null, _t861 = null, _t862 = null, _t863 = null, _t864 = null, _t865 = null, _t866 = null, _t867 = null, _t868 = null, _t869 = null, _t870 = null, _t871 = null, _t872 = null, _t873 = null, _t874 = null, _t875 = null, _t876 = null, _t877 = null, _t878 = null, _t879 = null, _t880 = null, _t881 = null, _t882 = null, _t883 = null, _t884 = null, _t885 = null, _t886 = null, _t887 = null, _t888 = null, _t889 = null, _t890 = null, _t891 = null, _t892 = null, _t893 = null, _t894 = null;
  Z.setLine(214);
  (v_line = Z.dup(Z.index(v_e, 1)));
  Z.setLine(215);
  (v_callee = Z.dup(Z.index(v_e, 2)));
  Z.setLine(216);
  (v_args = Z.dup(Z.index(v_e, 3)));
  Z.setLine(217);
  {
    const _it80 = Z.foreachArr(Z.dup(v_args));
    L80: for (let _i80 = 0; _i80 < _it80.keys.length; _i80++) {
      v_a = _it80.vals[_i80];
      Z.setLine(218);
      if (Z.truthy(!Z.ident(Z.index(v_a, 2), null))) {
        Z.setLine(218);
        f_zs_invoke(Z.dup(v_this), "err", ((_t731 = Z.arrNew()), Z.apush(_t731, Z.dup(v_line)), Z.apush(_t731, "E0104"), Z.apush(_t731, "argumenty nazwane niedostępne w backendzie natywnym 0.0.1"), _t731));
      }
      Z.setLine(219);
      if (Z.truthy(Z.index(v_a, 4))) {
        Z.setLine(219);
        f_zs_invoke(Z.dup(v_this), "err", ((_t732 = Z.arrNew()), Z.apush(_t732, Z.dup(v_line)), Z.apush(_t732, "E0104"), Z.apush(_t732, "operator ... (spread) niedostępny w backendzie natywnym 0.0.1"), _t732));
      }
      Z.setLine(220);
      f_zs_invoke(Z.dup(v_this), "checkExpr", ((_t733 = Z.arrNew()), Z.apush(_t733, Z.dup(Z.index(v_a, 3))), _t733));
    }
  }
  Z.setLine(222);
  (v_n = Z.B.count(v_args));
  Z.setLine(223);
  if (Z.truthy(Z.ident(Z.index(v_callee, 0), ":Prop"))) {
    Z.setLine(224);
    if (Z.truthy((Z.truthy(Z.ident(Z.index(v_callee, 3), "getMessage")) && Z.truthy(Z.ident(v_n, 0))))) {
      Z.setLine(224);
      f_zs_invoke(Z.dup(v_this), "checkExpr", ((_t734 = Z.arrNew()), Z.apush(_t734, Z.dup(Z.index(v_callee, 2))), _t734));
      Z.setLine(224);
      return null;
    }
    Z.setLine(225);
    f_zs_invoke(Z.dup(v_this), "err", ((_t735 = Z.arrNew()), Z.apush(_t735, Z.dup(v_line)), Z.apush(_t735, "E0102"), Z.apush(_t735, Z.concat(Z.concat("metoda `", Z.index(v_callee, 3)), "` niedostępna w backendzie natywnym 0.0.1 (obsługiwane: getMessage na wyjątku)")), _t735));
    Z.setLine(226);
    return null;
  }
  Z.setLine(228);
  (v_name = f_zs_invoke(Z.dup(v_this), "calleeName", ((_t736 = Z.arrNew()), Z.apush(_t736, Z.dup(v_callee)), _t736)));
  Z.setLine(229);
  if (Z.truthy(!Z.ident(v_name, null))) {
    Z.setLine(230);
    if (Z.truthy(Z.B.has_key(Z.B.zs_obj_get(v_this, "funcs"), v_name))) {
      Z.setLine(231);
      (v_f = Z.dup(Z.index(Z.B.zs_obj_get(v_this, "funcs"), v_name)));
      Z.setLine(232);
      (v_min = 0);
      Z.setLine(233);
      {
        const _it81 = Z.foreachArr(Z.dup(Z.index(v_f, "params")));
        L81: for (let _i81 = 0; _i81 < _it81.keys.length; _i81++) {
          v_p = _it81.vals[_i81];
          Z.setLine(233);
          if (Z.truthy(Z.ident(Z.index(v_p, 4), null))) {
            Z.setLine(233);
            ((_t737 = v_min), (v_min = Z.add(_t737, 1)), _t737);
          }
        }
      }
      Z.setLine(234);
      if (Z.truthy((Z.truthy((Z.cmp(v_n, v_min) < 0)) || Z.truthy((Z.cmp(v_n, Z.B.count(Z.index(v_f, "params"))) > 0))))) {
        Z.setLine(235);
        f_zs_invoke(Z.dup(v_this), "err", ((_t738 = Z.arrNew()), Z.apush(_t738, Z.dup(v_line)), Z.apush(_t738, "E0104"), Z.apush(_t738, Z.concat(Z.concat(Z.concat(Z.concat(Z.concat("funkcja ", v_name), " oczekuje "), (Z.truthy(Z.ident(v_min, Z.B.count(Z.index(v_f, "params")))) ? v_min : Z.concat(Z.concat(v_min, ".."), Z.B.count(Z.index(v_f, "params"))))), " argumentów, podano "), v_n)), _t738));
      }
    } else {
      Z.setLine(237);
      if (Z.truthy(Z.B.has_key(((_t739 = Z.arrNew()), Z.aset(_t739, "count", ((_t740 = Z.arrNew()), Z.apush(_t740, 1), Z.apush(_t740, 1), _t740)), Z.aset(_t739, "strlen", ((_t741 = Z.arrNew()), Z.apush(_t741, 1), Z.apush(_t741, 1), _t741)), Z.aset(_t739, "typeof", ((_t742 = Z.arrNew()), Z.apush(_t742, 1), Z.apush(_t742, 1), _t742)), Z.aset(_t739, "is_int", ((_t743 = Z.arrNew()), Z.apush(_t743, 1), Z.apush(_t743, 1), _t743)), Z.aset(_t739, "is_float", ((_t744 = Z.arrNew()), Z.apush(_t744, 1), Z.apush(_t744, 1), _t744)), Z.aset(_t739, "is_string", ((_t745 = Z.arrNew()), Z.apush(_t745, 1), Z.apush(_t745, 1), _t745)), Z.aset(_t739, "is_bool", ((_t746 = Z.arrNew()), Z.apush(_t746, 1), Z.apush(_t746, 1), _t746)), Z.aset(_t739, "is_array", ((_t747 = Z.arrNew()), Z.apush(_t747, 1), Z.apush(_t747, 1), _t747)), Z.aset(_t739, "is_null", ((_t748 = Z.arrNew()), Z.apush(_t748, 1), Z.apush(_t748, 1), _t748)), Z.aset(_t739, "strval", ((_t749 = Z.arrNew()), Z.apush(_t749, 1), Z.apush(_t749, 1), _t749)), Z.aset(_t739, "boolval", ((_t750 = Z.arrNew()), Z.apush(_t750, 1), Z.apush(_t750, 1), _t750)), Z.aset(_t739, "intval", ((_t751 = Z.arrNew()), Z.apush(_t751, 1), Z.apush(_t751, 1), _t751)), Z.aset(_t739, "floatval", ((_t752 = Z.arrNew()), Z.apush(_t752, 1), Z.apush(_t752, 1), _t752)), Z.aset(_t739, "ord", ((_t753 = Z.arrNew()), Z.apush(_t753, 1), Z.apush(_t753, 1), _t753)), Z.aset(_t739, "chr", ((_t754 = Z.arrNew()), Z.apush(_t754, 1), Z.apush(_t754, 1), _t754)), Z.aset(_t739, "contains", ((_t755 = Z.arrNew()), Z.apush(_t755, 2), Z.apush(_t755, 2), _t755)), Z.aset(_t739, "starts_with", ((_t756 = Z.arrNew()), Z.apush(_t756, 2), Z.apush(_t756, 2), _t756)), Z.aset(_t739, "ends_with", ((_t757 = Z.arrNew()), Z.apush(_t757, 2), Z.apush(_t757, 2), _t757)), Z.aset(_t739, "index_of", ((_t758 = Z.arrNew()), Z.apush(_t758, 2), Z.apush(_t758, 2), _t758)), Z.aset(_t739, "repeat", ((_t759 = Z.arrNew()), Z.apush(_t759, 2), Z.apush(_t759, 2), _t759)), Z.aset(_t739, "substr", ((_t760 = Z.arrNew()), Z.apush(_t760, 2), Z.apush(_t760, 3), _t760)), Z.aset(_t739, "trim", ((_t761 = Z.arrNew()), Z.apush(_t761, 1), Z.apush(_t761, 1), _t761)), Z.aset(_t739, "join", ((_t762 = Z.arrNew()), Z.apush(_t762, 2), Z.apush(_t762, 2), _t762)), Z.aset(_t739, "in_array", ((_t763 = Z.arrNew()), Z.apush(_t763, 2), Z.apush(_t763, 2), _t763)), Z.aset(_t739, "range", ((_t764 = Z.arrNew()), Z.apush(_t764, 2), Z.apush(_t764, 2), _t764)), Z.aset(_t739, "keys", ((_t765 = Z.arrNew()), Z.apush(_t765, 1), Z.apush(_t765, 1), _t765)), Z.aset(_t739, "values", ((_t766 = Z.arrNew()), Z.apush(_t766, 1), Z.apush(_t766, 1), _t766)), Z.aset(_t739, "has_key", ((_t767 = Z.arrNew()), Z.apush(_t767, 2), Z.apush(_t767, 2), _t767)), Z.aset(_t739, "upper", ((_t768 = Z.arrNew()), Z.apush(_t768, 1), Z.apush(_t768, 1), _t768)), Z.aset(_t739, "lower", ((_t769 = Z.arrNew()), Z.apush(_t769, 1), Z.apush(_t769, 1), _t769)), Z.aset(_t739, "replace", ((_t770 = Z.arrNew()), Z.apush(_t770, 3), Z.apush(_t770, 3), _t770)), Z.aset(_t739, "split", ((_t771 = Z.arrNew()), Z.apush(_t771, 2), Z.apush(_t771, 2), _t771)), Z.aset(_t739, "chars", ((_t772 = Z.arrNew()), Z.apush(_t772, 1), Z.apush(_t772, 1), _t772)), Z.aset(_t739, "pad_left", ((_t773 = Z.arrNew()), Z.apush(_t773, 2), Z.apush(_t773, 3), _t773)), Z.aset(_t739, "pad_right", ((_t774 = Z.arrNew()), Z.apush(_t774, 2), Z.apush(_t774, 3), _t774)), Z.aset(_t739, "to_hex", ((_t775 = Z.arrNew()), Z.apush(_t775, 1), Z.apush(_t775, 1), _t775)), Z.aset(_t739, "is_digit", ((_t776 = Z.arrNew()), Z.apush(_t776, 1), Z.apush(_t776, 1), _t776)), Z.aset(_t739, "is_alpha", ((_t777 = Z.arrNew()), Z.apush(_t777, 1), Z.apush(_t777, 1), _t777)), Z.aset(_t739, "is_alnum", ((_t778 = Z.arrNew()), Z.apush(_t778, 1), Z.apush(_t778, 1), _t778)), Z.aset(_t739, "is_space", ((_t779 = Z.arrNew()), Z.apush(_t779, 1), Z.apush(_t779, 1), _t779)), Z.aset(_t739, "is_hex_digit", ((_t780 = Z.arrNew()), Z.apush(_t780, 1), Z.apush(_t780, 1), _t780)), Z.aset(_t739, "array_slice", ((_t781 = Z.arrNew()), Z.apush(_t781, 2), Z.apush(_t781, 3), _t781)), Z.aset(_t739, "reverse", ((_t782 = Z.arrNew()), Z.apush(_t782, 1), Z.apush(_t782, 1), _t782)), Z.aset(_t739, "sort", ((_t783 = Z.arrNew()), Z.apush(_t783, 1), Z.apush(_t783, 1), _t783)), Z.aset(_t739, "push", ((_t784 = Z.arrNew()), Z.apush(_t784, 2), Z.apush(_t784, Z.neg(1)), _t784)), Z.aset(_t739, "dump", ((_t785 = Z.arrNew()), Z.apush(_t785, 1), Z.apush(_t785, Z.neg(1)), _t785)), Z.aset(_t739, "read_line", ((_t786 = Z.arrNew()), Z.apush(_t786, 0), Z.apush(_t786, 0), _t786)), Z.aset(_t739, "zs_obj_new", ((_t787 = Z.arrNew()), Z.apush(_t787, 1), Z.apush(_t787, 1), _t787)), Z.aset(_t739, "zs_obj_class", ((_t788 = Z.arrNew()), Z.apush(_t788, 1), Z.apush(_t788, 1), _t788)), Z.aset(_t739, "zs_obj_get", ((_t789 = Z.arrNew()), Z.apush(_t789, 2), Z.apush(_t789, 2), _t789)), Z.aset(_t739, "zs_obj_take", ((_t790 = Z.arrNew()), Z.apush(_t790, 2), Z.apush(_t790, 2), _t790)), Z.aset(_t739, "zs_obj_set", ((_t791 = Z.arrNew()), Z.apush(_t791, 3), Z.apush(_t791, 3), _t791)), Z.aset(_t739, "zs_obj_put", ((_t792 = Z.arrNew()), Z.apush(_t792, 3), Z.apush(_t792, 3), _t792)), Z.aset(_t739, "zs_no_method", ((_t793 = Z.arrNew()), Z.apush(_t793, 2), Z.apush(_t793, 2), _t793)), Z.aset(_t739, "zs_no_class", ((_t794 = Z.arrNew()), Z.apush(_t794, 1), Z.apush(_t794, 1), _t794)), Z.aset(_t739, "zs_mkfn", ((_t795 = Z.arrNew()), Z.apush(_t795, 2), Z.apush(_t795, 2), _t795)), Z.aset(_t739, "zs_fn_id", ((_t796 = Z.arrNew()), Z.apush(_t796, 1), Z.apush(_t796, 1), _t796)), Z.aset(_t739, "zs_fn_cap", ((_t797 = Z.arrNew()), Z.apush(_t797, 1), Z.apush(_t797, 1), _t797)), Z.aset(_t739, "is_callable", ((_t798 = Z.arrNew()), Z.apush(_t798, 1), Z.apush(_t798, 1), _t798)), Z.aset(_t739, "zs_sget", ((_t799 = Z.arrNew()), Z.apush(_t799, 1), Z.apush(_t799, 1), _t799)), Z.aset(_t739, "zs_sset", ((_t800 = Z.arrNew()), Z.apush(_t800, 2), Z.apush(_t800, 2), _t800)), Z.aset(_t739, "necho", ((_t801 = Z.arrNew()), Z.apush(_t801, 1), Z.apush(_t801, Z.neg(1)), _t801)), Z.aset(_t739, "eecho", ((_t802 = Z.arrNew()), Z.apush(_t802, 0), Z.apush(_t802, Z.neg(1)), _t802)), Z.aset(_t739, "exit", ((_t803 = Z.arrNew()), Z.apush(_t803, 0), Z.apush(_t803, 1), _t803)), _t739), v_name))) {
        Z.setLine(238);
        (v_ar = Z.dup(Z.index(((_t804 = Z.arrNew()), Z.aset(_t804, "count", ((_t805 = Z.arrNew()), Z.apush(_t805, 1), Z.apush(_t805, 1), _t805)), Z.aset(_t804, "strlen", ((_t806 = Z.arrNew()), Z.apush(_t806, 1), Z.apush(_t806, 1), _t806)), Z.aset(_t804, "typeof", ((_t807 = Z.arrNew()), Z.apush(_t807, 1), Z.apush(_t807, 1), _t807)), Z.aset(_t804, "is_int", ((_t808 = Z.arrNew()), Z.apush(_t808, 1), Z.apush(_t808, 1), _t808)), Z.aset(_t804, "is_float", ((_t809 = Z.arrNew()), Z.apush(_t809, 1), Z.apush(_t809, 1), _t809)), Z.aset(_t804, "is_string", ((_t810 = Z.arrNew()), Z.apush(_t810, 1), Z.apush(_t810, 1), _t810)), Z.aset(_t804, "is_bool", ((_t811 = Z.arrNew()), Z.apush(_t811, 1), Z.apush(_t811, 1), _t811)), Z.aset(_t804, "is_array", ((_t812 = Z.arrNew()), Z.apush(_t812, 1), Z.apush(_t812, 1), _t812)), Z.aset(_t804, "is_null", ((_t813 = Z.arrNew()), Z.apush(_t813, 1), Z.apush(_t813, 1), _t813)), Z.aset(_t804, "strval", ((_t814 = Z.arrNew()), Z.apush(_t814, 1), Z.apush(_t814, 1), _t814)), Z.aset(_t804, "boolval", ((_t815 = Z.arrNew()), Z.apush(_t815, 1), Z.apush(_t815, 1), _t815)), Z.aset(_t804, "intval", ((_t816 = Z.arrNew()), Z.apush(_t816, 1), Z.apush(_t816, 1), _t816)), Z.aset(_t804, "floatval", ((_t817 = Z.arrNew()), Z.apush(_t817, 1), Z.apush(_t817, 1), _t817)), Z.aset(_t804, "ord", ((_t818 = Z.arrNew()), Z.apush(_t818, 1), Z.apush(_t818, 1), _t818)), Z.aset(_t804, "chr", ((_t819 = Z.arrNew()), Z.apush(_t819, 1), Z.apush(_t819, 1), _t819)), Z.aset(_t804, "contains", ((_t820 = Z.arrNew()), Z.apush(_t820, 2), Z.apush(_t820, 2), _t820)), Z.aset(_t804, "starts_with", ((_t821 = Z.arrNew()), Z.apush(_t821, 2), Z.apush(_t821, 2), _t821)), Z.aset(_t804, "ends_with", ((_t822 = Z.arrNew()), Z.apush(_t822, 2), Z.apush(_t822, 2), _t822)), Z.aset(_t804, "index_of", ((_t823 = Z.arrNew()), Z.apush(_t823, 2), Z.apush(_t823, 2), _t823)), Z.aset(_t804, "repeat", ((_t824 = Z.arrNew()), Z.apush(_t824, 2), Z.apush(_t824, 2), _t824)), Z.aset(_t804, "substr", ((_t825 = Z.arrNew()), Z.apush(_t825, 2), Z.apush(_t825, 3), _t825)), Z.aset(_t804, "trim", ((_t826 = Z.arrNew()), Z.apush(_t826, 1), Z.apush(_t826, 1), _t826)), Z.aset(_t804, "join", ((_t827 = Z.arrNew()), Z.apush(_t827, 2), Z.apush(_t827, 2), _t827)), Z.aset(_t804, "in_array", ((_t828 = Z.arrNew()), Z.apush(_t828, 2), Z.apush(_t828, 2), _t828)), Z.aset(_t804, "range", ((_t829 = Z.arrNew()), Z.apush(_t829, 2), Z.apush(_t829, 2), _t829)), Z.aset(_t804, "keys", ((_t830 = Z.arrNew()), Z.apush(_t830, 1), Z.apush(_t830, 1), _t830)), Z.aset(_t804, "values", ((_t831 = Z.arrNew()), Z.apush(_t831, 1), Z.apush(_t831, 1), _t831)), Z.aset(_t804, "has_key", ((_t832 = Z.arrNew()), Z.apush(_t832, 2), Z.apush(_t832, 2), _t832)), Z.aset(_t804, "upper", ((_t833 = Z.arrNew()), Z.apush(_t833, 1), Z.apush(_t833, 1), _t833)), Z.aset(_t804, "lower", ((_t834 = Z.arrNew()), Z.apush(_t834, 1), Z.apush(_t834, 1), _t834)), Z.aset(_t804, "replace", ((_t835 = Z.arrNew()), Z.apush(_t835, 3), Z.apush(_t835, 3), _t835)), Z.aset(_t804, "split", ((_t836 = Z.arrNew()), Z.apush(_t836, 2), Z.apush(_t836, 2), _t836)), Z.aset(_t804, "chars", ((_t837 = Z.arrNew()), Z.apush(_t837, 1), Z.apush(_t837, 1), _t837)), Z.aset(_t804, "pad_left", ((_t838 = Z.arrNew()), Z.apush(_t838, 2), Z.apush(_t838, 3), _t838)), Z.aset(_t804, "pad_right", ((_t839 = Z.arrNew()), Z.apush(_t839, 2), Z.apush(_t839, 3), _t839)), Z.aset(_t804, "to_hex", ((_t840 = Z.arrNew()), Z.apush(_t840, 1), Z.apush(_t840, 1), _t840)), Z.aset(_t804, "is_digit", ((_t841 = Z.arrNew()), Z.apush(_t841, 1), Z.apush(_t841, 1), _t841)), Z.aset(_t804, "is_alpha", ((_t842 = Z.arrNew()), Z.apush(_t842, 1), Z.apush(_t842, 1), _t842)), Z.aset(_t804, "is_alnum", ((_t843 = Z.arrNew()), Z.apush(_t843, 1), Z.apush(_t843, 1), _t843)), Z.aset(_t804, "is_space", ((_t844 = Z.arrNew()), Z.apush(_t844, 1), Z.apush(_t844, 1), _t844)), Z.aset(_t804, "is_hex_digit", ((_t845 = Z.arrNew()), Z.apush(_t845, 1), Z.apush(_t845, 1), _t845)), Z.aset(_t804, "array_slice", ((_t846 = Z.arrNew()), Z.apush(_t846, 2), Z.apush(_t846, 3), _t846)), Z.aset(_t804, "reverse", ((_t847 = Z.arrNew()), Z.apush(_t847, 1), Z.apush(_t847, 1), _t847)), Z.aset(_t804, "sort", ((_t848 = Z.arrNew()), Z.apush(_t848, 1), Z.apush(_t848, 1), _t848)), Z.aset(_t804, "push", ((_t849 = Z.arrNew()), Z.apush(_t849, 2), Z.apush(_t849, Z.neg(1)), _t849)), Z.aset(_t804, "dump", ((_t850 = Z.arrNew()), Z.apush(_t850, 1), Z.apush(_t850, Z.neg(1)), _t850)), Z.aset(_t804, "read_line", ((_t851 = Z.arrNew()), Z.apush(_t851, 0), Z.apush(_t851, 0), _t851)), Z.aset(_t804, "zs_obj_new", ((_t852 = Z.arrNew()), Z.apush(_t852, 1), Z.apush(_t852, 1), _t852)), Z.aset(_t804, "zs_obj_class", ((_t853 = Z.arrNew()), Z.apush(_t853, 1), Z.apush(_t853, 1), _t853)), Z.aset(_t804, "zs_obj_get", ((_t854 = Z.arrNew()), Z.apush(_t854, 2), Z.apush(_t854, 2), _t854)), Z.aset(_t804, "zs_obj_take", ((_t855 = Z.arrNew()), Z.apush(_t855, 2), Z.apush(_t855, 2), _t855)), Z.aset(_t804, "zs_obj_set", ((_t856 = Z.arrNew()), Z.apush(_t856, 3), Z.apush(_t856, 3), _t856)), Z.aset(_t804, "zs_obj_put", ((_t857 = Z.arrNew()), Z.apush(_t857, 3), Z.apush(_t857, 3), _t857)), Z.aset(_t804, "zs_no_method", ((_t858 = Z.arrNew()), Z.apush(_t858, 2), Z.apush(_t858, 2), _t858)), Z.aset(_t804, "zs_no_class", ((_t859 = Z.arrNew()), Z.apush(_t859, 1), Z.apush(_t859, 1), _t859)), Z.aset(_t804, "zs_mkfn", ((_t860 = Z.arrNew()), Z.apush(_t860, 2), Z.apush(_t860, 2), _t860)), Z.aset(_t804, "zs_fn_id", ((_t861 = Z.arrNew()), Z.apush(_t861, 1), Z.apush(_t861, 1), _t861)), Z.aset(_t804, "zs_fn_cap", ((_t862 = Z.arrNew()), Z.apush(_t862, 1), Z.apush(_t862, 1), _t862)), Z.aset(_t804, "is_callable", ((_t863 = Z.arrNew()), Z.apush(_t863, 1), Z.apush(_t863, 1), _t863)), Z.aset(_t804, "zs_sget", ((_t864 = Z.arrNew()), Z.apush(_t864, 1), Z.apush(_t864, 1), _t864)), Z.aset(_t804, "zs_sset", ((_t865 = Z.arrNew()), Z.apush(_t865, 2), Z.apush(_t865, 2), _t865)), Z.aset(_t804, "necho", ((_t866 = Z.arrNew()), Z.apush(_t866, 1), Z.apush(_t866, Z.neg(1)), _t866)), Z.aset(_t804, "eecho", ((_t867 = Z.arrNew()), Z.apush(_t867, 0), Z.apush(_t867, Z.neg(1)), _t867)), Z.aset(_t804, "exit", ((_t868 = Z.arrNew()), Z.apush(_t868, 0), Z.apush(_t868, 1), _t868)), _t804), v_name)));
        Z.setLine(239);
        if (Z.truthy((Z.truthy((Z.cmp(v_n, Z.index(v_ar, 0)) < 0)) || Z.truthy((Z.truthy((Z.cmp(Z.index(v_ar, 1), 0) >= 0)) && Z.truthy((Z.cmp(v_n, Z.index(v_ar, 1)) > 0))))))) {
          Z.setLine(239);
          f_zs_invoke(Z.dup(v_this), "err", ((_t869 = Z.arrNew()), Z.apush(_t869, Z.dup(v_line)), Z.apush(_t869, "E0104"), Z.apush(_t869, Z.concat(Z.concat(Z.concat(Z.concat("funkcja wbudowana ", v_name), ": zła liczba argumentów ("), v_n), ")")), _t869));
        }
      } else {
        Z.setLine(241);
        f_zs_invoke(Z.dup(v_this), "err", ((_t870 = Z.arrNew()), Z.apush(_t870, Z.dup(v_line)), Z.apush(_t870, "E0103"), Z.apush(_t870, Z.concat(Z.concat("nieznana funkcja `", v_name), "` (backend natywny 0.0.1 obsługuje funkcje użytkownika i podzbiór wbudowanych)")), _t870));
      }
    }
    Z.setLine(243);
    return null;
  }
  Z.setLine(245);
  if (Z.truthy((Z.truthy(Z.ident(Z.index(v_callee, 0), ":Dot")) && Z.truthy(Z.ident(Z.index(Z.index(v_callee, 2), 0), ":Name"))))) {
    Z.setLine(246);
    (v_m = Z.dup(Z.index(Z.index(v_callee, 2), 2)));
    Z.setLine(247);
    (v_f = Z.dup(Z.index(v_callee, 3)));
    Z.setLine(248);
    if (Z.truthy((Z.truthy(Z.ident(v_m, "Math")) && Z.truthy(Z.B.has_key(((_t871 = Z.arrNew()), Z.aset(_t871, "sqrt", 1), Z.aset(_t871, "floor", 1), Z.aset(_t871, "ceil", 1), Z.aset(_t871, "round", 1), Z.aset(_t871, "abs", 1), Z.aset(_t871, "min", 2), Z.aset(_t871, "max", 2), Z.aset(_t871, "pow", 2), _t871), v_f))))) {
      Z.setLine(249);
      if (Z.truthy(!Z.ident(v_n, Z.index(((_t872 = Z.arrNew()), Z.aset(_t872, "sqrt", 1), Z.aset(_t872, "floor", 1), Z.aset(_t872, "ceil", 1), Z.aset(_t872, "round", 1), Z.aset(_t872, "abs", 1), Z.aset(_t872, "min", 2), Z.aset(_t872, "max", 2), Z.aset(_t872, "pow", 2), _t872), v_f)))) {
        Z.setLine(249);
        f_zs_invoke(Z.dup(v_this), "err", ((_t873 = Z.arrNew()), Z.apush(_t873, Z.dup(v_line)), Z.apush(_t873, "E0104"), Z.apush(_t873, Z.concat(Z.concat("Math.", v_f), ": zła liczba argumentów")), _t873));
      }
      Z.setLine(250);
      return null;
    }
    Z.setLine(252);
    if (Z.truthy((Z.truthy(Z.B.has_key(((_t874 = Z.arrNew()), Z.aset(_t874, "System", ((_t875 = Z.arrNew()), Z.aset(_t875, "args", 0), Z.aset(_t875, "env", 1), Z.aset(_t875, "os", 0), Z.aset(_t875, "architecture", 0), Z.aset(_t875, "time", 0), Z.aset(_t875, "cpuCount", 0), Z.aset(_t875, "dirname", 1), Z.aset(_t875, "resolveImport", 2), Z.aset(_t875, "version", 0), Z.aset(_t875, "exit", Z.neg(1)), Z.aset(_t875, "setEnv", 2), Z.aset(_t875, "unsetEnv", 1), Z.aset(_t875, "environ", 0), Z.aset(_t875, "cwd", 0), Z.aset(_t875, "chdir", 1), Z.aset(_t875, "pid", 0), Z.aset(_t875, "hostname", 0), Z.aset(_t875, "bytes", 1), Z.aset(_t875, "fromBytes", 1), Z.aset(_t875, "nowNanos", 0), Z.aset(_t875, "monotonic", 0), Z.aset(_t875, "sleep", 1), Z.aset(_t875, "localOffset", 1), Z.aset(_t875, "gc", 0), Z.aset(_t875, "gcStats", 0), _t875)), Z.aset(_t874, "File", ((_t876 = Z.arrNew()), Z.aset(_t876, "read", 1), Z.aset(_t876, "write", 2), Z.aset(_t876, "append", 2), Z.aset(_t876, "exists", 1), Z.aset(_t876, "delete", 1), Z.aset(_t876, "stat", 1), Z.aset(_t876, "rename", 2), Z.aset(_t876, "realpath", 1), Z.aset(_t876, "chmod", 2), Z.aset(_t876, "symlink", 2), Z.aset(_t876, "readlink", 1), _t876)), Z.aset(_t874, "Directory", ((_t877 = Z.arrNew()), Z.aset(_t877, "create", 1), Z.aset(_t877, "exists", 1), Z.aset(_t877, "list", 1), Z.aset(_t877, "remove", 1), _t877)), Z.aset(_t874, "Process", ((_t878 = Z.arrNew()), Z.aset(_t878, "run", Z.neg(1)), Z.aset(_t878, "exec", Z.neg(1)), _t878)), Z.aset(_t874, "Socket", ((_t879 = Z.arrNew()), Z.aset(_t879, "tcpConnect", 3), Z.aset(_t879, "tcpListen", 2), Z.aset(_t879, "accept", 1), Z.aset(_t879, "read", 2), Z.aset(_t879, "write", 2), Z.aset(_t879, "close", 1), Z.aset(_t879, "setTimeout", 2), Z.aset(_t879, "udpBind", 2), Z.aset(_t879, "sendTo", 4), Z.aset(_t879, "recvFrom", 2), Z.aset(_t879, "resolve", 1), Z.aset(_t879, "localAddr", 1), Z.aset(_t879, "peerAddr", 1), _t879)), _t874), v_m)) && Z.truthy(Z.B.has_key(Z.index(((_t880 = Z.arrNew()), Z.aset(_t880, "System", ((_t881 = Z.arrNew()), Z.aset(_t881, "args", 0), Z.aset(_t881, "env", 1), Z.aset(_t881, "os", 0), Z.aset(_t881, "architecture", 0), Z.aset(_t881, "time", 0), Z.aset(_t881, "cpuCount", 0), Z.aset(_t881, "dirname", 1), Z.aset(_t881, "resolveImport", 2), Z.aset(_t881, "version", 0), Z.aset(_t881, "exit", Z.neg(1)), Z.aset(_t881, "setEnv", 2), Z.aset(_t881, "unsetEnv", 1), Z.aset(_t881, "environ", 0), Z.aset(_t881, "cwd", 0), Z.aset(_t881, "chdir", 1), Z.aset(_t881, "pid", 0), Z.aset(_t881, "hostname", 0), Z.aset(_t881, "bytes", 1), Z.aset(_t881, "fromBytes", 1), Z.aset(_t881, "nowNanos", 0), Z.aset(_t881, "monotonic", 0), Z.aset(_t881, "sleep", 1), Z.aset(_t881, "localOffset", 1), Z.aset(_t881, "gc", 0), Z.aset(_t881, "gcStats", 0), _t881)), Z.aset(_t880, "File", ((_t882 = Z.arrNew()), Z.aset(_t882, "read", 1), Z.aset(_t882, "write", 2), Z.aset(_t882, "append", 2), Z.aset(_t882, "exists", 1), Z.aset(_t882, "delete", 1), Z.aset(_t882, "stat", 1), Z.aset(_t882, "rename", 2), Z.aset(_t882, "realpath", 1), Z.aset(_t882, "chmod", 2), Z.aset(_t882, "symlink", 2), Z.aset(_t882, "readlink", 1), _t882)), Z.aset(_t880, "Directory", ((_t883 = Z.arrNew()), Z.aset(_t883, "create", 1), Z.aset(_t883, "exists", 1), Z.aset(_t883, "list", 1), Z.aset(_t883, "remove", 1), _t883)), Z.aset(_t880, "Process", ((_t884 = Z.arrNew()), Z.aset(_t884, "run", Z.neg(1)), Z.aset(_t884, "exec", Z.neg(1)), _t884)), Z.aset(_t880, "Socket", ((_t885 = Z.arrNew()), Z.aset(_t885, "tcpConnect", 3), Z.aset(_t885, "tcpListen", 2), Z.aset(_t885, "accept", 1), Z.aset(_t885, "read", 2), Z.aset(_t885, "write", 2), Z.aset(_t885, "close", 1), Z.aset(_t885, "setTimeout", 2), Z.aset(_t885, "udpBind", 2), Z.aset(_t885, "sendTo", 4), Z.aset(_t885, "recvFrom", 2), Z.aset(_t885, "resolve", 1), Z.aset(_t885, "localAddr", 1), Z.aset(_t885, "peerAddr", 1), _t885)), _t880), v_m), v_f))))) {
      Z.setLine(253);
      (v_ar = Z.dup(Z.index(Z.index(((_t886 = Z.arrNew()), Z.aset(_t886, "System", ((_t887 = Z.arrNew()), Z.aset(_t887, "args", 0), Z.aset(_t887, "env", 1), Z.aset(_t887, "os", 0), Z.aset(_t887, "architecture", 0), Z.aset(_t887, "time", 0), Z.aset(_t887, "cpuCount", 0), Z.aset(_t887, "dirname", 1), Z.aset(_t887, "resolveImport", 2), Z.aset(_t887, "version", 0), Z.aset(_t887, "exit", Z.neg(1)), Z.aset(_t887, "setEnv", 2), Z.aset(_t887, "unsetEnv", 1), Z.aset(_t887, "environ", 0), Z.aset(_t887, "cwd", 0), Z.aset(_t887, "chdir", 1), Z.aset(_t887, "pid", 0), Z.aset(_t887, "hostname", 0), Z.aset(_t887, "bytes", 1), Z.aset(_t887, "fromBytes", 1), Z.aset(_t887, "nowNanos", 0), Z.aset(_t887, "monotonic", 0), Z.aset(_t887, "sleep", 1), Z.aset(_t887, "localOffset", 1), Z.aset(_t887, "gc", 0), Z.aset(_t887, "gcStats", 0), _t887)), Z.aset(_t886, "File", ((_t888 = Z.arrNew()), Z.aset(_t888, "read", 1), Z.aset(_t888, "write", 2), Z.aset(_t888, "append", 2), Z.aset(_t888, "exists", 1), Z.aset(_t888, "delete", 1), Z.aset(_t888, "stat", 1), Z.aset(_t888, "rename", 2), Z.aset(_t888, "realpath", 1), Z.aset(_t888, "chmod", 2), Z.aset(_t888, "symlink", 2), Z.aset(_t888, "readlink", 1), _t888)), Z.aset(_t886, "Directory", ((_t889 = Z.arrNew()), Z.aset(_t889, "create", 1), Z.aset(_t889, "exists", 1), Z.aset(_t889, "list", 1), Z.aset(_t889, "remove", 1), _t889)), Z.aset(_t886, "Process", ((_t890 = Z.arrNew()), Z.aset(_t890, "run", Z.neg(1)), Z.aset(_t890, "exec", Z.neg(1)), _t890)), Z.aset(_t886, "Socket", ((_t891 = Z.arrNew()), Z.aset(_t891, "tcpConnect", 3), Z.aset(_t891, "tcpListen", 2), Z.aset(_t891, "accept", 1), Z.aset(_t891, "read", 2), Z.aset(_t891, "write", 2), Z.aset(_t891, "close", 1), Z.aset(_t891, "setTimeout", 2), Z.aset(_t891, "udpBind", 2), Z.aset(_t891, "sendTo", 4), Z.aset(_t891, "recvFrom", 2), Z.aset(_t891, "resolve", 1), Z.aset(_t891, "localAddr", 1), Z.aset(_t891, "peerAddr", 1), _t891)), _t886), v_m), v_f)));
      Z.setLine(254);
      if (Z.truthy((Z.truthy((Z.cmp(v_ar, 0) >= 0)) && Z.truthy(!Z.ident(v_n, v_ar))))) {
        Z.setLine(254);
        f_zs_invoke(Z.dup(v_this), "err", ((_t892 = Z.arrNew()), Z.apush(_t892, Z.dup(v_line)), Z.apush(_t892, "E0104"), Z.apush(_t892, Z.concat(Z.concat(Z.concat(Z.concat(Z.concat(v_m, "."), v_f), ": zła liczba argumentów ("), v_n), ")")), _t892));
      }
      Z.setLine(255);
      return null;
    }
    Z.setLine(257);
    f_zs_invoke(Z.dup(v_this), "err", ((_t893 = Z.arrNew()), Z.apush(_t893, Z.dup(v_line)), Z.apush(_t893, "E0103"), Z.apush(_t893, Z.concat(Z.concat(Z.concat(Z.concat("funkcja ", v_m), "."), v_f), " niedostępna w backendzie natywnym 0.0.1")), _t893));
    Z.setLine(258);
    return null;
  }
  Z.setLine(260);
  f_zs_invoke(Z.dup(v_this), "err", ((_t894 = Z.arrNew()), Z.apush(_t894, Z.dup(v_line)), Z.apush(_t894, "E0102"), Z.apush(_t894, "wywołanie wartości niedostępne w backendzie natywnym 0.0.1"), _t894));
  return null;
}
function f_Lowerer__topCallsMain(v_this, v_x) {
  let v_i = null, v_y = null;
  let _t895 = null, _t896 = null, _t897 = null;
  Z.setLine(264);
  if (Z.truthy(f_Workspace_parser__isNode(Z.dup(v_x)))) {
    Z.setLine(265);
    if (Z.truthy((Z.truthy((Z.truthy(Z.ident(Z.index(v_x, 0), ":Call")) && Z.truthy(Z.ident(Z.index(Z.index(v_x, 2), 0), ":Name")))) && Z.truthy(Z.ident(Z.index(Z.index(v_x, 2), 2), "main"))))) {
      Z.setLine(265);
      return true;
    }
    Z.setLine(266);
    if (Z.truthy(Z.ident(Z.index(v_x, 0), ":FuncStmt"))) {
      Z.setLine(266);
      return false;
    }
    Z.setLine(267);
    (v_i = 2);
    L82: for (; Z.truthy((Z.cmp(v_i, Z.B.count(v_x)) < 0)); ((_t895 = v_i), (v_i = Z.add(_t895, 1)), _t895)) {
      Z.setLine(267);
      if (Z.truthy(f_zs_invoke(Z.dup(v_this), "topCallsMain", ((_t896 = Z.arrNew()), Z.apush(_t896, Z.dup(Z.index(v_x, v_i))), _t896)))) {
        Z.setLine(267);
        return true;
      }
    }
    Z.setLine(268);
    return false;
  }
  Z.setLine(270);
  if (Z.truthy(Z.B.is_array(v_x))) {
    Z.setLine(270);
    {
      const _it83 = Z.foreachArr(Z.dup(v_x));
      L83: for (let _i83 = 0; _i83 < _it83.keys.length; _i83++) {
        v_y = _it83.vals[_i83];
        Z.setLine(270);
        if (Z.truthy(f_zs_invoke(Z.dup(v_this), "topCallsMain", ((_t897 = Z.arrNew()), Z.apush(_t897, Z.dup(v_y)), _t897)))) {
          Z.setLine(270);
          return true;
        }
      }
    }
  }
  Z.setLine(271);
  return false;
  return null;
}
function f_Lowerer__new() {
  let v___o = null;
  Z.setLine(44);
  (v___o = Z.B.zs_obj_new("Lowerer"));
  Z.setLine(44);
  Z.B.zs_obj_set(v___o, "funcs", null);
  Z.setLine(44);
  Z.B.zs_obj_set(v___o, "order", null);
  Z.setLine(44);
  Z.B.zs_obj_set(v___o, "errors", null);
  Z.setLine(44);
  f_Lowerer____construct(Z.dup(v___o));
  Z.setLine(44);
  return Z.dup(v___o);
  return null;
}
function f_Lifter__err(v_this, v_line, v_m) {
  let v___r78 = null, v___w79 = null;
  let _t898 = null;
  Z.setLine(62);
  (v___r78 = ((_t898 = Z.arrNew()), Z.apush(_t898, Z.dup(v_line)), Z.apush(_t898, "E0104"), Z.apush(_t898, Z.dup(v_m)), _t898));
  Z.setLine(62);
  (v___w79 = Z.B.zs_obj_take(v_this, "errors"));
  Z.setLine(62);
  Z.apush((v___w79 = Z.wr(v___w79)), Z.dup(v___r78));
  Z.setLine(62);
  Z.B.zs_obj_put(v_this, "errors", v___w79);
  return null;
}
function f_Lifter__scan(v_this, v_x) {
  let v_k = null, v___k80 = null, v___r81 = null, v___w82 = null, v_n = null, v___k83 = null, v___r84 = null, v___w85 = null, v___k86 = null, v___r87 = null, v___w88 = null, v___k89 = null, v___r90 = null, v___w91 = null, v___k92 = null, v___r93 = null, v___w94 = null, v_v = null;
  let _t899 = null, _t900 = null;
  Z.setLine(66);
  if (Z.truthy(!Z.truthy(Z.B.is_array(v_x)))) {
    Z.setLine(66);
    return null;
  }
  Z.setLine(67);
  if (Z.truthy(f_Workspace_parser__isNode(Z.dup(v_x)))) {
    Z.setLine(68);
    (v_k = Z.dup(Z.index(v_x, 0)));
    Z.setLine(69);
    if (Z.truthy(Z.ident(v_k, ":Var"))) {
      Z.setLine(69);
      (v___k80 = Z.dup(Z.index(v_x, 2)));
      Z.setLine(69);
      (v___r81 = true);
      Z.setLine(69);
      (v___w82 = Z.B.zs_obj_take(v_this, "acc"));
      Z.setLine(69);
      Z.aset((v___w82 = Z.wr(v___w82)), v___k80, Z.dup(v___r81));
      Z.setLine(69);
      Z.B.zs_obj_put(v_this, "acc", v___w82);
      Z.setLine(69);
      return null;
    }
    Z.setLine(70);
    if (Z.truthy(Z.ident(v_k, ":Closure"))) {
      Z.setLine(70);
      {
        const _it84 = Z.foreachArr(f_zs_invoke(Z.dup(v_this), "freeOf", ((_t899 = Z.arrNew()), Z.apush(_t899, Z.dup(Z.index(v_x, 2))), _t899)));
        L84: for (let _i84 = 0; _i84 < _it84.keys.length; _i84++) {
          v_n = _it84.vals[_i84];
          Z.setLine(70);
          (v___k83 = Z.dup(v_n));
          Z.setLine(70);
          (v___r84 = true);
          Z.setLine(70);
          (v___w85 = Z.B.zs_obj_take(v_this, "acc"));
          Z.setLine(70);
          Z.aset((v___w85 = Z.wr(v___w85)), v___k83, Z.dup(v___r84));
          Z.setLine(70);
          Z.B.zs_obj_put(v_this, "acc", v___w85);
        }
      }
      Z.setLine(70);
      return null;
    }
    Z.setLine(71);
    if (Z.truthy(Z.ident(v_k, ":Foreach"))) {
      Z.setLine(72);
      if (Z.truthy(!Z.ident(Z.index(v_x, 3), null))) {
        Z.setLine(72);
        (v___k86 = Z.dup(Z.index(v_x, 3)));
        Z.setLine(72);
        (v___r87 = true);
        Z.setLine(72);
        (v___w88 = Z.B.zs_obj_take(v_this, "acc"));
        Z.setLine(72);
        Z.aset((v___w88 = Z.wr(v___w88)), v___k86, Z.dup(v___r87));
        Z.setLine(72);
        Z.B.zs_obj_put(v_this, "acc", v___w88);
      }
      Z.setLine(73);
      if (Z.truthy(!Z.ident(Z.index(v_x, 4), null))) {
        Z.setLine(73);
        (v___k89 = Z.dup(Z.index(v_x, 4)));
        Z.setLine(73);
        (v___r90 = true);
        Z.setLine(73);
        (v___w91 = Z.B.zs_obj_take(v_this, "acc"));
        Z.setLine(73);
        Z.aset((v___w91 = Z.wr(v___w91)), v___k89, Z.dup(v___r90));
        Z.setLine(73);
        Z.B.zs_obj_put(v_this, "acc", v___w91);
      }
    }
    Z.setLine(75);
    if (Z.truthy((Z.truthy(Z.ident(v_k, ":Catch")) && Z.truthy(!Z.ident(Z.index(v_x, 3), null))))) {
      Z.setLine(75);
      (v___k92 = Z.dup(Z.index(v_x, 3)));
      Z.setLine(75);
      (v___r93 = true);
      Z.setLine(75);
      (v___w94 = Z.B.zs_obj_take(v_this, "acc"));
      Z.setLine(75);
      Z.aset((v___w94 = Z.wr(v___w94)), v___k92, Z.dup(v___r93));
      Z.setLine(75);
      Z.B.zs_obj_put(v_this, "acc", v___w94);
    }
  }
  Z.setLine(77);
  {
    const _it85 = Z.foreachArr(Z.dup(v_x));
    L85: for (let _i85 = 0; _i85 < _it85.keys.length; _i85++) {
      v_v = _it85.vals[_i85];
      Z.setLine(77);
      f_zs_invoke(Z.dup(v_this), "scan", ((_t900 = Z.arrNew()), Z.apush(_t900, Z.dup(v_v)), _t900));
    }
  }
  return null;
}
function f_Lifter__names(v_this, v_x) {
  let v_save = null, v_r = null;
  let _t901 = null, _t902 = null;
  Z.setLine(81);
  (v_save = Z.B.zs_obj_get(v_this, "acc"));
  Z.setLine(82);
  Z.B.zs_obj_set(v_this, "acc", ((_t901 = Z.arrNew()), _t901));
  Z.setLine(83);
  f_zs_invoke(Z.dup(v_this), "scan", ((_t902 = Z.arrNew()), Z.apush(_t902, Z.dup(v_x)), _t902));
  Z.setLine(84);
  (v_r = Z.B.zs_obj_get(v_this, "acc"));
  Z.setLine(85);
  Z.B.zs_obj_set(v_this, "acc", v_save);
  Z.setLine(86);
  return Z.dup(v_r);
  return null;
}
function f_Lifter__freeOf(v_this, v_f) {
  let v_r = null, v_n = null, v_t = null, v_pn = null, v_p = null, v_out = null;
  let _t903 = null, _t904 = null, _t905 = null, _t906 = null;
  Z.setLine(91);
  (v_r = f_zs_invoke(Z.dup(v_this), "names", ((_t903 = Z.arrNew()), Z.apush(_t903, Z.dup(Z.index(v_f, 5))), _t903)));
  Z.setLine(92);
  {
    const _it86 = Z.foreachArr(f_zs_invoke(Z.dup(v_this), "names", ((_t904 = Z.arrNew()), Z.apush(_t904, Z.dup(Z.index(v_f, 3))), _t904)));
    L86: for (let _i86 = 0; _i86 < _it86.keys.length; _i86++) {
      v_t = _it86.vals[_i86];
      v_n = _it86.keys[_i86];
      Z.setLine(92);
      Z.aset((v_r = Z.wr(v_r)), v_n, true);
    }
  }
  Z.setLine(93);
  (v_pn = ((_t905 = Z.arrNew()), _t905));
  Z.setLine(94);
  {
    const _it87 = Z.foreachArr(Z.dup(Z.index(v_f, 3)));
    L87: for (let _i87 = 0; _i87 < _it87.keys.length; _i87++) {
      v_p = _it87.vals[_i87];
      Z.setLine(94);
      Z.aset((v_pn = Z.wr(v_pn)), Z.index(v_p, 2), true);
    }
  }
  Z.setLine(95);
  (v_out = ((_t906 = Z.arrNew()), _t906));
  Z.setLine(96);
  {
    const _it88 = Z.foreachArr(Z.dup(v_r));
    L88: for (let _i88 = 0; _i88 < _it88.keys.length; _i88++) {
      v_t = _it88.vals[_i88];
      v_n = _it88.keys[_i88];
      Z.setLine(96);
      if (Z.truthy(!Z.truthy(Z.B.has_key(v_pn, v_n)))) {
        Z.setLine(96);
        Z.apush((v_out = Z.wr(v_out)), Z.dup(v_n));
      }
    }
  }
  Z.setLine(97);
  return Z.dup(v_out);
  return null;
}
function f_Lifter__lift(v_this, v_x, v_vis) {
  let v_f = null, v_line = null, v_cap = null, v_n = null, v_id = null, v_vis2 = null, v_p = null, v_body = null, v_s = null, v_ps = null, v_own = null, v___k95 = null, v___r96 = null, v___w97 = null, v___r98 = null, v___w99 = null, v_items = null;
  let _t907 = null, _t908 = null, _t909 = null, _t910 = null, _t911 = null, _t912 = null, _t913 = null, _t914 = null, _t915 = null, _t916 = null, _t917 = null, _t918 = null, _t919 = null, _t920 = null, _t921 = null, _t922 = null, _t923 = null;
  Z.setLine(101);
  (v_f = Z.dup(Z.index(v_x, 2)));
  Z.setLine(102);
  (v_line = Z.dup(Z.index(v_x, 1)));
  Z.setLine(103);
  (v_cap = ((_t907 = Z.arrNew()), _t907));
  Z.setLine(104);
  {
    const _it89 = Z.foreachArr(f_zs_invoke(Z.dup(v_this), "freeOf", ((_t908 = Z.arrNew()), Z.apush(_t908, Z.dup(v_f)), _t908)));
    L89: for (let _i89 = 0; _i89 < _it89.keys.length; _i89++) {
      v_n = _it89.vals[_i89];
      Z.setLine(104);
      if (Z.truthy(Z.B.has_key(v_vis, v_n))) {
        Z.setLine(104);
        Z.apush((v_cap = Z.wr(v_cap)), Z.dup(v_n));
      }
    }
  }
  Z.setLine(105);
  (v_id = Z.B.zs_obj_get(v_this, "n"));
  Z.setLine(106);
  Z.B.zs_obj_set(v_this, "n", Z.add(Z.B.zs_obj_get(v_this, "n"), 1));
  Z.setLine(107);
  (v_vis2 = f_zs_invoke(Z.dup(v_this), "names", ((_t909 = Z.arrNew()), Z.apush(_t909, Z.dup(Z.index(v_f, 5))), _t909)));
  Z.setLine(108);
  {
    const _it90 = Z.foreachArr(Z.dup(Z.index(v_f, 3)));
    L90: for (let _i90 = 0; _i90 < _it90.keys.length; _i90++) {
      v_p = _it90.vals[_i90];
      Z.setLine(108);
      Z.aset((v_vis2 = Z.wr(v_vis2)), Z.index(v_p, 2), true);
    }
  }
  Z.setLine(109);
  {
    const _it91 = Z.foreachArr(Z.dup(v_cap));
    L91: for (let _i91 = 0; _i91 < _it91.keys.length; _i91++) {
      v_n = _it91.vals[_i91];
      Z.setLine(109);
      Z.aset((v_vis2 = Z.wr(v_vis2)), v_n, true);
    }
  }
  Z.setLine(110);
  (v_body = ((_t910 = Z.arrNew()), _t910));
  Z.setLine(111);
  {
    const _it92 = Z.foreachArr(Z.dup(v_cap));
    L92: for (let _i92 = 0; _i92 < _it92.keys.length; _i92++) {
      v_n = _it92.vals[_i92];
      Z.setLine(112);
      Z.apush((v_body = Z.wr(v_body)), ((_t911 = Z.arrNew()), Z.apush(_t911, ":Expr"), Z.apush(_t911, Z.dup(v_line)), Z.apush(_t911, ((_t912 = Z.arrNew()), Z.apush(_t912, ":Assign"), Z.apush(_t912, Z.dup(v_line)), Z.apush(_t912, f_Workspace_closures__var(Z.dup(v_line), Z.dup(v_n))), Z.apush(_t912, ((_t913 = Z.arrNew()), Z.apush(_t913, ":Index"), Z.apush(_t913, Z.dup(v_line)), Z.apush(_t913, f_Workspace_closures__var(Z.dup(v_line), "__cap")), Z.apush(_t913, f_Workspace_closures__str(Z.dup(v_line), Z.dup(v_n))), _t913)), _t912)), _t911));
    }
  }
  Z.setLine(114);
  {
    const _it93 = Z.foreachArr(Z.dup(Z.index(v_f, 5)));
    L93: for (let _i93 = 0; _i93 < _it93.keys.length; _i93++) {
      v_s = _it93.vals[_i93];
      Z.setLine(114);
      Z.apush((v_body = Z.wr(v_body)), f_zs_invoke(Z.dup(v_this), "rw", ((_t914 = Z.arrNew()), Z.apush(_t914, Z.dup(v_s)), Z.apush(_t914, Z.dup(v_vis2)), _t914)));
    }
  }
  Z.setLine(115);
  (v_ps = ((_t915 = Z.arrNew()), Z.apush(_t915, f_Workspace_closures__param("__cap")), _t915));
  Z.setLine(116);
  (v_own = ((_t916 = Z.arrNew()), _t916));
  Z.setLine(117);
  {
    const _it94 = Z.foreachArr(Z.dup(Z.index(v_f, 3)));
    L94: for (let _i94 = 0; _i94 < _it94.keys.length; _i94++) {
      v_p = _it94.vals[_i94];
      Z.setLine(118);
      if (Z.truthy(!Z.ident(Z.index(v_p, 4), null))) {
        Z.setLine(118);
        Z.aset((v_p = Z.wr(v_p)), 4, f_zs_invoke(Z.dup(v_this), "rw", ((_t917 = Z.arrNew()), Z.apush(_t917, Z.dup(Z.index(v_p, 4))), Z.apush(_t917, Z.dup(v_vis2)), _t917)));
      }
      Z.setLine(119);
      Z.apush((v_ps = Z.wr(v_ps)), Z.dup(v_p));
      Z.setLine(120);
      Z.apush((v_own = Z.wr(v_own)), Z.dup(v_p));
    }
  }
  Z.setLine(122);
  (v___k95 = Z.dup(v_id));
  Z.setLine(122);
  (v___r96 = Z.dup(v_own));
  Z.setLine(122);
  (v___w97 = Z.B.zs_obj_take(v_this, "lams"));
  Z.setLine(122);
  Z.aset((v___w97 = Z.wr(v___w97)), v___k95, Z.dup(v___r96));
  Z.setLine(122);
  Z.B.zs_obj_put(v_this, "lams", v___w97);
  Z.setLine(123);
  (v___r98 = ((_t918 = Z.arrNew()), Z.apush(_t918, ":FuncStmt"), Z.apush(_t918, Z.dup(v_line)), Z.apush(_t918, ((_t919 = Z.arrNew()), Z.apush(_t919, ":Func"), Z.apush(_t919, Z.dup(v_line)), Z.apush(_t919, Z.concat("__lam", v_id)), Z.apush(_t919, Z.dup(v_ps)), Z.apush(_t919, Z.dup(Z.index(v_f, 4))), Z.apush(_t919, Z.dup(v_body)), Z.apush(_t919, false), _t919)), _t918));
  Z.setLine(123);
  (v___w99 = Z.B.zs_obj_take(v_this, "out"));
  Z.setLine(123);
  Z.apush((v___w99 = Z.wr(v___w99)), Z.dup(v___r98));
  Z.setLine(123);
  Z.B.zs_obj_put(v_this, "out", v___w99);
  Z.setLine(124);
  (v_items = ((_t920 = Z.arrNew()), _t920));
  Z.setLine(125);
  {
    const _it95 = Z.foreachArr(Z.dup(v_cap));
    L95: for (let _i95 = 0; _i95 < _it95.keys.length; _i95++) {
      v_n = _it95.vals[_i95];
      Z.setLine(125);
      Z.apush((v_items = Z.wr(v_items)), ((_t921 = Z.arrNew()), Z.apush(_t921, ":Item"), Z.apush(_t921, 0), Z.apush(_t921, f_Workspace_closures__str(Z.dup(v_line), Z.dup(v_n))), Z.apush(_t921, f_Workspace_closures__var(Z.dup(v_line), Z.dup(v_n))), _t921));
    }
  }
  Z.setLine(126);
  return f_Workspace_closures__call(Z.dup(v_line), "zs_mkfn", ((_t922 = Z.arrNew()), Z.apush(_t922, f_Workspace_closures__intl(Z.dup(v_line), Z.dup(v_id))), Z.apush(_t922, ((_t923 = Z.arrNew()), Z.apush(_t923, ":Array"), Z.apush(_t923, Z.dup(v_line)), Z.apush(_t923, Z.dup(v_items)), _t923)), _t922));
  return null;
}
function f_Lifter__rw(v_this, v_x, v_vis) {
  let v_o = null, v_k = null, v_v = null, v___k100 = null, v___r101 = null, v___w102 = null, v_i = null;
  let _t924 = null, _t925 = null, _t926 = null, _t927 = null, _t928 = null, _t929 = null;
  Z.setLine(130);
  if (Z.truthy(!Z.truthy(Z.B.is_array(v_x)))) {
    Z.setLine(130);
    return Z.dup(v_x);
  }
  Z.setLine(131);
  if (Z.truthy(!Z.truthy(f_Workspace_parser__isNode(Z.dup(v_x))))) {
    Z.setLine(132);
    (v_o = ((_t924 = Z.arrNew()), _t924));
    Z.setLine(133);
    {
      const _it96 = Z.foreachArr(Z.dup(v_x));
      L96: for (let _i96 = 0; _i96 < _it96.keys.length; _i96++) {
        v_v = _it96.vals[_i96];
        v_k = _it96.keys[_i96];
        Z.setLine(133);
        Z.aset((v_o = Z.wr(v_o)), v_k, f_zs_invoke(Z.dup(v_this), "rw", ((_t925 = Z.arrNew()), Z.apush(_t925, Z.dup(v_v)), Z.apush(_t925, Z.dup(v_vis)), _t925)));
      }
    }
    Z.setLine(134);
    return Z.dup(v_o);
  }
  Z.setLine(136);
  (v_k = Z.dup(Z.index(v_x, 0)));
  Z.setLine(137);
  if (Z.truthy(Z.ident(v_k, ":Closure"))) {
    Z.setLine(137);
    return f_zs_invoke(Z.dup(v_this), "lift", ((_t926 = Z.arrNew()), Z.apush(_t926, Z.dup(v_x)), Z.apush(_t926, Z.dup(v_vis)), _t926));
  }
  Z.setLine(138);
  if (Z.truthy(Z.ident(v_k, ":Call"))) {
    Z.setLine(138);
    return f_zs_invoke(Z.dup(v_this), "rwCall", ((_t927 = Z.arrNew()), Z.apush(_t927, Z.dup(v_x)), Z.apush(_t927, Z.dup(v_vis)), _t927));
  }
  Z.setLine(139);
  if (Z.truthy((Z.truthy(Z.ident(v_k, ":Str")) && Z.truthy(Z.B.has_key(Z.B.zs_obj_get(v_this, "fnp"), Z.index(v_x, 2)))))) {
    Z.setLine(139);
    (v___k100 = Z.dup(Z.index(v_x, 2)));
    Z.setLine(139);
    (v___r101 = true);
    Z.setLine(139);
    (v___w102 = Z.B.zs_obj_take(v_this, "named"));
    Z.setLine(139);
    Z.aset((v___w102 = Z.wr(v___w102)), v___k100, Z.dup(v___r101));
    Z.setLine(139);
    Z.B.zs_obj_put(v_this, "named", v___w102);
  }
  Z.setLine(140);
  (v_o = ((_t928 = Z.arrNew()), _t928));
  Z.setLine(141);
  {
    const _it97 = Z.foreachArr(Z.dup(v_x));
    L97: for (let _i97 = 0; _i97 < _it97.keys.length; _i97++) {
      v_v = _it97.vals[_i97];
      v_i = _it97.keys[_i97];
      Z.setLine(141);
      Z.aset((v_o = Z.wr(v_o)), v_i, (Z.truthy((Z.cmp(v_i, 2) < 0)) ? v_v : f_zs_invoke(Z.dup(v_this), "rw", ((_t929 = Z.arrNew()), Z.apush(_t929, Z.dup(v_v)), Z.apush(_t929, Z.dup(v_vis)), _t929))));
    }
  }
  Z.setLine(142);
  return Z.dup(v_o);
  return null;
}
function f_Lifter__argsArray(v_this, v_line, v_args, v_vis) {
  let v_cur = null, v_items = null, v_a = null, v_v = null, v_seg = null;
  let _t930 = null, _t931 = null, _t932 = null, _t933 = null, _t934 = null, _t935 = null, _t936 = null, _t937 = null, _t938 = null, _t939 = null, _t940 = null;
  Z.setLine(147);
  (v_cur = null);
  Z.setLine(148);
  (v_items = ((_t930 = Z.arrNew()), _t930));
  Z.setLine(149);
  {
    const _it98 = Z.foreachArr(Z.dup(v_args));
    L98: for (let _i98 = 0; _i98 < _it98.keys.length; _i98++) {
      v_a = _it98.vals[_i98];
      Z.setLine(150);
      (v_v = f_zs_invoke(Z.dup(v_this), "rw", ((_t931 = Z.arrNew()), Z.apush(_t931, Z.dup(Z.index(v_a, 3))), Z.apush(_t931, Z.dup(v_vis)), _t931)));
      Z.setLine(151);
      if (Z.truthy(Z.index(v_a, 4))) {
        Z.setLine(152);
        (v_seg = ((_t932 = Z.arrNew()), Z.apush(_t932, ":Array"), Z.apush(_t932, Z.dup(v_line)), Z.apush(_t932, Z.dup(v_items)), _t932));
        Z.setLine(153);
        (v_cur = (Z.truthy(Z.ident(v_cur, null)) ? v_seg : f_Workspace_closures__call(Z.dup(v_line), "zs_spread", ((_t933 = Z.arrNew()), Z.apush(_t933, Z.dup(v_cur)), Z.apush(_t933, Z.dup(v_seg)), _t933))));
        Z.setLine(154);
        (v_cur = f_Workspace_closures__call(Z.dup(v_line), "zs_spread", ((_t934 = Z.arrNew()), Z.apush(_t934, Z.dup(v_cur)), Z.apush(_t934, Z.dup(v_v)), _t934)));
        Z.setLine(155);
        (v_items = ((_t935 = Z.arrNew()), _t935));
        Z.setLine(156);
        Z.B.zs_obj_set(v_this, "usesSpread", true);
      } else {
        Z.setLine(157);
        if (Z.truthy(!Z.ident(Z.index(v_a, 2), null))) {
          Z.setLine(158);
          Z.apush((v_items = Z.wr(v_items)), ((_t936 = Z.arrNew()), Z.apush(_t936, ":Item"), Z.apush(_t936, 0), Z.apush(_t936, f_Workspace_closures__str(Z.dup(v_line), Z.dup(Z.index(v_a, 2)))), Z.apush(_t936, Z.dup(v_v)), _t936));
        } else {
          Z.setLine(160);
          Z.apush((v_items = Z.wr(v_items)), ((_t937 = Z.arrNew()), Z.apush(_t937, ":Item"), Z.apush(_t937, 0), Z.apush(_t937, null), Z.apush(_t937, Z.dup(v_v)), _t937));
        }
      }
    }
  }
  Z.setLine(163);
  if (Z.truthy(Z.ident(v_cur, null))) {
    Z.setLine(163);
    return ((_t938 = Z.arrNew()), Z.apush(_t938, ":Array"), Z.apush(_t938, Z.dup(v_line)), Z.apush(_t938, Z.dup(v_items)), _t938);
  }
  Z.setLine(164);
  if (Z.truthy((Z.cmp(Z.B.count(v_items), 0) > 0))) {
    Z.setLine(164);
    (v_cur = f_Workspace_closures__call(Z.dup(v_line), "zs_spread", ((_t939 = Z.arrNew()), Z.apush(_t939, Z.dup(v_cur)), Z.apush(_t939, ((_t940 = Z.arrNew()), Z.apush(_t940, ":Array"), Z.apush(_t940, Z.dup(v_line)), Z.apush(_t940, Z.dup(v_items)), _t940)), _t939)));
  }
  Z.setLine(165);
  return Z.dup(v_cur);
  return null;
}
function f_Lifter__rwCall(v_this, v_x, v_vis) {
  let v_line = null, v_callee = null, v_args = null, v_spread = null, v_namedArg = null, v_a = null, v_kind = null, v_n = null, v___k103 = null, v___r104 = null, v___w105 = null;
  let _t941 = null, _t942 = null, _t943 = null, _t944 = null, _t945 = null, _t946 = null, _t947 = null, _t948 = null, _t949 = null, _t950 = null;
  Z.setLine(169);
  (v_line = Z.dup(Z.index(v_x, 1)));
  Z.setLine(170);
  (v_callee = Z.dup(Z.index(v_x, 2)));
  Z.setLine(171);
  (v_args = Z.dup(Z.index(v_x, 3)));
  Z.setLine(172);
  (v_spread = false);
  Z.setLine(173);
  (v_namedArg = false);
  Z.setLine(174);
  {
    const _it99 = Z.foreachArr(Z.dup(v_args));
    L99: for (let _i99 = 0; _i99 < _it99.keys.length; _i99++) {
      v_a = _it99.vals[_i99];
      Z.setLine(174);
      if (Z.truthy(Z.index(v_a, 4))) {
        Z.setLine(174);
        (v_spread = true);
      }
      Z.setLine(174);
      if (Z.truthy(!Z.ident(Z.index(v_a, 2), null))) {
        Z.setLine(174);
        (v_namedArg = true);
      }
    }
  }
  Z.setLine(175);
  (v_kind = Z.dup(Z.index(v_callee, 0)));
  Z.setLine(176);
  if (Z.truthy(Z.ident(v_kind, ":Name"))) {
    Z.setLine(177);
    (v_n = Z.dup(Z.index(v_callee, 2)));
    Z.setLine(178);
    if (Z.truthy((Z.truthy(Z.B.has_key(Z.B.zs_obj_get(v_this, "fnp"), v_n)) && Z.truthy((Z.truthy(v_spread) || Z.truthy(v_namedArg)))))) {
      Z.setLine(179);
      if (Z.truthy(v_spread)) {
        Z.setLine(180);
        (v___k103 = Z.dup(v_n));
        Z.setLine(180);
        (v___r104 = true);
        Z.setLine(180);
        (v___w105 = Z.B.zs_obj_take(v_this, "named"));
        Z.setLine(180);
        Z.aset((v___w105 = Z.wr(v___w105)), v___k103, Z.dup(v___r104));
        Z.setLine(180);
        Z.B.zs_obj_put(v_this, "named", v___w105);
        Z.setLine(181);
        Z.B.zs_obj_set(v_this, "dyn", true);
        Z.setLine(182);
        return f_Workspace_closures__call(Z.dup(v_line), "zs_call", ((_t941 = Z.arrNew()), Z.apush(_t941, f_Workspace_closures__str(Z.dup(v_line), Z.dup(v_n))), Z.apush(_t941, f_zs_invoke(Z.dup(v_this), "argsArray", ((_t942 = Z.arrNew()), Z.apush(_t942, Z.dup(v_line)), Z.apush(_t942, Z.dup(v_args)), Z.apush(_t942, Z.dup(v_vis)), _t942))), _t941));
      }
      Z.setLine(184);
      return f_zs_invoke(Z.dup(v_this), "reorder", ((_t943 = Z.arrNew()), Z.apush(_t943, Z.dup(v_x)), Z.apush(_t943, Z.dup(v_vis)), _t943));
    }
    Z.setLine(186);
    if (Z.truthy((Z.truthy(v_spread) || Z.truthy(v_namedArg)))) {
      Z.setLine(187);
      f_zs_invoke(Z.dup(v_this), "err", ((_t944 = Z.arrNew()), Z.apush(_t944, Z.dup(v_line)), Z.apush(_t944, Z.concat(Z.concat("argumenty nazwane i rozwinięcie ... niedostępne dla funkcji wbudowanych (", v_n), ")")), _t944));
    }
    Z.setLine(189);
    if (Z.truthy((Z.truthy((Z.truthy(Z.ident(v_n, "zs_spread")) || Z.truthy(Z.ident(v_n, "zs_arg_missing")))) || Z.truthy(Z.ident(v_n, "zs_call"))))) {
      Z.setLine(189);
      Z.B.zs_obj_set(v_this, "sawHelper", true);
    }
    Z.setLine(190);
    return f_zs_invoke(Z.dup(v_this), "plain", ((_t945 = Z.arrNew()), Z.apush(_t945, Z.dup(v_x)), Z.apush(_t945, Z.dup(v_vis)), _t945));
  }
  Z.setLine(192);
  if (Z.truthy((Z.truthy(Z.ident(v_kind, ":Dot")) || Z.truthy(Z.ident(v_kind, ":Prop"))))) {
    Z.setLine(193);
    if (Z.truthy((Z.truthy(v_spread) || Z.truthy(v_namedArg)))) {
      Z.setLine(193);
      f_zs_invoke(Z.dup(v_this), "err", ((_t946 = Z.arrNew()), Z.apush(_t946, Z.dup(v_line)), Z.apush(_t946, "argumenty nazwane i rozwinięcie ... niedostępne dla wywołań modułów wbudowanych"), _t946));
    }
    Z.setLine(194);
    return f_zs_invoke(Z.dup(v_this), "plain", ((_t947 = Z.arrNew()), Z.apush(_t947, Z.dup(v_x)), Z.apush(_t947, Z.dup(v_vis)), _t947));
  }
  Z.setLine(197);
  Z.B.zs_obj_set(v_this, "dyn", true);
  Z.setLine(198);
  return f_Workspace_closures__call(Z.dup(v_line), "zs_call", ((_t948 = Z.arrNew()), Z.apush(_t948, f_zs_invoke(Z.dup(v_this), "rw", ((_t949 = Z.arrNew()), Z.apush(_t949, Z.dup(v_callee)), Z.apush(_t949, Z.dup(v_vis)), _t949))), Z.apush(_t948, f_zs_invoke(Z.dup(v_this), "argsArray", ((_t950 = Z.arrNew()), Z.apush(_t950, Z.dup(v_line)), Z.apush(_t950, Z.dup(v_args)), Z.apush(_t950, Z.dup(v_vis)), _t950))), _t948));
  return null;
}
function f_Lifter__plain(v_this, v_x, v_vis) {
  let v_o = null, v_a = null;
  let _t951 = null, _t952 = null, _t953 = null, _t954 = null;
  Z.setLine(202);
  (v_o = ((_t951 = Z.arrNew()), Z.apush(_t951, ":Call"), Z.apush(_t951, Z.dup(Z.index(v_x, 1))), Z.apush(_t951, f_zs_invoke(Z.dup(v_this), "rw", ((_t952 = Z.arrNew()), Z.apush(_t952, Z.dup(Z.index(v_x, 2))), Z.apush(_t952, Z.dup(v_vis)), _t952))), Z.apush(_t951, ((_t953 = Z.arrNew()), _t953)), _t951));
  Z.setLine(203);
  {
    const _it100 = Z.foreachArr(Z.dup(Z.index(v_x, 3)));
    L100: for (let _i100 = 0; _i100 < _it100.keys.length; _i100++) {
      v_a = _it100.vals[_i100];
      Z.setLine(203);
      Z.aset((v_a = Z.wr(v_a)), 3, f_zs_invoke(Z.dup(v_this), "rw", ((_t954 = Z.arrNew()), Z.apush(_t954, Z.dup(Z.index(v_a, 3))), Z.apush(_t954, Z.dup(v_vis)), _t954)));
      Z.setLine(203);
      Z.apush(Z.wrelem((v_o = Z.wr(v_o)), 3), Z.dup(v_a));
    }
  }
  Z.setLine(204);
  return Z.dup(v_o);
  return null;
}
function f_Lifter__reorder(v_this, v_x, v_vis) {
  let v_line = null, v_n = null, v_ps = null, v_slots = null, v_pos = null, v_maxi = null, v_a = null, v_v = null, v_j = null, v_i = null, v_out = null, v_pn = null;
  let _t955 = null, _t956 = null, _t957 = null, _t958 = null, _t959 = null, _t960 = null, _t961 = null, _t962 = null, _t963 = null, _t964 = null, _t965 = null;
  Z.setLine(209);
  (v_line = Z.dup(Z.index(v_x, 1)));
  Z.setLine(210);
  (v_n = Z.dup(Z.index(Z.index(v_x, 2), 2)));
  Z.setLine(211);
  (v_ps = Z.dup(Z.index(Z.B.zs_obj_get(v_this, "fnp"), v_n)));
  Z.setLine(212);
  (v_slots = ((_t955 = Z.arrNew()), _t955));
  Z.setLine(213);
  (v_pos = 0);
  Z.setLine(214);
  (v_maxi = Z.neg(1));
  Z.setLine(215);
  {
    const _it101 = Z.foreachArr(Z.dup(Z.index(v_x, 3)));
    L101: for (let _i101 = 0; _i101 < _it101.keys.length; _i101++) {
      v_a = _it101.vals[_i101];
      Z.setLine(216);
      (v_v = f_zs_invoke(Z.dup(v_this), "rw", ((_t956 = Z.arrNew()), Z.apush(_t956, Z.dup(Z.index(v_a, 3))), Z.apush(_t956, Z.dup(v_vis)), _t956)));
      Z.setLine(217);
      if (Z.truthy(Z.ident(Z.index(v_a, 2), null))) {
        Z.setLine(218);
        Z.aset((v_slots = Z.wr(v_slots)), v_pos, Z.dup(v_v));
        Z.setLine(219);
        if (Z.truthy((Z.cmp(v_pos, v_maxi) > 0))) {
          Z.setLine(219);
          (v_maxi = Z.dup(v_pos));
        }
        Z.setLine(220);
        ((_t957 = v_pos), (v_pos = Z.add(_t957, 1)), _t957);
        continue L101;
      }
      Z.setLine(223);
      (v_j = Z.neg(1));
      Z.setLine(224);
      (v_i = 0);
      L102: for (; Z.truthy((Z.cmp(v_i, Z.B.count(v_ps)) < 0)); ((_t958 = v_i), (v_i = Z.add(_t958, 1)), _t958)) {
        Z.setLine(224);
        if (Z.truthy((Z.truthy(Z.ident(Z.index(Z.index(v_ps, v_i), 2), Z.index(v_a, 2))) && Z.truthy(!Z.truthy(Z.index(Z.index(v_ps, v_i), 5)))))) {
          Z.setLine(224);
          (v_j = Z.dup(v_i));
        }
      }
      Z.setLine(225);
      if (Z.truthy((Z.cmp(v_j, 0) < 0))) {
        Z.setLine(225);
        f_zs_invoke(Z.dup(v_this), "err", ((_t959 = Z.arrNew()), Z.apush(_t959, Z.dup(v_line)), Z.apush(_t959, Z.concat(Z.concat(Z.concat(v_n, ": nieznany argument nazwany `"), Z.index(v_a, 2)), "`")), _t959));
        Z.setLine(225);
        return Z.dup(v_x);
      }
      Z.setLine(226);
      if (Z.truthy(Z.B.has_key(v_slots, v_j))) {
        Z.setLine(226);
        f_zs_invoke(Z.dup(v_this), "err", ((_t960 = Z.arrNew()), Z.apush(_t960, Z.dup(v_line)), Z.apush(_t960, Z.concat(Z.concat(Z.concat(v_n, ": argument `"), Z.index(v_a, 2)), "` podany dwukrotnie")), _t960));
        Z.setLine(226);
        return Z.dup(v_x);
      }
      Z.setLine(227);
      Z.aset((v_slots = Z.wr(v_slots)), v_j, Z.dup(v_v));
      Z.setLine(228);
      if (Z.truthy((Z.cmp(v_j, v_maxi) > 0))) {
        Z.setLine(228);
        (v_maxi = Z.dup(v_j));
      }
    }
  }
  Z.setLine(230);
  (v_out = ((_t961 = Z.arrNew()), _t961));
  Z.setLine(231);
  (v_i = 0);
  L103: for (; Z.truthy((Z.cmp(v_i, v_maxi) <= 0)); ((_t962 = v_i), (v_i = Z.add(_t962, 1)), _t962)) {
    Z.setLine(232);
    if (Z.truthy(Z.B.has_key(v_slots, v_i))) {
      Z.setLine(232);
      Z.apush((v_out = Z.wr(v_out)), f_Workspace_closures__arg(Z.dup(Z.index(v_slots, v_i))));
      continue L103;
    }
    Z.setLine(233);
    if (Z.truthy((Z.truthy((Z.cmp(v_i, Z.B.count(v_ps)) < 0)) && Z.truthy(!Z.ident(Z.index(Z.index(v_ps, v_i), 4), null))))) {
      Z.setLine(233);
      Z.apush((v_out = Z.wr(v_out)), f_Workspace_closures__arg(f_zs_invoke(Z.dup(v_this), "rw", ((_t963 = Z.arrNew()), Z.apush(_t963, Z.dup(Z.index(Z.index(v_ps, v_i), 4))), Z.apush(_t963, Z.dup(v_vis)), _t963))));
      continue L103;
    }
    Z.setLine(234);
    (v_pn = (Z.truthy((Z.cmp(v_i, Z.B.count(v_ps)) < 0)) ? Z.index(Z.index(v_ps, v_i), 2) : "?"));
    Z.setLine(235);
    f_zs_invoke(Z.dup(v_this), "err", ((_t964 = Z.arrNew()), Z.apush(_t964, Z.dup(v_line)), Z.apush(_t964, Z.concat(Z.concat(v_n, ": brak argumentu $"), v_pn)), _t964));
    Z.setLine(236);
    return Z.dup(v_x);
  }
  Z.setLine(238);
  return ((_t965 = Z.arrNew()), Z.apush(_t965, ":Call"), Z.apush(_t965, Z.dup(v_line)), Z.apush(_t965, Z.dup(Z.index(v_x, 2))), Z.apush(_t965, Z.dup(v_out)), _t965);
  return null;
}
function f_Lifter__helpers(v_this) {
  let v_line = null, v_out = null, v_src = null, v_s = null;
  let _t966 = null, _t967 = null;
  Z.setLine(242);
  (v_line = 0);
  Z.setLine(243);
  (v_out = ((_t966 = Z.arrNew()), _t966));
  Z.setLine(244);
  if (Z.truthy((Z.truthy((Z.truthy((Z.cmp(Z.B.zs_obj_get(v_this, "n"), 0) > 0)) || Z.truthy(Z.B.zs_obj_get(v_this, "dyn")))) || Z.truthy((Z.cmp(Z.B.count(Z.B.zs_obj_get(v_this, "named")), 0) > 0))))) {
    Z.setLine(244);
    Z.apush((v_out = Z.wr(v_out)), f_zs_invoke(Z.dup(v_this), "dispatcher", ((_t967 = Z.arrNew()), _t967)));
  }
  Z.setLine(245);
  (v_src = Z.concat(Z.concat("func zs_arg_missing($f, $p) { throw new Error($f . \": brak argumentu $\" . $p); } ", "func zs_not_callable($f) { throw new Error(\"wartość typu \" . typeof($f) . \" nie jest wywoływalna\"); } "), "func zs_spread($a, $b) { foreach ($b as $k => $v) { if (is_int($k)) { $a[] = $v; } else { $a[$k] = $v; } } return $a; }"));
  Z.setLine(248);
  {
    const _it104 = Z.foreachArr(f_Workspace_parser__parse(Z.dup(v_src)));
    L104: for (let _i104 = 0; _i104 < _it104.keys.length; _i104++) {
      v_s = _it104.vals[_i104];
      Z.setLine(248);
      Z.apush((v_out = Z.wr(v_out)), Z.dup(v_s));
    }
  }
  Z.setLine(249);
  return Z.dup(v_out);
  return null;
}
function f_Lifter__dispatcher(v_this) {
  let v_line = null, v_body = null, v_id = null, v_ps = null, v_args = null, v_fname = null, v_t = null;
  let _t968 = null, _t969 = null, _t970 = null, _t971 = null, _t972 = null, _t973 = null, _t974 = null, _t975 = null, _t976 = null, _t977 = null, _t978 = null, _t979 = null, _t980 = null, _t981 = null, _t982 = null, _t983 = null, _t984 = null, _t985 = null, _t986 = null, _t987 = null, _t988 = null, _t989 = null, _t990 = null;
  Z.setLine(253);
  (v_line = 0);
  Z.setLine(254);
  (v_body = ((_t968 = Z.arrNew()), _t968));
  Z.setLine(255);
  Z.apush((v_body = Z.wr(v_body)), ((_t969 = Z.arrNew()), Z.apush(_t969, ":Expr"), Z.apush(_t969, Z.dup(v_line)), Z.apush(_t969, ((_t970 = Z.arrNew()), Z.apush(_t970, ":Assign"), Z.apush(_t970, Z.dup(v_line)), Z.apush(_t970, f_Workspace_closures__var(Z.dup(v_line), "id")), Z.apush(_t970, f_Workspace_closures__call(Z.dup(v_line), "zs_fn_id", ((_t971 = Z.arrNew()), Z.apush(_t971, f_Workspace_closures__var(Z.dup(v_line), "f")), _t971))), _t970)), _t969));
  Z.setLine(256);
  Z.apush((v_body = Z.wr(v_body)), ((_t972 = Z.arrNew()), Z.apush(_t972, ":Expr"), Z.apush(_t972, Z.dup(v_line)), Z.apush(_t972, ((_t973 = Z.arrNew()), Z.apush(_t973, ":Assign"), Z.apush(_t973, Z.dup(v_line)), Z.apush(_t973, f_Workspace_closures__var(Z.dup(v_line), "cap")), Z.apush(_t973, f_Workspace_closures__call(Z.dup(v_line), "zs_fn_cap", ((_t974 = Z.arrNew()), Z.apush(_t974, f_Workspace_closures__var(Z.dup(v_line), "f")), _t974))), _t973)), _t972));
  Z.setLine(257);
  {
    const _it105 = Z.foreachArr(Z.B.zs_obj_get(v_this, "lams"));
    L105: for (let _i105 = 0; _i105 < _it105.keys.length; _i105++) {
      v_ps = _it105.vals[_i105];
      v_id = _it105.keys[_i105];
      Z.setLine(258);
      (v_args = f_Workspace_closures__prepend(f_Workspace_closures__arg(f_Workspace_closures__var(Z.dup(v_line), "cap")), f_Workspace_closures__bindArgs(Z.dup(v_line), Z.dup(v_ps), "args", "{closure}")));
      Z.setLine(259);
      Z.apush((v_body = Z.wr(v_body)), ((_t975 = Z.arrNew()), Z.apush(_t975, ":If"), Z.apush(_t975, Z.dup(v_line)), Z.apush(_t975, ((_t976 = Z.arrNew()), Z.apush(_t976, ":Binary"), Z.apush(_t976, Z.dup(v_line)), Z.apush(_t976, "Identical"), Z.apush(_t976, f_Workspace_closures__var(Z.dup(v_line), "id")), Z.apush(_t976, f_Workspace_closures__intl(Z.dup(v_line), Z.dup(v_id))), _t976)), Z.apush(_t975, ((_t977 = Z.arrNew()), Z.apush(_t977, ((_t978 = Z.arrNew()), Z.apush(_t978, ":Return"), Z.apush(_t978, Z.dup(v_line)), Z.apush(_t978, ((_t979 = Z.arrNew()), Z.apush(_t979, ":Call"), Z.apush(_t979, Z.dup(v_line)), Z.apush(_t979, f_Workspace_closures__nm(Z.dup(v_line), Z.concat("__lam", v_id))), Z.apush(_t979, Z.dup(v_args)), _t979)), _t978)), _t977)), Z.apush(_t975, null), _t975));
    }
  }
  Z.setLine(262);
  {
    const _it106 = Z.foreachArr(Z.B.zs_obj_get(v_this, "named"));
    L106: for (let _i106 = 0; _i106 < _it106.keys.length; _i106++) {
      v_t = _it106.vals[_i106];
      v_fname = _it106.keys[_i106];
      Z.setLine(263);
      Z.apush((v_body = Z.wr(v_body)), ((_t980 = Z.arrNew()), Z.apush(_t980, ":If"), Z.apush(_t980, Z.dup(v_line)), Z.apush(_t980, ((_t981 = Z.arrNew()), Z.apush(_t981, ":Binary"), Z.apush(_t981, Z.dup(v_line)), Z.apush(_t981, "Identical"), Z.apush(_t981, f_Workspace_closures__var(Z.dup(v_line), "id")), Z.apush(_t981, f_Workspace_closures__str(Z.dup(v_line), Z.dup(v_fname))), _t981)), Z.apush(_t980, ((_t982 = Z.arrNew()), Z.apush(_t982, ((_t983 = Z.arrNew()), Z.apush(_t983, ":Return"), Z.apush(_t983, Z.dup(v_line)), Z.apush(_t983, ((_t984 = Z.arrNew()), Z.apush(_t984, ":Call"), Z.apush(_t984, Z.dup(v_line)), Z.apush(_t984, f_Workspace_closures__nm(Z.dup(v_line), Z.dup(v_fname))), Z.apush(_t984, f_Workspace_closures__bindArgs(Z.dup(v_line), Z.dup(Z.index(Z.B.zs_obj_get(v_this, "fnp"), v_fname)), "args", Z.dup(v_fname))), _t984)), _t983)), _t982)), Z.apush(_t980, null), _t980));
    }
  }
  Z.setLine(266);
  Z.apush((v_body = Z.wr(v_body)), ((_t985 = Z.arrNew()), Z.apush(_t985, ":Return"), Z.apush(_t985, Z.dup(v_line)), Z.apush(_t985, f_Workspace_closures__call(Z.dup(v_line), "zs_not_callable", ((_t986 = Z.arrNew()), Z.apush(_t986, f_Workspace_closures__var(Z.dup(v_line), "f")), _t986))), _t985));
  Z.setLine(267);
  return ((_t987 = Z.arrNew()), Z.apush(_t987, ":FuncStmt"), Z.apush(_t987, Z.dup(v_line)), Z.apush(_t987, ((_t988 = Z.arrNew()), Z.apush(_t988, ":Func"), Z.apush(_t988, Z.dup(v_line)), Z.apush(_t988, "zs_call"), Z.apush(_t988, ((_t989 = Z.arrNew()), Z.apush(_t989, f_Workspace_closures__param("f")), Z.apush(_t989, f_Workspace_closures__param("args")), _t989)), Z.apush(_t988, ((_t990 = Z.arrNew()), _t990)), Z.apush(_t988, Z.dup(v_body)), Z.apush(_t988, false), _t988)), _t987);
  return null;
}
function f_Lifter__new() {
  let v___o = null;
  let _t991 = null, _t992 = null, _t993 = null, _t994 = null, _t995 = null, _t996 = null;
  Z.setLine(50);
  (v___o = Z.B.zs_obj_new("Lifter"));
  Z.setLine(50);
  Z.B.zs_obj_set(v___o, "n", 0);
  Z.setLine(50);
  Z.B.zs_obj_set(v___o, "out", ((_t991 = Z.arrNew()), _t991));
  Z.setLine(50);
  Z.B.zs_obj_set(v___o, "lams", ((_t992 = Z.arrNew()), _t992));
  Z.setLine(50);
  Z.B.zs_obj_set(v___o, "fnp", ((_t993 = Z.arrNew()), _t993));
  Z.setLine(50);
  Z.B.zs_obj_set(v___o, "named", ((_t994 = Z.arrNew()), _t994));
  Z.setLine(50);
  Z.B.zs_obj_set(v___o, "dyn", false);
  Z.setLine(50);
  Z.B.zs_obj_set(v___o, "usesSpread", false);
  Z.setLine(50);
  Z.B.zs_obj_set(v___o, "sawHelper", false);
  Z.setLine(50);
  Z.B.zs_obj_set(v___o, "errors", ((_t995 = Z.arrNew()), _t995));
  Z.setLine(50);
  Z.B.zs_obj_set(v___o, "acc", ((_t996 = Z.arrNew()), _t996));
  Z.setLine(50);
  return Z.dup(v___o);
  return null;
}
function f_Cls__new() {
  let v___o = null;
  let _t997 = null, _t998 = null, _t999 = null;
  Z.setLine(20);
  (v___o = Z.B.zs_obj_new("Cls"));
  Z.setLine(20);
  Z.B.zs_obj_set(v___o, "name", null);
  Z.setLine(20);
  Z.B.zs_obj_set(v___o, "parent", null);
  Z.setLine(20);
  Z.B.zs_obj_set(v___o, "ifaces", null);
  Z.setLine(20);
  Z.B.zs_obj_set(v___o, "line", null);
  Z.setLine(20);
  Z.B.zs_obj_set(v___o, "props", ((_t997 = Z.arrNew()), _t997));
  Z.setLine(20);
  Z.B.zs_obj_set(v___o, "consts", ((_t998 = Z.arrNew()), _t998));
  Z.setLine(20);
  Z.B.zs_obj_set(v___o, "methods", ((_t999 = Z.arrNew()), _t999));
  Z.setLine(20);
  return Z.dup(v___o);
  return null;
}
function f_Desugar__err(v_this, v_line, v_msg) {
  let v___r106 = null, v___w107 = null;
  let _t1000 = null;
  Z.setLine(38);
  (v___r106 = ((_t1000 = Z.arrNew()), Z.apush(_t1000, Z.dup(v_line)), Z.apush(_t1000, "E0108"), Z.apush(_t1000, Z.dup(v_msg)), _t1000));
  Z.setLine(38);
  (v___w107 = Z.B.zs_obj_take(v_this, "errors"));
  Z.setLine(38);
  Z.apush((v___w107 = Z.wr(v___w107)), Z.dup(v___r106));
  Z.setLine(38);
  Z.B.zs_obj_put(v_this, "errors", v___w107);
  return null;
}
function f_Desugar__node(v_this, v_k, v_line, v_a, v_b, v_c, v_d) {
  let _t1001 = null;
  Z.setLine(40);
  return ((_t1001 = Z.arrNew()), Z.apush(_t1001, Z.concat(":", v_k)), Z.apush(_t1001, Z.dup(v_line)), Z.apush(_t1001, Z.dup(v_a)), Z.apush(_t1001, Z.dup(v_b)), Z.apush(_t1001, Z.dup(v_c)), Z.apush(_t1001, Z.dup(v_d)), _t1001);
  return null;
}
function f_Desugar__nm(v_this, v_line, v_n) {
  let _t1002 = null;
  Z.setLine(41);
  return ((_t1002 = Z.arrNew()), Z.apush(_t1002, ":Name"), Z.apush(_t1002, Z.dup(v_line)), Z.apush(_t1002, Z.dup(v_n)), _t1002);
  return null;
}
function f_Desugar__mkstr(v_this, v_line, v_s) {
  let _t1003 = null;
  Z.setLine(42);
  return ((_t1003 = Z.arrNew()), Z.apush(_t1003, ":Str"), Z.apush(_t1003, Z.dup(v_line)), Z.apush(_t1003, Z.dup(v_s)), _t1003);
  return null;
}
function f_Desugar__mkvar(v_this, v_line, v_n) {
  let _t1004 = null;
  Z.setLine(43);
  return ((_t1004 = Z.arrNew()), Z.apush(_t1004, ":Var"), Z.apush(_t1004, Z.dup(v_line)), Z.apush(_t1004, Z.dup(v_n)), _t1004);
  return null;
}
function f_Desugar__call(v_this, v_line, v_fn, v_args) {
  let v_as = null, v_a = null;
  let _t1005 = null, _t1006 = null, _t1007 = null, _t1008 = null;
  Z.setLine(45);
  (v_as = ((_t1005 = Z.arrNew()), _t1005));
  Z.setLine(46);
  {
    const _it107 = Z.foreachArr(Z.dup(v_args));
    L107: for (let _i107 = 0; _i107 < _it107.keys.length; _i107++) {
      v_a = _it107.vals[_i107];
      Z.setLine(46);
      Z.apush((v_as = Z.wr(v_as)), ((_t1006 = Z.arrNew()), Z.apush(_t1006, ":Arg"), Z.apush(_t1006, 0), Z.apush(_t1006, null), Z.apush(_t1006, Z.dup(v_a)), Z.apush(_t1006, false), _t1006));
    }
  }
  Z.setLine(47);
  return ((_t1007 = Z.arrNew()), Z.apush(_t1007, ":Call"), Z.apush(_t1007, Z.dup(v_line)), Z.apush(_t1007, f_zs_invoke(Z.dup(v_this), "nm", ((_t1008 = Z.arrNew()), Z.apush(_t1008, Z.dup(v_line)), Z.apush(_t1008, Z.dup(v_fn)), _t1008))), Z.apush(_t1007, Z.dup(v_as)), _t1007);
  return null;
}
function f_Desugar__fresh(v_this, v_p) {
  Z.setLine(49);
  Z.B.zs_obj_set(v_this, "tmp", Z.add(Z.B.zs_obj_get(v_this, "tmp"), 1));
  Z.setLine(49);
  return Z.concat(Z.concat("__", v_p), Z.B.zs_obj_get(v_this, "tmp"));
  return null;
}
function f_Desugar__collect(v_this, v_ast) {
  let v_s = null, v_c = null, v_k = null, v_p = null, v___k108 = null, v___r109 = null, v___w110 = null, v_cn = null, v___k111 = null, v___r112 = null, v___w113 = null, v_m = null, v___k114 = null, v___r115 = null, v___w116 = null, v___k117 = null, v___r118 = null, v___w119 = null;
  let _t1009 = null, _t1010 = null, _t1011 = null;
  Z.setLine(53);
  {
    const _it108 = Z.foreachArr(Z.dup(v_ast));
    L108: for (let _i108 = 0; _i108 < _it108.keys.length; _i108++) {
      v_s = _it108.vals[_i108];
      Z.setLine(54);
      if (Z.truthy(!Z.ident(Z.index(v_s, 0), ":ClassStmt"))) {
        continue L108;
      }
      Z.setLine(55);
      (v_c = Z.dup(Z.index(v_s, 2)));
      Z.setLine(56);
      (v_k = f_Cls__new());
      Z.setLine(57);
      Z.B.zs_obj_set(v_k, "name", Z.index(v_c, 2));
      Z.setLine(57);
      Z.B.zs_obj_set(v_k, "parent", Z.index(v_c, 3));
      Z.setLine(57);
      Z.B.zs_obj_set(v_k, "ifaces", Z.index(v_c, 4));
      Z.setLine(57);
      Z.B.zs_obj_set(v_k, "line", Z.index(v_s, 1));
      Z.setLine(58);
      {
        const _it109 = Z.foreachArr(Z.dup(Z.index(v_c, 7)));
        L109: for (let _i109 = 0; _i109 < _it109.keys.length; _i109++) {
          v_p = _it109.vals[_i109];
          Z.setLine(58);
          (v___k108 = Z.dup(Z.index(v_p, 2)));
          Z.setLine(58);
          (v___r109 = ((_t1009 = Z.arrNew()), Z.aset(_t1009, "default", Z.dup(Z.index(v_p, 3))), Z.aset(_t1009, "static", Z.dup(Z.index(v_p, 4))), _t1009));
          Z.setLine(58);
          (v___w110 = Z.B.zs_obj_take(v_k, "props"));
          Z.setLine(58);
          Z.aset((v___w110 = Z.wr(v___w110)), v___k108, Z.dup(v___r109));
          Z.setLine(58);
          Z.B.zs_obj_put(v_k, "props", v___w110);
        }
      }
      Z.setLine(59);
      {
        const _it110 = Z.foreachArr(Z.dup(Z.index(v_c, 8)));
        L110: for (let _i110 = 0; _i110 < _it110.keys.length; _i110++) {
          v_cn = _it110.vals[_i110];
          Z.setLine(59);
          (v___k111 = Z.dup(Z.index(v_cn, 2)));
          Z.setLine(59);
          (v___r112 = Z.dup(Z.index(v_cn, 3)));
          Z.setLine(59);
          (v___w113 = Z.B.zs_obj_take(v_k, "consts"));
          Z.setLine(59);
          Z.aset((v___w113 = Z.wr(v___w113)), v___k111, Z.dup(v___r112));
          Z.setLine(59);
          Z.B.zs_obj_put(v_k, "consts", v___w113);
        }
      }
      Z.setLine(60);
      {
        const _it111 = Z.foreachArr(Z.dup(Z.index(v_c, 9)));
        L111: for (let _i111 = 0; _i111 < _it111.keys.length; _i111++) {
          v_m = _it111.vals[_i111];
          Z.setLine(60);
          (v___k114 = Z.dup(Z.index(Z.index(v_m, 2), 2)));
          Z.setLine(60);
          (v___r115 = ((_t1010 = Z.arrNew()), Z.aset(_t1010, "decl", Z.dup(Z.index(v_m, 2))), Z.aset(_t1010, "static", Z.dup(Z.index(v_m, 3))), Z.aset(_t1010, "abstract", Z.dup(Z.index(v_m, 4))), _t1010));
          Z.setLine(60);
          (v___w116 = Z.B.zs_obj_take(v_k, "methods"));
          Z.setLine(60);
          Z.aset((v___w116 = Z.wr(v___w116)), v___k114, Z.dup(v___r115));
          Z.setLine(60);
          Z.B.zs_obj_put(v_k, "methods", v___w116);
        }
      }
      Z.setLine(61);
      if (Z.truthy(Z.B.has_key(Z.B.zs_obj_get(v_this, "classes"), Z.B.zs_obj_get(v_k, "name")))) {
        Z.setLine(61);
        f_zs_invoke(Z.dup(v_this), "err", ((_t1011 = Z.arrNew()), Z.apush(_t1011, Z.dup(Z.index(v_s, 1))), Z.apush(_t1011, Z.concat(Z.concat("klasa ", Z.B.zs_obj_get(v_k, "name")), " zdefiniowana wielokrotnie")), _t1011));
      }
      Z.setLine(62);
      (v___k117 = Z.B.zs_obj_get(v_k, "name"));
      Z.setLine(62);
      (v___r118 = Z.dup(v_k));
      Z.setLine(62);
      (v___w119 = Z.B.zs_obj_take(v_this, "classes"));
      Z.setLine(62);
      Z.aset((v___w119 = Z.wr(v___w119)), v___k117, Z.dup(v___r118));
      Z.setLine(62);
      Z.B.zs_obj_put(v_this, "classes", v___w119);
    }
  }
  return null;
}
function f_Desugar__chain(v_this, v_name) {
  let v_out = null, v_n = null;
  let _t1012 = null;
  Z.setLine(67);
  (v_out = ((_t1012 = Z.arrNew()), _t1012));
  Z.setLine(68);
  (v_n = Z.dup(v_name));
  L112: while (true) {
    Z.setLine(69);
    if (!Z.truthy((Z.truthy((Z.truthy(!Z.ident(v_n, null)) && Z.truthy(Z.B.has_key(Z.B.zs_obj_get(v_this, "classes"), v_n)))) && Z.truthy((Z.cmp(Z.B.count(v_out), 64) < 0))))) break;
    Z.setLine(69);
    Z.apush((v_out = Z.wr(v_out)), Z.dup(v_n));
    Z.setLine(69);
    (v_n = Z.B.zs_obj_get(Z.index(Z.B.zs_obj_get(v_this, "classes"), v_n), "parent"));
  }
  Z.setLine(70);
  return Z.dup(v_out);
  return null;
}
function f_Desugar__owner(v_this, v_cls, v_m) {
  let v_n = null;
  let _t1013 = null;
  Z.setLine(75);
  {
    const _it113 = Z.foreachArr(f_zs_invoke(Z.dup(v_this), "chain", ((_t1013 = Z.arrNew()), Z.apush(_t1013, Z.dup(v_cls)), _t1013)));
    L113: for (let _i113 = 0; _i113 < _it113.keys.length; _i113++) {
      v_n = _it113.vals[_i113];
      Z.setLine(76);
      if (Z.truthy((Z.truthy(Z.B.has_key(Z.B.zs_obj_get(Z.index(Z.B.zs_obj_get(v_this, "classes"), v_n), "methods"), v_m)) && Z.truthy(!Z.truthy(Z.index(Z.index(Z.B.zs_obj_get(Z.index(Z.B.zs_obj_get(v_this, "classes"), v_n), "methods"), v_m), "abstract")))))) {
        Z.setLine(76);
        return Z.dup(v_n);
      }
    }
  }
  Z.setLine(78);
  return null;
  return null;
}
function f_Desugar__allProps(v_this, v_cls) {
  let v_names = null, v_out = null, v_n = null, v_p = null, v_d = null;
  let _t1014 = null, _t1015 = null, _t1016 = null, _t1017 = null, _t1018 = null;
  Z.setLine(82);
  (v_names = f_Workspace_classes__array_reverse_names(f_zs_invoke(Z.dup(v_this), "chain", ((_t1014 = Z.arrNew()), Z.apush(_t1014, Z.dup(v_cls)), _t1014))));
  Z.setLine(83);
  (v_out = ((_t1015 = Z.arrNew()), _t1015));
  Z.setLine(84);
  {
    const _it114 = Z.foreachArr(Z.dup(v_names));
    L114: for (let _i114 = 0; _i114 < _it114.keys.length; _i114++) {
      v_n = _it114.vals[_i114];
      Z.setLine(85);
      {
        const _it115 = Z.foreachArr(Z.B.zs_obj_get(Z.index(Z.B.zs_obj_get(v_this, "classes"), v_n), "props"));
        L115: for (let _i115 = 0; _i115 < _it115.keys.length; _i115++) {
          v_d = _it115.vals[_i115];
          v_p = _it115.keys[_i115];
          Z.setLine(86);
          if (Z.truthy(Z.index(v_d, "static"))) {
            continue L115;
          }
          Z.setLine(87);
          if (Z.truthy(!Z.truthy(Z.B.has_key(v_out, v_p)))) {
            Z.setLine(87);
            Z.aset((v_out = Z.wr(v_out)), v_p, ((_t1016 = Z.arrNew()), Z.aset(_t1016, "default", Z.dup(Z.index(v_d, "default"))), Z.aset(_t1016, "cls", Z.dup(v_n)), _t1016));
          } else {
            Z.setLine(88);
            Z.aset((v_out = Z.wr(v_out)), v_p, ((_t1017 = Z.arrNew()), Z.aset(_t1017, "default", (((_t1018 = Z.indexOpt(v_d, "default")) !== null) ? _t1018 : Z.dup(Z.index(Z.index(v_out, v_p), "default")))), Z.aset(_t1017, "cls", Z.dup(v_n)), _t1017));
          }
        }
      }
    }
  }
  Z.setLine(91);
  return Z.dup(v_out);
  return null;
}
function f_Desugar__isaNames(v_this, v_cls) {
  let v_out = null, v_stack = null, v_n = null, v_c = null, v_i = null;
  let _t1019 = null, _t1020 = null;
  Z.setLine(95);
  (v_out = ((_t1019 = Z.arrNew()), _t1019));
  Z.setLine(96);
  (v_stack = ((_t1020 = Z.arrNew()), Z.apush(_t1020, Z.dup(v_cls)), _t1020));
  L116: while (true) {
    Z.setLine(97);
    if (!Z.truthy((Z.cmp(Z.B.count(v_stack), 0) > 0))) break;
    Z.setLine(98);
    (v_n = Z.dup(Z.index(v_stack, Z.sub(Z.B.count(v_stack), 1))));
    Z.setLine(99);
    (v_stack = Z.B.array_slice(v_stack, 0, Z.sub(Z.B.count(v_stack), 1)));
    Z.setLine(100);
    if (Z.truthy(Z.B.in_array(v_n, v_out))) {
      continue L116;
    }
    Z.setLine(101);
    Z.apush((v_out = Z.wr(v_out)), Z.dup(v_n));
    Z.setLine(102);
    if (Z.truthy(Z.ident(v_n, "Exception"))) {
      Z.setLine(102);
      Z.apush((v_out = Z.wr(v_out)), "Throwable");
    }
    Z.setLine(103);
    if (Z.truthy(Z.B.has_key(Z.B.zs_obj_get(v_this, "classes"), v_n))) {
      Z.setLine(104);
      (v_c = Z.dup(Z.index(Z.B.zs_obj_get(v_this, "classes"), v_n)));
      Z.setLine(105);
      if (Z.truthy(!Z.ident(Z.B.zs_obj_get(v_c, "parent"), null))) {
        Z.setLine(105);
        Z.apush((v_stack = Z.wr(v_stack)), Z.B.zs_obj_get(v_c, "parent"));
      }
      Z.setLine(106);
      {
        const _it117 = Z.foreachArr(Z.B.zs_obj_get(v_c, "ifaces"));
        L117: for (let _i117 = 0; _i117 < _it117.keys.length; _i117++) {
          v_i = _it117.vals[_i117];
          Z.setLine(106);
          Z.apush((v_stack = Z.wr(v_stack)), Z.dup(v_i));
        }
      }
    }
  }
  Z.setLine(109);
  return Z.dup(v_out);
  return null;
}
function f_Desugar__rwList(v_this, v_xs) {
  let v_o = null, v_x = null, v_r = null, v_y = null;
  let _t1021 = null, _t1022 = null, _t1023 = null;
  Z.setLine(114);
  (v_o = ((_t1021 = Z.arrNew()), _t1021));
  Z.setLine(115);
  {
    const _it118 = Z.foreachArr(Z.dup(v_xs));
    L118: for (let _i118 = 0; _i118 < _it118.keys.length; _i118++) {
      v_x = _it118.vals[_i118];
      Z.setLine(116);
      if (Z.truthy((Z.truthy(f_Workspace_parser__isNode(Z.dup(v_x))) && Z.truthy(Z.ident(Z.index(v_x, 0), ":Expr"))))) {
        Z.setLine(117);
        (v_r = f_zs_invoke(Z.dup(v_this), "stmtExpr", ((_t1022 = Z.arrNew()), Z.apush(_t1022, Z.dup(v_x)), _t1022)));
        Z.setLine(118);
        if (Z.truthy(!Z.ident(v_r, null))) {
          Z.setLine(118);
          {
            const _it119 = Z.foreachArr(Z.dup(v_r));
            L119: for (let _i119 = 0; _i119 < _it119.keys.length; _i119++) {
              v_y = _it119.vals[_i119];
              Z.setLine(118);
              Z.apush((v_o = Z.wr(v_o)), Z.dup(v_y));
            }
          }
          continue L118;
        }
      }
      Z.setLine(120);
      Z.apush((v_o = Z.wr(v_o)), f_zs_invoke(Z.dup(v_this), "rw", ((_t1023 = Z.arrNew()), Z.apush(_t1023, Z.dup(v_x)), _t1023)));
    }
  }
  Z.setLine(122);
  return Z.dup(v_o);
  return null;
}
function f_Desugar__rw(v_this, v_x) {
  let v_o = null, v_k = null, v_v = null, v_line = null, v_r = null, v_cn = null, v_sn = null, v_t = null, v_i = null;
  let _t1024 = null, _t1025 = null, _t1026 = null, _t1027 = null, _t1028 = null, _t1029 = null, _t1030 = null, _t1031 = null, _t1032 = null, _t1033 = null, _t1034 = null, _t1035 = null, _t1036 = null, _t1037 = null, _t1038 = null, _t1039 = null, _t1040 = null, _t1041 = null, _t1042 = null, _t1043 = null, _t1044 = null, _t1045 = null, _t1046 = null, _t1047 = null, _t1048 = null, _t1049 = null, _t1050 = null, _t1051 = null, _t1052 = null, _t1053 = null, _t1054 = null, _t1055 = null, _t1056 = null, _t1057 = null, _t1058 = null, _t1059 = null, _t1060 = null, _t1061 = null, _t1062 = null, _t1063 = null, _t1064 = null, _t1065 = null, _t1066 = null, _t1067 = null, _t1068 = null, _t1069 = null, _t1070 = null, _t1071 = null, _t1072 = null, _t1073 = null, _t1074 = null, _t1075 = null, _t1076 = null, _t1077 = null, _t1078 = null, _t1079 = null, _t1080 = null, _t1081 = null, _t1082 = null, _t1083 = null, _t1084 = null, _t1085 = null, _t1086 = null, _t1087 = null;
  Z.setLine(126);
  if (Z.truthy(!Z.truthy(Z.B.is_array(v_x)))) {
    Z.setLine(126);
    return Z.dup(v_x);
  }
  Z.setLine(127);
  if (Z.truthy(!Z.truthy(f_Workspace_parser__isNode(Z.dup(v_x))))) {
    Z.setLine(128);
    (v_o = ((_t1024 = Z.arrNew()), _t1024));
    Z.setLine(129);
    {
      const _it120 = Z.foreachArr(Z.dup(v_x));
      L120: for (let _i120 = 0; _i120 < _it120.keys.length; _i120++) {
        v_v = _it120.vals[_i120];
        v_k = _it120.keys[_i120];
        Z.setLine(130);
        if (Z.truthy((Z.truthy((Z.truthy(Z.B.is_array(v_v)) && Z.truthy((Z.cmp(Z.B.count(v_v), 0) > 0)))) && Z.truthy(f_Workspace_parser__isNode((((_t1025 = Z.indexOpt(v_v, 0)) !== null) ? _t1025 : null)))))) {
          Z.setLine(130);
          Z.aset((v_o = Z.wr(v_o)), v_k, f_zs_invoke(Z.dup(v_this), "rwList", ((_t1026 = Z.arrNew()), Z.apush(_t1026, Z.dup(v_v)), _t1026)));
        } else {
          Z.setLine(131);
          Z.aset((v_o = Z.wr(v_o)), v_k, f_zs_invoke(Z.dup(v_this), "rw", ((_t1027 = Z.arrNew()), Z.apush(_t1027, Z.dup(v_v)), _t1027)));
        }
      }
    }
    Z.setLine(133);
    return Z.dup(v_o);
  }
  Z.setLine(135);
  (v_k = Z.dup(Z.index(v_x, 0)));
  Z.setLine(136);
  (v_line = Z.dup(Z.index(v_x, 1)));
  Z.setLine(137);
  if (Z.truthy(Z.ident(v_k, ":Expr"))) {
    Z.setLine(138);
    (v_r = f_zs_invoke(Z.dup(v_this), "stmtExpr", ((_t1028 = Z.arrNew()), Z.apush(_t1028, Z.dup(v_x)), _t1028)));
    Z.setLine(139);
    if (Z.truthy(!Z.ident(v_r, null))) {
      Z.setLine(139);
      return (Z.truthy(Z.ident(Z.B.count(v_r), 1)) ? Z.index(v_r, 0) : ((_t1029 = Z.arrNew()), Z.apush(_t1029, ":Block"), Z.apush(_t1029, Z.dup(v_line)), Z.apush(_t1029, Z.dup(v_r)), _t1029));
    }
  }
  Z.setLine(141);
  if (Z.truthy((Z.truthy((Z.truthy(Z.ident(v_k, ":Try")) && Z.truthy(Z.B.zs_obj_get(v_this, "excMode")))) && Z.truthy((Z.cmp(Z.B.count(Z.index(v_x, 3)), 0) > 0))))) {
    Z.setLine(141);
    return f_zs_invoke(Z.dup(v_this), "rwTry", ((_t1030 = Z.arrNew()), Z.apush(_t1030, Z.dup(v_x)), _t1030));
  }
  Z.setLine(142);
  if (Z.truthy(Z.ident(v_k, ":New"))) {
    Z.setLine(142);
    return f_zs_invoke(Z.dup(v_this), "rwNew", ((_t1031 = Z.arrNew()), Z.apush(_t1031, Z.dup(v_x)), _t1031));
  }
  Z.setLine(143);
  if (Z.truthy(Z.ident(v_k, ":InstanceOf"))) {
    Z.setLine(143);
    return f_zs_invoke(Z.dup(v_this), "call", ((_t1032 = Z.arrNew()), Z.apush(_t1032, Z.dup(v_line)), Z.apush(_t1032, "zs_isa"), Z.apush(_t1032, ((_t1033 = Z.arrNew()), Z.apush(_t1033, f_zs_invoke(Z.dup(v_this), "rw", ((_t1034 = Z.arrNew()), Z.apush(_t1034, Z.dup(Z.index(v_x, 2))), _t1034))), Z.apush(_t1033, f_zs_invoke(Z.dup(v_this), "mkstr", ((_t1035 = Z.arrNew()), Z.apush(_t1035, Z.dup(v_line)), Z.apush(_t1035, Z.dup(Z.index(v_x, 3))), _t1035))), _t1033)), _t1032));
  }
  Z.setLine(144);
  if (Z.truthy(Z.ident(v_k, ":Prop"))) {
    Z.setLine(144);
    return f_zs_invoke(Z.dup(v_this), "call", ((_t1036 = Z.arrNew()), Z.apush(_t1036, Z.dup(v_line)), Z.apush(_t1036, "zs_obj_get"), Z.apush(_t1036, ((_t1037 = Z.arrNew()), Z.apush(_t1037, f_zs_invoke(Z.dup(v_this), "rw", ((_t1038 = Z.arrNew()), Z.apush(_t1038, Z.dup(Z.index(v_x, 2))), _t1038))), Z.apush(_t1037, f_zs_invoke(Z.dup(v_this), "mkstr", ((_t1039 = Z.arrNew()), Z.apush(_t1039, Z.dup(v_line)), Z.apush(_t1039, Z.dup(Z.index(v_x, 3))), _t1039))), _t1037)), _t1036));
  }
  Z.setLine(145);
  if (Z.truthy(Z.ident(v_k, ":Dot"))) {
    Z.setLine(146);
    if (Z.truthy(Z.ident(Z.index(Z.index(v_x, 2), 0), ":Name"))) {
      Z.setLine(147);
      (v_cn = f_zs_invoke(Z.dup(v_this), "clsName", ((_t1040 = Z.arrNew()), Z.apush(_t1040, Z.dup(Z.index(Z.index(v_x, 2), 2))), _t1040)));
      Z.setLine(148);
      if (Z.truthy(!Z.ident(v_cn, null))) {
        Z.setLine(149);
        (v_v = f_zs_invoke(Z.dup(v_this), "constOf", ((_t1041 = Z.arrNew()), Z.apush(_t1041, Z.dup(v_cn)), Z.apush(_t1041, Z.dup(Z.index(v_x, 3))), _t1041)));
        Z.setLine(150);
        if (Z.truthy(!Z.ident(v_v, null))) {
          Z.setLine(150);
          return f_zs_invoke(Z.dup(v_this), "rw", ((_t1042 = Z.arrNew()), Z.apush(_t1042, Z.dup(v_v)), _t1042));
        }
        Z.setLine(151);
        (v_sn = f_zs_invoke(Z.dup(v_this), "staticName", ((_t1043 = Z.arrNew()), Z.apush(_t1043, Z.dup(v_cn)), Z.apush(_t1043, Z.dup(Z.index(v_x, 3))), _t1043)));
        Z.setLine(152);
        if (Z.truthy(!Z.ident(v_sn, null))) {
          Z.setLine(152);
          return f_zs_invoke(Z.dup(v_this), "call", ((_t1044 = Z.arrNew()), Z.apush(_t1044, Z.dup(v_line)), Z.apush(_t1044, "zs_sget"), Z.apush(_t1044, ((_t1045 = Z.arrNew()), Z.apush(_t1045, f_zs_invoke(Z.dup(v_this), "mkstr", ((_t1046 = Z.arrNew()), Z.apush(_t1046, Z.dup(v_line)), Z.apush(_t1046, Z.dup(v_sn)), _t1046))), _t1045)), _t1044));
        }
        Z.setLine(153);
        f_zs_invoke(Z.dup(v_this), "err", ((_t1047 = Z.arrNew()), Z.apush(_t1047, Z.dup(v_line)), Z.apush(_t1047, Z.concat(Z.concat(Z.concat("brak stałej lub statycznego pola ", v_cn), "."), Z.index(v_x, 3))), _t1047));
      }
    }
    Z.setLine(156);
    return ((_t1048 = Z.arrNew()), Z.apush(_t1048, ":Dot"), Z.apush(_t1048, Z.dup(v_line)), Z.apush(_t1048, f_zs_invoke(Z.dup(v_this), "rw", ((_t1049 = Z.arrNew()), Z.apush(_t1049, Z.dup(Z.index(v_x, 2))), _t1049))), Z.apush(_t1048, Z.dup(Z.index(v_x, 3))), _t1048);
  }
  Z.setLine(158);
  if (Z.truthy((Z.truthy(Z.ident(v_k, ":Assign")) && Z.truthy(!Z.ident(f_zs_invoke(Z.dup(v_this), "staticTarget", ((_t1050 = Z.arrNew()), Z.apush(_t1050, Z.dup(Z.index(v_x, 2))), _t1050)), null))))) {
    Z.setLine(159);
    return f_zs_invoke(Z.dup(v_this), "call", ((_t1051 = Z.arrNew()), Z.apush(_t1051, Z.dup(v_line)), Z.apush(_t1051, "zs_sset"), Z.apush(_t1051, ((_t1052 = Z.arrNew()), Z.apush(_t1052, f_zs_invoke(Z.dup(v_this), "mkstr", ((_t1053 = Z.arrNew()), Z.apush(_t1053, Z.dup(v_line)), Z.apush(_t1053, f_zs_invoke(Z.dup(v_this), "staticTarget", ((_t1054 = Z.arrNew()), Z.apush(_t1054, Z.dup(Z.index(v_x, 2))), _t1054))), _t1053))), Z.apush(_t1052, f_zs_invoke(Z.dup(v_this), "rw", ((_t1055 = Z.arrNew()), Z.apush(_t1055, Z.dup(Z.index(v_x, 3))), _t1055))), _t1052)), _t1051));
  }
  Z.setLine(161);
  if (Z.truthy((Z.truthy((Z.truthy(Z.ident(v_k, ":AssignOp")) && Z.truthy(!Z.ident(Z.index(v_x, 2), "Coalesce")))) && Z.truthy(!Z.ident(f_zs_invoke(Z.dup(v_this), "staticTarget", ((_t1056 = Z.arrNew()), Z.apush(_t1056, Z.dup(Z.index(v_x, 3))), _t1056)), null))))) {
    Z.setLine(162);
    (v_sn = f_zs_invoke(Z.dup(v_this), "mkstr", ((_t1057 = Z.arrNew()), Z.apush(_t1057, Z.dup(v_line)), Z.apush(_t1057, f_zs_invoke(Z.dup(v_this), "staticTarget", ((_t1058 = Z.arrNew()), Z.apush(_t1058, Z.dup(Z.index(v_x, 3))), _t1058))), _t1057)));
    Z.setLine(163);
    return f_zs_invoke(Z.dup(v_this), "call", ((_t1059 = Z.arrNew()), Z.apush(_t1059, Z.dup(v_line)), Z.apush(_t1059, "zs_sset"), Z.apush(_t1059, ((_t1060 = Z.arrNew()), Z.apush(_t1060, Z.dup(v_sn)), Z.apush(_t1060, ((_t1061 = Z.arrNew()), Z.apush(_t1061, ":Binary"), Z.apush(_t1061, Z.dup(v_line)), Z.apush(_t1061, Z.dup(Z.index(v_x, 2))), Z.apush(_t1061, f_zs_invoke(Z.dup(v_this), "call", ((_t1062 = Z.arrNew()), Z.apush(_t1062, Z.dup(v_line)), Z.apush(_t1062, "zs_sget"), Z.apush(_t1062, ((_t1063 = Z.arrNew()), Z.apush(_t1063, Z.dup(v_sn)), _t1063)), _t1062))), Z.apush(_t1061, f_zs_invoke(Z.dup(v_this), "rw", ((_t1064 = Z.arrNew()), Z.apush(_t1064, Z.dup(Z.index(v_x, 4))), _t1064))), _t1061)), _t1060)), _t1059));
  }
  Z.setLine(165);
  if (Z.truthy((Z.truthy(Z.ident(v_k, ":IncDec")) && Z.truthy(!Z.ident(f_zs_invoke(Z.dup(v_this), "staticTarget", ((_t1065 = Z.arrNew()), Z.apush(_t1065, Z.dup(Z.index(v_x, 2))), _t1065)), null))))) {
    Z.setLine(166);
    (v_sn = f_zs_invoke(Z.dup(v_this), "mkstr", ((_t1066 = Z.arrNew()), Z.apush(_t1066, Z.dup(v_line)), Z.apush(_t1066, f_zs_invoke(Z.dup(v_this), "staticTarget", ((_t1067 = Z.arrNew()), Z.apush(_t1067, Z.dup(Z.index(v_x, 2))), _t1067))), _t1066)));
    Z.setLine(167);
    return f_zs_invoke(Z.dup(v_this), "call", ((_t1068 = Z.arrNew()), Z.apush(_t1068, Z.dup(v_line)), Z.apush(_t1068, "zs_sset"), Z.apush(_t1068, ((_t1069 = Z.arrNew()), Z.apush(_t1069, Z.dup(v_sn)), Z.apush(_t1069, ((_t1070 = Z.arrNew()), Z.apush(_t1070, ":Binary"), Z.apush(_t1070, Z.dup(v_line)), Z.apush(_t1070, (Z.truthy(Z.index(v_x, 3)) ? "Add" : "Sub")), Z.apush(_t1070, f_zs_invoke(Z.dup(v_this), "call", ((_t1071 = Z.arrNew()), Z.apush(_t1071, Z.dup(v_line)), Z.apush(_t1071, "zs_sget"), Z.apush(_t1071, ((_t1072 = Z.arrNew()), Z.apush(_t1072, Z.dup(v_sn)), _t1072)), _t1071))), Z.apush(_t1070, ((_t1073 = Z.arrNew()), Z.apush(_t1073, ":Int"), Z.apush(_t1073, Z.dup(v_line)), Z.apush(_t1073, 1), _t1073)), _t1070)), _t1069)), _t1068));
  }
  Z.setLine(169);
  if (Z.truthy((Z.truthy(Z.ident(v_k, ":Assign")) && Z.truthy(Z.ident(Z.index(Z.index(v_x, 2), 0), ":Prop"))))) {
    Z.setLine(170);
    (v_t = Z.dup(Z.index(v_x, 2)));
    Z.setLine(171);
    return f_zs_invoke(Z.dup(v_this), "call", ((_t1074 = Z.arrNew()), Z.apush(_t1074, Z.dup(v_line)), Z.apush(_t1074, "zs_obj_set"), Z.apush(_t1074, ((_t1075 = Z.arrNew()), Z.apush(_t1075, f_zs_invoke(Z.dup(v_this), "rw", ((_t1076 = Z.arrNew()), Z.apush(_t1076, Z.dup(Z.index(v_t, 2))), _t1076))), Z.apush(_t1075, f_zs_invoke(Z.dup(v_this), "mkstr", ((_t1077 = Z.arrNew()), Z.apush(_t1077, Z.dup(v_line)), Z.apush(_t1077, Z.dup(Z.index(v_t, 3))), _t1077))), Z.apush(_t1075, f_zs_invoke(Z.dup(v_this), "rw", ((_t1078 = Z.arrNew()), Z.apush(_t1078, Z.dup(Z.index(v_x, 3))), _t1078))), _t1075)), _t1074));
  }
  Z.setLine(173);
  if (Z.truthy((Z.truthy((Z.truthy(Z.ident(v_k, ":AssignOp")) && Z.truthy(Z.ident(Z.index(Z.index(v_x, 3), 0), ":Prop")))) && Z.truthy(!Z.ident(Z.index(v_x, 2), "Coalesce"))))) {
    Z.setLine(174);
    (v_t = Z.dup(Z.index(v_x, 3)));
    Z.setLine(175);
    return f_zs_invoke(Z.dup(v_this), "propModify", ((_t1079 = Z.arrNew()), Z.apush(_t1079, Z.dup(v_line)), Z.apush(_t1079, Z.dup(v_t)), Z.apush(_t1079, Z.dup(Z.index(v_x, 2))), Z.apush(_t1079, f_zs_invoke(Z.dup(v_this), "rw", ((_t1080 = Z.arrNew()), Z.apush(_t1080, Z.dup(Z.index(v_x, 4))), _t1080))), _t1079));
  }
  Z.setLine(177);
  if (Z.truthy((Z.truthy(Z.ident(v_k, ":IncDec")) && Z.truthy(Z.ident(Z.index(Z.index(v_x, 2), 0), ":Prop"))))) {
    Z.setLine(178);
    return f_zs_invoke(Z.dup(v_this), "propModify", ((_t1081 = Z.arrNew()), Z.apush(_t1081, Z.dup(v_line)), Z.apush(_t1081, Z.dup(Z.index(v_x, 2))), Z.apush(_t1081, (Z.truthy(Z.index(v_x, 3)) ? "Add" : "Sub")), Z.apush(_t1081, ((_t1082 = Z.arrNew()), Z.apush(_t1082, ":Int"), Z.apush(_t1082, Z.dup(v_line)), Z.apush(_t1082, 1), _t1082)), _t1081));
  }
  Z.setLine(180);
  if (Z.truthy(Z.ident(v_k, ":Call"))) {
    Z.setLine(180);
    return f_zs_invoke(Z.dup(v_this), "rwCall", ((_t1083 = Z.arrNew()), Z.apush(_t1083, Z.dup(v_x)), _t1083));
  }
  Z.setLine(181);
  (v_o = ((_t1084 = Z.arrNew()), _t1084));
  Z.setLine(182);
  {
    const _it121 = Z.foreachArr(Z.dup(v_x));
    L121: for (let _i121 = 0; _i121 < _it121.keys.length; _i121++) {
      v_v = _it121.vals[_i121];
      v_i = _it121.keys[_i121];
      Z.setLine(183);
      if (Z.truthy((Z.cmp(v_i, 2) < 0))) {
        Z.setLine(183);
        Z.aset((v_o = Z.wr(v_o)), v_i, Z.dup(v_v));
        continue L121;
      }
      Z.setLine(184);
      if (Z.truthy((Z.truthy((Z.truthy(Z.B.is_array(v_v)) && Z.truthy((Z.cmp(Z.B.count(v_v), 0) > 0)))) && Z.truthy(f_Workspace_parser__isNode((((_t1085 = Z.indexOpt(v_v, 0)) !== null) ? _t1085 : null)))))) {
        Z.setLine(184);
        Z.aset((v_o = Z.wr(v_o)), v_i, f_zs_invoke(Z.dup(v_this), "rwList", ((_t1086 = Z.arrNew()), Z.apush(_t1086, Z.dup(v_v)), _t1086)));
      } else {
        Z.setLine(185);
        Z.aset((v_o = Z.wr(v_o)), v_i, f_zs_invoke(Z.dup(v_this), "rw", ((_t1087 = Z.arrNew()), Z.apush(_t1087, Z.dup(v_v)), _t1087)));
      }
    }
  }
  Z.setLine(187);
  return Z.dup(v_o);
  return null;
}
function f_Desugar__baseOk(v_this, v_b) {
  Z.setLine(190);
  return Z.ident(Z.index(v_b, 0), ":Var");
  return null;
}
function f_Desugar__propModify(v_this, v_line, v_t, v_op, v_rhs) {
  let v_base = null, v_get = null;
  let _t1088 = null, _t1089 = null, _t1090 = null, _t1091 = null, _t1092 = null, _t1093 = null, _t1094 = null, _t1095 = null, _t1096 = null, _t1097 = null;
  Z.setLine(193);
  (v_base = Z.dup(Z.index(v_t, 2)));
  Z.setLine(194);
  if (Z.truthy(!Z.truthy(f_zs_invoke(Z.dup(v_this), "baseOk", ((_t1088 = Z.arrNew()), Z.apush(_t1088, Z.dup(v_base)), _t1088))))) {
    Z.setLine(194);
    f_zs_invoke(Z.dup(v_this), "err", ((_t1089 = Z.arrNew()), Z.apush(_t1089, Z.dup(v_line)), Z.apush(_t1089, "modyfikacja właściwości wymaga zmiennej jako obiektu (np. $this->x += 1)"), _t1089));
    Z.setLine(194);
    return ((_t1090 = Z.arrNew()), Z.apush(_t1090, ":Null"), Z.apush(_t1090, Z.dup(v_line)), _t1090);
  }
  Z.setLine(195);
  (v_get = f_zs_invoke(Z.dup(v_this), "call", ((_t1091 = Z.arrNew()), Z.apush(_t1091, Z.dup(v_line)), Z.apush(_t1091, "zs_obj_get"), Z.apush(_t1091, ((_t1092 = Z.arrNew()), Z.apush(_t1092, Z.dup(v_base)), Z.apush(_t1092, f_zs_invoke(Z.dup(v_this), "mkstr", ((_t1093 = Z.arrNew()), Z.apush(_t1093, Z.dup(v_line)), Z.apush(_t1093, Z.dup(Z.index(v_t, 3))), _t1093))), _t1092)), _t1091)));
  Z.setLine(196);
  return f_zs_invoke(Z.dup(v_this), "call", ((_t1094 = Z.arrNew()), Z.apush(_t1094, Z.dup(v_line)), Z.apush(_t1094, "zs_obj_set"), Z.apush(_t1094, ((_t1095 = Z.arrNew()), Z.apush(_t1095, Z.dup(v_base)), Z.apush(_t1095, f_zs_invoke(Z.dup(v_this), "mkstr", ((_t1096 = Z.arrNew()), Z.apush(_t1096, Z.dup(v_line)), Z.apush(_t1096, Z.dup(Z.index(v_t, 3))), _t1096))), Z.apush(_t1095, ((_t1097 = Z.arrNew()), Z.apush(_t1097, ":Binary"), Z.apush(_t1097, Z.dup(v_line)), Z.apush(_t1097, Z.dup(v_op)), Z.apush(_t1097, Z.dup(v_get)), Z.apush(_t1097, Z.dup(v_rhs)), _t1097)), _t1095)), _t1094));
  return null;
}
function f_Desugar__staticName(v_this, v_cn, v_p) {
  let v_n = null, v_d = null;
  let _t1098 = null;
  Z.setLine(201);
  {
    const _it122 = Z.foreachArr(f_zs_invoke(Z.dup(v_this), "chain", ((_t1098 = Z.arrNew()), Z.apush(_t1098, Z.dup(v_cn)), _t1098)));
    L122: for (let _i122 = 0; _i122 < _it122.keys.length; _i122++) {
      v_n = _it122.vals[_i122];
      Z.setLine(202);
      (v_d = Z.B.zs_obj_get(Z.index(Z.B.zs_obj_get(v_this, "classes"), v_n), "props"));
      Z.setLine(203);
      if (Z.truthy((Z.truthy(Z.B.has_key(v_d, v_p)) && Z.truthy(Z.index(Z.index(v_d, v_p), "static"))))) {
        Z.setLine(203);
        return Z.concat(Z.concat(v_n, "::"), v_p);
      }
    }
  }
  Z.setLine(205);
  return null;
  return null;
}
function f_Desugar__staticTarget(v_this, v_t) {
  let v_cn = null;
  let _t1099 = null, _t1100 = null;
  Z.setLine(209);
  if (Z.truthy((Z.truthy((Z.truthy(!Z.truthy(Z.B.is_array(v_t))) || Z.truthy(!Z.ident(Z.index(v_t, 0), ":Dot")))) || Z.truthy(!Z.ident(Z.index(Z.index(v_t, 2), 0), ":Name"))))) {
    Z.setLine(209);
    return null;
  }
  Z.setLine(210);
  (v_cn = f_zs_invoke(Z.dup(v_this), "clsName", ((_t1099 = Z.arrNew()), Z.apush(_t1099, Z.dup(Z.index(Z.index(v_t, 2), 2))), _t1099)));
  Z.setLine(211);
  if (Z.truthy(Z.ident(v_cn, null))) {
    Z.setLine(211);
    return null;
  }
  Z.setLine(212);
  return f_zs_invoke(Z.dup(v_this), "staticName", ((_t1100 = Z.arrNew()), Z.apush(_t1100, Z.dup(v_cn)), Z.apush(_t1100, Z.dup(Z.index(v_t, 3))), _t1100));
  return null;
}
function f_Desugar__clsName(v_this, v_n) {
  Z.setLine(216);
  if (Z.truthy((Z.truthy(Z.ident(v_n, "static")) || Z.truthy(Z.ident(v_n, "self"))))) {
    Z.setLine(216);
    return (Z.truthy(!Z.ident(Z.B.zs_obj_get(v_this, "cur"), null)) ? Z.B.zs_obj_get(Z.B.zs_obj_get(v_this, "cur"), "name") : null);
  }
  Z.setLine(217);
  return (Z.truthy(Z.B.has_key(Z.B.zs_obj_get(v_this, "classes"), v_n)) ? v_n : null);
  return null;
}
function f_Desugar__constOf(v_this, v_cn, v_k) {
  let v_n = null;
  let _t1101 = null;
  Z.setLine(221);
  {
    const _it123 = Z.foreachArr(f_zs_invoke(Z.dup(v_this), "chain", ((_t1101 = Z.arrNew()), Z.apush(_t1101, Z.dup(v_cn)), _t1101)));
    L123: for (let _i123 = 0; _i123 < _it123.keys.length; _i123++) {
      v_n = _it123.vals[_i123];
      Z.setLine(222);
      if (Z.truthy(Z.B.has_key(Z.B.zs_obj_get(Z.index(Z.B.zs_obj_get(v_this, "classes"), v_n), "consts"), v_k))) {
        Z.setLine(222);
        return Z.dup(Z.index(Z.B.zs_obj_get(Z.index(Z.B.zs_obj_get(v_this, "classes"), v_n), "consts"), v_k));
      }
    }
  }
  Z.setLine(224);
  return null;
  return null;
}
function f_Desugar__rwNew(v_this, v_x) {
  let v_line = null, v_args = null, v_a = null;
  let _t1102 = null, _t1103 = null, _t1104 = null, _t1105 = null, _t1106 = null, _t1107 = null, _t1108 = null, _t1109 = null, _t1110 = null;
  Z.setLine(228);
  (v_line = Z.dup(Z.index(v_x, 1)));
  Z.setLine(229);
  (v_args = ((_t1102 = Z.arrNew()), _t1102));
  Z.setLine(230);
  {
    const _it124 = Z.foreachArr(Z.dup(Z.index(v_x, 3)));
    L124: for (let _i124 = 0; _i124 < _it124.keys.length; _i124++) {
      v_a = _it124.vals[_i124];
      Z.setLine(230);
      Z.aset((v_a = Z.wr(v_a)), 3, f_zs_invoke(Z.dup(v_this), "rw", ((_t1103 = Z.arrNew()), Z.apush(_t1103, Z.dup(Z.index(v_a, 3))), _t1103)));
      Z.setLine(230);
      Z.apush((v_args = Z.wr(v_args)), Z.dup(v_a));
    }
  }
  Z.setLine(231);
  if (Z.truthy(Z.B.in_array(Z.index(v_x, 2), ((_t1104 = Z.arrNew()), Z.apush(_t1104, "Exception"), Z.apush(_t1104, "Error"), _t1104)))) {
    Z.setLine(231);
    return ((_t1105 = Z.arrNew()), Z.apush(_t1105, ":New"), Z.apush(_t1105, Z.dup(v_line)), Z.apush(_t1105, Z.dup(Z.index(v_x, 2))), Z.apush(_t1105, Z.dup(v_args)), _t1105);
  }
  Z.setLine(232);
  if (Z.truthy(!Z.truthy(Z.B.has_key(Z.B.zs_obj_get(v_this, "classes"), Z.index(v_x, 2))))) {
    Z.setLine(233);
    return f_zs_invoke(Z.dup(v_this), "call", ((_t1106 = Z.arrNew()), Z.apush(_t1106, Z.dup(v_line)), Z.apush(_t1106, "zs_no_class"), Z.apush(_t1106, ((_t1107 = Z.arrNew()), Z.apush(_t1107, f_zs_invoke(Z.dup(v_this), "mkstr", ((_t1108 = Z.arrNew()), Z.apush(_t1108, Z.dup(v_line)), Z.apush(_t1108, Z.dup(Z.index(v_x, 2))), _t1108))), _t1107)), _t1106));
  }
  Z.setLine(235);
  return ((_t1109 = Z.arrNew()), Z.apush(_t1109, ":Call"), Z.apush(_t1109, Z.dup(v_line)), Z.apush(_t1109, f_zs_invoke(Z.dup(v_this), "nm", ((_t1110 = Z.arrNew()), Z.apush(_t1110, Z.dup(v_line)), Z.apush(_t1110, Z.concat(Z.index(v_x, 2), "__new")), _t1110))), Z.apush(_t1109, Z.dup(v_args)), _t1109);
  return null;
}
function f_Desugar__rwCall(v_this, v_x) {
  let v_line = null, v_callee = null, v_args = null, v_a = null, v_m = null, v_special = null, v___k120 = null, v___r121 = null, v___w122 = null, v_cur = null, v_its = null, v_seg = null, v_arr = null, v_items = null, v_n = null, v_o = null, v_as = null, v_cn = null;
  let _t1111 = null, _t1112 = null, _t1113 = null, _t1114 = null, _t1115 = null, _t1116 = null, _t1117 = null, _t1118 = null, _t1119 = null, _t1120 = null, _t1121 = null, _t1122 = null, _t1123 = null, _t1124 = null, _t1125 = null, _t1126 = null, _t1127 = null, _t1128 = null, _t1129 = null, _t1130 = null, _t1131 = null, _t1132 = null, _t1133 = null, _t1134 = null, _t1135 = null, _t1136 = null, _t1137 = null, _t1138 = null, _t1139 = null, _t1140 = null, _t1141 = null, _t1142 = null, _t1143 = null, _t1144 = null, _t1145 = null, _t1146 = null, _t1147 = null, _t1148 = null, _t1149 = null, _t1150 = null, _t1151 = null, _t1152 = null, _t1153 = null, _t1154 = null, _t1155 = null, _t1156 = null;
  Z.setLine(239);
  (v_line = Z.dup(Z.index(v_x, 1)));
  Z.setLine(240);
  (v_callee = Z.dup(Z.index(v_x, 2)));
  Z.setLine(241);
  (v_args = ((_t1111 = Z.arrNew()), _t1111));
  Z.setLine(242);
  {
    const _it125 = Z.foreachArr(Z.dup(Z.index(v_x, 3)));
    L125: for (let _i125 = 0; _i125 < _it125.keys.length; _i125++) {
      v_a = _it125.vals[_i125];
      Z.setLine(242);
      Z.aset((v_a = Z.wr(v_a)), 3, f_zs_invoke(Z.dup(v_this), "rw", ((_t1112 = Z.arrNew()), Z.apush(_t1112, Z.dup(Z.index(v_a, 3))), _t1112)));
      Z.setLine(242);
      Z.apush((v_args = Z.wr(v_args)), Z.dup(v_a));
    }
  }
  Z.setLine(243);
  if (Z.truthy(Z.ident(Z.index(v_callee, 0), ":Prop"))) {
    Z.setLine(244);
    (v_m = Z.dup(Z.index(v_callee, 3)));
    Z.setLine(245);
    if (Z.truthy((Z.truthy((Z.truthy(Z.ident(v_m, "getMessage")) && Z.truthy(Z.ident(Z.B.count(v_args), 0)))) && Z.truthy(!Z.truthy(f_zs_invoke(Z.dup(v_this), "anyMethod", ((_t1113 = Z.arrNew()), Z.apush(_t1113, "getMessage"), _t1113))))))) {
      Z.setLine(246);
      return ((_t1114 = Z.arrNew()), Z.apush(_t1114, ":Call"), Z.apush(_t1114, Z.dup(v_line)), Z.apush(_t1114, ((_t1115 = Z.arrNew()), Z.apush(_t1115, ":Prop"), Z.apush(_t1115, Z.dup(Z.index(v_callee, 1))), Z.apush(_t1115, f_zs_invoke(Z.dup(v_this), "rw", ((_t1116 = Z.arrNew()), Z.apush(_t1116, Z.dup(Z.index(v_callee, 2))), _t1116))), Z.apush(_t1115, Z.dup(v_m)), _t1115)), Z.apush(_t1114, Z.dup(v_args)), _t1114);
    }
    Z.setLine(248);
    (v_special = false);
    Z.setLine(249);
    {
      const _it126 = Z.foreachArr(Z.dup(v_args));
      L126: for (let _i126 = 0; _i126 < _it126.keys.length; _i126++) {
        v_a = _it126.vals[_i126];
        Z.setLine(249);
        if (Z.truthy((Z.truthy(Z.index(v_a, 4)) || Z.truthy(!Z.ident(Z.index(v_a, 2), null))))) {
          Z.setLine(249);
          (v_special = true);
        }
      }
    }
    Z.setLine(250);
    if (Z.truthy(v_special)) {
      Z.setLine(251);
      (v___k120 = Z.dup(v_m));
      Z.setLine(251);
      (v___r121 = true);
      Z.setLine(251);
      (v___w122 = Z.B.zs_obj_take(v_this, "nuse"));
      Z.setLine(251);
      Z.aset((v___w122 = Z.wr(v___w122)), v___k120, Z.dup(v___r121));
      Z.setLine(251);
      Z.B.zs_obj_put(v_this, "nuse", v___w122);
      Z.setLine(252);
      (v_cur = null);
      Z.setLine(253);
      (v_its = ((_t1117 = Z.arrNew()), _t1117));
      Z.setLine(254);
      {
        const _it127 = Z.foreachArr(Z.dup(v_args));
        L127: for (let _i127 = 0; _i127 < _it127.keys.length; _i127++) {
          v_a = _it127.vals[_i127];
          Z.setLine(255);
          if (Z.truthy(Z.index(v_a, 4))) {
            Z.setLine(256);
            (v_seg = ((_t1118 = Z.arrNew()), Z.apush(_t1118, ":Array"), Z.apush(_t1118, Z.dup(v_line)), Z.apush(_t1118, Z.dup(v_its)), _t1118));
            Z.setLine(257);
            (v_cur = (Z.truthy(Z.ident(v_cur, null)) ? v_seg : f_zs_invoke(Z.dup(v_this), "call", ((_t1119 = Z.arrNew()), Z.apush(_t1119, Z.dup(v_line)), Z.apush(_t1119, "zs_spread"), Z.apush(_t1119, ((_t1120 = Z.arrNew()), Z.apush(_t1120, Z.dup(v_cur)), Z.apush(_t1120, Z.dup(v_seg)), _t1120)), _t1119))));
            Z.setLine(258);
            (v_cur = f_zs_invoke(Z.dup(v_this), "call", ((_t1121 = Z.arrNew()), Z.apush(_t1121, Z.dup(v_line)), Z.apush(_t1121, "zs_spread"), Z.apush(_t1121, ((_t1122 = Z.arrNew()), Z.apush(_t1122, Z.dup(v_cur)), Z.apush(_t1122, Z.dup(Z.index(v_a, 3))), _t1122)), _t1121)));
            Z.setLine(259);
            (v_its = ((_t1123 = Z.arrNew()), _t1123));
          } else {
            Z.setLine(260);
            if (Z.truthy(!Z.ident(Z.index(v_a, 2), null))) {
              Z.setLine(260);
              Z.apush((v_its = Z.wr(v_its)), ((_t1124 = Z.arrNew()), Z.apush(_t1124, ":Item"), Z.apush(_t1124, 0), Z.apush(_t1124, f_zs_invoke(Z.dup(v_this), "mkstr", ((_t1125 = Z.arrNew()), Z.apush(_t1125, Z.dup(v_line)), Z.apush(_t1125, Z.dup(Z.index(v_a, 2))), _t1125))), Z.apush(_t1124, Z.dup(Z.index(v_a, 3))), _t1124));
            } else {
              Z.setLine(261);
              Z.apush((v_its = Z.wr(v_its)), ((_t1126 = Z.arrNew()), Z.apush(_t1126, ":Item"), Z.apush(_t1126, 0), Z.apush(_t1126, null), Z.apush(_t1126, Z.dup(Z.index(v_a, 3))), _t1126));
            }
          }
        }
      }
      Z.setLine(263);
      if (Z.truthy(Z.ident(v_cur, null))) {
        Z.setLine(263);
        (v_cur = ((_t1127 = Z.arrNew()), Z.apush(_t1127, ":Array"), Z.apush(_t1127, Z.dup(v_line)), Z.apush(_t1127, Z.dup(v_its)), _t1127));
      } else {
        Z.setLine(264);
        if (Z.truthy((Z.cmp(Z.B.count(v_its), 0) > 0))) {
          Z.setLine(264);
          (v_cur = f_zs_invoke(Z.dup(v_this), "call", ((_t1128 = Z.arrNew()), Z.apush(_t1128, Z.dup(v_line)), Z.apush(_t1128, "zs_spread"), Z.apush(_t1128, ((_t1129 = Z.arrNew()), Z.apush(_t1129, Z.dup(v_cur)), Z.apush(_t1129, ((_t1130 = Z.arrNew()), Z.apush(_t1130, ":Array"), Z.apush(_t1130, Z.dup(v_line)), Z.apush(_t1130, Z.dup(v_its)), _t1130)), _t1129)), _t1128)));
        }
      }
      Z.setLine(265);
      return f_zs_invoke(Z.dup(v_this), "call", ((_t1131 = Z.arrNew()), Z.apush(_t1131, Z.dup(v_line)), Z.apush(_t1131, "zs_invoke_n"), Z.apush(_t1131, ((_t1132 = Z.arrNew()), Z.apush(_t1132, f_zs_invoke(Z.dup(v_this), "rw", ((_t1133 = Z.arrNew()), Z.apush(_t1133, Z.dup(Z.index(v_callee, 2))), _t1133))), Z.apush(_t1132, f_zs_invoke(Z.dup(v_this), "mkstr", ((_t1134 = Z.arrNew()), Z.apush(_t1134, Z.dup(v_line)), Z.apush(_t1134, Z.dup(v_m)), _t1134))), Z.apush(_t1132, Z.dup(v_cur)), _t1132)), _t1131));
    }
    Z.setLine(267);
    (v_arr = ((_t1135 = Z.arrNew()), Z.apush(_t1135, ":Array"), Z.apush(_t1135, Z.dup(v_line)), Z.apush(_t1135, ((_t1136 = Z.arrNew()), _t1136)), _t1135));
    Z.setLine(268);
    (v_items = ((_t1137 = Z.arrNew()), _t1137));
    Z.setLine(269);
    {
      const _it128 = Z.foreachArr(Z.dup(v_args));
      L128: for (let _i128 = 0; _i128 < _it128.keys.length; _i128++) {
        v_a = _it128.vals[_i128];
        Z.setLine(269);
        Z.apush((v_items = Z.wr(v_items)), ((_t1138 = Z.arrNew()), Z.apush(_t1138, ":Item"), Z.apush(_t1138, 0), Z.apush(_t1138, null), Z.apush(_t1138, Z.dup(Z.index(v_a, 3))), Z.apush(_t1138, false), _t1138));
      }
    }
    Z.setLine(270);
    Z.aset((v_arr = Z.wr(v_arr)), 2, Z.dup(v_items));
    Z.setLine(271);
    return f_zs_invoke(Z.dup(v_this), "call", ((_t1139 = Z.arrNew()), Z.apush(_t1139, Z.dup(v_line)), Z.apush(_t1139, "zs_invoke"), Z.apush(_t1139, ((_t1140 = Z.arrNew()), Z.apush(_t1140, f_zs_invoke(Z.dup(v_this), "rw", ((_t1141 = Z.arrNew()), Z.apush(_t1141, Z.dup(Z.index(v_callee, 2))), _t1141))), Z.apush(_t1140, f_zs_invoke(Z.dup(v_this), "mkstr", ((_t1142 = Z.arrNew()), Z.apush(_t1142, Z.dup(v_line)), Z.apush(_t1142, Z.dup(v_m)), _t1142))), Z.apush(_t1140, Z.dup(v_arr)), _t1140)), _t1139));
  }
  Z.setLine(273);
  if (Z.truthy((Z.truthy(Z.ident(Z.index(v_callee, 0), ":Dot")) && Z.truthy(Z.ident(Z.index(Z.index(v_callee, 2), 0), ":Name"))))) {
    Z.setLine(274);
    (v_n = Z.dup(Z.index(Z.index(v_callee, 2), 2)));
    Z.setLine(275);
    (v_m = Z.dup(Z.index(v_callee, 3)));
    Z.setLine(276);
    if (Z.truthy(Z.ident(v_n, "parent"))) {
      Z.setLine(277);
      if (Z.truthy((Z.truthy(Z.ident(Z.B.zs_obj_get(v_this, "cur"), null)) || Z.truthy(Z.ident(Z.B.zs_obj_get(Z.B.zs_obj_get(v_this, "cur"), "parent"), null))))) {
        Z.setLine(277);
        f_zs_invoke(Z.dup(v_this), "err", ((_t1143 = Z.arrNew()), Z.apush(_t1143, Z.dup(v_line)), Z.apush(_t1143, "parent poza klasą z rodzicem"), _t1143));
        Z.setLine(277);
        return Z.dup(v_x);
      }
      Z.setLine(278);
      (v_o = f_zs_invoke(Z.dup(v_this), "owner", ((_t1144 = Z.arrNew()), Z.apush(_t1144, Z.B.zs_obj_get(Z.B.zs_obj_get(v_this, "cur"), "parent")), Z.apush(_t1144, Z.dup(v_m)), _t1144)));
      Z.setLine(279);
      if (Z.truthy(Z.ident(v_o, null))) {
        Z.setLine(279);
        f_zs_invoke(Z.dup(v_this), "err", ((_t1145 = Z.arrNew()), Z.apush(_t1145, Z.dup(v_line)), Z.apush(_t1145, Z.concat(Z.concat(Z.concat("klasa ", Z.B.zs_obj_get(Z.B.zs_obj_get(v_this, "cur"), "parent")), " nie ma metody "), v_m)), _t1145));
        Z.setLine(279);
        return Z.dup(v_x);
      }
      Z.setLine(280);
      (v_as = Z.dup(v_args));
      Z.setLine(281);
      if (Z.truthy(!Z.truthy(Z.index(Z.index(Z.B.zs_obj_get(Z.index(Z.B.zs_obj_get(v_this, "classes"), v_o), "methods"), v_m), "static")))) {
        Z.setLine(281);
        (v_as = f_Workspace_classes__prepend(((_t1146 = Z.arrNew()), Z.apush(_t1146, ":Arg"), Z.apush(_t1146, 0), Z.apush(_t1146, null), Z.apush(_t1146, f_zs_invoke(Z.dup(v_this), "mkvar", ((_t1147 = Z.arrNew()), Z.apush(_t1147, Z.dup(v_line)), Z.apush(_t1147, "this"), _t1147))), Z.apush(_t1146, false), _t1146), Z.dup(v_as)));
      }
      Z.setLine(282);
      return ((_t1148 = Z.arrNew()), Z.apush(_t1148, ":Call"), Z.apush(_t1148, Z.dup(v_line)), Z.apush(_t1148, f_zs_invoke(Z.dup(v_this), "nm", ((_t1149 = Z.arrNew()), Z.apush(_t1149, Z.dup(v_line)), Z.apush(_t1149, Z.concat(Z.concat(v_o, "__"), v_m)), _t1149))), Z.apush(_t1148, Z.dup(v_as)), _t1148);
    }
    Z.setLine(284);
    (v_cn = f_zs_invoke(Z.dup(v_this), "clsName", ((_t1150 = Z.arrNew()), Z.apush(_t1150, Z.dup(v_n)), _t1150)));
    Z.setLine(285);
    if (Z.truthy(!Z.ident(v_cn, null))) {
      Z.setLine(286);
      (v_o = f_zs_invoke(Z.dup(v_this), "owner", ((_t1151 = Z.arrNew()), Z.apush(_t1151, Z.dup(v_cn)), Z.apush(_t1151, Z.dup(v_m)), _t1151)));
      Z.setLine(287);
      if (Z.truthy((Z.truthy(Z.ident(v_o, null)) || Z.truthy(!Z.truthy(Z.index(Z.index(Z.B.zs_obj_get(Z.index(Z.B.zs_obj_get(v_this, "classes"), v_o), "methods"), v_m), "static")))))) {
        Z.setLine(287);
        f_zs_invoke(Z.dup(v_this), "err", ((_t1152 = Z.arrNew()), Z.apush(_t1152, Z.dup(v_line)), Z.apush(_t1152, Z.concat(Z.concat(Z.concat("brak metody statycznej ", v_cn), "."), v_m)), _t1152));
        Z.setLine(287);
        return Z.dup(v_x);
      }
      Z.setLine(288);
      return ((_t1153 = Z.arrNew()), Z.apush(_t1153, ":Call"), Z.apush(_t1153, Z.dup(v_line)), Z.apush(_t1153, f_zs_invoke(Z.dup(v_this), "nm", ((_t1154 = Z.arrNew()), Z.apush(_t1154, Z.dup(v_line)), Z.apush(_t1154, Z.concat(Z.concat(v_o, "__"), v_m)), _t1154))), Z.apush(_t1153, Z.dup(v_args)), _t1153);
    }
  }
  Z.setLine(291);
  return ((_t1155 = Z.arrNew()), Z.apush(_t1155, ":Call"), Z.apush(_t1155, Z.dup(v_line)), Z.apush(_t1155, f_zs_invoke(Z.dup(v_this), "rw", ((_t1156 = Z.arrNew()), Z.apush(_t1156, Z.dup(v_callee)), _t1156))), Z.apush(_t1155, Z.dup(v_args)), _t1155);
  return null;
}
function f_Desugar__rwTry(v_this, v_x) {
  let v_line = null, v_ex = null, v_chain = null, v_i = null, v_c = null, v_cond = null, v_t = null, v_one = null, v_then = null, v_s = null, v_fin = null;
  let _t1157 = null, _t1158 = null, _t1159 = null, _t1160 = null, _t1161 = null, _t1162 = null, _t1163 = null, _t1164 = null, _t1165 = null, _t1166 = null, _t1167 = null, _t1168 = null, _t1169 = null, _t1170 = null, _t1171 = null, _t1172 = null, _t1173 = null, _t1174 = null, _t1175 = null, _t1176 = null, _t1177 = null, _t1178 = null, _t1179 = null, _t1180 = null, _t1181 = null;
  Z.setLine(295);
  (v_line = Z.dup(Z.index(v_x, 1)));
  Z.setLine(296);
  (v_ex = f_zs_invoke(Z.dup(v_this), "fresh", ((_t1157 = Z.arrNew()), Z.apush(_t1157, "ex"), _t1157)));
  Z.setLine(297);
  (v_chain = ((_t1158 = Z.arrNew()), Z.apush(_t1158, ((_t1159 = Z.arrNew()), Z.apush(_t1159, ":Throw"), Z.apush(_t1159, Z.dup(v_line)), Z.apush(_t1159, f_zs_invoke(Z.dup(v_this), "mkvar", ((_t1160 = Z.arrNew()), Z.apush(_t1160, Z.dup(v_line)), Z.apush(_t1160, Z.dup(v_ex)), _t1160))), _t1159)), _t1158));
  Z.setLine(298);
  (v_i = Z.sub(Z.B.count(Z.index(v_x, 3)), 1));
  L129: for (; Z.truthy((Z.cmp(v_i, 0) >= 0)); ((_t1161 = v_i), (v_i = Z.sub(_t1161, 1)), _t1161)) {
    Z.setLine(299);
    (v_c = Z.dup(Z.index(Z.index(v_x, 3), v_i)));
    Z.setLine(300);
    (v_cond = null);
    Z.setLine(301);
    {
      const _it130 = Z.foreachArr(Z.dup(Z.index(v_c, 2)));
      L130: for (let _i130 = 0; _i130 < _it130.keys.length; _i130++) {
        v_t = _it130.vals[_i130];
        Z.setLine(302);
        (v_one = (Z.truthy(Z.ident(v_t, "Throwable")) ? ((_t1162 = Z.arrNew()), Z.apush(_t1162, ":Bool"), Z.apush(_t1162, Z.dup(v_line)), Z.apush(_t1162, true), _t1162) : f_zs_invoke(Z.dup(v_this), "call", ((_t1163 = Z.arrNew()), Z.apush(_t1163, Z.dup(v_line)), Z.apush(_t1163, "zs_isa"), Z.apush(_t1163, ((_t1164 = Z.arrNew()), Z.apush(_t1164, f_zs_invoke(Z.dup(v_this), "mkvar", ((_t1165 = Z.arrNew()), Z.apush(_t1165, Z.dup(v_line)), Z.apush(_t1165, Z.dup(v_ex)), _t1165))), Z.apush(_t1164, f_zs_invoke(Z.dup(v_this), "mkstr", ((_t1166 = Z.arrNew()), Z.apush(_t1166, Z.dup(v_line)), Z.apush(_t1166, Z.dup(v_t)), _t1166))), _t1164)), _t1163))));
        Z.setLine(303);
        (v_cond = (Z.truthy(Z.ident(v_cond, null)) ? v_one : ((_t1167 = Z.arrNew()), Z.apush(_t1167, ":Binary"), Z.apush(_t1167, Z.dup(v_line)), Z.apush(_t1167, "Or"), Z.apush(_t1167, Z.dup(v_cond)), Z.apush(_t1167, Z.dup(v_one)), _t1167)));
      }
    }
    Z.setLine(305);
    (v_then = ((_t1168 = Z.arrNew()), _t1168));
    Z.setLine(306);
    if (Z.truthy(!Z.ident(Z.index(v_c, 3), null))) {
      Z.setLine(306);
      Z.apush((v_then = Z.wr(v_then)), ((_t1169 = Z.arrNew()), Z.apush(_t1169, ":Expr"), Z.apush(_t1169, Z.dup(v_line)), Z.apush(_t1169, ((_t1170 = Z.arrNew()), Z.apush(_t1170, ":Assign"), Z.apush(_t1170, Z.dup(v_line)), Z.apush(_t1170, f_zs_invoke(Z.dup(v_this), "mkvar", ((_t1171 = Z.arrNew()), Z.apush(_t1171, Z.dup(v_line)), Z.apush(_t1171, Z.dup(Z.index(v_c, 3))), _t1171))), Z.apush(_t1170, f_zs_invoke(Z.dup(v_this), "mkvar", ((_t1172 = Z.arrNew()), Z.apush(_t1172, Z.dup(v_line)), Z.apush(_t1172, Z.dup(v_ex)), _t1172))), _t1170)), _t1169));
    }
    Z.setLine(307);
    {
      const _it131 = Z.foreachArr(f_zs_invoke(Z.dup(v_this), "rwList", ((_t1173 = Z.arrNew()), Z.apush(_t1173, Z.dup(Z.index(v_c, 4))), _t1173)));
      L131: for (let _i131 = 0; _i131 < _it131.keys.length; _i131++) {
        v_s = _it131.vals[_i131];
        Z.setLine(307);
        Z.apush((v_then = Z.wr(v_then)), Z.dup(v_s));
      }
    }
    Z.setLine(308);
    (v_chain = ((_t1174 = Z.arrNew()), Z.apush(_t1174, ((_t1175 = Z.arrNew()), Z.apush(_t1175, ":If"), Z.apush(_t1175, Z.dup(v_line)), Z.apush(_t1175, Z.dup(v_cond)), Z.apush(_t1175, Z.dup(v_then)), Z.apush(_t1175, Z.dup(v_chain)), _t1175)), _t1174));
  }
  Z.setLine(310);
  (v_fin = (Z.truthy(Z.ident(Z.index(v_x, 4), null)) ? null : f_zs_invoke(Z.dup(v_this), "rwList", ((_t1176 = Z.arrNew()), Z.apush(_t1176, Z.dup(Z.index(v_x, 4))), _t1176))));
  Z.setLine(311);
  return ((_t1177 = Z.arrNew()), Z.apush(_t1177, ":Try"), Z.apush(_t1177, Z.dup(v_line)), Z.apush(_t1177, f_zs_invoke(Z.dup(v_this), "rwList", ((_t1178 = Z.arrNew()), Z.apush(_t1178, Z.dup(Z.index(v_x, 2))), _t1178))), Z.apush(_t1177, ((_t1179 = Z.arrNew()), Z.apush(_t1179, ((_t1180 = Z.arrNew()), Z.apush(_t1180, ":Catch"), Z.apush(_t1180, 0), Z.apush(_t1180, ((_t1181 = Z.arrNew()), Z.apush(_t1181, "Throwable"), _t1181)), Z.apush(_t1180, Z.dup(v_ex)), Z.apush(_t1180, Z.dup(v_chain)), _t1180)), _t1179)), Z.apush(_t1177, Z.dup(v_fin)), _t1177);
  return null;
}
function f_Desugar__anyMethod(v_this, v_m) {
  let v_c = null;
  Z.setLine(315);
  {
    const _it132 = Z.foreachArr(Z.B.zs_obj_get(v_this, "classes"));
    L132: for (let _i132 = 0; _i132 < _it132.keys.length; _i132++) {
      v_c = _it132.vals[_i132];
      Z.setLine(315);
      if (Z.truthy(Z.B.has_key(Z.B.zs_obj_get(v_c, "methods"), v_m))) {
        Z.setLine(315);
        return true;
      }
    }
  }
  Z.setLine(316);
  return false;
  return null;
}
function f_Desugar__stmtExpr(v_this, v_s) {
  let v_e = null, v_line = null, v_target = null, v_kind = null, v_keys = null, v_t = null, v_sname = null, v_out = null, v_base = null, v_bv = null, v_ks = null, v_key = null, v_kv = null, v_rv = null, v_rhs = null, v_w = null, v_tgt = null, v_kk = null, v_ne = null;
  let _t1182 = null, _t1183 = null, _t1184 = null, _t1185 = null, _t1186 = null, _t1187 = null, _t1188 = null, _t1189 = null, _t1190 = null, _t1191 = null, _t1192 = null, _t1193 = null, _t1194 = null, _t1195 = null, _t1196 = null, _t1197 = null, _t1198 = null, _t1199 = null, _t1200 = null, _t1201 = null, _t1202 = null, _t1203 = null, _t1204 = null, _t1205 = null, _t1206 = null, _t1207 = null, _t1208 = null, _t1209 = null, _t1210 = null, _t1211 = null, _t1212 = null, _t1213 = null, _t1214 = null, _t1215 = null, _t1216 = null, _t1217 = null, _t1218 = null, _t1219 = null, _t1220 = null, _t1221 = null, _t1222 = null, _t1223 = null, _t1224 = null, _t1225 = null, _t1226 = null, _t1227 = null, _t1228 = null, _t1229 = null, _t1230 = null, _t1231 = null;
  Z.setLine(321);
  (v_e = Z.dup(Z.index(v_s, 2)));
  Z.setLine(322);
  (v_line = Z.dup(Z.index(v_s, 1)));
  Z.setLine(323);
  (v_target = null);
  Z.setLine(323);
  (v_kind = null);
  Z.setLine(324);
  if (Z.truthy(Z.ident(Z.index(v_e, 0), ":Assign"))) {
    Z.setLine(324);
    (v_target = Z.dup(Z.index(v_e, 2)));
    Z.setLine(324);
    (v_kind = "assign");
  } else {
    Z.setLine(325);
    if (Z.truthy(Z.ident(Z.index(v_e, 0), ":AssignOp"))) {
      Z.setLine(325);
      (v_target = Z.dup(Z.index(v_e, 3)));
      Z.setLine(325);
      (v_kind = "op");
    } else {
      Z.setLine(326);
      if (Z.truthy(Z.ident(Z.index(v_e, 0), ":IncDec"))) {
        Z.setLine(326);
        (v_target = Z.dup(Z.index(v_e, 2)));
        Z.setLine(326);
        (v_kind = "incdec");
      }
    }
  }
  Z.setLine(327);
  if (Z.truthy((Z.truthy(Z.ident(v_target, null)) || Z.truthy(!Z.ident(Z.index(v_target, 0), ":Index"))))) {
    Z.setLine(327);
    return null;
  }
  Z.setLine(328);
  (v_keys = ((_t1182 = Z.arrNew()), _t1182));
  Z.setLine(329);
  (v_t = Z.dup(v_target));
  L133: while (true) {
    Z.setLine(330);
    if (!Z.truthy(Z.ident(Z.index(v_t, 0), ":Index"))) break;
    Z.setLine(330);
    Z.apush((v_keys = Z.wr(v_keys)), Z.dup(Z.index(v_t, 3)));
    Z.setLine(330);
    (v_t = Z.dup(Z.index(v_t, 2)));
  }
  Z.setLine(331);
  (v_sname = f_zs_invoke(Z.dup(v_this), "staticTarget", ((_t1183 = Z.arrNew()), Z.apush(_t1183, Z.dup(v_t)), _t1183)));
  Z.setLine(332);
  if (Z.truthy((Z.truthy(!Z.ident(Z.index(v_t, 0), ":Prop")) && Z.truthy(Z.ident(v_sname, null))))) {
    Z.setLine(332);
    return null;
  }
  Z.setLine(334);
  (v_keys = f_Workspace_classes__array_reverse_names(Z.dup(v_keys)));
  Z.setLine(335);
  (v_out = ((_t1184 = Z.arrNew()), _t1184));
  Z.setLine(336);
  (v_base = (Z.truthy(!Z.ident(v_sname, null)) ? ((_t1185 = Z.arrNew()), Z.apush(_t1185, ":Null"), Z.apush(_t1185, Z.dup(v_line)), _t1185) : f_zs_invoke(Z.dup(v_this), "rw", ((_t1186 = Z.arrNew()), Z.apush(_t1186, Z.dup(Z.index(v_t, 2))), _t1186))));
  Z.setLine(337);
  if (Z.truthy((Z.truthy(Z.ident(v_sname, null)) && Z.truthy(!Z.ident(Z.index(v_base, 0), ":Var"))))) {
    Z.setLine(338);
    (v_bv = f_zs_invoke(Z.dup(v_this), "fresh", ((_t1187 = Z.arrNew()), Z.apush(_t1187, "o"), _t1187)));
    Z.setLine(339);
    Z.apush((v_out = Z.wr(v_out)), ((_t1188 = Z.arrNew()), Z.apush(_t1188, ":Expr"), Z.apush(_t1188, Z.dup(v_line)), Z.apush(_t1188, ((_t1189 = Z.arrNew()), Z.apush(_t1189, ":Assign"), Z.apush(_t1189, Z.dup(v_line)), Z.apush(_t1189, f_zs_invoke(Z.dup(v_this), "mkvar", ((_t1190 = Z.arrNew()), Z.apush(_t1190, Z.dup(v_line)), Z.apush(_t1190, Z.dup(v_bv)), _t1190))), Z.apush(_t1189, Z.dup(v_base)), _t1189)), _t1188));
    Z.setLine(340);
    (v_base = f_zs_invoke(Z.dup(v_this), "mkvar", ((_t1191 = Z.arrNew()), Z.apush(_t1191, Z.dup(v_line)), Z.apush(_t1191, Z.dup(v_bv)), _t1191)));
  }
  Z.setLine(342);
  (v_ks = ((_t1192 = Z.arrNew()), _t1192));
  Z.setLine(343);
  {
    const _it134 = Z.foreachArr(Z.dup(v_keys));
    L134: for (let _i134 = 0; _i134 < _it134.keys.length; _i134++) {
      v_key = _it134.vals[_i134];
      Z.setLine(344);
      if (Z.truthy(Z.ident(v_key, null))) {
        Z.setLine(344);
        Z.apush((v_ks = Z.wr(v_ks)), null);
        continue L134;
      }
      Z.setLine(345);
      (v_kv = f_zs_invoke(Z.dup(v_this), "fresh", ((_t1193 = Z.arrNew()), Z.apush(_t1193, "k"), _t1193)));
      Z.setLine(346);
      Z.apush((v_out = Z.wr(v_out)), ((_t1194 = Z.arrNew()), Z.apush(_t1194, ":Expr"), Z.apush(_t1194, Z.dup(v_line)), Z.apush(_t1194, ((_t1195 = Z.arrNew()), Z.apush(_t1195, ":Assign"), Z.apush(_t1195, Z.dup(v_line)), Z.apush(_t1195, f_zs_invoke(Z.dup(v_this), "mkvar", ((_t1196 = Z.arrNew()), Z.apush(_t1196, Z.dup(v_line)), Z.apush(_t1196, Z.dup(v_kv)), _t1196))), Z.apush(_t1195, f_zs_invoke(Z.dup(v_this), "rw", ((_t1197 = Z.arrNew()), Z.apush(_t1197, Z.dup(v_key)), _t1197))), _t1195)), _t1194));
      Z.setLine(347);
      Z.apush((v_ks = Z.wr(v_ks)), f_zs_invoke(Z.dup(v_this), "mkvar", ((_t1198 = Z.arrNew()), Z.apush(_t1198, Z.dup(v_line)), Z.apush(_t1198, Z.dup(v_kv)), _t1198)));
    }
  }
  Z.setLine(349);
  (v_rv = null);
  Z.setLine(350);
  if (Z.truthy((Z.truthy(Z.ident(v_kind, "assign")) || Z.truthy(Z.ident(v_kind, "op"))))) {
    Z.setLine(351);
    (v_rv = f_zs_invoke(Z.dup(v_this), "fresh", ((_t1199 = Z.arrNew()), Z.apush(_t1199, "r"), _t1199)));
    Z.setLine(352);
    (v_rhs = (Z.truthy(Z.ident(v_kind, "assign")) ? Z.index(v_e, 3) : Z.index(v_e, 4)));
    Z.setLine(353);
    Z.apush((v_out = Z.wr(v_out)), ((_t1200 = Z.arrNew()), Z.apush(_t1200, ":Expr"), Z.apush(_t1200, Z.dup(v_line)), Z.apush(_t1200, ((_t1201 = Z.arrNew()), Z.apush(_t1201, ":Assign"), Z.apush(_t1201, Z.dup(v_line)), Z.apush(_t1201, f_zs_invoke(Z.dup(v_this), "mkvar", ((_t1202 = Z.arrNew()), Z.apush(_t1202, Z.dup(v_line)), Z.apush(_t1202, Z.dup(v_rv)), _t1202))), Z.apush(_t1201, f_zs_invoke(Z.dup(v_this), "rw", ((_t1203 = Z.arrNew()), Z.apush(_t1203, Z.dup(v_rhs)), _t1203))), _t1201)), _t1200));
  }
  Z.setLine(355);
  (v_w = f_zs_invoke(Z.dup(v_this), "fresh", ((_t1204 = Z.arrNew()), Z.apush(_t1204, "w"), _t1204)));
  Z.setLine(356);
  Z.apush((v_out = Z.wr(v_out)), ((_t1205 = Z.arrNew()), Z.apush(_t1205, ":Expr"), Z.apush(_t1205, Z.dup(v_line)), Z.apush(_t1205, ((_t1206 = Z.arrNew()), Z.apush(_t1206, ":Assign"), Z.apush(_t1206, Z.dup(v_line)), Z.apush(_t1206, f_zs_invoke(Z.dup(v_this), "mkvar", ((_t1207 = Z.arrNew()), Z.apush(_t1207, Z.dup(v_line)), Z.apush(_t1207, Z.dup(v_w)), _t1207))), Z.apush(_t1206, (Z.truthy(!Z.ident(v_sname, null)) ? f_zs_invoke(Z.dup(v_this), "call", ((_t1208 = Z.arrNew()), Z.apush(_t1208, Z.dup(v_line)), Z.apush(_t1208, "zs_sget"), Z.apush(_t1208, ((_t1209 = Z.arrNew()), Z.apush(_t1209, f_zs_invoke(Z.dup(v_this), "mkstr", ((_t1210 = Z.arrNew()), Z.apush(_t1210, Z.dup(v_line)), Z.apush(_t1210, Z.dup(v_sname)), _t1210))), _t1209)), _t1208)) : f_zs_invoke(Z.dup(v_this), "call", ((_t1211 = Z.arrNew()), Z.apush(_t1211, Z.dup(v_line)), Z.apush(_t1211, "zs_obj_take"), Z.apush(_t1211, ((_t1212 = Z.arrNew()), Z.apush(_t1212, Z.dup(v_base)), Z.apush(_t1212, f_zs_invoke(Z.dup(v_this), "mkstr", ((_t1213 = Z.arrNew()), Z.apush(_t1213, Z.dup(v_line)), Z.apush(_t1213, Z.dup(Z.index(v_t, 3))), _t1213))), _t1212)), _t1211)))), _t1206)), _t1205));
  Z.setLine(357);
  (v_tgt = f_zs_invoke(Z.dup(v_this), "mkvar", ((_t1214 = Z.arrNew()), Z.apush(_t1214, Z.dup(v_line)), Z.apush(_t1214, Z.dup(v_w)), _t1214)));
  Z.setLine(358);
  {
    const _it135 = Z.foreachArr(Z.dup(v_ks));
    L135: for (let _i135 = 0; _i135 < _it135.keys.length; _i135++) {
      v_kk = _it135.vals[_i135];
      Z.setLine(358);
      (v_tgt = ((_t1215 = Z.arrNew()), Z.apush(_t1215, ":Index"), Z.apush(_t1215, Z.dup(v_line)), Z.apush(_t1215, Z.dup(v_tgt)), Z.apush(_t1215, Z.dup(v_kk)), _t1215));
    }
  }
  Z.setLine(359);
  if (Z.truthy(Z.ident(v_kind, "assign"))) {
    Z.setLine(359);
    (v_ne = ((_t1216 = Z.arrNew()), Z.apush(_t1216, ":Assign"), Z.apush(_t1216, Z.dup(v_line)), Z.apush(_t1216, Z.dup(v_tgt)), Z.apush(_t1216, f_zs_invoke(Z.dup(v_this), "mkvar", ((_t1217 = Z.arrNew()), Z.apush(_t1217, Z.dup(v_line)), Z.apush(_t1217, Z.dup(v_rv)), _t1217))), _t1216));
  } else {
    Z.setLine(360);
    if (Z.truthy(Z.ident(v_kind, "op"))) {
      Z.setLine(360);
      (v_ne = ((_t1218 = Z.arrNew()), Z.apush(_t1218, ":AssignOp"), Z.apush(_t1218, Z.dup(v_line)), Z.apush(_t1218, Z.dup(Z.index(v_e, 2))), Z.apush(_t1218, Z.dup(v_tgt)), Z.apush(_t1218, f_zs_invoke(Z.dup(v_this), "mkvar", ((_t1219 = Z.arrNew()), Z.apush(_t1219, Z.dup(v_line)), Z.apush(_t1219, Z.dup(v_rv)), _t1219))), _t1218));
    } else {
      Z.setLine(361);
      (v_ne = ((_t1220 = Z.arrNew()), Z.apush(_t1220, ":IncDec"), Z.apush(_t1220, Z.dup(v_line)), Z.apush(_t1220, Z.dup(v_tgt)), Z.apush(_t1220, Z.dup(Z.index(v_e, 3))), Z.apush(_t1220, Z.dup(Z.index(v_e, 4))), _t1220));
    }
  }
  Z.setLine(362);
  Z.apush((v_out = Z.wr(v_out)), ((_t1221 = Z.arrNew()), Z.apush(_t1221, ":Expr"), Z.apush(_t1221, Z.dup(v_line)), Z.apush(_t1221, Z.dup(v_ne)), _t1221));
  Z.setLine(363);
  if (Z.truthy(!Z.ident(v_sname, null))) {
    Z.setLine(363);
    Z.apush((v_out = Z.wr(v_out)), ((_t1222 = Z.arrNew()), Z.apush(_t1222, ":Expr"), Z.apush(_t1222, Z.dup(v_line)), Z.apush(_t1222, f_zs_invoke(Z.dup(v_this), "call", ((_t1223 = Z.arrNew()), Z.apush(_t1223, Z.dup(v_line)), Z.apush(_t1223, "zs_sset"), Z.apush(_t1223, ((_t1224 = Z.arrNew()), Z.apush(_t1224, f_zs_invoke(Z.dup(v_this), "mkstr", ((_t1225 = Z.arrNew()), Z.apush(_t1225, Z.dup(v_line)), Z.apush(_t1225, Z.dup(v_sname)), _t1225))), Z.apush(_t1224, f_zs_invoke(Z.dup(v_this), "mkvar", ((_t1226 = Z.arrNew()), Z.apush(_t1226, Z.dup(v_line)), Z.apush(_t1226, Z.dup(v_w)), _t1226))), _t1224)), _t1223))), _t1222));
  } else {
    Z.setLine(364);
    Z.apush((v_out = Z.wr(v_out)), ((_t1227 = Z.arrNew()), Z.apush(_t1227, ":Expr"), Z.apush(_t1227, Z.dup(v_line)), Z.apush(_t1227, f_zs_invoke(Z.dup(v_this), "call", ((_t1228 = Z.arrNew()), Z.apush(_t1228, Z.dup(v_line)), Z.apush(_t1228, "zs_obj_put"), Z.apush(_t1228, ((_t1229 = Z.arrNew()), Z.apush(_t1229, Z.dup(v_base)), Z.apush(_t1229, f_zs_invoke(Z.dup(v_this), "mkstr", ((_t1230 = Z.arrNew()), Z.apush(_t1230, Z.dup(v_line)), Z.apush(_t1230, Z.dup(Z.index(v_t, 3))), _t1230))), Z.apush(_t1229, f_zs_invoke(Z.dup(v_this), "mkvar", ((_t1231 = Z.arrNew()), Z.apush(_t1231, Z.dup(v_line)), Z.apush(_t1231, Z.dup(v_w)), _t1231))), _t1229)), _t1228))), _t1227));
  }
  Z.setLine(365);
  return Z.dup(v_out);
  return null;
}
function f_Desugar__funcStmt(v_this, v_line, v_name, v_params, v_body) {
  let _t1232 = null, _t1233 = null, _t1234 = null;
  Z.setLine(370);
  return ((_t1232 = Z.arrNew()), Z.apush(_t1232, ":FuncStmt"), Z.apush(_t1232, Z.dup(v_line)), Z.apush(_t1232, ((_t1233 = Z.arrNew()), Z.apush(_t1233, ":Func"), Z.apush(_t1233, Z.dup(v_line)), Z.apush(_t1233, Z.dup(v_name)), Z.apush(_t1233, Z.dup(v_params)), Z.apush(_t1233, ((_t1234 = Z.arrNew()), _t1234)), Z.apush(_t1233, Z.dup(v_body)), Z.apush(_t1233, false), _t1233)), _t1232);
  return null;
}
function f_Desugar__param(v_this, v_name, v_default) {
  let _t1235 = null, _t1236 = null;
  Z.setLine(373);
  return ((_t1235 = Z.arrNew()), Z.apush(_t1235, ":Param"), Z.apush(_t1235, 0), Z.apush(_t1235, Z.dup(v_name)), Z.apush(_t1235, ((_t1236 = Z.arrNew()), _t1236)), Z.apush(_t1235, Z.dup(v_default)), Z.apush(_t1235, false), _t1235);
  return null;
}
function f_Desugar__genClass(v_this, v_k) {
  let v_m = null, v_d = null, v_f = null, v_params = null, v_body = null, v___r123 = null, v___w124 = null, v_line = null, v_ctorOwner = null, v_p = null, v_dv = null, v_args = null, v___r125 = null, v___w126 = null;
  let _t1237 = null, _t1238 = null, _t1239 = null, _t1240 = null, _t1241 = null, _t1242 = null, _t1243 = null, _t1244 = null, _t1245 = null, _t1246 = null, _t1247 = null, _t1248 = null, _t1249 = null, _t1250 = null, _t1251 = null, _t1252 = null, _t1253 = null, _t1254 = null, _t1255 = null, _t1256 = null, _t1257 = null, _t1258 = null, _t1259 = null, _t1260 = null, _t1261 = null, _t1262 = null, _t1263 = null, _t1264 = null, _t1265 = null;
  Z.setLine(376);
  Z.B.zs_obj_set(v_this, "cur", v_k);
  Z.setLine(378);
  {
    const _it136 = Z.foreachArr(Z.B.zs_obj_get(v_k, "methods"));
    L136: for (let _i136 = 0; _i136 < _it136.keys.length; _i136++) {
      v_d = _it136.vals[_i136];
      v_m = _it136.keys[_i136];
      Z.setLine(379);
      if (Z.truthy(Z.index(v_d, "abstract"))) {
        continue L136;
      }
      Z.setLine(380);
      (v_f = Z.dup(Z.index(v_d, "decl")));
      Z.setLine(381);
      (v_params = Z.dup(Z.index(v_f, 3)));
      Z.setLine(382);
      if (Z.truthy(!Z.truthy(Z.index(v_d, "static")))) {
        Z.setLine(382);
        (v_params = f_Workspace_classes__prepend(f_zs_invoke(Z.dup(v_this), "param", ((_t1237 = Z.arrNew()), Z.apush(_t1237, "this"), _t1237)), Z.dup(v_params)));
      }
      Z.setLine(383);
      Z.B.zs_obj_set(v_this, "curStatic", Z.index(v_d, "static"));
      Z.setLine(384);
      (v_body = f_zs_invoke(Z.dup(v_this), "rwList", ((_t1238 = Z.arrNew()), Z.apush(_t1238, Z.dup(Z.index(v_f, 5))), _t1238)));
      Z.setLine(385);
      (v___r123 = ((_t1239 = Z.arrNew()), Z.apush(_t1239, ":FuncStmt"), Z.apush(_t1239, Z.dup(Z.index(v_f, 1))), Z.apush(_t1239, ((_t1240 = Z.arrNew()), Z.apush(_t1240, ":Func"), Z.apush(_t1240, Z.dup(Z.index(v_f, 1))), Z.apush(_t1240, Z.concat(Z.concat(Z.B.zs_obj_get(v_k, "name"), "__"), v_m)), Z.apush(_t1240, Z.dup(v_params)), Z.apush(_t1240, Z.dup(Z.index(v_f, 4))), Z.apush(_t1240, Z.dup(v_body)), Z.apush(_t1240, false), _t1240)), _t1239));
      Z.setLine(385);
      (v___w124 = Z.B.zs_obj_take(v_this, "extra"));
      Z.setLine(385);
      Z.apush((v___w124 = Z.wr(v___w124)), Z.dup(v___r123));
      Z.setLine(385);
      Z.B.zs_obj_put(v_this, "extra", v___w124);
    }
  }
  Z.setLine(388);
  (v_line = Z.B.zs_obj_get(v_k, "line"));
  Z.setLine(389);
  (v_ctorOwner = f_zs_invoke(Z.dup(v_this), "owner", ((_t1241 = Z.arrNew()), Z.apush(_t1241, Z.B.zs_obj_get(v_k, "name")), Z.apush(_t1241, "__construct"), _t1241)));
  Z.setLine(390);
  (v_params = ((_t1242 = Z.arrNew()), _t1242));
  Z.setLine(391);
  if (Z.truthy(!Z.ident(v_ctorOwner, null))) {
    Z.setLine(391);
    (v_params = Z.dup(Z.index(Z.index(Z.index(Z.B.zs_obj_get(Z.index(Z.B.zs_obj_get(v_this, "classes"), v_ctorOwner), "methods"), "__construct"), "decl"), 3)));
  }
  Z.setLine(392);
  (v_body = ((_t1243 = Z.arrNew()), _t1243));
  Z.setLine(393);
  Z.apush((v_body = Z.wr(v_body)), ((_t1244 = Z.arrNew()), Z.apush(_t1244, ":Expr"), Z.apush(_t1244, Z.dup(v_line)), Z.apush(_t1244, ((_t1245 = Z.arrNew()), Z.apush(_t1245, ":Assign"), Z.apush(_t1245, Z.dup(v_line)), Z.apush(_t1245, f_zs_invoke(Z.dup(v_this), "mkvar", ((_t1246 = Z.arrNew()), Z.apush(_t1246, Z.dup(v_line)), Z.apush(_t1246, "__o"), _t1246))), Z.apush(_t1245, f_zs_invoke(Z.dup(v_this), "call", ((_t1247 = Z.arrNew()), Z.apush(_t1247, Z.dup(v_line)), Z.apush(_t1247, "zs_obj_new"), Z.apush(_t1247, ((_t1248 = Z.arrNew()), Z.apush(_t1248, f_zs_invoke(Z.dup(v_this), "mkstr", ((_t1249 = Z.arrNew()), Z.apush(_t1249, Z.dup(v_line)), Z.apush(_t1249, Z.B.zs_obj_get(v_k, "name")), _t1249))), _t1248)), _t1247))), _t1245)), _t1244));
  Z.setLine(394);
  {
    const _it137 = Z.foreachArr(f_zs_invoke(Z.dup(v_this), "allProps", ((_t1250 = Z.arrNew()), Z.apush(_t1250, Z.B.zs_obj_get(v_k, "name")), _t1250)));
    L137: for (let _i137 = 0; _i137 < _it137.keys.length; _i137++) {
      v_d = _it137.vals[_i137];
      v_p = _it137.keys[_i137];
      Z.setLine(395);
      Z.B.zs_obj_set(v_this, "cur", Z.index(Z.B.zs_obj_get(v_this, "classes"), Z.index(v_d, "cls")));
      Z.setLine(396);
      (v_dv = (Z.truthy(Z.ident(Z.index(v_d, "default"), null)) ? ((_t1251 = Z.arrNew()), Z.apush(_t1251, ":Null"), Z.apush(_t1251, Z.dup(v_line)), _t1251) : f_zs_invoke(Z.dup(v_this), "rw", ((_t1252 = Z.arrNew()), Z.apush(_t1252, Z.dup(Z.index(v_d, "default"))), _t1252))));
      Z.setLine(397);
      Z.apush((v_body = Z.wr(v_body)), ((_t1253 = Z.arrNew()), Z.apush(_t1253, ":Expr"), Z.apush(_t1253, Z.dup(v_line)), Z.apush(_t1253, f_zs_invoke(Z.dup(v_this), "call", ((_t1254 = Z.arrNew()), Z.apush(_t1254, Z.dup(v_line)), Z.apush(_t1254, "zs_obj_set"), Z.apush(_t1254, ((_t1255 = Z.arrNew()), Z.apush(_t1255, f_zs_invoke(Z.dup(v_this), "mkvar", ((_t1256 = Z.arrNew()), Z.apush(_t1256, Z.dup(v_line)), Z.apush(_t1256, "__o"), _t1256))), Z.apush(_t1255, f_zs_invoke(Z.dup(v_this), "mkstr", ((_t1257 = Z.arrNew()), Z.apush(_t1257, Z.dup(v_line)), Z.apush(_t1257, Z.dup(v_p)), _t1257))), Z.apush(_t1255, Z.dup(v_dv)), _t1255)), _t1254))), _t1253));
    }
  }
  Z.setLine(399);
  Z.B.zs_obj_set(v_this, "cur", v_k);
  Z.setLine(400);
  if (Z.truthy(!Z.ident(v_ctorOwner, null))) {
    Z.setLine(401);
    (v_args = ((_t1258 = Z.arrNew()), Z.apush(_t1258, f_zs_invoke(Z.dup(v_this), "mkvar", ((_t1259 = Z.arrNew()), Z.apush(_t1259, Z.dup(v_line)), Z.apush(_t1259, "__o"), _t1259))), _t1258));
    Z.setLine(402);
    {
      const _it138 = Z.foreachArr(Z.dup(v_params));
      L138: for (let _i138 = 0; _i138 < _it138.keys.length; _i138++) {
        v_p = _it138.vals[_i138];
        Z.setLine(402);
        Z.apush((v_args = Z.wr(v_args)), f_zs_invoke(Z.dup(v_this), "mkvar", ((_t1260 = Z.arrNew()), Z.apush(_t1260, Z.dup(v_line)), Z.apush(_t1260, Z.dup(Z.index(v_p, 2))), _t1260)));
      }
    }
    Z.setLine(403);
    Z.apush((v_body = Z.wr(v_body)), ((_t1261 = Z.arrNew()), Z.apush(_t1261, ":Expr"), Z.apush(_t1261, Z.dup(v_line)), Z.apush(_t1261, f_zs_invoke(Z.dup(v_this), "call", ((_t1262 = Z.arrNew()), Z.apush(_t1262, Z.dup(v_line)), Z.apush(_t1262, Z.concat(v_ctorOwner, "____construct")), Z.apush(_t1262, Z.dup(v_args)), _t1262))), _t1261));
  }
  Z.setLine(405);
  Z.apush((v_body = Z.wr(v_body)), ((_t1263 = Z.arrNew()), Z.apush(_t1263, ":Return"), Z.apush(_t1263, Z.dup(v_line)), Z.apush(_t1263, f_zs_invoke(Z.dup(v_this), "mkvar", ((_t1264 = Z.arrNew()), Z.apush(_t1264, Z.dup(v_line)), Z.apush(_t1264, "__o"), _t1264))), _t1263));
  Z.setLine(406);
  (v___r125 = f_zs_invoke(Z.dup(v_this), "funcStmt", ((_t1265 = Z.arrNew()), Z.apush(_t1265, Z.dup(v_line)), Z.apush(_t1265, Z.concat(Z.B.zs_obj_get(v_k, "name"), "__new")), Z.apush(_t1265, Z.dup(v_params)), Z.apush(_t1265, Z.dup(v_body)), _t1265)));
  Z.setLine(406);
  (v___w126 = Z.B.zs_obj_take(v_this, "extra"));
  Z.setLine(406);
  Z.apush((v___w126 = Z.wr(v___w126)), Z.dup(v___r125));
  Z.setLine(406);
  Z.B.zs_obj_put(v_this, "extra", v___w126);
  return null;
}
function f_Desugar__wrapper(v_this, v_owner, v_m) {
  let v_f = null, v_line = null, v_ps = null, v_np = null, v_min = null, v_p = null, v_body = null, v_cnt = null, v_isVar = null, v_n = null, v_cargs = null, v_i = null, v_msg = null, v_act = null, v_sl = null, v_call = null, v_cmp = null;
  let _t1266 = null, _t1267 = null, _t1268 = null, _t1269 = null, _t1270 = null, _t1271 = null, _t1272 = null, _t1273 = null, _t1274 = null, _t1275 = null, _t1276 = null, _t1277 = null, _t1278 = null, _t1279 = null, _t1280 = null, _t1281 = null, _t1282 = null, _t1283 = null, _t1284 = null, _t1285 = null, _t1286 = null, _t1287 = null, _t1288 = null, _t1289 = null, _t1290 = null, _t1291 = null, _t1292 = null, _t1293 = null, _t1294 = null, _t1295 = null, _t1296 = null, _t1297 = null, _t1298 = null, _t1299 = null, _t1300 = null, _t1301 = null, _t1302 = null, _t1303 = null;
  Z.setLine(411);
  (v_f = Z.dup(Z.index(Z.index(Z.B.zs_obj_get(Z.index(Z.B.zs_obj_get(v_this, "classes"), v_owner), "methods"), v_m), "decl")));
  Z.setLine(412);
  (v_line = Z.dup(Z.index(v_f, 1)));
  Z.setLine(413);
  (v_ps = Z.dup(Z.index(v_f, 3)));
  Z.setLine(414);
  (v_np = Z.B.count(v_ps));
  Z.setLine(415);
  (v_min = 0);
  Z.setLine(416);
  {
    const _it139 = Z.foreachArr(Z.dup(v_ps));
    L139: for (let _i139 = 0; _i139 < _it139.keys.length; _i139++) {
      v_p = _it139.vals[_i139];
      Z.setLine(416);
      if (Z.truthy(Z.ident(Z.index(v_p, 4), null))) {
        Z.setLine(416);
        ((_t1266 = v_min), (v_min = Z.add(_t1266, 1)), _t1266);
      }
    }
  }
  Z.setLine(417);
  (v_body = ((_t1267 = Z.arrNew()), _t1267));
  Z.setLine(418);
  (v_cnt = f_zs_invoke(Z.dup(v_this), "call", ((_t1268 = Z.arrNew()), Z.apush(_t1268, Z.dup(v_line)), Z.apush(_t1268, "count"), Z.apush(_t1268, ((_t1269 = Z.arrNew()), Z.apush(_t1269, f_zs_invoke(Z.dup(v_this), "mkvar", ((_t1270 = Z.arrNew()), Z.apush(_t1270, Z.dup(v_line)), Z.apush(_t1270, "args"), _t1270))), _t1269)), _t1268)));
  Z.setLine(419);
  (v_isVar = (Z.truthy((Z.cmp(v_np, 0) > 0)) && Z.truthy(Z.index(Z.index(v_ps, Z.sub(v_np, 1)), 5))));
  Z.setLine(420);
  if (Z.truthy(v_isVar)) {
    Z.setLine(420);
    (v_np = Z.sub(v_np, 1));
  }
  Z.setLine(421);
  (v_n = 0);
  L140: for (; Z.truthy((Z.cmp(v_n, v_np) <= 0)); ((_t1271 = v_n), (v_n = Z.add(_t1271, 1)), _t1271)) {
    Z.setLine(422);
    (v_cargs = ((_t1272 = Z.arrNew()), Z.apush(_t1272, f_zs_invoke(Z.dup(v_this), "mkvar", ((_t1273 = Z.arrNew()), Z.apush(_t1273, Z.dup(v_line)), Z.apush(_t1273, "this"), _t1273))), _t1272));
    Z.setLine(423);
    (v_i = 0);
    L141: for (; Z.truthy((Z.cmp(v_i, v_n) < 0)); ((_t1274 = v_i), (v_i = Z.add(_t1274, 1)), _t1274)) {
      Z.setLine(423);
      Z.apush((v_cargs = Z.wr(v_cargs)), ((_t1275 = Z.arrNew()), Z.apush(_t1275, ":Index"), Z.apush(_t1275, Z.dup(v_line)), Z.apush(_t1275, f_zs_invoke(Z.dup(v_this), "mkvar", ((_t1276 = Z.arrNew()), Z.apush(_t1276, Z.dup(v_line)), Z.apush(_t1276, "args"), _t1276))), Z.apush(_t1275, ((_t1277 = Z.arrNew()), Z.apush(_t1277, ":Int"), Z.apush(_t1277, Z.dup(v_line)), Z.apush(_t1277, Z.dup(v_i)), _t1277)), _t1275));
    }
    Z.setLine(424);
    if (Z.truthy((Z.cmp(v_n, v_min) < 0))) {
      Z.setLine(425);
      (v_msg = Z.concat(Z.concat(v_m, ": brak argumentu $"), Z.index(Z.index(v_ps, v_n), 2)));
      Z.setLine(426);
      (v_act = ((_t1278 = Z.arrNew()), Z.apush(_t1278, ":Throw"), Z.apush(_t1278, Z.dup(v_line)), Z.apush(_t1278, ((_t1279 = Z.arrNew()), Z.apush(_t1279, ":New"), Z.apush(_t1279, Z.dup(v_line)), Z.apush(_t1279, "Error"), Z.apush(_t1279, ((_t1280 = Z.arrNew()), Z.apush(_t1280, ((_t1281 = Z.arrNew()), Z.apush(_t1281, ":Arg"), Z.apush(_t1281, 0), Z.apush(_t1281, null), Z.apush(_t1281, f_zs_invoke(Z.dup(v_this), "mkstr", ((_t1282 = Z.arrNew()), Z.apush(_t1282, Z.dup(v_line)), Z.apush(_t1282, Z.dup(v_msg)), _t1282))), Z.apush(_t1281, false), _t1281)), _t1280)), _t1279)), _t1278));
    } else {
      Z.setLine(428);
      (v_act = ((_t1283 = Z.arrNew()), Z.apush(_t1283, ":Return"), Z.apush(_t1283, Z.dup(v_line)), Z.apush(_t1283, f_zs_invoke(Z.dup(v_this), "call", ((_t1284 = Z.arrNew()), Z.apush(_t1284, Z.dup(v_line)), Z.apush(_t1284, Z.concat(Z.concat(v_owner, "__"), v_m)), Z.apush(_t1284, Z.dup(v_cargs)), _t1284))), _t1283));
    }
    Z.setLine(430);
    if (Z.truthy((Z.truthy(v_isVar) && Z.truthy(Z.ident(v_n, v_np))))) {
      Z.setLine(431);
      (v_sl = f_zs_invoke(Z.dup(v_this), "call", ((_t1285 = Z.arrNew()), Z.apush(_t1285, Z.dup(v_line)), Z.apush(_t1285, "array_slice"), Z.apush(_t1285, ((_t1286 = Z.arrNew()), Z.apush(_t1286, f_zs_invoke(Z.dup(v_this), "mkvar", ((_t1287 = Z.arrNew()), Z.apush(_t1287, Z.dup(v_line)), Z.apush(_t1287, "args"), _t1287))), Z.apush(_t1286, ((_t1288 = Z.arrNew()), Z.apush(_t1288, ":Int"), Z.apush(_t1288, Z.dup(v_line)), Z.apush(_t1288, Z.dup(v_np)), _t1288)), _t1286)), _t1285)));
      Z.setLine(432);
      (v_call = f_zs_invoke(Z.dup(v_this), "call", ((_t1289 = Z.arrNew()), Z.apush(_t1289, Z.dup(v_line)), Z.apush(_t1289, Z.concat(Z.concat(v_owner, "__"), v_m)), Z.apush(_t1289, Z.dup(v_cargs)), _t1289)));
      Z.setLine(433);
      Z.apush(Z.wrelem((v_call = Z.wr(v_call)), 3), ((_t1290 = Z.arrNew()), Z.apush(_t1290, ":Arg"), Z.apush(_t1290, 0), Z.apush(_t1290, null), Z.apush(_t1290, Z.dup(v_sl)), Z.apush(_t1290, true), _t1290));
      Z.setLine(434);
      (v_act = ((_t1291 = Z.arrNew()), Z.apush(_t1291, ":Return"), Z.apush(_t1291, Z.dup(v_line)), Z.apush(_t1291, Z.dup(v_call)), _t1291));
    }
    Z.setLine(436);
    (v_cmp = (Z.truthy(Z.ident(v_n, v_np)) ? ((_t1292 = Z.arrNew()), Z.apush(_t1292, ":Binary"), Z.apush(_t1292, Z.dup(v_line)), Z.apush(_t1292, "Ge"), Z.apush(_t1292, Z.dup(v_cnt)), Z.apush(_t1292, ((_t1293 = Z.arrNew()), Z.apush(_t1293, ":Int"), Z.apush(_t1293, Z.dup(v_line)), Z.apush(_t1293, Z.dup(v_n)), _t1293)), _t1292) : ((_t1294 = Z.arrNew()), Z.apush(_t1294, ":Binary"), Z.apush(_t1294, Z.dup(v_line)), Z.apush(_t1294, "Identical"), Z.apush(_t1294, Z.dup(v_cnt)), Z.apush(_t1294, ((_t1295 = Z.arrNew()), Z.apush(_t1295, ":Int"), Z.apush(_t1295, Z.dup(v_line)), Z.apush(_t1295, Z.dup(v_n)), _t1295)), _t1294)));
    Z.setLine(437);
    Z.apush((v_body = Z.wr(v_body)), ((_t1296 = Z.arrNew()), Z.apush(_t1296, ":If"), Z.apush(_t1296, Z.dup(v_line)), Z.apush(_t1296, Z.dup(v_cmp)), Z.apush(_t1296, ((_t1297 = Z.arrNew()), Z.apush(_t1297, Z.dup(v_act)), _t1297)), Z.apush(_t1296, null), _t1296));
  }
  Z.setLine(439);
  Z.apush((v_body = Z.wr(v_body)), ((_t1298 = Z.arrNew()), Z.apush(_t1298, ":Return"), Z.apush(_t1298, Z.dup(v_line)), Z.apush(_t1298, ((_t1299 = Z.arrNew()), Z.apush(_t1299, ":Null"), Z.apush(_t1299, Z.dup(v_line)), _t1299)), _t1298));
  Z.setLine(440);
  return f_zs_invoke(Z.dup(v_this), "funcStmt", ((_t1300 = Z.arrNew()), Z.apush(_t1300, Z.dup(v_line)), Z.apush(_t1300, Z.concat(Z.concat(Z.concat(v_owner, "__"), v_m), "__w")), Z.apush(_t1300, ((_t1301 = Z.arrNew()), Z.apush(_t1301, f_zs_invoke(Z.dup(v_this), "param", ((_t1302 = Z.arrNew()), Z.apush(_t1302, "this"), _t1302))), Z.apush(_t1301, f_zs_invoke(Z.dup(v_this), "param", ((_t1303 = Z.arrNew()), Z.apush(_t1303, "args"), _t1303))), _t1301)), Z.apush(_t1300, Z.dup(v_body)), _t1300));
  return null;
}
function f_Desugar__wrapperN(v_this, v_owner, v_m) {
  let v_f = null, v_line = null, v_args = null, v_body = null;
  let _t1304 = null, _t1305 = null, _t1306 = null, _t1307 = null, _t1308 = null, _t1309 = null, _t1310 = null, _t1311 = null, _t1312 = null, _t1313 = null;
  Z.setLine(444);
  (v_f = Z.dup(Z.index(Z.index(Z.B.zs_obj_get(Z.index(Z.B.zs_obj_get(v_this, "classes"), v_owner), "methods"), v_m), "decl")));
  Z.setLine(445);
  (v_line = Z.dup(Z.index(v_f, 1)));
  Z.setLine(446);
  (v_args = f_Workspace_classes__prepend(((_t1304 = Z.arrNew()), Z.apush(_t1304, ":Arg"), Z.apush(_t1304, 0), Z.apush(_t1304, null), Z.apush(_t1304, f_zs_invoke(Z.dup(v_this), "mkvar", ((_t1305 = Z.arrNew()), Z.apush(_t1305, Z.dup(v_line)), Z.apush(_t1305, "this"), _t1305))), Z.apush(_t1304, false), _t1304), f_Workspace_closures__bindArgs(Z.dup(v_line), Z.dup(Z.index(v_f, 3)), "args", Z.dup(v_m))));
  Z.setLine(447);
  (v_body = ((_t1306 = Z.arrNew()), Z.apush(_t1306, ((_t1307 = Z.arrNew()), Z.apush(_t1307, ":Return"), Z.apush(_t1307, Z.dup(v_line)), Z.apush(_t1307, ((_t1308 = Z.arrNew()), Z.apush(_t1308, ":Call"), Z.apush(_t1308, Z.dup(v_line)), Z.apush(_t1308, f_zs_invoke(Z.dup(v_this), "nm", ((_t1309 = Z.arrNew()), Z.apush(_t1309, Z.dup(v_line)), Z.apush(_t1309, Z.concat(Z.concat(v_owner, "__"), v_m)), _t1309))), Z.apush(_t1308, Z.dup(v_args)), _t1308)), _t1307)), _t1306));
  Z.setLine(448);
  return f_zs_invoke(Z.dup(v_this), "funcStmt", ((_t1310 = Z.arrNew()), Z.apush(_t1310, Z.dup(v_line)), Z.apush(_t1310, Z.concat(Z.concat(Z.concat(v_owner, "__"), v_m), "__wn")), Z.apush(_t1310, ((_t1311 = Z.arrNew()), Z.apush(_t1311, f_zs_invoke(Z.dup(v_this), "param", ((_t1312 = Z.arrNew()), Z.apush(_t1312, "this"), _t1312))), Z.apush(_t1311, f_zs_invoke(Z.dup(v_this), "param", ((_t1313 = Z.arrNew()), Z.apush(_t1313, "args"), _t1313))), _t1311)), Z.apush(_t1310, Z.dup(v_body)), _t1310));
  return null;
}
function f_Desugar__genDispatchN(v_this) {
  let v_line = null, v_body = null, v_wrapped = null, v_cn = null, v_k = null, v_stmts = null, v_seen = null, v_n = null, v_m = null, v_d = null, v_wn = null, v___r127 = null, v___w128 = null, v___r129 = null, v___w130 = null;
  let _t1314 = null, _t1315 = null, _t1316 = null, _t1317 = null, _t1318 = null, _t1319 = null, _t1320 = null, _t1321 = null, _t1322 = null, _t1323 = null, _t1324 = null, _t1325 = null, _t1326 = null, _t1327 = null, _t1328 = null, _t1329 = null, _t1330 = null, _t1331 = null, _t1332 = null, _t1333 = null, _t1334 = null, _t1335 = null, _t1336 = null, _t1337 = null, _t1338 = null, _t1339 = null, _t1340 = null, _t1341 = null, _t1342 = null, _t1343 = null, _t1344 = null, _t1345 = null, _t1346 = null, _t1347 = null, _t1348 = null, _t1349 = null;
  Z.setLine(452);
  (v_line = 0);
  Z.setLine(453);
  (v_body = ((_t1314 = Z.arrNew()), _t1314));
  Z.setLine(454);
  Z.apush((v_body = Z.wr(v_body)), ((_t1315 = Z.arrNew()), Z.apush(_t1315, ":Expr"), Z.apush(_t1315, Z.dup(v_line)), Z.apush(_t1315, ((_t1316 = Z.arrNew()), Z.apush(_t1316, ":Assign"), Z.apush(_t1316, Z.dup(v_line)), Z.apush(_t1316, f_zs_invoke(Z.dup(v_this), "mkvar", ((_t1317 = Z.arrNew()), Z.apush(_t1317, Z.dup(v_line)), Z.apush(_t1317, "c"), _t1317))), Z.apush(_t1316, f_zs_invoke(Z.dup(v_this), "call", ((_t1318 = Z.arrNew()), Z.apush(_t1318, Z.dup(v_line)), Z.apush(_t1318, "zs_obj_class"), Z.apush(_t1318, ((_t1319 = Z.arrNew()), Z.apush(_t1319, f_zs_invoke(Z.dup(v_this), "mkvar", ((_t1320 = Z.arrNew()), Z.apush(_t1320, Z.dup(v_line)), Z.apush(_t1320, "o"), _t1320))), _t1319)), _t1318))), _t1316)), _t1315));
  Z.setLine(455);
  (v_wrapped = ((_t1321 = Z.arrNew()), _t1321));
  Z.setLine(456);
  {
    const _it142 = Z.foreachArr(Z.B.zs_obj_get(v_this, "classes"));
    L142: for (let _i142 = 0; _i142 < _it142.keys.length; _i142++) {
      v_k = _it142.vals[_i142];
      v_cn = _it142.keys[_i142];
      Z.setLine(457);
      (v_stmts = ((_t1322 = Z.arrNew()), _t1322));
      Z.setLine(458);
      (v_seen = ((_t1323 = Z.arrNew()), _t1323));
      Z.setLine(459);
      {
        const _it143 = Z.foreachArr(f_zs_invoke(Z.dup(v_this), "chain", ((_t1324 = Z.arrNew()), Z.apush(_t1324, Z.dup(v_cn)), _t1324)));
        L143: for (let _i143 = 0; _i143 < _it143.keys.length; _i143++) {
          v_n = _it143.vals[_i143];
          Z.setLine(460);
          {
            const _it144 = Z.foreachArr(Z.B.zs_obj_get(Z.index(Z.B.zs_obj_get(v_this, "classes"), v_n), "methods"));
            L144: for (let _i144 = 0; _i144 < _it144.keys.length; _i144++) {
              v_d = _it144.vals[_i144];
              v_m = _it144.keys[_i144];
              Z.setLine(461);
              if (Z.truthy((Z.truthy((Z.truthy((Z.truthy((Z.truthy(Z.index(v_d, "abstract")) || Z.truthy(Z.index(v_d, "static")))) || Z.truthy(Z.ident(v_m, "__construct")))) || Z.truthy(Z.B.has_key(v_seen, v_m)))) || Z.truthy(!Z.truthy(Z.B.has_key(Z.B.zs_obj_get(v_this, "nuse"), v_m)))))) {
                continue L144;
              }
              Z.setLine(462);
              Z.aset((v_seen = Z.wr(v_seen)), v_m, true);
              Z.setLine(463);
              (v_wn = Z.concat(Z.concat(Z.concat(v_n, "__"), v_m), "__wn"));
              Z.setLine(464);
              if (Z.truthy(!Z.truthy(Z.B.has_key(v_wrapped, v_wn)))) {
                Z.setLine(464);
                Z.aset((v_wrapped = Z.wr(v_wrapped)), v_wn, true);
                Z.setLine(464);
                (v___r127 = f_zs_invoke(Z.dup(v_this), "wrapperN", ((_t1325 = Z.arrNew()), Z.apush(_t1325, Z.dup(v_n)), Z.apush(_t1325, Z.dup(v_m)), _t1325)));
                Z.setLine(464);
                (v___w128 = Z.B.zs_obj_take(v_this, "extra"));
                Z.setLine(464);
                Z.apush((v___w128 = Z.wr(v___w128)), Z.dup(v___r127));
                Z.setLine(464);
                Z.B.zs_obj_put(v_this, "extra", v___w128);
              }
              Z.setLine(465);
              Z.apush((v_stmts = Z.wr(v_stmts)), ((_t1326 = Z.arrNew()), Z.apush(_t1326, ":If"), Z.apush(_t1326, Z.dup(v_line)), Z.apush(_t1326, ((_t1327 = Z.arrNew()), Z.apush(_t1327, ":Binary"), Z.apush(_t1327, Z.dup(v_line)), Z.apush(_t1327, "Identical"), Z.apush(_t1327, f_zs_invoke(Z.dup(v_this), "mkvar", ((_t1328 = Z.arrNew()), Z.apush(_t1328, Z.dup(v_line)), Z.apush(_t1328, "name"), _t1328))), Z.apush(_t1327, f_zs_invoke(Z.dup(v_this), "mkstr", ((_t1329 = Z.arrNew()), Z.apush(_t1329, Z.dup(v_line)), Z.apush(_t1329, Z.dup(v_m)), _t1329))), _t1327)), Z.apush(_t1326, ((_t1330 = Z.arrNew()), Z.apush(_t1330, ((_t1331 = Z.arrNew()), Z.apush(_t1331, ":Return"), Z.apush(_t1331, Z.dup(v_line)), Z.apush(_t1331, f_zs_invoke(Z.dup(v_this), "call", ((_t1332 = Z.arrNew()), Z.apush(_t1332, Z.dup(v_line)), Z.apush(_t1332, Z.dup(v_wn)), Z.apush(_t1332, ((_t1333 = Z.arrNew()), Z.apush(_t1333, f_zs_invoke(Z.dup(v_this), "mkvar", ((_t1334 = Z.arrNew()), Z.apush(_t1334, Z.dup(v_line)), Z.apush(_t1334, "o"), _t1334))), Z.apush(_t1333, f_zs_invoke(Z.dup(v_this), "mkvar", ((_t1335 = Z.arrNew()), Z.apush(_t1335, Z.dup(v_line)), Z.apush(_t1335, "args"), _t1335))), _t1333)), _t1332))), _t1331)), _t1330)), Z.apush(_t1326, null), _t1326));
            }
          }
        }
      }
      Z.setLine(469);
      if (Z.truthy((Z.cmp(Z.B.count(v_stmts), 0) > 0))) {
        Z.setLine(470);
        Z.apush((v_body = Z.wr(v_body)), ((_t1336 = Z.arrNew()), Z.apush(_t1336, ":If"), Z.apush(_t1336, Z.dup(v_line)), Z.apush(_t1336, ((_t1337 = Z.arrNew()), Z.apush(_t1337, ":Binary"), Z.apush(_t1337, Z.dup(v_line)), Z.apush(_t1337, "Identical"), Z.apush(_t1337, f_zs_invoke(Z.dup(v_this), "mkvar", ((_t1338 = Z.arrNew()), Z.apush(_t1338, Z.dup(v_line)), Z.apush(_t1338, "c"), _t1338))), Z.apush(_t1337, f_zs_invoke(Z.dup(v_this), "mkstr", ((_t1339 = Z.arrNew()), Z.apush(_t1339, Z.dup(v_line)), Z.apush(_t1339, Z.dup(v_cn)), _t1339))), _t1337)), Z.apush(_t1336, Z.dup(v_stmts)), Z.apush(_t1336, null), _t1336));
      }
    }
  }
  Z.setLine(473);
  Z.apush((v_body = Z.wr(v_body)), ((_t1340 = Z.arrNew()), Z.apush(_t1340, ":Return"), Z.apush(_t1340, Z.dup(v_line)), Z.apush(_t1340, f_zs_invoke(Z.dup(v_this), "call", ((_t1341 = Z.arrNew()), Z.apush(_t1341, Z.dup(v_line)), Z.apush(_t1341, "zs_no_method"), Z.apush(_t1341, ((_t1342 = Z.arrNew()), Z.apush(_t1342, f_zs_invoke(Z.dup(v_this), "mkvar", ((_t1343 = Z.arrNew()), Z.apush(_t1343, Z.dup(v_line)), Z.apush(_t1343, "o"), _t1343))), Z.apush(_t1342, f_zs_invoke(Z.dup(v_this), "mkvar", ((_t1344 = Z.arrNew()), Z.apush(_t1344, Z.dup(v_line)), Z.apush(_t1344, "name"), _t1344))), _t1342)), _t1341))), _t1340));
  Z.setLine(474);
  (v___r129 = f_zs_invoke(Z.dup(v_this), "funcStmt", ((_t1345 = Z.arrNew()), Z.apush(_t1345, Z.dup(v_line)), Z.apush(_t1345, "zs_invoke_n"), Z.apush(_t1345, ((_t1346 = Z.arrNew()), Z.apush(_t1346, f_zs_invoke(Z.dup(v_this), "param", ((_t1347 = Z.arrNew()), Z.apush(_t1347, "o"), _t1347))), Z.apush(_t1346, f_zs_invoke(Z.dup(v_this), "param", ((_t1348 = Z.arrNew()), Z.apush(_t1348, "name"), _t1348))), Z.apush(_t1346, f_zs_invoke(Z.dup(v_this), "param", ((_t1349 = Z.arrNew()), Z.apush(_t1349, "args"), _t1349))), _t1346)), Z.apush(_t1345, Z.dup(v_body)), _t1345)));
  Z.setLine(474);
  (v___w130 = Z.B.zs_obj_take(v_this, "extra"));
  Z.setLine(474);
  Z.apush((v___w130 = Z.wr(v___w130)), Z.dup(v___r129));
  Z.setLine(474);
  Z.B.zs_obj_put(v_this, "extra", v___w130);
  return null;
}
function f_Desugar__genDispatch(v_this) {
  let v_line = null, v_body = null, v_wrapped = null, v_cn = null, v_k = null, v_stmts = null, v_seen = null, v_n = null, v_m = null, v_d = null, v_wn = null, v___r131 = null, v___w132 = null, v___r133 = null, v___w134 = null, v_b = null, v_or = null, v_t = null, v___r135 = null, v___w136 = null;
  let _t1350 = null, _t1351 = null, _t1352 = null, _t1353 = null, _t1354 = null, _t1355 = null, _t1356 = null, _t1357 = null, _t1358 = null, _t1359 = null, _t1360 = null, _t1361 = null, _t1362 = null, _t1363 = null, _t1364 = null, _t1365 = null, _t1366 = null, _t1367 = null, _t1368 = null, _t1369 = null, _t1370 = null, _t1371 = null, _t1372 = null, _t1373 = null, _t1374 = null, _t1375 = null, _t1376 = null, _t1377 = null, _t1378 = null, _t1379 = null, _t1380 = null, _t1381 = null, _t1382 = null, _t1383 = null, _t1384 = null, _t1385 = null, _t1386 = null, _t1387 = null, _t1388 = null, _t1389 = null, _t1390 = null, _t1391 = null, _t1392 = null, _t1393 = null, _t1394 = null, _t1395 = null, _t1396 = null, _t1397 = null, _t1398 = null, _t1399 = null, _t1400 = null, _t1401 = null, _t1402 = null, _t1403 = null, _t1404 = null, _t1405 = null, _t1406 = null, _t1407 = null, _t1408 = null, _t1409 = null, _t1410 = null, _t1411 = null, _t1412 = null, _t1413 = null, _t1414 = null, _t1415 = null, _t1416 = null, _t1417 = null, _t1418 = null, _t1419 = null, _t1420 = null, _t1421 = null, _t1422 = null, _t1423 = null, _t1424 = null, _t1425 = null, _t1426 = null, _t1427 = null, _t1428 = null, _t1429 = null, _t1430 = null, _t1431 = null, _t1432 = null, _t1433 = null, _t1434 = null, _t1435 = null, _t1436 = null, _t1437 = null, _t1438 = null, _t1439 = null, _t1440 = null, _t1441 = null, _t1442 = null, _t1443 = null, _t1444 = null, _t1445 = null, _t1446 = null, _t1447 = null, _t1448 = null, _t1449 = null, _t1450 = null, _t1451 = null, _t1452 = null, _t1453 = null, _t1454 = null, _t1455 = null, _t1456 = null, _t1457 = null, _t1458 = null, _t1459 = null, _t1460 = null;
  Z.setLine(478);
  if (Z.truthy((Z.cmp(Z.B.count(Z.B.zs_obj_get(v_this, "nuse")), 0) > 0))) {
    Z.setLine(478);
    f_zs_invoke(Z.dup(v_this), "genDispatchN", ((_t1350 = Z.arrNew()), _t1350));
  }
  Z.setLine(479);
  (v_line = 0);
  Z.setLine(480);
  (v_body = ((_t1351 = Z.arrNew()), _t1351));
  Z.setLine(481);
  Z.apush((v_body = Z.wr(v_body)), ((_t1352 = Z.arrNew()), Z.apush(_t1352, ":Expr"), Z.apush(_t1352, Z.dup(v_line)), Z.apush(_t1352, ((_t1353 = Z.arrNew()), Z.apush(_t1353, ":Assign"), Z.apush(_t1353, Z.dup(v_line)), Z.apush(_t1353, f_zs_invoke(Z.dup(v_this), "mkvar", ((_t1354 = Z.arrNew()), Z.apush(_t1354, Z.dup(v_line)), Z.apush(_t1354, "c"), _t1354))), Z.apush(_t1353, f_zs_invoke(Z.dup(v_this), "call", ((_t1355 = Z.arrNew()), Z.apush(_t1355, Z.dup(v_line)), Z.apush(_t1355, "zs_obj_class"), Z.apush(_t1355, ((_t1356 = Z.arrNew()), Z.apush(_t1356, f_zs_invoke(Z.dup(v_this), "mkvar", ((_t1357 = Z.arrNew()), Z.apush(_t1357, Z.dup(v_line)), Z.apush(_t1357, "o"), _t1357))), _t1356)), _t1355))), _t1353)), _t1352));
  Z.setLine(482);
  Z.apush((v_body = Z.wr(v_body)), ((_t1358 = Z.arrNew()), Z.apush(_t1358, ":If"), Z.apush(_t1358, Z.dup(v_line)), Z.apush(_t1358, ((_t1359 = Z.arrNew()), Z.apush(_t1359, ":Binary"), Z.apush(_t1359, Z.dup(v_line)), Z.apush(_t1359, "Identical"), Z.apush(_t1359, f_zs_invoke(Z.dup(v_this), "mkvar", ((_t1360 = Z.arrNew()), Z.apush(_t1360, Z.dup(v_line)), Z.apush(_t1360, "c"), _t1360))), Z.apush(_t1359, ((_t1361 = Z.arrNew()), Z.apush(_t1361, ":Null"), Z.apush(_t1361, Z.dup(v_line)), _t1361)), _t1359)), Z.apush(_t1358, ((_t1362 = Z.arrNew()), Z.apush(_t1362, ((_t1363 = Z.arrNew()), Z.apush(_t1363, ":If"), Z.apush(_t1363, Z.dup(v_line)), Z.apush(_t1363, ((_t1364 = Z.arrNew()), Z.apush(_t1364, ":Binary"), Z.apush(_t1364, Z.dup(v_line)), Z.apush(_t1364, "Identical"), Z.apush(_t1364, f_zs_invoke(Z.dup(v_this), "mkvar", ((_t1365 = Z.arrNew()), Z.apush(_t1365, Z.dup(v_line)), Z.apush(_t1365, "name"), _t1365))), Z.apush(_t1364, f_zs_invoke(Z.dup(v_this), "mkstr", ((_t1366 = Z.arrNew()), Z.apush(_t1366, Z.dup(v_line)), Z.apush(_t1366, "getMessage"), _t1366))), _t1364)), Z.apush(_t1363, ((_t1367 = Z.arrNew()), Z.apush(_t1367, ((_t1368 = Z.arrNew()), Z.apush(_t1368, ":Return"), Z.apush(_t1368, Z.dup(v_line)), Z.apush(_t1368, ((_t1369 = Z.arrNew()), Z.apush(_t1369, ":Call"), Z.apush(_t1369, Z.dup(v_line)), Z.apush(_t1369, ((_t1370 = Z.arrNew()), Z.apush(_t1370, ":Prop"), Z.apush(_t1370, Z.dup(v_line)), Z.apush(_t1370, f_zs_invoke(Z.dup(v_this), "mkvar", ((_t1371 = Z.arrNew()), Z.apush(_t1371, Z.dup(v_line)), Z.apush(_t1371, "o"), _t1371))), Z.apush(_t1370, "getMessage"), _t1370)), Z.apush(_t1369, ((_t1372 = Z.arrNew()), _t1372)), _t1369)), _t1368)), _t1367)), Z.apush(_t1363, null), _t1363)), _t1362)), Z.apush(_t1358, null), _t1358));
  Z.setLine(485);
  (v_wrapped = ((_t1373 = Z.arrNew()), _t1373));
  Z.setLine(486);
  {
    const _it145 = Z.foreachArr(Z.B.zs_obj_get(v_this, "classes"));
    L145: for (let _i145 = 0; _i145 < _it145.keys.length; _i145++) {
      v_k = _it145.vals[_i145];
      v_cn = _it145.keys[_i145];
      Z.setLine(487);
      (v_stmts = ((_t1374 = Z.arrNew()), _t1374));
      Z.setLine(488);
      (v_seen = ((_t1375 = Z.arrNew()), _t1375));
      Z.setLine(489);
      {
        const _it146 = Z.foreachArr(f_zs_invoke(Z.dup(v_this), "chain", ((_t1376 = Z.arrNew()), Z.apush(_t1376, Z.dup(v_cn)), _t1376)));
        L146: for (let _i146 = 0; _i146 < _it146.keys.length; _i146++) {
          v_n = _it146.vals[_i146];
          Z.setLine(490);
          {
            const _it147 = Z.foreachArr(Z.B.zs_obj_get(Z.index(Z.B.zs_obj_get(v_this, "classes"), v_n), "methods"));
            L147: for (let _i147 = 0; _i147 < _it147.keys.length; _i147++) {
              v_d = _it147.vals[_i147];
              v_m = _it147.keys[_i147];
              Z.setLine(491);
              if (Z.truthy((Z.truthy((Z.truthy((Z.truthy(Z.index(v_d, "abstract")) || Z.truthy(Z.index(v_d, "static")))) || Z.truthy(Z.ident(v_m, "__construct")))) || Z.truthy(Z.B.has_key(v_seen, v_m))))) {
                continue L147;
              }
              Z.setLine(492);
              Z.aset((v_seen = Z.wr(v_seen)), v_m, true);
              Z.setLine(493);
              (v_wn = Z.concat(Z.concat(Z.concat(v_n, "__"), v_m), "__w"));
              Z.setLine(494);
              if (Z.truthy(!Z.truthy(Z.B.has_key(v_wrapped, v_wn)))) {
                Z.setLine(494);
                Z.aset((v_wrapped = Z.wr(v_wrapped)), v_wn, true);
                Z.setLine(494);
                (v___r131 = f_zs_invoke(Z.dup(v_this), "wrapper", ((_t1377 = Z.arrNew()), Z.apush(_t1377, Z.dup(v_n)), Z.apush(_t1377, Z.dup(v_m)), _t1377)));
                Z.setLine(494);
                (v___w132 = Z.B.zs_obj_take(v_this, "extra"));
                Z.setLine(494);
                Z.apush((v___w132 = Z.wr(v___w132)), Z.dup(v___r131));
                Z.setLine(494);
                Z.B.zs_obj_put(v_this, "extra", v___w132);
              }
              Z.setLine(495);
              Z.apush((v_stmts = Z.wr(v_stmts)), ((_t1378 = Z.arrNew()), Z.apush(_t1378, ":If"), Z.apush(_t1378, Z.dup(v_line)), Z.apush(_t1378, ((_t1379 = Z.arrNew()), Z.apush(_t1379, ":Binary"), Z.apush(_t1379, Z.dup(v_line)), Z.apush(_t1379, "Identical"), Z.apush(_t1379, f_zs_invoke(Z.dup(v_this), "mkvar", ((_t1380 = Z.arrNew()), Z.apush(_t1380, Z.dup(v_line)), Z.apush(_t1380, "name"), _t1380))), Z.apush(_t1379, f_zs_invoke(Z.dup(v_this), "mkstr", ((_t1381 = Z.arrNew()), Z.apush(_t1381, Z.dup(v_line)), Z.apush(_t1381, Z.dup(v_m)), _t1381))), _t1379)), Z.apush(_t1378, ((_t1382 = Z.arrNew()), Z.apush(_t1382, ((_t1383 = Z.arrNew()), Z.apush(_t1383, ":Return"), Z.apush(_t1383, Z.dup(v_line)), Z.apush(_t1383, f_zs_invoke(Z.dup(v_this), "call", ((_t1384 = Z.arrNew()), Z.apush(_t1384, Z.dup(v_line)), Z.apush(_t1384, Z.dup(v_wn)), Z.apush(_t1384, ((_t1385 = Z.arrNew()), Z.apush(_t1385, f_zs_invoke(Z.dup(v_this), "mkvar", ((_t1386 = Z.arrNew()), Z.apush(_t1386, Z.dup(v_line)), Z.apush(_t1386, "o"), _t1386))), Z.apush(_t1385, f_zs_invoke(Z.dup(v_this), "mkvar", ((_t1387 = Z.arrNew()), Z.apush(_t1387, Z.dup(v_line)), Z.apush(_t1387, "args"), _t1387))), _t1385)), _t1384))), _t1383)), _t1382)), Z.apush(_t1378, null), _t1378));
            }
          }
        }
      }
      Z.setLine(499);
      if (Z.truthy((Z.cmp(Z.B.count(v_stmts), 0) > 0))) {
        Z.setLine(500);
        Z.apush((v_body = Z.wr(v_body)), ((_t1388 = Z.arrNew()), Z.apush(_t1388, ":If"), Z.apush(_t1388, Z.dup(v_line)), Z.apush(_t1388, ((_t1389 = Z.arrNew()), Z.apush(_t1389, ":Binary"), Z.apush(_t1389, Z.dup(v_line)), Z.apush(_t1389, "Identical"), Z.apush(_t1389, f_zs_invoke(Z.dup(v_this), "mkvar", ((_t1390 = Z.arrNew()), Z.apush(_t1390, Z.dup(v_line)), Z.apush(_t1390, "c"), _t1390))), Z.apush(_t1389, f_zs_invoke(Z.dup(v_this), "mkstr", ((_t1391 = Z.arrNew()), Z.apush(_t1391, Z.dup(v_line)), Z.apush(_t1391, Z.dup(v_cn)), _t1391))), _t1389)), Z.apush(_t1388, Z.dup(v_stmts)), Z.apush(_t1388, null), _t1388));
      }
    }
  }
  Z.setLine(503);
  Z.apush((v_body = Z.wr(v_body)), ((_t1392 = Z.arrNew()), Z.apush(_t1392, ":Return"), Z.apush(_t1392, Z.dup(v_line)), Z.apush(_t1392, f_zs_invoke(Z.dup(v_this), "call", ((_t1393 = Z.arrNew()), Z.apush(_t1393, Z.dup(v_line)), Z.apush(_t1393, "zs_no_method"), Z.apush(_t1393, ((_t1394 = Z.arrNew()), Z.apush(_t1394, f_zs_invoke(Z.dup(v_this), "mkvar", ((_t1395 = Z.arrNew()), Z.apush(_t1395, Z.dup(v_line)), Z.apush(_t1395, "o"), _t1395))), Z.apush(_t1394, f_zs_invoke(Z.dup(v_this), "mkvar", ((_t1396 = Z.arrNew()), Z.apush(_t1396, Z.dup(v_line)), Z.apush(_t1396, "name"), _t1396))), _t1394)), _t1393))), _t1392));
  Z.setLine(504);
  (v___r133 = f_zs_invoke(Z.dup(v_this), "funcStmt", ((_t1397 = Z.arrNew()), Z.apush(_t1397, Z.dup(v_line)), Z.apush(_t1397, "zs_invoke"), Z.apush(_t1397, ((_t1398 = Z.arrNew()), Z.apush(_t1398, f_zs_invoke(Z.dup(v_this), "param", ((_t1399 = Z.arrNew()), Z.apush(_t1399, "o"), _t1399))), Z.apush(_t1398, f_zs_invoke(Z.dup(v_this), "param", ((_t1400 = Z.arrNew()), Z.apush(_t1400, "name"), _t1400))), Z.apush(_t1398, f_zs_invoke(Z.dup(v_this), "param", ((_t1401 = Z.arrNew()), Z.apush(_t1401, "args"), _t1401))), _t1398)), Z.apush(_t1397, Z.dup(v_body)), _t1397)));
  Z.setLine(504);
  (v___w134 = Z.B.zs_obj_take(v_this, "extra"));
  Z.setLine(504);
  Z.apush((v___w134 = Z.wr(v___w134)), Z.dup(v___r133));
  Z.setLine(504);
  Z.B.zs_obj_put(v_this, "extra", v___w134);
  Z.setLine(506);
  (v_b = ((_t1402 = Z.arrNew()), _t1402));
  Z.setLine(507);
  Z.apush((v_b = Z.wr(v_b)), ((_t1403 = Z.arrNew()), Z.apush(_t1403, ":Expr"), Z.apush(_t1403, Z.dup(v_line)), Z.apush(_t1403, ((_t1404 = Z.arrNew()), Z.apush(_t1404, ":Assign"), Z.apush(_t1404, Z.dup(v_line)), Z.apush(_t1404, f_zs_invoke(Z.dup(v_this), "mkvar", ((_t1405 = Z.arrNew()), Z.apush(_t1405, Z.dup(v_line)), Z.apush(_t1405, "c"), _t1405))), Z.apush(_t1404, f_zs_invoke(Z.dup(v_this), "call", ((_t1406 = Z.arrNew()), Z.apush(_t1406, Z.dup(v_line)), Z.apush(_t1406, "zs_obj_class"), Z.apush(_t1406, ((_t1407 = Z.arrNew()), Z.apush(_t1407, f_zs_invoke(Z.dup(v_this), "mkvar", ((_t1408 = Z.arrNew()), Z.apush(_t1408, Z.dup(v_line)), Z.apush(_t1408, "o"), _t1408))), _t1407)), _t1406))), _t1404)), _t1403));
  Z.setLine(508);
  Z.apush((v_b = Z.wr(v_b)), ((_t1409 = Z.arrNew()), Z.apush(_t1409, ":If"), Z.apush(_t1409, Z.dup(v_line)), Z.apush(_t1409, ((_t1410 = Z.arrNew()), Z.apush(_t1410, ":Binary"), Z.apush(_t1410, Z.dup(v_line)), Z.apush(_t1410, "Identical"), Z.apush(_t1410, f_zs_invoke(Z.dup(v_this), "mkvar", ((_t1411 = Z.arrNew()), Z.apush(_t1411, Z.dup(v_line)), Z.apush(_t1411, "c"), _t1411))), Z.apush(_t1410, ((_t1412 = Z.arrNew()), Z.apush(_t1412, ":Null"), Z.apush(_t1412, Z.dup(v_line)), _t1412)), _t1410)), Z.apush(_t1409, ((_t1413 = Z.arrNew()), Z.apush(_t1413, ((_t1414 = Z.arrNew()), Z.apush(_t1414, ":Expr"), Z.apush(_t1414, Z.dup(v_line)), Z.apush(_t1414, ((_t1415 = Z.arrNew()), Z.apush(_t1415, ":Assign"), Z.apush(_t1415, Z.dup(v_line)), Z.apush(_t1415, f_zs_invoke(Z.dup(v_this), "mkvar", ((_t1416 = Z.arrNew()), Z.apush(_t1416, Z.dup(v_line)), Z.apush(_t1416, "t"), _t1416))), Z.apush(_t1415, f_zs_invoke(Z.dup(v_this), "call", ((_t1417 = Z.arrNew()), Z.apush(_t1417, Z.dup(v_line)), Z.apush(_t1417, "typeof"), Z.apush(_t1417, ((_t1418 = Z.arrNew()), Z.apush(_t1418, f_zs_invoke(Z.dup(v_this), "mkvar", ((_t1419 = Z.arrNew()), Z.apush(_t1419, Z.dup(v_line)), Z.apush(_t1419, "o"), _t1419))), _t1418)), _t1417))), _t1415)), _t1414)), Z.apush(_t1413, ((_t1420 = Z.arrNew()), Z.apush(_t1420, ":Return"), Z.apush(_t1420, Z.dup(v_line)), Z.apush(_t1420, ((_t1421 = Z.arrNew()), Z.apush(_t1421, ":Binary"), Z.apush(_t1421, Z.dup(v_line)), Z.apush(_t1421, "Or"), Z.apush(_t1421, ((_t1422 = Z.arrNew()), Z.apush(_t1422, ":Binary"), Z.apush(_t1422, Z.dup(v_line)), Z.apush(_t1422, "Identical"), Z.apush(_t1422, f_zs_invoke(Z.dup(v_this), "mkvar", ((_t1423 = Z.arrNew()), Z.apush(_t1423, Z.dup(v_line)), Z.apush(_t1423, "t"), _t1423))), Z.apush(_t1422, f_zs_invoke(Z.dup(v_this), "mkvar", ((_t1424 = Z.arrNew()), Z.apush(_t1424, Z.dup(v_line)), Z.apush(_t1424, "k"), _t1424))), _t1422)), Z.apush(_t1421, ((_t1425 = Z.arrNew()), Z.apush(_t1425, ":Binary"), Z.apush(_t1425, Z.dup(v_line)), Z.apush(_t1425, "Or"), Z.apush(_t1425, ((_t1426 = Z.arrNew()), Z.apush(_t1426, ":Binary"), Z.apush(_t1426, Z.dup(v_line)), Z.apush(_t1426, "And"), Z.apush(_t1426, ((_t1427 = Z.arrNew()), Z.apush(_t1427, ":Binary"), Z.apush(_t1427, Z.dup(v_line)), Z.apush(_t1427, "Identical"), Z.apush(_t1427, f_zs_invoke(Z.dup(v_this), "mkvar", ((_t1428 = Z.arrNew()), Z.apush(_t1428, Z.dup(v_line)), Z.apush(_t1428, "k"), _t1428))), Z.apush(_t1427, f_zs_invoke(Z.dup(v_this), "mkstr", ((_t1429 = Z.arrNew()), Z.apush(_t1429, Z.dup(v_line)), Z.apush(_t1429, "Exception"), _t1429))), _t1427)), Z.apush(_t1426, ((_t1430 = Z.arrNew()), Z.apush(_t1430, ":Binary"), Z.apush(_t1430, Z.dup(v_line)), Z.apush(_t1430, "Identical"), Z.apush(_t1430, f_zs_invoke(Z.dup(v_this), "mkvar", ((_t1431 = Z.arrNew()), Z.apush(_t1431, Z.dup(v_line)), Z.apush(_t1431, "t"), _t1431))), Z.apush(_t1430, f_zs_invoke(Z.dup(v_this), "mkstr", ((_t1432 = Z.arrNew()), Z.apush(_t1432, Z.dup(v_line)), Z.apush(_t1432, "Error"), _t1432))), _t1430)), _t1426)), Z.apush(_t1425, ((_t1433 = Z.arrNew()), Z.apush(_t1433, ":Binary"), Z.apush(_t1433, Z.dup(v_line)), Z.apush(_t1433, "And"), Z.apush(_t1433, ((_t1434 = Z.arrNew()), Z.apush(_t1434, ":Binary"), Z.apush(_t1434, Z.dup(v_line)), Z.apush(_t1434, "Identical"), Z.apush(_t1434, f_zs_invoke(Z.dup(v_this), "mkvar", ((_t1435 = Z.arrNew()), Z.apush(_t1435, Z.dup(v_line)), Z.apush(_t1435, "k"), _t1435))), Z.apush(_t1434, f_zs_invoke(Z.dup(v_this), "mkstr", ((_t1436 = Z.arrNew()), Z.apush(_t1436, Z.dup(v_line)), Z.apush(_t1436, "Throwable"), _t1436))), _t1434)), Z.apush(_t1433, ((_t1437 = Z.arrNew()), Z.apush(_t1437, ":Binary"), Z.apush(_t1437, Z.dup(v_line)), Z.apush(_t1437, "Or"), Z.apush(_t1437, ((_t1438 = Z.arrNew()), Z.apush(_t1438, ":Binary"), Z.apush(_t1438, Z.dup(v_line)), Z.apush(_t1438, "Identical"), Z.apush(_t1438, f_zs_invoke(Z.dup(v_this), "mkvar", ((_t1439 = Z.arrNew()), Z.apush(_t1439, Z.dup(v_line)), Z.apush(_t1439, "t"), _t1439))), Z.apush(_t1438, f_zs_invoke(Z.dup(v_this), "mkstr", ((_t1440 = Z.arrNew()), Z.apush(_t1440, Z.dup(v_line)), Z.apush(_t1440, "Exception"), _t1440))), _t1438)), Z.apush(_t1437, ((_t1441 = Z.arrNew()), Z.apush(_t1441, ":Binary"), Z.apush(_t1441, Z.dup(v_line)), Z.apush(_t1441, "Identical"), Z.apush(_t1441, f_zs_invoke(Z.dup(v_this), "mkvar", ((_t1442 = Z.arrNew()), Z.apush(_t1442, Z.dup(v_line)), Z.apush(_t1442, "t"), _t1442))), Z.apush(_t1441, f_zs_invoke(Z.dup(v_this), "mkstr", ((_t1443 = Z.arrNew()), Z.apush(_t1443, Z.dup(v_line)), Z.apush(_t1443, "Error"), _t1443))), _t1441)), _t1437)), _t1433)), _t1425)), _t1421)), _t1420)), _t1413)), Z.apush(_t1409, null), _t1409));
  Z.setLine(515);
  {
    const _it148 = Z.foreachArr(Z.B.zs_obj_get(v_this, "classes"));
    L148: for (let _i148 = 0; _i148 < _it148.keys.length; _i148++) {
      v_k = _it148.vals[_i148];
      v_cn = _it148.keys[_i148];
      Z.setLine(516);
      (v_or = null);
      Z.setLine(517);
      {
        const _it149 = Z.foreachArr(f_zs_invoke(Z.dup(v_this), "isaNames", ((_t1444 = Z.arrNew()), Z.apush(_t1444, Z.dup(v_cn)), _t1444)));
        L149: for (let _i149 = 0; _i149 < _it149.keys.length; _i149++) {
          v_n = _it149.vals[_i149];
          Z.setLine(518);
          (v_t = ((_t1445 = Z.arrNew()), Z.apush(_t1445, ":Binary"), Z.apush(_t1445, Z.dup(v_line)), Z.apush(_t1445, "Identical"), Z.apush(_t1445, f_zs_invoke(Z.dup(v_this), "mkvar", ((_t1446 = Z.arrNew()), Z.apush(_t1446, Z.dup(v_line)), Z.apush(_t1446, "k"), _t1446))), Z.apush(_t1445, f_zs_invoke(Z.dup(v_this), "mkstr", ((_t1447 = Z.arrNew()), Z.apush(_t1447, Z.dup(v_line)), Z.apush(_t1447, Z.dup(v_n)), _t1447))), _t1445));
          Z.setLine(519);
          (v_or = (Z.truthy(Z.ident(v_or, null)) ? v_t : ((_t1448 = Z.arrNew()), Z.apush(_t1448, ":Binary"), Z.apush(_t1448, Z.dup(v_line)), Z.apush(_t1448, "Or"), Z.apush(_t1448, Z.dup(v_or)), Z.apush(_t1448, Z.dup(v_t)), _t1448)));
        }
      }
      Z.setLine(521);
      Z.apush((v_b = Z.wr(v_b)), ((_t1449 = Z.arrNew()), Z.apush(_t1449, ":If"), Z.apush(_t1449, Z.dup(v_line)), Z.apush(_t1449, ((_t1450 = Z.arrNew()), Z.apush(_t1450, ":Binary"), Z.apush(_t1450, Z.dup(v_line)), Z.apush(_t1450, "Identical"), Z.apush(_t1450, f_zs_invoke(Z.dup(v_this), "mkvar", ((_t1451 = Z.arrNew()), Z.apush(_t1451, Z.dup(v_line)), Z.apush(_t1451, "c"), _t1451))), Z.apush(_t1450, f_zs_invoke(Z.dup(v_this), "mkstr", ((_t1452 = Z.arrNew()), Z.apush(_t1452, Z.dup(v_line)), Z.apush(_t1452, Z.dup(v_cn)), _t1452))), _t1450)), Z.apush(_t1449, ((_t1453 = Z.arrNew()), Z.apush(_t1453, ((_t1454 = Z.arrNew()), Z.apush(_t1454, ":Return"), Z.apush(_t1454, Z.dup(v_line)), Z.apush(_t1454, Z.dup(v_or)), _t1454)), _t1453)), Z.apush(_t1449, null), _t1449));
    }
  }
  Z.setLine(523);
  Z.apush((v_b = Z.wr(v_b)), ((_t1455 = Z.arrNew()), Z.apush(_t1455, ":Return"), Z.apush(_t1455, Z.dup(v_line)), Z.apush(_t1455, ((_t1456 = Z.arrNew()), Z.apush(_t1456, ":Bool"), Z.apush(_t1456, Z.dup(v_line)), Z.apush(_t1456, false), _t1456)), _t1455));
  Z.setLine(524);
  (v___r135 = f_zs_invoke(Z.dup(v_this), "funcStmt", ((_t1457 = Z.arrNew()), Z.apush(_t1457, Z.dup(v_line)), Z.apush(_t1457, "zs_isa"), Z.apush(_t1457, ((_t1458 = Z.arrNew()), Z.apush(_t1458, f_zs_invoke(Z.dup(v_this), "param", ((_t1459 = Z.arrNew()), Z.apush(_t1459, "o"), _t1459))), Z.apush(_t1458, f_zs_invoke(Z.dup(v_this), "param", ((_t1460 = Z.arrNew()), Z.apush(_t1460, "k"), _t1460))), _t1458)), Z.apush(_t1457, Z.dup(v_b)), _t1457)));
  Z.setLine(524);
  (v___w136 = Z.B.zs_obj_take(v_this, "extra"));
  Z.setLine(524);
  Z.apush((v___w136 = Z.wr(v___w136)), Z.dup(v___r135));
  Z.setLine(524);
  Z.B.zs_obj_put(v_this, "extra", v___w136);
  return null;
}
function f_Desugar__new() {
  let v___o = null;
  let _t1461 = null, _t1462 = null, _t1463 = null, _t1464 = null, _t1465 = null;
  Z.setLine(27);
  (v___o = Z.B.zs_obj_new("Desugar"));
  Z.setLine(27);
  Z.B.zs_obj_set(v___o, "classes", ((_t1461 = Z.arrNew()), _t1461));
  Z.setLine(27);
  Z.B.zs_obj_set(v___o, "errors", ((_t1462 = Z.arrNew()), _t1462));
  Z.setLine(27);
  Z.B.zs_obj_set(v___o, "tmp", 0);
  Z.setLine(27);
  Z.B.zs_obj_set(v___o, "cur", null);
  Z.setLine(27);
  Z.B.zs_obj_set(v___o, "curStatic", false);
  Z.setLine(27);
  Z.B.zs_obj_set(v___o, "dispatch", ((_t1463 = Z.arrNew()), _t1463));
  Z.setLine(27);
  Z.B.zs_obj_set(v___o, "extra", ((_t1464 = Z.arrNew()), _t1464));
  Z.setLine(27);
  Z.B.zs_obj_set(v___o, "nuse", ((_t1465 = Z.arrNew()), _t1465));
  Z.setLine(27);
  Z.B.zs_obj_set(v___o, "excMode", false);
  Z.setLine(27);
  return Z.dup(v___o);
  return null;
}
function f_Linker__err(v_this, v_file, v_line, v_code, v_msg) {
  let v___r137 = null, v___w138 = null;
  let _t1466 = null;
  Z.setLine(25);
  (v___r137 = ((_t1466 = Z.arrNew()), Z.apush(_t1466, Z.dup(v_line)), Z.apush(_t1466, Z.dup(v_code)), Z.apush(_t1466, Z.dup(v_msg)), Z.apush(_t1466, Z.dup(v_file)), _t1466));
  Z.setLine(25);
  (v___w138 = Z.B.zs_obj_take(v_this, "errors"));
  Z.setLine(25);
  Z.apush((v___w138 = Z.wr(v___w138)), Z.dup(v___r137));
  Z.setLine(25);
  Z.B.zs_obj_put(v_this, "errors", v___w138);
  return null;
}
function f_Linker__prefixOf(v_this, v_path) {
  Z.setLine(27);
  return Z.B.join(v_path, "_");
  return null;
}
function f_Linker__dirOf(v_this, v_file) {
  let v_d = null;
  Z.setLine(30);
  (v_d = Z.M.System.dirname(v_file));
  Z.setLine(31);
  return (Z.truthy((Z.truthy(Z.ident(v_d, null)) || Z.truthy(Z.ident(v_d, "")))) ? "." : v_d);
  return null;
}
function f_Linker__rw(v_this, v_x, v_self, v_funcs, v_aliases) {
  let v_callee = null, v_m = null, v_args = null, v_a = null, v_o = null, v_k = null, v_v = null;
  let _t1467 = null, _t1468 = null, _t1469 = null, _t1470 = null, _t1471 = null, _t1472 = null, _t1473 = null, _t1474 = null;
  Z.setLine(36);
  if (Z.truthy(!Z.truthy(Z.B.is_array(v_x)))) {
    Z.setLine(36);
    return Z.dup(v_x);
  }
  Z.setLine(37);
  if (Z.truthy((Z.truthy(f_Workspace_parser__isNode(Z.dup(v_x))) && Z.truthy(Z.ident(Z.index(v_x, 0), ":Call"))))) {
    Z.setLine(38);
    (v_callee = Z.dup(Z.index(v_x, 2)));
    Z.setLine(39);
    if (Z.truthy((Z.truthy((Z.truthy(Z.ident(Z.index(v_callee, 0), ":Name")) && Z.truthy(!Z.ident(v_self, null)))) && Z.truthy(Z.B.has_key(v_funcs, Z.index(v_callee, 2)))))) {
      Z.setLine(40);
      Z.aset((v_callee = Z.wr(v_callee)), 2, Z.concat(Z.concat(v_self, "__"), Z.index(v_callee, 2)));
      Z.setLine(41);
      Z.aset((v_x = Z.wr(v_x)), 2, Z.dup(v_callee));
    } else {
      Z.setLine(42);
      if (Z.truthy((Z.truthy((Z.truthy(Z.ident(Z.index(v_callee, 0), ":Dot")) && Z.truthy(Z.ident(Z.index(Z.index(v_callee, 2), 0), ":Name")))) && Z.truthy(Z.B.has_key(v_aliases, Z.index(Z.index(v_callee, 2), 2)))))) {
        Z.setLine(43);
        (v_m = Z.dup(Z.index(v_aliases, Z.index(Z.index(v_callee, 2), 2))));
        Z.setLine(44);
        Z.aset((v_x = Z.wr(v_x)), 2, ((_t1467 = Z.arrNew()), Z.apush(_t1467, ":Name"), Z.apush(_t1467, Z.dup(Z.index(v_callee, 1))), Z.apush(_t1467, Z.concat(Z.concat(Z.index(v_m, "prefix"), "__"), Z.index(v_callee, 3))), _t1467));
      }
    }
    Z.setLine(46);
    (v_args = ((_t1468 = Z.arrNew()), _t1468));
    Z.setLine(47);
    {
      const _it150 = Z.foreachArr(Z.dup(Z.index(v_x, 3)));
      L150: for (let _i150 = 0; _i150 < _it150.keys.length; _i150++) {
        v_a = _it150.vals[_i150];
        Z.setLine(47);
        Z.apush((v_args = Z.wr(v_args)), f_zs_invoke(Z.dup(v_this), "rw", ((_t1469 = Z.arrNew()), Z.apush(_t1469, Z.dup(v_a)), Z.apush(_t1469, Z.dup(v_self)), Z.apush(_t1469, Z.dup(v_funcs)), Z.apush(_t1469, Z.dup(v_aliases)), _t1469)));
      }
    }
    Z.setLine(48);
    Z.aset((v_x = Z.wr(v_x)), 3, Z.dup(v_args));
    Z.setLine(49);
    if (Z.truthy(!Z.ident(Z.index(Z.index(v_x, 2), 0), ":Dot"))) {
      Z.setLine(49);
      Z.aset((v_x = Z.wr(v_x)), 2, f_zs_invoke(Z.dup(v_this), "rw", ((_t1470 = Z.arrNew()), Z.apush(_t1470, Z.dup(Z.index(v_x, 2))), Z.apush(_t1470, Z.dup(v_self)), Z.apush(_t1470, Z.dup(v_funcs)), Z.apush(_t1470, Z.dup(v_aliases)), _t1470)));
    }
    Z.setLine(50);
    return Z.dup(v_x);
  }
  Z.setLine(52);
  if (Z.truthy((Z.truthy((Z.truthy((Z.truthy((Z.truthy(f_Workspace_parser__isNode(Z.dup(v_x))) && Z.truthy(Z.ident(Z.index(v_x, 0), ":Dot")))) && Z.truthy(Z.ident(Z.index(Z.index(v_x, 2), 0), ":Name")))) && Z.truthy(Z.ident(Z.index(Z.index(v_x, 2), 2), "System")))) && Z.truthy(Z.ident(Z.index(v_x, 3), "version"))))) {
    Z.setLine(53);
    return ((_t1471 = Z.arrNew()), Z.apush(_t1471, ":Call"), Z.apush(_t1471, Z.dup(Z.index(v_x, 1))), Z.apush(_t1471, Z.dup(v_x)), Z.apush(_t1471, ((_t1472 = Z.arrNew()), _t1472)), _t1471);
  }
  Z.setLine(55);
  (v_o = ((_t1473 = Z.arrNew()), _t1473));
  Z.setLine(56);
  {
    const _it151 = Z.foreachArr(Z.dup(v_x));
    L151: for (let _i151 = 0; _i151 < _it151.keys.length; _i151++) {
      v_v = _it151.vals[_i151];
      v_k = _it151.keys[_i151];
      Z.setLine(56);
      Z.aset((v_o = Z.wr(v_o)), v_k, f_zs_invoke(Z.dup(v_this), "rw", ((_t1474 = Z.arrNew()), Z.apush(_t1474, Z.dup(v_v)), Z.apush(_t1474, Z.dup(v_self)), Z.apush(_t1474, Z.dup(v_funcs)), Z.apush(_t1474, Z.dup(v_aliases)), _t1474)));
    }
  }
  Z.setLine(57);
  return Z.dup(v_o);
  return null;
}
function f_Linker__loadModule(v_this, v_file, v_path, v_fromFile, v_line) {
  let v___k139 = null, v___r140 = null, v___w141 = null, v_ast = null, v___ex142 = null, v_e = null, v___k143 = null, v___r144 = null, v___w145 = null, v_prefix = null, v_funcs = null, v_s = null, v_aliases = null, v_stmts = null, v_k = null, v_f = null, v___k146 = null, v___r147 = null, v___w148 = null, v_m = null, v___k149 = null, v___r150 = null, v___w151 = null, v___r152 = null, v___w153 = null;
  let _t1475 = null, _t1476 = null, _t1477 = null, _t1478 = null, _t1479 = null, _t1480 = null, _t1481 = null, _t1482 = null, _t1483 = null, _t1484 = null, _t1485 = null, _t1486 = null;
  Z.setLine(62);
  if (Z.truthy(Z.B.has_key(Z.B.zs_obj_get(v_this, "loaded"), v_file))) {
    Z.setLine(62);
    return Z.dup(Z.index(Z.B.zs_obj_get(v_this, "loaded"), v_file));
  }
  Z.setLine(63);
  if (Z.truthy((((_t1475 = Z.indexOpt(Z.B.zs_obj_get(v_this, "active"), v_file)) !== null) ? _t1475 : false))) {
    Z.setLine(63);
    f_zs_invoke(Z.dup(v_this), "err", ((_t1476 = Z.arrNew()), Z.apush(_t1476, Z.dup(v_fromFile)), Z.apush(_t1476, Z.dup(v_line)), Z.apush(_t1476, "E0106"), Z.apush(_t1476, Z.concat("cykliczny import ", Z.B.join(v_path, "."))), _t1476));
    Z.setLine(63);
    return null;
  }
  Z.setLine(64);
  (v___k139 = Z.dup(v_file));
  Z.setLine(64);
  (v___r140 = true);
  Z.setLine(64);
  (v___w141 = Z.B.zs_obj_take(v_this, "active"));
  Z.setLine(64);
  Z.aset((v___w141 = Z.wr(v___w141)), v___k139, Z.dup(v___r140));
  Z.setLine(64);
  Z.B.zs_obj_put(v_this, "active", v___w141);
  try {
    Z.setLine(65);
    (v_ast = f_Workspace_parser__parse(Z.M.File.read(v_file)));
  } catch (_e) {
    _e = Z.toExc(_e);
    if (true) {
      v___ex142 = _e;
      Z.setLine(65);
      if (Z.truthy(f_zs_isa(Z.dup(v___ex142), "Exception"))) {
        Z.setLine(65);
        (v_e = Z.dup(v___ex142));
        Z.setLine(66);
        f_zs_invoke(Z.dup(v_this), "err", ((_t1477 = Z.arrNew()), Z.apush(_t1477, Z.dup(v_file)), Z.apush(_t1477, 0), Z.apush(_t1477, "E0106"), Z.apush(_t1477, Z.concat("błąd składni modułu: ", f_zs_invoke(Z.dup(v_e), "getMessage", ((_t1478 = Z.arrNew()), _t1478)))), _t1477));
        Z.setLine(66);
        (v___k143 = Z.dup(v_file));
        Z.setLine(66);
        (v___r144 = false);
        Z.setLine(66);
        (v___w145 = Z.B.zs_obj_take(v_this, "active"));
        Z.setLine(66);
        Z.aset((v___w145 = Z.wr(v___w145)), v___k143, Z.dup(v___r144));
        Z.setLine(66);
        Z.B.zs_obj_put(v_this, "active", v___w145);
        Z.setLine(66);
        return null;
      } else {
        Z.setLine(65);
        Z.throwV(v___ex142);
      }
    }
    else throw _e;
  }
  Z.setLine(67);
  (v_prefix = f_zs_invoke(Z.dup(v_this), "prefixOf", ((_t1479 = Z.arrNew()), Z.apush(_t1479, Z.dup(v_path)), _t1479)));
  Z.setLine(68);
  (v_funcs = ((_t1480 = Z.arrNew()), _t1480));
  Z.setLine(69);
  {
    const _it152 = Z.foreachArr(Z.dup(v_ast));
    L152: for (let _i152 = 0; _i152 < _it152.keys.length; _i152++) {
      v_s = _it152.vals[_i152];
      Z.setLine(69);
      if (Z.truthy(Z.ident(Z.index(v_s, 0), ":FuncStmt"))) {
        Z.setLine(69);
        Z.aset((v_funcs = Z.wr(v_funcs)), Z.index(Z.index(v_s, 2), 2), true);
      }
    }
  }
  Z.setLine(70);
  (v_aliases = f_zs_invoke(Z.dup(v_this), "collectImports", ((_t1481 = Z.arrNew()), Z.apush(_t1481, Z.dup(v_ast)), Z.apush(_t1481, Z.dup(v_file)), _t1481)));
  Z.setLine(71);
  (v_stmts = ((_t1482 = Z.arrNew()), _t1482));
  Z.setLine(72);
  {
    const _it153 = Z.foreachArr(Z.dup(v_ast));
    L153: for (let _i153 = 0; _i153 < _it153.keys.length; _i153++) {
      v_s = _it153.vals[_i153];
      Z.setLine(73);
      (v_k = Z.dup(Z.index(v_s, 0)));
      Z.setLine(74);
      if (Z.truthy(Z.ident(v_k, ":FuncStmt"))) {
        Z.setLine(75);
        (v_f = Z.dup(Z.index(v_s, 2)));
        Z.setLine(76);
        Z.aset((v_f = Z.wr(v_f)), 2, Z.concat(Z.concat(v_prefix, "__"), Z.index(v_f, 2)));
        Z.setLine(77);
        Z.aset((v_f = Z.wr(v_f)), 5, f_zs_invoke(Z.dup(v_this), "rw", ((_t1483 = Z.arrNew()), Z.apush(_t1483, Z.dup(Z.index(v_f, 5))), Z.apush(_t1483, Z.dup(v_prefix)), Z.apush(_t1483, Z.dup(v_funcs)), Z.apush(_t1483, Z.dup(v_aliases)), _t1483)));
        Z.setLine(78);
        Z.aset((v_s = Z.wr(v_s)), 2, Z.dup(v_f));
        Z.setLine(79);
        Z.apush((v_stmts = Z.wr(v_stmts)), Z.dup(v_s));
      } else {
        Z.setLine(80);
        if (Z.truthy(Z.ident(v_k, ":ClassStmt"))) {
          Z.setLine(81);
          Z.apush((v_stmts = Z.wr(v_stmts)), f_zs_invoke(Z.dup(v_this), "rw", ((_t1484 = Z.arrNew()), Z.apush(_t1484, Z.dup(v_s)), Z.apush(_t1484, Z.dup(v_prefix)), Z.apush(_t1484, Z.dup(v_funcs)), Z.apush(_t1484, Z.dup(v_aliases)), _t1484)));
        } else {
          Z.setLine(82);
          if (Z.truthy((Z.truthy(!Z.ident(v_k, ":Import")) && Z.truthy(!Z.ident(v_k, ":Namespace"))))) {
            Z.setLine(83);
            f_zs_invoke(Z.dup(v_this), "err", ((_t1485 = Z.arrNew()), Z.apush(_t1485, Z.dup(v_file)), Z.apush(_t1485, Z.dup(Z.index(v_s, 1))), Z.apush(_t1485, "E0106"), Z.apush(_t1485, Z.concat(Z.concat("moduł natywny może zawierać tylko funkcje, klasy, import i namespace (instrukcja ", Z.B.substr(v_k, 1)), ")")), _t1485));
          }
        }
      }
    }
  }
  Z.setLine(86);
  (v___k146 = Z.dup(v_file));
  Z.setLine(86);
  (v___r147 = false);
  Z.setLine(86);
  (v___w148 = Z.B.zs_obj_take(v_this, "active"));
  Z.setLine(86);
  Z.aset((v___w148 = Z.wr(v___w148)), v___k146, Z.dup(v___r147));
  Z.setLine(86);
  Z.B.zs_obj_put(v_this, "active", v___w148);
  Z.setLine(87);
  (v_m = ((_t1486 = Z.arrNew()), Z.aset(_t1486, "prefix", Z.dup(v_prefix)), Z.aset(_t1486, "funcs", Z.dup(v_funcs)), _t1486));
  Z.setLine(88);
  (v___k149 = Z.dup(v_file));
  Z.setLine(88);
  (v___r150 = Z.dup(v_m));
  Z.setLine(88);
  (v___w151 = Z.B.zs_obj_take(v_this, "loaded"));
  Z.setLine(88);
  Z.aset((v___w151 = Z.wr(v___w151)), v___k149, Z.dup(v___r150));
  Z.setLine(88);
  Z.B.zs_obj_put(v_this, "loaded", v___w151);
  Z.setLine(89);
  {
    const _it154 = Z.foreachArr(Z.dup(v_stmts));
    L154: for (let _i154 = 0; _i154 < _it154.keys.length; _i154++) {
      v_s = _it154.vals[_i154];
      Z.setLine(89);
      (v___r152 = Z.dup(v_s));
      Z.setLine(89);
      (v___w153 = Z.B.zs_obj_take(v_this, "out"));
      Z.setLine(89);
      Z.apush((v___w153 = Z.wr(v___w153)), Z.dup(v___r152));
      Z.setLine(89);
      Z.B.zs_obj_put(v_this, "out", v___w153);
    }
  }
  Z.setLine(90);
  return Z.dup(v_m);
  return null;
}
function f_Linker__collectImports(v_this, v_ast, v_file) {
  let v_aliases = null, v_s = null, v_path = null, v_f = null, v_m = null;
  let _t1487 = null, _t1488 = null, _t1489 = null, _t1490 = null;
  Z.setLine(95);
  (v_aliases = ((_t1487 = Z.arrNew()), _t1487));
  Z.setLine(96);
  {
    const _it155 = Z.foreachArr(Z.dup(v_ast));
    L155: for (let _i155 = 0; _i155 < _it155.keys.length; _i155++) {
      v_s = _it155.vals[_i155];
      Z.setLine(97);
      if (Z.truthy(!Z.ident(Z.index(v_s, 0), ":Import"))) {
        continue L155;
      }
      Z.setLine(98);
      (v_path = Z.dup(Z.index(v_s, 2)));
      Z.setLine(99);
      if (Z.truthy(Z.B.in_array(Z.index(v_path, 0), f_Workspace_link__builtin_modules()))) {
        continue L155;
      }
      Z.setLine(100);
      (v_f = Z.M.System.resolveImport(v_path, f_zs_invoke(Z.dup(v_this), "dirOf", ((_t1488 = Z.arrNew()), Z.apush(_t1488, Z.dup(v_file)), _t1488))));
      Z.setLine(101);
      if (Z.truthy(Z.ident(v_f, null))) {
        Z.setLine(101);
        f_zs_invoke(Z.dup(v_this), "err", ((_t1489 = Z.arrNew()), Z.apush(_t1489, Z.dup(v_file)), Z.apush(_t1489, Z.dup(Z.index(v_s, 1))), Z.apush(_t1489, "E0106"), Z.apush(_t1489, Z.concat("nie znaleziono modułu ", Z.B.join(v_path, "."))), _t1489));
        continue L155;
      }
      Z.setLine(102);
      (v_m = f_zs_invoke(Z.dup(v_this), "loadModule", ((_t1490 = Z.arrNew()), Z.apush(_t1490, Z.dup(v_f)), Z.apush(_t1490, Z.dup(v_path)), Z.apush(_t1490, Z.dup(v_file)), Z.apush(_t1490, Z.dup(Z.index(v_s, 1))), _t1490)));
      Z.setLine(103);
      if (Z.truthy(!Z.ident(v_m, null))) {
        Z.setLine(103);
        Z.aset((v_aliases = Z.wr(v_aliases)), Z.index(v_path, Z.sub(Z.B.count(v_path), 1)), Z.dup(v_m));
      }
    }
  }
  Z.setLine(105);
  return Z.dup(v_aliases);
  return null;
}
function f_Linker__new() {
  let v___o = null;
  let _t1491 = null, _t1492 = null, _t1493 = null, _t1494 = null;
  Z.setLine(19);
  (v___o = Z.B.zs_obj_new("Linker"));
  Z.setLine(19);
  Z.B.zs_obj_set(v___o, "errors", ((_t1491 = Z.arrNew()), _t1491));
  Z.setLine(19);
  Z.B.zs_obj_set(v___o, "loaded", ((_t1492 = Z.arrNew()), _t1492));
  Z.setLine(19);
  Z.B.zs_obj_set(v___o, "active", ((_t1493 = Z.arrNew()), _t1493));
  Z.setLine(19);
  Z.B.zs_obj_set(v___o, "out", ((_t1494 = Z.arrNew()), _t1494));
  Z.setLine(19);
  return Z.dup(v___o);
  return null;
}
function f_VarPass__rw(v_this, v_x) {
  let v_k = null, v_args = null, v_a = null, v_out = null, v_i = null, v___r154 = null, v___w155 = null, v_named = null, v_ps = null, v___r156 = null, v___w157 = null, v_rest = null, v_items = null, v___r158 = null, v___w159 = null, v_o = null, v_v = null;
  let _t1495 = null, _t1496 = null, _t1497 = null, _t1498 = null, _t1499 = null, _t1500 = null, _t1501 = null, _t1502 = null, _t1503 = null, _t1504 = null, _t1505 = null, _t1506 = null, _t1507 = null, _t1508 = null, _t1509 = null, _t1510 = null, _t1511 = null;
  Z.setLine(152);
  if (Z.truthy(!Z.truthy(Z.B.is_array(v_x)))) {
    Z.setLine(152);
    return Z.dup(v_x);
  }
  Z.setLine(153);
  if (Z.truthy((Z.truthy((Z.truthy((Z.truthy(f_Workspace_parser__isNode(Z.dup(v_x))) && Z.truthy(Z.ident(Z.index(v_x, 0), ":Call")))) && Z.truthy(Z.ident(Z.index(Z.index(v_x, 2), 0), ":Name")))) && Z.truthy(Z.B.has_key(Z.B.zs_obj_get(v_this, "fixed"), Z.index(Z.index(v_x, 2), 2)))))) {
    Z.setLine(154);
    (v_k = Z.dup(Z.index(Z.B.zs_obj_get(v_this, "fixed"), Z.index(Z.index(v_x, 2), 2))));
    Z.setLine(155);
    (v_args = ((_t1495 = Z.arrNew()), _t1495));
    Z.setLine(156);
    {
      const _it156 = Z.foreachArr(Z.dup(Z.index(v_x, 3)));
      L156: for (let _i156 = 0; _i156 < _it156.keys.length; _i156++) {
        v_a = _it156.vals[_i156];
        Z.setLine(156);
        Z.aset((v_a = Z.wr(v_a)), 3, f_zs_invoke(Z.dup(v_this), "rw", ((_t1496 = Z.arrNew()), Z.apush(_t1496, Z.dup(Z.index(v_a, 3))), _t1496)));
        Z.setLine(156);
        Z.apush((v_args = Z.wr(v_args)), Z.dup(v_a));
      }
    }
    Z.setLine(157);
    (v_out = ((_t1497 = Z.arrNew()), _t1497));
    Z.setLine(158);
    (v_i = 0);
    L157: for (; Z.truthy((Z.truthy((Z.cmp(v_i, Z.B.count(v_args)) < 0)) && Z.truthy((Z.cmp(v_i, v_k) < 0)))); ((_t1498 = v_i), (v_i = Z.add(_t1498, 1)), _t1498)) {
      Z.setLine(159);
      if (Z.truthy(Z.index(Z.index(v_args, v_i), 4))) {
        Z.setLine(159);
        (v___r154 = ((_t1499 = Z.arrNew()), Z.apush(_t1499, Z.dup(Z.index(v_x, 1))), Z.apush(_t1499, "E0104"), Z.apush(_t1499, "rozwinięcie ... w pozycji stałego parametru niedostępne w backendzie natywnym 0.0.1"), _t1499));
        Z.setLine(159);
        (v___w155 = Z.B.zs_obj_take(v_this, "errors"));
        Z.setLine(159);
        Z.apush((v___w155 = Z.wr(v___w155)), Z.dup(v___r154));
        Z.setLine(159);
        Z.B.zs_obj_put(v_this, "errors", v___w155);
      }
      Z.setLine(160);
      Z.apush((v_out = Z.wr(v_out)), Z.dup(Z.index(v_args, v_i)));
    }
    Z.setLine(162);
    (v_named = false);
    Z.setLine(163);
    {
      const _it158 = Z.foreachArr(Z.dup(v_args));
      L158: for (let _i158 = 0; _i158 < _it158.keys.length; _i158++) {
        v_a = _it158.vals[_i158];
        Z.setLine(163);
        if (Z.truthy(!Z.ident(Z.index(v_a, 2), null))) {
          Z.setLine(163);
          (v_named = true);
        }
      }
    }
    Z.setLine(164);
    if (Z.truthy(!Z.truthy(v_named))) {
      Z.setLine(165);
      (v_ps = Z.dup(Z.index(Z.B.zs_obj_get(v_this, "defs"), Z.index(Z.index(v_x, 2), 2))));
      Z.setLine(166);
      (v_i = Z.B.count(v_out));
      L159: for (; Z.truthy((Z.cmp(v_i, v_k) < 0)); ((_t1500 = v_i), (v_i = Z.add(_t1500, 1)), _t1500)) {
        Z.setLine(167);
        if (Z.truthy(Z.ident(Z.index(Z.index(v_ps, v_i), 4), null))) {
          Z.setLine(167);
          (v___r156 = ((_t1501 = Z.arrNew()), Z.apush(_t1501, Z.dup(Z.index(v_x, 1))), Z.apush(_t1501, "E0104"), Z.apush(_t1501, "za mało argumentów w wywołaniu funkcji wariadycznej"), _t1501));
          Z.setLine(167);
          (v___w157 = Z.B.zs_obj_take(v_this, "errors"));
          Z.setLine(167);
          Z.apush((v___w157 = Z.wr(v___w157)), Z.dup(v___r156));
          Z.setLine(167);
          Z.B.zs_obj_put(v_this, "errors", v___w157);
        } else {
          Z.setLine(168);
          Z.apush((v_out = Z.wr(v_out)), ((_t1502 = Z.arrNew()), Z.apush(_t1502, ":Arg"), Z.apush(_t1502, 0), Z.apush(_t1502, null), Z.apush(_t1502, Z.dup(Z.index(Z.index(v_ps, v_i), 4))), Z.apush(_t1502, false), _t1502));
        }
      }
    }
    Z.setLine(171);
    (v_rest = ((_t1503 = Z.arrNew()), _t1503));
    Z.setLine(172);
    (v_i = Z.dup(v_k));
    L160: for (; Z.truthy((Z.cmp(v_i, Z.B.count(v_args)) < 0)); ((_t1504 = v_i), (v_i = Z.add(_t1504, 1)), _t1504)) {
      Z.setLine(172);
      Z.apush((v_rest = Z.wr(v_rest)), Z.dup(Z.index(v_args, v_i)));
    }
    Z.setLine(173);
    if (Z.truthy((Z.truthy(Z.ident(Z.B.count(v_rest), 1)) && Z.truthy(Z.index(Z.index(v_rest, 0), 4))))) {
      Z.setLine(174);
      (v_a = Z.dup(Z.index(v_rest, 0)));
      Z.setLine(174);
      Z.aset((v_a = Z.wr(v_a)), 4, false);
      Z.setLine(174);
      Z.apush((v_out = Z.wr(v_out)), Z.dup(v_a));
    } else {
      Z.setLine(176);
      (v_items = ((_t1505 = Z.arrNew()), _t1505));
      Z.setLine(177);
      {
        const _it161 = Z.foreachArr(Z.dup(v_rest));
        L161: for (let _i161 = 0; _i161 < _it161.keys.length; _i161++) {
          v_a = _it161.vals[_i161];
          Z.setLine(178);
          if (Z.truthy(Z.index(v_a, 4))) {
            Z.setLine(178);
            (v___r158 = ((_t1506 = Z.arrNew()), Z.apush(_t1506, Z.dup(Z.index(v_x, 1))), Z.apush(_t1506, "E0104"), Z.apush(_t1506, "rozwinięcie ... wśród innych argumentów wariadycznych niedostępne w backendzie natywnym 0.0.1"), _t1506));
            Z.setLine(178);
            (v___w159 = Z.B.zs_obj_take(v_this, "errors"));
            Z.setLine(178);
            Z.apush((v___w159 = Z.wr(v___w159)), Z.dup(v___r158));
            Z.setLine(178);
            Z.B.zs_obj_put(v_this, "errors", v___w159);
          }
          Z.setLine(179);
          Z.apush((v_items = Z.wr(v_items)), ((_t1507 = Z.arrNew()), Z.apush(_t1507, ":Item"), Z.apush(_t1507, 0), Z.apush(_t1507, null), Z.apush(_t1507, Z.dup(Z.index(v_a, 3))), Z.apush(_t1507, false), _t1507));
        }
      }
      Z.setLine(181);
      Z.apush((v_out = Z.wr(v_out)), ((_t1508 = Z.arrNew()), Z.apush(_t1508, ":Arg"), Z.apush(_t1508, 0), Z.apush(_t1508, null), Z.apush(_t1508, ((_t1509 = Z.arrNew()), Z.apush(_t1509, ":Array"), Z.apush(_t1509, Z.dup(Z.index(v_x, 1))), Z.apush(_t1509, Z.dup(v_items)), _t1509)), Z.apush(_t1508, false), _t1508));
    }
    Z.setLine(183);
    Z.aset((v_x = Z.wr(v_x)), 3, Z.dup(v_out));
    Z.setLine(184);
    return Z.dup(v_x);
  }
  Z.setLine(186);
  (v_o = ((_t1510 = Z.arrNew()), _t1510));
  Z.setLine(187);
  {
    const _it162 = Z.foreachArr(Z.dup(v_x));
    L162: for (let _i162 = 0; _i162 < _it162.keys.length; _i162++) {
      v_v = _it162.vals[_i162];
      v_k = _it162.keys[_i162];
      Z.setLine(187);
      Z.aset((v_o = Z.wr(v_o)), v_k, f_zs_invoke(Z.dup(v_this), "rw", ((_t1511 = Z.arrNew()), Z.apush(_t1511, Z.dup(v_v)), _t1511)));
    }
  }
  Z.setLine(188);
  return Z.dup(v_o);
  return null;
}
function f_VarPass__new() {
  let v___o = null;
  let _t1512 = null, _t1513 = null, _t1514 = null;
  Z.setLine(146);
  (v___o = Z.B.zs_obj_new("VarPass"));
  Z.setLine(146);
  Z.B.zs_obj_set(v___o, "fixed", ((_t1512 = Z.arrNew()), _t1512));
  Z.setLine(146);
  Z.B.zs_obj_set(v___o, "defs", ((_t1513 = Z.arrNew()), _t1513));
  Z.setLine(146);
  Z.B.zs_obj_set(v___o, "errors", ((_t1514 = Z.arrNew()), _t1514));
  Z.setLine(146);
  return Z.dup(v___o);
  return null;
}
function f_LlEmitter____construct(v_this, v_ir) {
  let _t1515 = null, _t1516 = null, _t1517 = null, _t1518 = null, _t1519 = null, _t1520 = null, _t1521 = null, _t1522 = null, _t1523 = null, _t1524 = null, _t1525 = null, _t1526 = null;
  Z.setLine(38);
  Z.B.zs_obj_set(v_this, "ir", v_ir);
  Z.setLine(39);
  Z.B.zs_obj_set(v_this, "code", ((_t1515 = Z.arrNew()), _t1515));
  Z.setLine(40);
  Z.B.zs_obj_set(v_this, "allocas", ((_t1516 = Z.arrNew()), _t1516));
  Z.setLine(41);
  Z.B.zs_obj_set(v_this, "globals", ((_t1517 = Z.arrNew()), _t1517));
  Z.setLine(42);
  Z.B.zs_obj_set(v_this, "strs", ((_t1518 = Z.arrNew()), _t1518));
  Z.setLine(43);
  Z.B.zs_obj_set(v_this, "strList", ((_t1519 = Z.arrNew()), _t1519));
  Z.setLine(44);
  Z.B.zs_obj_set(v_this, "cstrs", ((_t1520 = Z.arrNew()), _t1520));
  Z.setLine(45);
  Z.B.zs_obj_set(v_this, "cstrList", ((_t1521 = Z.arrNew()), _t1521));
  Z.setLine(46);
  Z.B.zs_obj_set(v_this, "floats", ((_t1522 = Z.arrNew()), _t1522));
  Z.setLine(47);
  Z.B.zs_obj_set(v_this, "tmp", 0);
  Z.setLine(48);
  Z.B.zs_obj_set(v_this, "lbl", 0);
  Z.setLine(49);
  Z.B.zs_obj_set(v_this, "loops", ((_t1523 = Z.arrNew()), _t1523));
  Z.setLine(50);
  Z.B.zs_obj_set(v_this, "loopId", 0);
  Z.setLine(51);
  Z.B.zs_obj_set(v_this, "tries", ((_t1524 = Z.arrNew()), _t1524));
  Z.setLine(52);
  Z.B.zs_obj_set(v_this, "rdStack", ((_t1525 = Z.arrNew()), _t1525));
  Z.setLine(53);
  Z.B.zs_obj_set(v_this, "fnCounts", ((_t1526 = Z.arrNew()), _t1526));
  Z.setLine(54);
  Z.B.zs_obj_set(v_this, "hid", 0);
  Z.setLine(55);
  Z.B.zs_obj_set(v_this, "curFunc", "");
  Z.setLine(56);
  Z.B.zs_obj_set(v_this, "term", false);
  Z.setLine(57);
  Z.B.zs_obj_set(v_this, "vol", "");
  Z.setLine(58);
  Z.B.zs_obj_set(v_this, "slotN", 0);
  return null;
}
function f_LlEmitter__r(v_this) {
  Z.setLine(62);
  Z.B.zs_obj_set(v_this, "tmp", Z.add(Z.B.zs_obj_get(v_this, "tmp"), 1));
  Z.setLine(62);
  return Z.concat("%t", Z.B.zs_obj_get(v_this, "tmp"));
  return null;
}
function f_LlEmitter__newLabel(v_this, v_p) {
  Z.setLine(63);
  Z.B.zs_obj_set(v_this, "lbl", Z.add(Z.B.zs_obj_get(v_this, "lbl"), 1));
  Z.setLine(63);
  return Z.concat(v_p, Z.B.zs_obj_get(v_this, "lbl"));
  return null;
}
function f_LlEmitter__line(v_this, v_s) {
  let v___r160 = null, v___w161 = null;
  let _t1527 = null, _t1528 = null;
  Z.setLine(66);
  if (Z.truthy(Z.B.zs_obj_get(v_this, "term"))) {
    Z.setLine(66);
    f_zs_invoke(Z.dup(v_this), "label", ((_t1527 = Z.arrNew()), Z.apush(_t1527, f_zs_invoke(Z.dup(v_this), "newLabel", ((_t1528 = Z.arrNew()), Z.apush(_t1528, "dead"), _t1528))), _t1527));
  }
  Z.setLine(67);
  (v___r160 = Z.concat("  ", v_s));
  Z.setLine(67);
  (v___w161 = Z.B.zs_obj_take(v_this, "code"));
  Z.setLine(67);
  Z.apush((v___w161 = Z.wr(v___w161)), Z.dup(v___r160));
  Z.setLine(67);
  Z.B.zs_obj_put(v_this, "code", v___w161);
  return null;
}
function f_LlEmitter__label(v_this, v_l) {
  let v___r162 = null, v___w163 = null, v___r164 = null, v___w165 = null;
  Z.setLine(71);
  if (Z.truthy(!Z.truthy(Z.B.zs_obj_get(v_this, "term")))) {
    Z.setLine(71);
    (v___r162 = Z.concat("  br label %", v_l));
    Z.setLine(71);
    (v___w163 = Z.B.zs_obj_take(v_this, "code"));
    Z.setLine(71);
    Z.apush((v___w163 = Z.wr(v___w163)), Z.dup(v___r162));
    Z.setLine(71);
    Z.B.zs_obj_put(v_this, "code", v___w163);
  }
  Z.setLine(72);
  (v___r164 = Z.concat(v_l, ":"));
  Z.setLine(72);
  (v___w165 = Z.B.zs_obj_take(v_this, "code"));
  Z.setLine(72);
  Z.apush((v___w165 = Z.wr(v___w165)), Z.dup(v___r164));
  Z.setLine(72);
  Z.B.zs_obj_put(v_this, "code", v___w165);
  Z.setLine(73);
  Z.B.zs_obj_set(v_this, "term", false);
  return null;
}
function f_LlEmitter__terminate(v_this, v_s) {
  let v___r166 = null, v___w167 = null;
  let _t1529 = null, _t1530 = null;
  Z.setLine(77);
  if (Z.truthy(Z.B.zs_obj_get(v_this, "term"))) {
    Z.setLine(77);
    f_zs_invoke(Z.dup(v_this), "label", ((_t1529 = Z.arrNew()), Z.apush(_t1529, f_zs_invoke(Z.dup(v_this), "newLabel", ((_t1530 = Z.arrNew()), Z.apush(_t1530, "dead"), _t1530))), _t1529));
  }
  Z.setLine(78);
  (v___r166 = Z.concat("  ", v_s));
  Z.setLine(78);
  (v___w167 = Z.B.zs_obj_take(v_this, "code"));
  Z.setLine(78);
  Z.apush((v___w167 = Z.wr(v___w167)), Z.dup(v___r166));
  Z.setLine(78);
  Z.B.zs_obj_put(v_this, "code", v___w167);
  Z.setLine(79);
  Z.B.zs_obj_set(v_this, "term", true);
  return null;
}
function f_LlEmitter__esc(v_this, v_s) {
  let v_out = null, v_c = null, v_o = null;
  Z.setLine(83);
  (v_out = "");
  Z.setLine(84);
  {
    const _it163 = Z.foreachArr(Z.B.chars(v_s));
    L163: for (let _i163 = 0; _i163 < _it163.keys.length; _i163++) {
      v_c = _it163.vals[_i163];
      Z.setLine(85);
      (v_o = Z.B.ord(v_c));
      Z.setLine(86);
      if (Z.truthy((Z.cmp(Z.B.strlen(v_c), 1) > 0))) {
        Z.setLine(86);
        (v_out = Z.concat(v_out, v_c));
      } else {
        Z.setLine(87);
        if (Z.truthy((Z.truthy((Z.truthy((Z.truthy((Z.cmp(v_o, 32) < 0)) || Z.truthy((Z.cmp(v_o, 127) >= 0)))) || Z.truthy(Z.ident(v_c, "\\")))) || Z.truthy(Z.ident(v_c, "\""))))) {
          Z.setLine(87);
          (v_out = Z.concat(v_out, Z.concat("\\", f_Workspace_emit_llvm__hex2(Z.dup(v_o)))));
        } else {
          Z.setLine(88);
          (v_out = Z.concat(v_out, v_c));
        }
      }
    }
  }
  Z.setLine(90);
  return Z.dup(v_out);
  return null;
}
function f_LlEmitter__cstr(v_this, v_s) {
  let v___k168 = null, v___r169 = null, v___w170 = null, v___r171 = null, v___w172 = null;
  Z.setLine(95);
  if (Z.truthy(!Z.truthy(Z.B.has_key(Z.B.zs_obj_get(v_this, "cstrs"), v_s)))) {
    Z.setLine(96);
    (v___k168 = Z.dup(v_s));
    Z.setLine(96);
    (v___r169 = Z.B.count(Z.B.zs_obj_get(v_this, "cstrList")));
    Z.setLine(96);
    (v___w170 = Z.B.zs_obj_take(v_this, "cstrs"));
    Z.setLine(96);
    Z.aset((v___w170 = Z.wr(v___w170)), v___k168, Z.dup(v___r169));
    Z.setLine(96);
    Z.B.zs_obj_put(v_this, "cstrs", v___w170);
    Z.setLine(97);
    (v___r171 = Z.dup(v_s));
    Z.setLine(97);
    (v___w172 = Z.B.zs_obj_take(v_this, "cstrList"));
    Z.setLine(97);
    Z.apush((v___w172 = Z.wr(v___w172)), Z.dup(v___r171));
    Z.setLine(97);
    Z.B.zs_obj_put(v_this, "cstrList", v___w172);
  }
  Z.setLine(99);
  return Z.concat("@.c", Z.index(Z.B.zs_obj_get(v_this, "cstrs"), v_s));
  return null;
}
function f_LlEmitter__strSlot(v_this, v_s) {
  let v___k173 = null, v___r174 = null, v___w175 = null, v___r176 = null, v___w177 = null;
  Z.setLine(104);
  if (Z.truthy(!Z.truthy(Z.B.has_key(Z.B.zs_obj_get(v_this, "strs"), v_s)))) {
    Z.setLine(105);
    (v___k173 = Z.dup(v_s));
    Z.setLine(105);
    (v___r174 = Z.B.count(Z.B.zs_obj_get(v_this, "strList")));
    Z.setLine(105);
    (v___w175 = Z.B.zs_obj_take(v_this, "strs"));
    Z.setLine(105);
    Z.aset((v___w175 = Z.wr(v___w175)), v___k173, Z.dup(v___r174));
    Z.setLine(105);
    Z.B.zs_obj_put(v_this, "strs", v___w175);
    Z.setLine(106);
    (v___r176 = Z.dup(v_s));
    Z.setLine(106);
    (v___w177 = Z.B.zs_obj_take(v_this, "strList"));
    Z.setLine(106);
    Z.apush((v___w177 = Z.wr(v___w177)), Z.dup(v___r176));
    Z.setLine(106);
    Z.B.zs_obj_put(v_this, "strList", v___w177);
  }
  Z.setLine(108);
  return Z.dup(Z.index(Z.B.zs_obj_get(v_this, "strs"), v_s));
  return null;
}
function f_LlEmitter__slot(v_this) {
  let v_n = null, v___r178 = null, v___w179 = null;
  Z.setLine(112);
  Z.B.zs_obj_set(v_this, "slotN", Z.add(Z.B.zs_obj_get(v_this, "slotN"), 1));
  Z.setLine(113);
  (v_n = Z.concat("%slot", Z.B.zs_obj_get(v_this, "slotN")));
  Z.setLine(114);
  (v___r178 = Z.concat(Z.concat("  ", v_n), " = alloca { i64, i64 }, align 8"));
  Z.setLine(114);
  (v___w179 = Z.B.zs_obj_take(v_this, "allocas"));
  Z.setLine(114);
  Z.apush((v___w179 = Z.wr(v___w179)), Z.dup(v___r178));
  Z.setLine(114);
  Z.B.zs_obj_put(v_this, "allocas", v___w179);
  Z.setLine(115);
  return Z.dup(v_n);
  return null;
}
function f_LlEmitter__ty(v_this, v_t) {
  Z.setLine(119);
  return (Z.truthy(Z.ident(v_t, "V")) ? "{ i64, i64 }" : v_t);
  return null;
}
function f_LlEmitter__rt(v_this, v_fn, v_ret, v_args) {
  let v_parts = null, v_a = null, v_x = null, v_y = null, v_res = null;
  let _t1531 = null, _t1532 = null, _t1533 = null, _t1534 = null, _t1535 = null, _t1536 = null, _t1537 = null, _t1538 = null, _t1539 = null;
  Z.setLine(123);
  (v_parts = ((_t1531 = Z.arrNew()), _t1531));
  Z.setLine(124);
  {
    const _it164 = Z.foreachArr(Z.dup(v_args));
    L164: for (let _i164 = 0; _i164 < _it164.keys.length; _i164++) {
      v_a = _it164.vals[_i164];
      Z.setLine(125);
      if (Z.truthy(Z.ident(Z.index(v_a, 0), "V"))) {
        Z.setLine(126);
        (v_x = f_zs_invoke(Z.dup(v_this), "r", ((_t1532 = Z.arrNew()), _t1532)));
        Z.setLine(127);
        (v_y = f_zs_invoke(Z.dup(v_this), "r", ((_t1533 = Z.arrNew()), _t1533)));
        Z.setLine(128);
        f_zs_invoke(Z.dup(v_this), "line", ((_t1534 = Z.arrNew()), Z.apush(_t1534, Z.concat(Z.concat(Z.concat(v_x, " = extractvalue { i64, i64 } "), Z.index(v_a, 1)), ", 0")), _t1534));
        Z.setLine(129);
        f_zs_invoke(Z.dup(v_this), "line", ((_t1535 = Z.arrNew()), Z.apush(_t1535, Z.concat(Z.concat(Z.concat(v_y, " = extractvalue { i64, i64 } "), Z.index(v_a, 1)), ", 1")), _t1535));
        Z.setLine(130);
        Z.apush((v_parts = Z.wr(v_parts)), Z.concat("i64 ", v_x));
        Z.setLine(131);
        Z.apush((v_parts = Z.wr(v_parts)), Z.concat("i64 ", v_y));
      } else {
        Z.setLine(132);
        Z.apush((v_parts = Z.wr(v_parts)), Z.concat(Z.concat(Z.index(v_a, 0), " "), Z.index(v_a, 1)));
      }
    }
  }
  Z.setLine(134);
  if (Z.truthy(Z.ident(v_ret, "void"))) {
    Z.setLine(134);
    f_zs_invoke(Z.dup(v_this), "line", ((_t1536 = Z.arrNew()), Z.apush(_t1536, Z.concat(Z.concat(Z.concat(Z.concat("call void @", v_fn), "("), Z.B.join(v_parts, ", ")), ")")), _t1536));
    Z.setLine(134);
    return null;
  }
  Z.setLine(135);
  (v_res = f_zs_invoke(Z.dup(v_this), "r", ((_t1537 = Z.arrNew()), _t1537)));
  Z.setLine(136);
  f_zs_invoke(Z.dup(v_this), "line", ((_t1538 = Z.arrNew()), Z.apush(_t1538, Z.concat(Z.concat(Z.concat(Z.concat(Z.concat(Z.concat(Z.concat(v_res, " = call "), f_zs_invoke(Z.dup(v_this), "ty", ((_t1539 = Z.arrNew()), Z.apush(_t1539, Z.dup(v_ret)), _t1539))), " @"), v_fn), "("), Z.B.join(v_parts, ", ")), ")")), _t1538));
  Z.setLine(137);
  return Z.dup(v_res);
  return null;
}
function f_LlEmitter__vcall(v_this, v_fn, v_regs) {
  let v_args = null, v_x = null;
  let _t1540 = null, _t1541 = null, _t1542 = null;
  Z.setLine(141);
  (v_args = ((_t1540 = Z.arrNew()), _t1540));
  Z.setLine(142);
  {
    const _it165 = Z.foreachArr(Z.dup(v_regs));
    L165: for (let _i165 = 0; _i165 < _it165.keys.length; _i165++) {
      v_x = _it165.vals[_i165];
      Z.setLine(142);
      Z.apush((v_args = Z.wr(v_args)), ((_t1541 = Z.arrNew()), Z.apush(_t1541, "V"), Z.apush(_t1541, Z.dup(v_x)), _t1541));
    }
  }
  Z.setLine(143);
  return f_zs_invoke(Z.dup(v_this), "rt", ((_t1542 = Z.arrNew()), Z.apush(_t1542, Z.dup(v_fn)), Z.apush(_t1542, "V"), Z.apush(_t1542, Z.dup(v_args)), _t1542));
  return null;
}
function f_LlEmitter__mkv(v_this, v_tag, v_bits) {
  let v_a = null;
  let _t1543 = null, _t1544 = null;
  Z.setLine(147);
  (v_a = f_zs_invoke(Z.dup(v_this), "r", ((_t1543 = Z.arrNew()), _t1543)));
  Z.setLine(148);
  f_zs_invoke(Z.dup(v_this), "line", ((_t1544 = Z.arrNew()), Z.apush(_t1544, Z.concat(Z.concat(Z.concat(Z.concat(Z.concat(v_a, " = insertvalue { i64, i64 } { i64 "), v_tag), ", i64 0 }, i64 "), v_bits), ", 1")), _t1544));
  Z.setLine(149);
  return Z.dup(v_a);
  return null;
}
function f_LlEmitter__nullv(v_this) {
  let _t1545 = null;
  Z.setLine(152);
  return f_zs_invoke(Z.dup(v_this), "mkv", ((_t1545 = Z.arrNew()), Z.apush(_t1545, 0), Z.apush(_t1545, "0"), _t1545));
  return null;
}
function f_LlEmitter__truthy(v_this, v_v) {
  let v_c = null, v_b = null;
  let _t1546 = null, _t1547 = null, _t1548 = null, _t1549 = null, _t1550 = null;
  Z.setLine(155);
  (v_c = f_zs_invoke(Z.dup(v_this), "rt", ((_t1546 = Z.arrNew()), Z.apush(_t1546, "zv_truthy"), Z.apush(_t1546, "i32"), Z.apush(_t1546, ((_t1547 = Z.arrNew()), Z.apush(_t1547, ((_t1548 = Z.arrNew()), Z.apush(_t1548, "V"), Z.apush(_t1548, Z.dup(v_v)), _t1548)), _t1547)), _t1546)));
  Z.setLine(156);
  (v_b = f_zs_invoke(Z.dup(v_this), "r", ((_t1549 = Z.arrNew()), _t1549)));
  Z.setLine(157);
  f_zs_invoke(Z.dup(v_this), "line", ((_t1550 = Z.arrNew()), Z.apush(_t1550, Z.concat(Z.concat(Z.concat(v_b, " = icmp ne i32 "), v_c), ", 0")), _t1550));
  Z.setLine(158);
  return Z.dup(v_b);
  return null;
}
function f_LlEmitter__boolOf(v_this, v_i1) {
  let v_z = null, v_a = null;
  let _t1551 = null, _t1552 = null, _t1553 = null, _t1554 = null;
  Z.setLine(162);
  (v_z = f_zs_invoke(Z.dup(v_this), "r", ((_t1551 = Z.arrNew()), _t1551)));
  Z.setLine(163);
  f_zs_invoke(Z.dup(v_this), "line", ((_t1552 = Z.arrNew()), Z.apush(_t1552, Z.concat(Z.concat(Z.concat(v_z, " = zext i1 "), v_i1), " to i64")), _t1552));
  Z.setLine(164);
  (v_a = f_zs_invoke(Z.dup(v_this), "r", ((_t1553 = Z.arrNew()), _t1553)));
  Z.setLine(165);
  f_zs_invoke(Z.dup(v_this), "line", ((_t1554 = Z.arrNew()), Z.apush(_t1554, Z.concat(Z.concat(Z.concat(v_a, " = insertvalue { i64, i64 } { i64 1, i64 0 }, i64 "), v_z), ", 1")), _t1554));
  Z.setLine(166);
  return Z.dup(v_a);
  return null;
}
function f_LlEmitter__ident(v_this, v_n) {
  Z.setLine(169);
  return Z.concat(Z.concat("%\"v_", v_n), "\"");
  return null;
}
function f_LlEmitter__load(v_this, v_n) {
  let v_t = null;
  let _t1555 = null, _t1556 = null, _t1557 = null;
  Z.setLine(172);
  (v_t = f_zs_invoke(Z.dup(v_this), "r", ((_t1555 = Z.arrNew()), _t1555)));
  Z.setLine(173);
  f_zs_invoke(Z.dup(v_this), "line", ((_t1556 = Z.arrNew()), Z.apush(_t1556, Z.concat(Z.concat(Z.concat(Z.concat(Z.concat(v_t, " = load "), Z.B.zs_obj_get(v_this, "vol")), "{ i64, i64 }, ptr "), f_zs_invoke(Z.dup(v_this), "ident", ((_t1557 = Z.arrNew()), Z.apush(_t1557, Z.dup(v_n)), _t1557))), ", align 8")), _t1556));
  Z.setLine(174);
  return Z.dup(v_t);
  return null;
}
function f_LlEmitter__store(v_this, v_n, v_v) {
  let _t1558 = null, _t1559 = null;
  Z.setLine(177);
  f_zs_invoke(Z.dup(v_this), "line", ((_t1558 = Z.arrNew()), Z.apush(_t1558, Z.concat(Z.concat(Z.concat(Z.concat(Z.concat(Z.concat("store ", Z.B.zs_obj_get(v_this, "vol")), "{ i64, i64 } "), v_v), ", ptr "), f_zs_invoke(Z.dup(v_this), "ident", ((_t1559 = Z.arrNew()), Z.apush(_t1559, Z.dup(v_n)), _t1559))), ", align 8")), _t1558));
  return null;
}
function f_LlEmitter__storeTo(v_this, v_ptr, v_v) {
  let _t1560 = null;
  Z.setLine(179);
  f_zs_invoke(Z.dup(v_this), "line", ((_t1560 = Z.arrNew()), Z.apush(_t1560, Z.concat(Z.concat(Z.concat(Z.concat("store { i64, i64 } ", v_v), ", ptr "), v_ptr), ", align 8")), _t1560));
  return null;
}
function f_LlEmitter__loadFrom(v_this, v_ptr) {
  let v_t = null;
  let _t1561 = null, _t1562 = null;
  Z.setLine(182);
  (v_t = f_zs_invoke(Z.dup(v_this), "r", ((_t1561 = Z.arrNew()), _t1561)));
  Z.setLine(183);
  f_zs_invoke(Z.dup(v_this), "line", ((_t1562 = Z.arrNew()), Z.apush(_t1562, Z.concat(Z.concat(Z.concat(v_t, " = load { i64, i64 }, ptr "), v_ptr), ", align 8")), _t1562));
  Z.setLine(184);
  return Z.dup(v_t);
  return null;
}
function f_LlEmitter__isLval(v_this, v_e) {
  Z.setLine(188);
  return (Z.truthy(Z.ident(Z.index(v_e, 0), ":Var")) || Z.truthy(Z.ident(Z.index(v_e, 0), ":Index")));
  return null;
}
function f_LlEmitter__val(v_this, v_e) {
  let v_x = null;
  let _t1563 = null, _t1564 = null, _t1565 = null, _t1566 = null;
  Z.setLine(191);
  (v_x = f_zs_invoke(Z.dup(v_this), "expr", ((_t1563 = Z.arrNew()), Z.apush(_t1563, Z.dup(v_e)), _t1563)));
  Z.setLine(192);
  return (Z.truthy(f_zs_invoke(Z.dup(v_this), "isLval", ((_t1564 = Z.arrNew()), Z.apush(_t1564, Z.dup(v_e)), _t1564))) ? f_zs_invoke(Z.dup(v_this), "vcall", ((_t1565 = Z.arrNew()), Z.apush(_t1565, "zv_dup"), Z.apush(_t1565, ((_t1566 = Z.arrNew()), Z.apush(_t1566, Z.dup(v_x)), _t1566)), _t1565)) : v_x);
  return null;
}
function f_LlEmitter__binop(v_this, v_op, v_a, v_b) {
  let v_m = null, v_fn = null, v_c = null, v_p = null, v_cc = null, v_x = null, v_y = null;
  let _t1567 = null, _t1568 = null, _t1569 = null, _t1570 = null, _t1571 = null, _t1572 = null, _t1573 = null, _t1574 = null, _t1575 = null, _t1576 = null, _t1577 = null, _t1578 = null, _t1579 = null, _t1580 = null, _t1581 = null, _t1582 = null, _t1583 = null, _t1584 = null, _t1585 = null, _t1586 = null, _t1587 = null, _t1588 = null, _t1589 = null;
  Z.setLine(196);
  (v_m = ((_t1567 = Z.arrNew()), Z.aset(_t1567, "Add", "zv_add"), Z.aset(_t1567, "Sub", "zv_sub"), Z.aset(_t1567, "Mul", "zv_mul"), Z.aset(_t1567, "Div", "zv_div"), Z.aset(_t1567, "Mod", "zv_mod"), Z.aset(_t1567, "Pow", "zv_pow"), Z.aset(_t1567, "Concat", "zv_concat"), Z.aset(_t1567, "BitAnd", "zv_bitand"), Z.aset(_t1567, "BitOr", "zv_bitor"), Z.aset(_t1567, "BitXor", "zv_bitxor"), Z.aset(_t1567, "Shl", "zv_shl"), Z.aset(_t1567, "Shr", "zv_shr"), _t1567));
  Z.setLine(197);
  if (Z.truthy(Z.B.has_key(v_m, v_op))) {
    Z.setLine(197);
    return f_zs_invoke(Z.dup(v_this), "vcall", ((_t1568 = Z.arrNew()), Z.apush(_t1568, Z.dup(Z.index(v_m, v_op))), Z.apush(_t1568, ((_t1569 = Z.arrNew()), Z.apush(_t1569, Z.dup(v_a)), Z.apush(_t1569, Z.dup(v_b)), _t1569)), _t1568));
  }
  Z.setLine(198);
  if (Z.truthy((Z.truthy((Z.truthy((Z.truthy(Z.ident(v_op, "Eq")) || Z.truthy(Z.ident(v_op, "NotEq")))) || Z.truthy(Z.ident(v_op, "Identical")))) || Z.truthy(Z.ident(v_op, "NotIdentical"))))) {
    Z.setLine(199);
    (v_fn = (Z.truthy((Z.truthy(Z.ident(v_op, "Eq")) || Z.truthy(Z.ident(v_op, "NotEq")))) ? "zv_eq" : "zv_ident"));
    Z.setLine(200);
    (v_c = f_zs_invoke(Z.dup(v_this), "rt", ((_t1570 = Z.arrNew()), Z.apush(_t1570, Z.dup(v_fn)), Z.apush(_t1570, "i32"), Z.apush(_t1570, ((_t1571 = Z.arrNew()), Z.apush(_t1571, ((_t1572 = Z.arrNew()), Z.apush(_t1572, "V"), Z.apush(_t1572, Z.dup(v_a)), _t1572)), Z.apush(_t1571, ((_t1573 = Z.arrNew()), Z.apush(_t1573, "V"), Z.apush(_t1573, Z.dup(v_b)), _t1573)), _t1571)), _t1570)));
    Z.setLine(201);
    (v_p = f_zs_invoke(Z.dup(v_this), "r", ((_t1574 = Z.arrNew()), _t1574)));
    Z.setLine(202);
    f_zs_invoke(Z.dup(v_this), "line", ((_t1575 = Z.arrNew()), Z.apush(_t1575, Z.concat(Z.concat(Z.concat(Z.concat(Z.concat(v_p, " = icmp "), (Z.truthy((Z.truthy(Z.ident(v_op, "Eq")) || Z.truthy(Z.ident(v_op, "Identical")))) ? "ne" : "eq")), " i32 "), v_c), ", 0")), _t1575));
    Z.setLine(203);
    return f_zs_invoke(Z.dup(v_this), "boolOf", ((_t1576 = Z.arrNew()), Z.apush(_t1576, Z.dup(v_p)), _t1576));
  }
  Z.setLine(205);
  if (Z.truthy((Z.truthy((Z.truthy((Z.truthy(Z.ident(v_op, "Lt")) || Z.truthy(Z.ident(v_op, "Gt")))) || Z.truthy(Z.ident(v_op, "Le")))) || Z.truthy(Z.ident(v_op, "Ge"))))) {
    Z.setLine(206);
    (v_c = f_zs_invoke(Z.dup(v_this), "rt", ((_t1577 = Z.arrNew()), Z.apush(_t1577, "zv_cmp"), Z.apush(_t1577, "i32"), Z.apush(_t1577, ((_t1578 = Z.arrNew()), Z.apush(_t1578, ((_t1579 = Z.arrNew()), Z.apush(_t1579, "V"), Z.apush(_t1579, Z.dup(v_a)), _t1579)), Z.apush(_t1578, ((_t1580 = Z.arrNew()), Z.apush(_t1580, "V"), Z.apush(_t1580, Z.dup(v_b)), _t1580)), _t1578)), _t1577)));
    Z.setLine(207);
    (v_cc = Z.dup(Z.index(((_t1581 = Z.arrNew()), Z.aset(_t1581, "Lt", "slt"), Z.aset(_t1581, "Gt", "sgt"), Z.aset(_t1581, "Le", "sle"), Z.aset(_t1581, "Ge", "sge"), _t1581), v_op)));
    Z.setLine(208);
    (v_p = f_zs_invoke(Z.dup(v_this), "r", ((_t1582 = Z.arrNew()), _t1582)));
    Z.setLine(209);
    f_zs_invoke(Z.dup(v_this), "line", ((_t1583 = Z.arrNew()), Z.apush(_t1583, Z.concat(Z.concat(Z.concat(Z.concat(Z.concat(v_p, " = icmp "), v_cc), " i32 "), v_c), ", 0")), _t1583));
    Z.setLine(210);
    return f_zs_invoke(Z.dup(v_this), "boolOf", ((_t1584 = Z.arrNew()), Z.apush(_t1584, Z.dup(v_p)), _t1584));
  }
  Z.setLine(212);
  if (Z.truthy(Z.ident(v_op, "Xor"))) {
    Z.setLine(213);
    (v_x = f_zs_invoke(Z.dup(v_this), "truthy", ((_t1585 = Z.arrNew()), Z.apush(_t1585, Z.dup(v_a)), _t1585)));
    Z.setLine(214);
    (v_y = f_zs_invoke(Z.dup(v_this), "truthy", ((_t1586 = Z.arrNew()), Z.apush(_t1586, Z.dup(v_b)), _t1586)));
    Z.setLine(215);
    (v_p = f_zs_invoke(Z.dup(v_this), "r", ((_t1587 = Z.arrNew()), _t1587)));
    Z.setLine(216);
    f_zs_invoke(Z.dup(v_this), "line", ((_t1588 = Z.arrNew()), Z.apush(_t1588, Z.concat(Z.concat(Z.concat(Z.concat(v_p, " = xor i1 "), v_x), ", "), v_y)), _t1588));
    Z.setLine(217);
    return f_zs_invoke(Z.dup(v_this), "boolOf", ((_t1589 = Z.arrNew()), Z.apush(_t1589, Z.dup(v_p)), _t1589));
  }
  Z.setLine(219);
  Z.raise(new Z.ZExc(0, Z.concat("emit_llvm: nieobsługiwany operator ", v_op)));
  return null;
}
function f_LlEmitter__quiet(v_this, v_e) {
  let v_b = null, v_k = null;
  let _t1590 = null, _t1591 = null, _t1592 = null, _t1593 = null, _t1594 = null;
  Z.setLine(224);
  if (Z.truthy((Z.truthy(Z.ident(Z.index(v_e, 0), ":Index")) && Z.truthy(!Z.ident(Z.index(v_e, 3), null))))) {
    Z.setLine(225);
    (v_b = f_zs_invoke(Z.dup(v_this), "quiet", ((_t1590 = Z.arrNew()), Z.apush(_t1590, Z.dup(Z.index(v_e, 2))), _t1590)));
    Z.setLine(226);
    (v_k = f_zs_invoke(Z.dup(v_this), "expr", ((_t1591 = Z.arrNew()), Z.apush(_t1591, Z.dup(Z.index(v_e, 3))), _t1591)));
    Z.setLine(227);
    return f_zs_invoke(Z.dup(v_this), "vcall", ((_t1592 = Z.arrNew()), Z.apush(_t1592, "zv_index_opt"), Z.apush(_t1592, ((_t1593 = Z.arrNew()), Z.apush(_t1593, Z.dup(v_b)), Z.apush(_t1593, Z.dup(v_k)), _t1593)), _t1592));
  }
  Z.setLine(229);
  return f_zs_invoke(Z.dup(v_this), "expr", ((_t1594 = Z.arrNew()), Z.apush(_t1594, Z.dup(v_e)), _t1594));
  return null;
}
function f_LlEmitter__keyOf(v_this, v_t, v_arr) {
  let v_n = null, v_a = null;
  let _t1595 = null, _t1596 = null, _t1597 = null, _t1598 = null, _t1599 = null, _t1600 = null;
  Z.setLine(233);
  if (Z.truthy(Z.ident(Z.index(v_t, 3), null))) {
    Z.setLine(234);
    (v_n = f_zs_invoke(Z.dup(v_this), "rt", ((_t1595 = Z.arrNew()), Z.apush(_t1595, "zs_array_len"), Z.apush(_t1595, "i64"), Z.apush(_t1595, ((_t1596 = Z.arrNew()), Z.apush(_t1596, ((_t1597 = Z.arrNew()), Z.apush(_t1597, "V"), Z.apush(_t1597, Z.dup(v_arr)), _t1597)), _t1596)), _t1595)));
    Z.setLine(235);
    (v_a = f_zs_invoke(Z.dup(v_this), "r", ((_t1598 = Z.arrNew()), _t1598)));
    Z.setLine(236);
    f_zs_invoke(Z.dup(v_this), "line", ((_t1599 = Z.arrNew()), Z.apush(_t1599, Z.concat(Z.concat(Z.concat(v_a, " = insertvalue { i64, i64 } { i64 2, i64 0 }, i64 "), v_n), ", 1")), _t1599));
    Z.setLine(237);
    return Z.dup(v_a);
  }
  Z.setLine(239);
  return f_zs_invoke(Z.dup(v_this), "expr", ((_t1600 = Z.arrNew()), Z.apush(_t1600, Z.dup(Z.index(v_t, 3))), _t1600));
  return null;
}
function f_LlEmitter__lv(v_this, v_base) {
  let v_cur = null, v_w = null, v_p = null, v_k = null, v_e = null, v_isnull = null, v_tg = null, v_sl = null, v_lnew = null, v_ljoin = null;
  let _t1601 = null, _t1602 = null, _t1603 = null, _t1604 = null, _t1605 = null, _t1606 = null, _t1607 = null, _t1608 = null, _t1609 = null, _t1610 = null, _t1611 = null, _t1612 = null, _t1613 = null, _t1614 = null, _t1615 = null, _t1616 = null, _t1617 = null, _t1618 = null, _t1619 = null, _t1620 = null, _t1621 = null, _t1622 = null, _t1623 = null, _t1624 = null, _t1625 = null, _t1626 = null;
  Z.setLine(244);
  if (Z.truthy(Z.ident(Z.index(v_base, 0), ":Var"))) {
    Z.setLine(245);
    (v_cur = f_zs_invoke(Z.dup(v_this), "load", ((_t1601 = Z.arrNew()), Z.apush(_t1601, Z.dup(Z.index(v_base, 2))), _t1601)));
    Z.setLine(246);
    (v_w = f_zs_invoke(Z.dup(v_this), "vcall", ((_t1602 = Z.arrNew()), Z.apush(_t1602, "zv_wr"), Z.apush(_t1602, ((_t1603 = Z.arrNew()), Z.apush(_t1603, Z.dup(v_cur)), _t1603)), _t1602)));
    Z.setLine(247);
    f_zs_invoke(Z.dup(v_this), "store", ((_t1604 = Z.arrNew()), Z.apush(_t1604, Z.dup(Z.index(v_base, 2))), Z.apush(_t1604, Z.dup(v_w)), _t1604));
    Z.setLine(248);
    return Z.dup(v_w);
  }
  Z.setLine(250);
  (v_p = f_zs_invoke(Z.dup(v_this), "lv", ((_t1605 = Z.arrNew()), Z.apush(_t1605, Z.dup(Z.index(v_base, 2))), _t1605)));
  Z.setLine(251);
  (v_k = f_zs_invoke(Z.dup(v_this), "keyOf", ((_t1606 = Z.arrNew()), Z.apush(_t1606, Z.dup(v_base)), Z.apush(_t1606, Z.dup(v_p)), _t1606)));
  Z.setLine(252);
  (v_e = f_zs_invoke(Z.dup(v_this), "vcall", ((_t1607 = Z.arrNew()), Z.apush(_t1607, "zv_index_opt"), Z.apush(_t1607, ((_t1608 = Z.arrNew()), Z.apush(_t1608, Z.dup(v_p)), Z.apush(_t1608, Z.dup(v_k)), _t1608)), _t1607)));
  Z.setLine(253);
  (v_isnull = f_zs_invoke(Z.dup(v_this), "r", ((_t1609 = Z.arrNew()), _t1609)));
  Z.setLine(254);
  (v_tg = f_zs_invoke(Z.dup(v_this), "r", ((_t1610 = Z.arrNew()), _t1610)));
  Z.setLine(255);
  f_zs_invoke(Z.dup(v_this), "line", ((_t1611 = Z.arrNew()), Z.apush(_t1611, Z.concat(Z.concat(Z.concat(v_tg, " = extractvalue { i64, i64 } "), v_e), ", 0")), _t1611));
  Z.setLine(256);
  f_zs_invoke(Z.dup(v_this), "line", ((_t1612 = Z.arrNew()), Z.apush(_t1612, Z.concat(Z.concat(Z.concat(v_isnull, " = icmp eq i64 "), v_tg), ", 0")), _t1612));
  Z.setLine(257);
  (v_sl = f_zs_invoke(Z.dup(v_this), "slot", ((_t1613 = Z.arrNew()), _t1613)));
  Z.setLine(258);
  f_zs_invoke(Z.dup(v_this), "storeTo", ((_t1614 = Z.arrNew()), Z.apush(_t1614, Z.dup(v_sl)), Z.apush(_t1614, Z.dup(v_e)), _t1614));
  Z.setLine(259);
  (v_lnew = f_zs_invoke(Z.dup(v_this), "newLabel", ((_t1615 = Z.arrNew()), Z.apush(_t1615, "lvnew"), _t1615)));
  Z.setLine(260);
  (v_ljoin = f_zs_invoke(Z.dup(v_this), "newLabel", ((_t1616 = Z.arrNew()), Z.apush(_t1616, "lvjoin"), _t1616)));
  Z.setLine(261);
  f_zs_invoke(Z.dup(v_this), "terminate", ((_t1617 = Z.arrNew()), Z.apush(_t1617, Z.concat(Z.concat(Z.concat(Z.concat(Z.concat("br i1 ", v_isnull), ", label %"), v_lnew), ", label %"), v_ljoin)), _t1617));
  Z.setLine(262);
  f_zs_invoke(Z.dup(v_this), "label", ((_t1618 = Z.arrNew()), Z.apush(_t1618, Z.dup(v_lnew)), _t1618));
  Z.setLine(263);
  f_zs_invoke(Z.dup(v_this), "storeTo", ((_t1619 = Z.arrNew()), Z.apush(_t1619, Z.dup(v_sl)), Z.apush(_t1619, f_zs_invoke(Z.dup(v_this), "newArr", ((_t1620 = Z.arrNew()), _t1620))), _t1619));
  Z.setLine(264);
  f_zs_invoke(Z.dup(v_this), "label", ((_t1621 = Z.arrNew()), Z.apush(_t1621, Z.dup(v_ljoin)), _t1621));
  Z.setLine(265);
  (v_cur = f_zs_invoke(Z.dup(v_this), "loadFrom", ((_t1622 = Z.arrNew()), Z.apush(_t1622, Z.dup(v_sl)), _t1622)));
  Z.setLine(266);
  (v_w = f_zs_invoke(Z.dup(v_this), "vcall", ((_t1623 = Z.arrNew()), Z.apush(_t1623, "zv_wr"), Z.apush(_t1623, ((_t1624 = Z.arrNew()), Z.apush(_t1624, Z.dup(v_cur)), _t1624)), _t1623)));
  Z.setLine(267);
  f_zs_invoke(Z.dup(v_this), "vcallVoid", ((_t1625 = Z.arrNew()), Z.apush(_t1625, "zv_set"), Z.apush(_t1625, ((_t1626 = Z.arrNew()), Z.apush(_t1626, Z.dup(v_p)), Z.apush(_t1626, Z.dup(v_k)), Z.apush(_t1626, Z.dup(v_w)), _t1626)), _t1625));
  Z.setLine(268);
  return Z.dup(v_w);
  return null;
}
function f_LlEmitter__newArr(v_this) {
  let _t1627 = null, _t1628 = null, _t1629 = null;
  Z.setLine(271);
  return f_zs_invoke(Z.dup(v_this), "rt", ((_t1627 = Z.arrNew()), Z.apush(_t1627, "zv_arr_new"), Z.apush(_t1627, "V"), Z.apush(_t1627, ((_t1628 = Z.arrNew()), Z.apush(_t1628, ((_t1629 = Z.arrNew()), Z.apush(_t1629, "i64"), Z.apush(_t1629, "4"), _t1629)), _t1628)), _t1627));
  return null;
}
function f_LlEmitter__vcallVoid(v_this, v_fn, v_regs) {
  let v_args = null, v_x = null;
  let _t1630 = null, _t1631 = null, _t1632 = null;
  Z.setLine(274);
  (v_args = ((_t1630 = Z.arrNew()), _t1630));
  Z.setLine(275);
  {
    const _it166 = Z.foreachArr(Z.dup(v_regs));
    L166: for (let _i166 = 0; _i166 < _it166.keys.length; _i166++) {
      v_x = _it166.vals[_i166];
      Z.setLine(275);
      Z.apush((v_args = Z.wr(v_args)), ((_t1631 = Z.arrNew()), Z.apush(_t1631, "V"), Z.apush(_t1631, Z.dup(v_x)), _t1631));
    }
  }
  Z.setLine(276);
  f_zs_invoke(Z.dup(v_this), "rt", ((_t1632 = Z.arrNew()), Z.apush(_t1632, Z.dup(v_fn)), Z.apush(_t1632, "void"), Z.apush(_t1632, Z.dup(v_args)), _t1632));
  return null;
}
function f_LlEmitter__incdec(v_this, v_e) {
  let v_t = null, v_fn = null, v_prefix = null, v_one = null, v_o = null, v_n = null, v_a = null, v_k = null;
  let _t1633 = null, _t1634 = null, _t1635 = null, _t1636 = null, _t1637 = null, _t1638 = null, _t1639 = null, _t1640 = null, _t1641 = null, _t1642 = null, _t1643 = null, _t1644 = null, _t1645 = null;
  Z.setLine(280);
  (v_t = Z.dup(Z.index(v_e, 2)));
  Z.setLine(281);
  (v_fn = (Z.truthy(Z.index(v_e, 3)) ? "zv_add" : "zv_sub"));
  Z.setLine(282);
  (v_prefix = Z.dup(Z.index(v_e, 4)));
  Z.setLine(283);
  (v_one = f_zs_invoke(Z.dup(v_this), "mkv", ((_t1633 = Z.arrNew()), Z.apush(_t1633, 2), Z.apush(_t1633, "1"), _t1633)));
  Z.setLine(284);
  if (Z.truthy(Z.ident(Z.index(v_t, 0), ":Var"))) {
    Z.setLine(285);
    (v_o = f_zs_invoke(Z.dup(v_this), "load", ((_t1634 = Z.arrNew()), Z.apush(_t1634, Z.dup(Z.index(v_t, 2))), _t1634)));
    Z.setLine(286);
    (v_n = f_zs_invoke(Z.dup(v_this), "vcall", ((_t1635 = Z.arrNew()), Z.apush(_t1635, Z.dup(v_fn)), Z.apush(_t1635, ((_t1636 = Z.arrNew()), Z.apush(_t1636, Z.dup(v_o)), Z.apush(_t1636, Z.dup(v_one)), _t1636)), _t1635)));
    Z.setLine(287);
    f_zs_invoke(Z.dup(v_this), "store", ((_t1637 = Z.arrNew()), Z.apush(_t1637, Z.dup(Z.index(v_t, 2))), Z.apush(_t1637, Z.dup(v_n)), _t1637));
    Z.setLine(288);
    return (Z.truthy(v_prefix) ? v_n : v_o);
  }
  Z.setLine(290);
  (v_a = f_zs_invoke(Z.dup(v_this), "lv", ((_t1638 = Z.arrNew()), Z.apush(_t1638, Z.dup(Z.index(v_t, 2))), _t1638)));
  Z.setLine(291);
  (v_k = f_zs_invoke(Z.dup(v_this), "keyOf", ((_t1639 = Z.arrNew()), Z.apush(_t1639, Z.dup(v_t)), Z.apush(_t1639, Z.dup(v_a)), _t1639)));
  Z.setLine(292);
  (v_o = f_zs_invoke(Z.dup(v_this), "vcall", ((_t1640 = Z.arrNew()), Z.apush(_t1640, "zv_index"), Z.apush(_t1640, ((_t1641 = Z.arrNew()), Z.apush(_t1641, Z.dup(v_a)), Z.apush(_t1641, Z.dup(v_k)), _t1641)), _t1640)));
  Z.setLine(293);
  (v_n = f_zs_invoke(Z.dup(v_this), "vcall", ((_t1642 = Z.arrNew()), Z.apush(_t1642, Z.dup(v_fn)), Z.apush(_t1642, ((_t1643 = Z.arrNew()), Z.apush(_t1643, Z.dup(v_o)), Z.apush(_t1643, Z.dup(v_one)), _t1643)), _t1642)));
  Z.setLine(294);
  f_zs_invoke(Z.dup(v_this), "vcallVoid", ((_t1644 = Z.arrNew()), Z.apush(_t1644, "zv_set"), Z.apush(_t1644, ((_t1645 = Z.arrNew()), Z.apush(_t1645, Z.dup(v_a)), Z.apush(_t1645, Z.dup(v_k)), Z.apush(_t1645, Z.dup(v_n)), _t1645)), _t1644));
  Z.setLine(295);
  return (Z.truthy(v_prefix) ? v_n : v_o);
  return null;
}
function f_LlEmitter__assignop(v_this, v_e) {
  let v_op = null, v_t = null, v_o = null, v_r = null, v_rhs = null, v_n = null, v_a = null, v_k = null;
  let _t1646 = null, _t1647 = null, _t1648 = null, _t1649 = null, _t1650 = null, _t1651 = null, _t1652 = null, _t1653 = null, _t1654 = null, _t1655 = null, _t1656 = null, _t1657 = null, _t1658 = null, _t1659 = null, _t1660 = null, _t1661 = null, _t1662 = null;
  Z.setLine(300);
  (v_op = Z.dup(Z.index(v_e, 2)));
  Z.setLine(301);
  (v_t = Z.dup(Z.index(v_e, 3)));
  Z.setLine(302);
  if (Z.truthy(Z.ident(Z.index(v_t, 0), ":Var"))) {
    Z.setLine(303);
    (v_o = f_zs_invoke(Z.dup(v_this), "load", ((_t1646 = Z.arrNew()), Z.apush(_t1646, Z.dup(Z.index(v_t, 2))), _t1646)));
    Z.setLine(304);
    if (Z.truthy(Z.ident(v_op, "Coalesce"))) {
      Z.setLine(305);
      (v_r = f_zs_invoke(Z.dup(v_this), "coalesceWith", ((_t1647 = Z.arrNew()), Z.apush(_t1647, Z.dup(v_o)), Z.apush(_t1647, Z.dup(Z.index(v_e, 4))), _t1647)));
      Z.setLine(306);
      f_zs_invoke(Z.dup(v_this), "store", ((_t1648 = Z.arrNew()), Z.apush(_t1648, Z.dup(Z.index(v_t, 2))), Z.apush(_t1648, Z.dup(v_r)), _t1648));
      Z.setLine(307);
      return Z.dup(v_r);
    }
    Z.setLine(309);
    (v_rhs = f_zs_invoke(Z.dup(v_this), "expr", ((_t1649 = Z.arrNew()), Z.apush(_t1649, Z.dup(Z.index(v_e, 4))), _t1649)));
    Z.setLine(310);
    (v_n = f_zs_invoke(Z.dup(v_this), "binop", ((_t1650 = Z.arrNew()), Z.apush(_t1650, Z.dup(v_op)), Z.apush(_t1650, Z.dup(v_o)), Z.apush(_t1650, Z.dup(v_rhs)), _t1650)));
    Z.setLine(311);
    f_zs_invoke(Z.dup(v_this), "store", ((_t1651 = Z.arrNew()), Z.apush(_t1651, Z.dup(Z.index(v_t, 2))), Z.apush(_t1651, Z.dup(v_n)), _t1651));
    Z.setLine(312);
    return Z.dup(v_n);
  }
  Z.setLine(314);
  (v_a = f_zs_invoke(Z.dup(v_this), "lv", ((_t1652 = Z.arrNew()), Z.apush(_t1652, Z.dup(Z.index(v_t, 2))), _t1652)));
  Z.setLine(315);
  (v_k = f_zs_invoke(Z.dup(v_this), "keyOf", ((_t1653 = Z.arrNew()), Z.apush(_t1653, Z.dup(v_t)), Z.apush(_t1653, Z.dup(v_a)), _t1653)));
  Z.setLine(316);
  if (Z.truthy(Z.ident(v_op, "Coalesce"))) {
    Z.setLine(317);
    (v_o = f_zs_invoke(Z.dup(v_this), "vcall", ((_t1654 = Z.arrNew()), Z.apush(_t1654, "zv_index_opt"), Z.apush(_t1654, ((_t1655 = Z.arrNew()), Z.apush(_t1655, Z.dup(v_a)), Z.apush(_t1655, Z.dup(v_k)), _t1655)), _t1654)));
    Z.setLine(318);
    (v_n = f_zs_invoke(Z.dup(v_this), "coalesceWith", ((_t1656 = Z.arrNew()), Z.apush(_t1656, Z.dup(v_o)), Z.apush(_t1656, Z.dup(Z.index(v_e, 4))), _t1656)));
  } else {
    Z.setLine(320);
    (v_o = f_zs_invoke(Z.dup(v_this), "vcall", ((_t1657 = Z.arrNew()), Z.apush(_t1657, "zv_index"), Z.apush(_t1657, ((_t1658 = Z.arrNew()), Z.apush(_t1658, Z.dup(v_a)), Z.apush(_t1658, Z.dup(v_k)), _t1658)), _t1657)));
    Z.setLine(321);
    (v_rhs = f_zs_invoke(Z.dup(v_this), "expr", ((_t1659 = Z.arrNew()), Z.apush(_t1659, Z.dup(Z.index(v_e, 4))), _t1659)));
    Z.setLine(322);
    (v_n = f_zs_invoke(Z.dup(v_this), "binop", ((_t1660 = Z.arrNew()), Z.apush(_t1660, Z.dup(v_op)), Z.apush(_t1660, Z.dup(v_o)), Z.apush(_t1660, Z.dup(v_rhs)), _t1660)));
  }
  Z.setLine(324);
  f_zs_invoke(Z.dup(v_this), "vcallVoid", ((_t1661 = Z.arrNew()), Z.apush(_t1661, "zv_set"), Z.apush(_t1661, ((_t1662 = Z.arrNew()), Z.apush(_t1662, Z.dup(v_a)), Z.apush(_t1662, Z.dup(v_k)), Z.apush(_t1662, Z.dup(v_n)), _t1662)), _t1661));
  Z.setLine(325);
  return Z.dup(v_n);
  return null;
}
function f_LlEmitter__coalesceWith(v_this, v_x, v_rhsExpr) {
  let v_sl = null, v_tg = null, v_isn = null, v_lr = null, v_lj = null, v_v = null;
  let _t1663 = null, _t1664 = null, _t1665 = null, _t1666 = null, _t1667 = null, _t1668 = null, _t1669 = null, _t1670 = null, _t1671 = null, _t1672 = null, _t1673 = null, _t1674 = null, _t1675 = null, _t1676 = null;
  Z.setLine(330);
  (v_sl = f_zs_invoke(Z.dup(v_this), "slot", ((_t1663 = Z.arrNew()), _t1663)));
  Z.setLine(331);
  f_zs_invoke(Z.dup(v_this), "storeTo", ((_t1664 = Z.arrNew()), Z.apush(_t1664, Z.dup(v_sl)), Z.apush(_t1664, Z.dup(v_x)), _t1664));
  Z.setLine(332);
  (v_tg = f_zs_invoke(Z.dup(v_this), "r", ((_t1665 = Z.arrNew()), _t1665)));
  Z.setLine(333);
  f_zs_invoke(Z.dup(v_this), "line", ((_t1666 = Z.arrNew()), Z.apush(_t1666, Z.concat(Z.concat(Z.concat(v_tg, " = extractvalue { i64, i64 } "), v_x), ", 0")), _t1666));
  Z.setLine(334);
  (v_isn = f_zs_invoke(Z.dup(v_this), "r", ((_t1667 = Z.arrNew()), _t1667)));
  Z.setLine(335);
  f_zs_invoke(Z.dup(v_this), "line", ((_t1668 = Z.arrNew()), Z.apush(_t1668, Z.concat(Z.concat(Z.concat(v_isn, " = icmp eq i64 "), v_tg), ", 0")), _t1668));
  Z.setLine(336);
  (v_lr = f_zs_invoke(Z.dup(v_this), "newLabel", ((_t1669 = Z.arrNew()), Z.apush(_t1669, "coal"), _t1669)));
  Z.setLine(337);
  (v_lj = f_zs_invoke(Z.dup(v_this), "newLabel", ((_t1670 = Z.arrNew()), Z.apush(_t1670, "coalj"), _t1670)));
  Z.setLine(338);
  f_zs_invoke(Z.dup(v_this), "terminate", ((_t1671 = Z.arrNew()), Z.apush(_t1671, Z.concat(Z.concat(Z.concat(Z.concat(Z.concat("br i1 ", v_isn), ", label %"), v_lr), ", label %"), v_lj)), _t1671));
  Z.setLine(339);
  f_zs_invoke(Z.dup(v_this), "label", ((_t1672 = Z.arrNew()), Z.apush(_t1672, Z.dup(v_lr)), _t1672));
  Z.setLine(340);
  (v_v = f_zs_invoke(Z.dup(v_this), "val", ((_t1673 = Z.arrNew()), Z.apush(_t1673, Z.dup(v_rhsExpr)), _t1673)));
  Z.setLine(341);
  f_zs_invoke(Z.dup(v_this), "storeTo", ((_t1674 = Z.arrNew()), Z.apush(_t1674, Z.dup(v_sl)), Z.apush(_t1674, Z.dup(v_v)), _t1674));
  Z.setLine(342);
  f_zs_invoke(Z.dup(v_this), "label", ((_t1675 = Z.arrNew()), Z.apush(_t1675, Z.dup(v_lj)), _t1675));
  Z.setLine(343);
  return f_zs_invoke(Z.dup(v_this), "loadFrom", ((_t1676 = Z.arrNew()), Z.apush(_t1676, Z.dup(v_sl)), _t1676));
  return null;
}
function f_LlEmitter__assign(v_this, v_e) {
  let v_t = null, v_v = null, v_a = null, v_k = null;
  let _t1677 = null, _t1678 = null, _t1679 = null, _t1680 = null, _t1681 = null, _t1682 = null, _t1683 = null, _t1684 = null, _t1685 = null;
  Z.setLine(347);
  (v_t = Z.dup(Z.index(v_e, 2)));
  Z.setLine(348);
  if (Z.truthy(Z.ident(Z.index(v_t, 0), ":Var"))) {
    Z.setLine(349);
    (v_v = f_zs_invoke(Z.dup(v_this), "val", ((_t1677 = Z.arrNew()), Z.apush(_t1677, Z.dup(Z.index(v_e, 3))), _t1677)));
    Z.setLine(350);
    f_zs_invoke(Z.dup(v_this), "store", ((_t1678 = Z.arrNew()), Z.apush(_t1678, Z.dup(Z.index(v_t, 2))), Z.apush(_t1678, Z.dup(v_v)), _t1678));
    Z.setLine(351);
    return Z.dup(v_v);
  }
  Z.setLine(353);
  (v_a = f_zs_invoke(Z.dup(v_this), "lv", ((_t1679 = Z.arrNew()), Z.apush(_t1679, Z.dup(Z.index(v_t, 2))), _t1679)));
  Z.setLine(354);
  (v_v = f_zs_invoke(Z.dup(v_this), "val", ((_t1680 = Z.arrNew()), Z.apush(_t1680, Z.dup(Z.index(v_e, 3))), _t1680)));
  Z.setLine(355);
  if (Z.truthy(Z.ident(Z.index(v_t, 3), null))) {
    Z.setLine(355);
    f_zs_invoke(Z.dup(v_this), "vcallVoid", ((_t1681 = Z.arrNew()), Z.apush(_t1681, "zv_append"), Z.apush(_t1681, ((_t1682 = Z.arrNew()), Z.apush(_t1682, Z.dup(v_a)), Z.apush(_t1682, Z.dup(v_v)), _t1682)), _t1681));
  } else {
    Z.setLine(357);
    (v_k = f_zs_invoke(Z.dup(v_this), "expr", ((_t1683 = Z.arrNew()), Z.apush(_t1683, Z.dup(Z.index(v_t, 3))), _t1683)));
    Z.setLine(358);
    f_zs_invoke(Z.dup(v_this), "vcallVoid", ((_t1684 = Z.arrNew()), Z.apush(_t1684, "zv_set"), Z.apush(_t1684, ((_t1685 = Z.arrNew()), Z.apush(_t1685, Z.dup(v_a)), Z.apush(_t1685, Z.dup(v_k)), Z.apush(_t1685, Z.dup(v_v)), _t1685)), _t1684));
  }
  Z.setLine(360);
  return Z.dup(v_v);
  return null;
}
function f_LlEmitter__argRegs(v_this, v_list, v_dup) {
  let v_out = null, v_a = null;
  let _t1686 = null, _t1687 = null, _t1688 = null;
  Z.setLine(364);
  (v_out = ((_t1686 = Z.arrNew()), _t1686));
  Z.setLine(365);
  {
    const _it167 = Z.foreachArr(Z.dup(v_list));
    L167: for (let _i167 = 0; _i167 < _it167.keys.length; _i167++) {
      v_a = _it167.vals[_i167];
      Z.setLine(365);
      Z.apush((v_out = Z.wr(v_out)), (Z.truthy(v_dup) ? f_zs_invoke(Z.dup(v_this), "val", ((_t1687 = Z.arrNew()), Z.apush(_t1687, Z.dup(Z.index(v_a, 3))), _t1687)) : f_zs_invoke(Z.dup(v_this), "expr", ((_t1688 = Z.arrNew()), Z.apush(_t1688, Z.dup(Z.index(v_a, 3))), _t1688))));
    }
  }
  Z.setLine(366);
  return Z.dup(v_out);
  return null;
}
function f_LlEmitter__call(v_this, v_e) {
  let v_callee = null, v_list = null, v_n = null, v_name = null, v_f = null, v_a = null, v_i = null, v_m = null;
  let _t1689 = null, _t1690 = null, _t1691 = null, _t1692 = null, _t1693 = null, _t1694 = null, _t1695 = null, _t1696 = null, _t1697 = null, _t1698 = null, _t1699 = null, _t1700 = null;
  Z.setLine(370);
  (v_callee = Z.dup(Z.index(v_e, 2)));
  Z.setLine(371);
  (v_list = Z.dup(Z.index(v_e, 3)));
  Z.setLine(372);
  (v_n = Z.B.count(v_list));
  Z.setLine(373);
  if (Z.truthy(Z.ident(Z.index(v_callee, 0), ":Prop"))) {
    Z.setLine(373);
    return f_zs_invoke(Z.dup(v_this), "vcall", ((_t1689 = Z.arrNew()), Z.apush(_t1689, "b_getmessage"), Z.apush(_t1689, ((_t1690 = Z.arrNew()), Z.apush(_t1690, f_zs_invoke(Z.dup(v_this), "expr", ((_t1691 = Z.arrNew()), Z.apush(_t1691, Z.dup(Z.index(v_callee, 2))), _t1691))), _t1690)), _t1689));
  }
  Z.setLine(374);
  if (Z.truthy(Z.ident(Z.index(v_callee, 0), ":Name"))) {
    Z.setLine(375);
    (v_name = Z.dup(Z.index(v_callee, 2)));
    Z.setLine(376);
    if (Z.truthy(Z.B.has_key(Z.index(Z.B.zs_obj_get(v_this, "ir"), "funcs"), v_name))) {
      Z.setLine(377);
      (v_f = Z.dup(Z.index(Z.index(Z.B.zs_obj_get(v_this, "ir"), "funcs"), v_name)));
      Z.setLine(378);
      (v_a = f_zs_invoke(Z.dup(v_this), "argRegs", ((_t1692 = Z.arrNew()), Z.apush(_t1692, Z.dup(v_list)), Z.apush(_t1692, true), _t1692)));
      Z.setLine(379);
      (v_i = Z.dup(v_n));
      L168: for (; Z.truthy((Z.cmp(v_i, Z.B.count(Z.index(v_f, "params"))) < 0)); ((_t1693 = v_i), (v_i = Z.add(_t1693, 1)), _t1693)) {
        Z.setLine(379);
        Z.apush((v_a = Z.wr(v_a)), f_zs_invoke(Z.dup(v_this), "expr", ((_t1694 = Z.arrNew()), Z.apush(_t1694, Z.dup(Z.index(Z.index(Z.index(v_f, "params"), v_i), 4))), _t1694)));
      }
      Z.setLine(380);
      return f_zs_invoke(Z.dup(v_this), "vcall", ((_t1695 = Z.arrNew()), Z.apush(_t1695, Z.concat("f_", v_name)), Z.apush(_t1695, Z.dup(v_a)), _t1695));
    }
    Z.setLine(382);
    return f_zs_invoke(Z.dup(v_this), "builtin", ((_t1696 = Z.arrNew()), Z.apush(_t1696, Z.dup(v_name)), Z.apush(_t1696, Z.dup(v_list)), _t1696));
  }
  Z.setLine(384);
  (v_m = Z.dup(Z.index(Z.index(v_callee, 2), 2)));
  Z.setLine(385);
  (v_f = Z.dup(Z.index(v_callee, 3)));
  Z.setLine(386);
  (v_a = f_zs_invoke(Z.dup(v_this), "argRegs", ((_t1697 = Z.arrNew()), Z.apush(_t1697, Z.dup(v_list)), Z.apush(_t1697, false), _t1697)));
  Z.setLine(387);
  if (Z.truthy((Z.truthy(Z.ident(v_m, "System")) && Z.truthy(Z.ident(v_f, "exit"))))) {
    Z.setLine(387);
    return f_zs_invoke(Z.dup(v_this), "doExit", ((_t1698 = Z.arrNew()), Z.apush(_t1698, Z.dup(v_a)), _t1698));
  }
  Z.setLine(388);
  if (Z.truthy((Z.truthy(Z.ident(v_m, "Process")) && Z.truthy(Z.ident(Z.B.count(v_a), 1))))) {
    Z.setLine(388);
    Z.apush((v_a = Z.wr(v_a)), f_zs_invoke(Z.dup(v_this), "nullv", ((_t1699 = Z.arrNew()), _t1699)));
  }
  Z.setLine(389);
  return f_zs_invoke(Z.dup(v_this), "vcall", ((_t1700 = Z.arrNew()), Z.apush(_t1700, Z.concat(Z.concat(Z.concat("m_", v_m), "_"), v_f)), Z.apush(_t1700, Z.dup(v_a)), _t1700));
  return null;
}
function f_LlEmitter__doExit(v_this, v_a) {
  let v_c = null;
  let _t1701 = null, _t1702 = null, _t1703 = null, _t1704 = null, _t1705 = null;
  Z.setLine(393);
  (v_c = (Z.truthy((Z.cmp(Z.B.count(v_a), 0) > 0)) ? Z.index(v_a, 0) : f_zs_invoke(Z.dup(v_this), "mkv", ((_t1701 = Z.arrNew()), Z.apush(_t1701, 2), Z.apush(_t1701, "0"), _t1701))));
  Z.setLine(394);
  f_zs_invoke(Z.dup(v_this), "vcallVoid", ((_t1702 = Z.arrNew()), Z.apush(_t1702, "s_exit"), Z.apush(_t1702, ((_t1703 = Z.arrNew()), Z.apush(_t1703, Z.dup(v_c)), _t1703)), _t1702));
  Z.setLine(395);
  f_zs_invoke(Z.dup(v_this), "terminate", ((_t1704 = Z.arrNew()), Z.apush(_t1704, "unreachable"), _t1704));
  Z.setLine(396);
  return f_zs_invoke(Z.dup(v_this), "nullv", ((_t1705 = Z.arrNew()), _t1705));
  return null;
}
function f_LlEmitter__builtin(v_this, v_name, v_list) {
  let v_a = null, v_first = null, v_x = null, v_r = null, v_i = null, v_has = null, v_l = null;
  let _t1706 = null, _t1707 = null, _t1708 = null, _t1709 = null, _t1710 = null, _t1711 = null, _t1712 = null, _t1713 = null, _t1714 = null, _t1715 = null, _t1716 = null, _t1717 = null, _t1718 = null, _t1719 = null, _t1720 = null, _t1721 = null, _t1722 = null, _t1723 = null, _t1724 = null, _t1725 = null, _t1726 = null, _t1727 = null, _t1728 = null, _t1729 = null, _t1730 = null, _t1731 = null, _t1732 = null, _t1733 = null, _t1734 = null, _t1735 = null, _t1736 = null;
  Z.setLine(400);
  (v_a = f_zs_invoke(Z.dup(v_this), "argRegs", ((_t1706 = Z.arrNew()), Z.apush(_t1706, Z.dup(v_list)), Z.apush(_t1706, false), _t1706)));
  Z.setLine(401);
  if (Z.truthy(Z.ident(v_name, "eecho"))) {
    Z.setLine(402);
    (v_first = 1);
    Z.setLine(403);
    {
      const _it169 = Z.foreachArr(Z.dup(v_a));
      L169: for (let _i169 = 0; _i169 < _it169.keys.length; _i169++) {
        v_x = _it169.vals[_i169];
        Z.setLine(403);
        f_zs_invoke(Z.dup(v_this), "rt", ((_t1707 = Z.arrNew()), Z.apush(_t1707, "zs_eecho_v"), Z.apush(_t1707, "void"), Z.apush(_t1707, ((_t1708 = Z.arrNew()), Z.apush(_t1708, ((_t1709 = Z.arrNew()), Z.apush(_t1709, "V"), Z.apush(_t1709, Z.dup(v_x)), _t1709)), Z.apush(_t1708, ((_t1710 = Z.arrNew()), Z.apush(_t1710, "i32"), Z.apush(_t1710, Z.concat("", v_first)), _t1710)), _t1708)), _t1707));
        Z.setLine(403);
        (v_first = 0);
      }
    }
    Z.setLine(404);
    if (Z.truthy(Z.ident(Z.B.count(v_a), 0))) {
      Z.setLine(404);
      f_zs_invoke(Z.dup(v_this), "rt", ((_t1711 = Z.arrNew()), Z.apush(_t1711, "zs_shutdown"), Z.apush(_t1711, "void"), Z.apush(_t1711, ((_t1712 = Z.arrNew()), _t1712)), _t1711));
    }
    Z.setLine(405);
    f_zs_invoke(Z.dup(v_this), "rt", ((_t1713 = Z.arrNew()), Z.apush(_t1713, "zs_eecho_end"), Z.apush(_t1713, "void"), Z.apush(_t1713, ((_t1714 = Z.arrNew()), _t1714)), _t1713));
    Z.setLine(406);
    return f_zs_invoke(Z.dup(v_this), "nullv", ((_t1715 = Z.arrNew()), _t1715));
  }
  Z.setLine(408);
  if (Z.truthy(Z.ident(v_name, "necho"))) {
    Z.setLine(409);
    {
      const _it170 = Z.foreachArr(Z.dup(v_a));
      L170: for (let _i170 = 0; _i170 < _it170.keys.length; _i170++) {
        v_x = _it170.vals[_i170];
        Z.setLine(409);
        f_zs_invoke(Z.dup(v_this), "rt", ((_t1716 = Z.arrNew()), Z.apush(_t1716, "zs_necho_v"), Z.apush(_t1716, "void"), Z.apush(_t1716, ((_t1717 = Z.arrNew()), Z.apush(_t1717, ((_t1718 = Z.arrNew()), Z.apush(_t1718, "V"), Z.apush(_t1718, Z.dup(v_x)), _t1718)), _t1717)), _t1716));
      }
    }
    Z.setLine(410);
    return f_zs_invoke(Z.dup(v_this), "nullv", ((_t1719 = Z.arrNew()), _t1719));
  }
  Z.setLine(412);
  if (Z.truthy(Z.ident(v_name, "exit"))) {
    Z.setLine(412);
    return f_zs_invoke(Z.dup(v_this), "doExit", ((_t1720 = Z.arrNew()), Z.apush(_t1720, Z.dup(v_a)), _t1720));
  }
  Z.setLine(413);
  if (Z.truthy(Z.ident(v_name, "dump"))) {
    Z.setLine(414);
    {
      const _it171 = Z.foreachArr(Z.dup(v_a));
      L171: for (let _i171 = 0; _i171 < _it171.keys.length; _i171++) {
        v_x = _it171.vals[_i171];
        Z.setLine(414);
        f_zs_invoke(Z.dup(v_this), "vcall", ((_t1721 = Z.arrNew()), Z.apush(_t1721, "b_dump"), Z.apush(_t1721, ((_t1722 = Z.arrNew()), Z.apush(_t1722, Z.dup(v_x)), _t1722)), _t1721));
      }
    }
    Z.setLine(415);
    return f_zs_invoke(Z.dup(v_this), "nullv", ((_t1723 = Z.arrNew()), _t1723));
  }
  Z.setLine(417);
  if (Z.truthy(Z.ident(v_name, "push"))) {
    Z.setLine(418);
    (v_r = Z.dup(Z.index(v_a, 0)));
    Z.setLine(419);
    (v_i = 1);
    L172: for (; Z.truthy((Z.cmp(v_i, Z.B.count(v_a)) < 0)); ((_t1724 = v_i), (v_i = Z.add(_t1724, 1)), _t1724)) {
      Z.setLine(419);
      (v_r = f_zs_invoke(Z.dup(v_this), "vcall", ((_t1725 = Z.arrNew()), Z.apush(_t1725, "b_push"), Z.apush(_t1725, ((_t1726 = Z.arrNew()), Z.apush(_t1726, Z.dup(v_r)), Z.apush(_t1726, Z.dup(Z.index(v_a, v_i))), _t1726)), _t1725)));
    }
    Z.setLine(420);
    return Z.dup(v_r);
  }
  Z.setLine(422);
  if (Z.truthy(Z.ident(v_name, "substr"))) {
    Z.setLine(423);
    (v_has = (Z.truthy(Z.ident(Z.B.count(v_a), 3)) ? "1" : "0"));
    Z.setLine(424);
    (v_l = (Z.truthy(Z.ident(Z.B.count(v_a), 3)) ? Z.index(v_a, 2) : f_zs_invoke(Z.dup(v_this), "nullv", ((_t1727 = Z.arrNew()), _t1727))));
    Z.setLine(425);
    return f_zs_invoke(Z.dup(v_this), "rt", ((_t1728 = Z.arrNew()), Z.apush(_t1728, "b_substr"), Z.apush(_t1728, "V"), Z.apush(_t1728, ((_t1729 = Z.arrNew()), Z.apush(_t1729, ((_t1730 = Z.arrNew()), Z.apush(_t1730, "V"), Z.apush(_t1730, Z.dup(Z.index(v_a, 0))), _t1730)), Z.apush(_t1729, ((_t1731 = Z.arrNew()), Z.apush(_t1731, "V"), Z.apush(_t1731, Z.dup(Z.index(v_a, 1))), _t1731)), Z.apush(_t1729, ((_t1732 = Z.arrNew()), Z.apush(_t1732, "V"), Z.apush(_t1732, Z.dup(v_l)), _t1732)), Z.apush(_t1729, ((_t1733 = Z.arrNew()), Z.apush(_t1733, "i32"), Z.apush(_t1733, Z.dup(v_has)), _t1733)), _t1729)), _t1728));
  }
  Z.setLine(427);
  if (Z.truthy((Z.truthy(Z.ident(Z.B.count(v_a), 3)) && Z.truthy(Z.B.in_array(v_name, ((_t1734 = Z.arrNew()), Z.apush(_t1734, "pad_left"), Z.apush(_t1734, "pad_right"), Z.apush(_t1734, "array_slice"), _t1734)))))) {
    Z.setLine(427);
    return f_zs_invoke(Z.dup(v_this), "vcall", ((_t1735 = Z.arrNew()), Z.apush(_t1735, Z.concat(Z.concat("b_", v_name), "3")), Z.apush(_t1735, Z.dup(v_a)), _t1735));
  }
  Z.setLine(428);
  return f_zs_invoke(Z.dup(v_this), "vcall", ((_t1736 = Z.arrNew()), Z.apush(_t1736, Z.concat("b_", v_name)), Z.apush(_t1736, Z.dup(v_a)), _t1736));
  return null;
}
function f_LlEmitter__expr(v_this, v_e) {
  let v_k = null, v_s = null, v_i = null, v_p = null, v_msg = null, v_arr = null, v_it = null, v_key = null, v_b = null, v_x = null, v_t = null, v_n = null, v_op = null, v_a = null;
  let _t1737 = null, _t1738 = null, _t1739 = null, _t1740 = null, _t1741 = null, _t1742 = null, _t1743 = null, _t1744 = null, _t1745 = null, _t1746 = null, _t1747 = null, _t1748 = null, _t1749 = null, _t1750 = null, _t1751 = null, _t1752 = null, _t1753 = null, _t1754 = null, _t1755 = null, _t1756 = null, _t1757 = null, _t1758 = null, _t1759 = null, _t1760 = null, _t1761 = null, _t1762 = null, _t1763 = null, _t1764 = null, _t1765 = null, _t1766 = null, _t1767 = null, _t1768 = null, _t1769 = null, _t1770 = null, _t1771 = null, _t1772 = null, _t1773 = null, _t1774 = null, _t1775 = null, _t1776 = null, _t1777 = null, _t1778 = null, _t1779 = null, _t1780 = null, _t1781 = null, _t1782 = null, _t1783 = null, _t1784 = null, _t1785 = null, _t1786 = null, _t1787 = null, _t1788 = null, _t1789 = null, _t1790 = null, _t1791 = null, _t1792 = null, _t1793 = null;
  Z.setLine(432);
  (v_k = Z.dup(Z.index(v_e, 0)));
  Z.setLine(433);
  if (Z.truthy(Z.ident(v_k, ":Null"))) {
    Z.setLine(433);
    return f_zs_invoke(Z.dup(v_this), "nullv", ((_t1737 = Z.arrNew()), _t1737));
  }
  Z.setLine(434);
  if (Z.truthy(Z.ident(v_k, ":Bool"))) {
    Z.setLine(434);
    return f_zs_invoke(Z.dup(v_this), "mkv", ((_t1738 = Z.arrNew()), Z.apush(_t1738, 1), Z.apush(_t1738, (Z.truthy(Z.index(v_e, 2)) ? "1" : "0")), _t1738));
  }
  Z.setLine(435);
  if (Z.truthy(Z.ident(v_k, ":Int"))) {
    Z.setLine(435);
    return f_zs_invoke(Z.dup(v_this), "mkv", ((_t1739 = Z.arrNew()), Z.apush(_t1739, 2), Z.apush(_t1739, Z.concat("", Z.index(v_e, 2))), _t1739));
  }
  Z.setLine(436);
  if (Z.truthy(Z.ident(v_k, ":Float"))) {
    Z.setLine(437);
    (v_s = Z.B.strval(Z.index(v_e, 2)));
    Z.setLine(438);
    return f_zs_invoke(Z.dup(v_this), "rt", ((_t1740 = Z.arrNew()), Z.apush(_t1740, "zl_float_lit"), Z.apush(_t1740, "V"), Z.apush(_t1740, ((_t1741 = Z.arrNew()), Z.apush(_t1741, ((_t1742 = Z.arrNew()), Z.apush(_t1742, "ptr"), Z.apush(_t1742, f_zs_invoke(Z.dup(v_this), "cstr", ((_t1743 = Z.arrNew()), Z.apush(_t1743, Z.dup(v_s)), _t1743))), _t1742)), _t1741)), _t1740));
  }
  Z.setLine(440);
  if (Z.truthy(Z.ident(v_k, ":Str"))) {
    Z.setLine(441);
    (v_i = f_zs_invoke(Z.dup(v_this), "strSlot", ((_t1744 = Z.arrNew()), Z.apush(_t1744, Z.dup(Z.index(v_e, 2))), _t1744)));
    Z.setLine(442);
    (v_p = f_zs_invoke(Z.dup(v_this), "r", ((_t1745 = Z.arrNew()), _t1745)));
    Z.setLine(443);
    f_zs_invoke(Z.dup(v_this), "line", ((_t1746 = Z.arrNew()), Z.apush(_t1746, Z.concat(Z.concat(v_p, " = getelementptr inbounds { i64, i64 }, ptr @S, i64 "), v_i)), _t1746));
    Z.setLine(444);
    return f_zs_invoke(Z.dup(v_this), "loadFrom", ((_t1747 = Z.arrNew()), Z.apush(_t1747, Z.dup(v_p)), _t1747));
  }
  Z.setLine(446);
  if (Z.truthy(Z.ident(v_k, ":Var"))) {
    Z.setLine(447);
    if (Z.truthy(!Z.truthy(Z.B.in_array(Z.index(v_e, 2), Z.B.zs_obj_get(v_this, "known"))))) {
      Z.setLine(448);
      f_zs_invoke(Z.dup(v_this), "setLine", ((_t1748 = Z.arrNew()), Z.apush(_t1748, Z.dup(Z.index(v_e, 1))), _t1748));
      Z.setLine(449);
      return f_zs_invoke(Z.dup(v_this), "rt", ((_t1749 = Z.arrNew()), Z.apush(_t1749, "zl_undef_var"), Z.apush(_t1749, "V"), Z.apush(_t1749, ((_t1750 = Z.arrNew()), Z.apush(_t1750, ((_t1751 = Z.arrNew()), Z.apush(_t1751, "ptr"), Z.apush(_t1751, f_zs_invoke(Z.dup(v_this), "cstr", ((_t1752 = Z.arrNew()), Z.apush(_t1752, Z.dup(Z.index(v_e, 2))), _t1752))), _t1751)), _t1750)), _t1749));
    }
    Z.setLine(451);
    return f_zs_invoke(Z.dup(v_this), "load", ((_t1753 = Z.arrNew()), Z.apush(_t1753, Z.dup(Z.index(v_e, 2))), _t1753));
  }
  Z.setLine(453);
  if (Z.truthy(Z.ident(v_k, ":New"))) {
    Z.setLine(454);
    (v_msg = (Z.truthy((Z.cmp(Z.B.count(Z.index(v_e, 3)), 0) > 0)) ? f_zs_invoke(Z.dup(v_this), "expr", ((_t1754 = Z.arrNew()), Z.apush(_t1754, Z.dup(Z.index(Z.index(Z.index(v_e, 3), 0), 3))), _t1754)) : f_zs_invoke(Z.dup(v_this), "emptyStr", ((_t1755 = Z.arrNew()), _t1755))));
    Z.setLine(455);
    return f_zs_invoke(Z.dup(v_this), "rt", ((_t1756 = Z.arrNew()), Z.apush(_t1756, "zv_exc_new"), Z.apush(_t1756, "V"), Z.apush(_t1756, ((_t1757 = Z.arrNew()), Z.apush(_t1757, ((_t1758 = Z.arrNew()), Z.apush(_t1758, "i32"), Z.apush(_t1758, (Z.truthy(Z.ident(Z.index(v_e, 2), "Error")) ? "1" : "0")), _t1758)), Z.apush(_t1757, ((_t1759 = Z.arrNew()), Z.apush(_t1759, "V"), Z.apush(_t1759, Z.dup(v_msg)), _t1759)), _t1757)), _t1756));
  }
  Z.setLine(457);
  if (Z.truthy(Z.ident(v_k, ":Array"))) {
    Z.setLine(458);
    (v_arr = f_zs_invoke(Z.dup(v_this), "rt", ((_t1760 = Z.arrNew()), Z.apush(_t1760, "zv_arr_new"), Z.apush(_t1760, "V"), Z.apush(_t1760, ((_t1761 = Z.arrNew()), Z.apush(_t1761, ((_t1762 = Z.arrNew()), Z.apush(_t1762, "i64"), Z.apush(_t1762, Z.concat("", Z.B.count(Z.index(v_e, 2)))), _t1762)), _t1761)), _t1760)));
    Z.setLine(459);
    {
      const _it173 = Z.foreachArr(Z.dup(Z.index(v_e, 2)));
      L173: for (let _i173 = 0; _i173 < _it173.keys.length; _i173++) {
        v_it = _it173.vals[_i173];
        Z.setLine(460);
        if (Z.truthy(Z.ident(Z.index(v_it, 2), null))) {
          Z.setLine(460);
          f_zs_invoke(Z.dup(v_this), "vcallVoid", ((_t1763 = Z.arrNew()), Z.apush(_t1763, "zv_append"), Z.apush(_t1763, ((_t1764 = Z.arrNew()), Z.apush(_t1764, Z.dup(v_arr)), Z.apush(_t1764, f_zs_invoke(Z.dup(v_this), "val", ((_t1765 = Z.arrNew()), Z.apush(_t1765, Z.dup(Z.index(v_it, 3))), _t1765))), _t1764)), _t1763));
        } else {
          Z.setLine(462);
          (v_key = f_zs_invoke(Z.dup(v_this), "expr", ((_t1766 = Z.arrNew()), Z.apush(_t1766, Z.dup(Z.index(v_it, 2))), _t1766)));
          Z.setLine(463);
          f_zs_invoke(Z.dup(v_this), "vcallVoid", ((_t1767 = Z.arrNew()), Z.apush(_t1767, "zv_set"), Z.apush(_t1767, ((_t1768 = Z.arrNew()), Z.apush(_t1768, Z.dup(v_arr)), Z.apush(_t1768, Z.dup(v_key)), Z.apush(_t1768, f_zs_invoke(Z.dup(v_this), "val", ((_t1769 = Z.arrNew()), Z.apush(_t1769, Z.dup(Z.index(v_it, 3))), _t1769))), _t1768)), _t1767));
        }
      }
    }
    Z.setLine(466);
    return Z.dup(v_arr);
  }
  Z.setLine(468);
  if (Z.truthy(Z.ident(v_k, ":Index"))) {
    Z.setLine(469);
    if (Z.truthy(Z.ident(Z.index(v_e, 3), null))) {
      Z.setLine(469);
      Z.raise(new Z.ZExc(0, Z.concat(Z.concat("emit_llvm: odczyt `[]` niedozwolony (linia ", Z.index(v_e, 1)), ")")));
    }
    Z.setLine(470);
    (v_b = f_zs_invoke(Z.dup(v_this), "expr", ((_t1770 = Z.arrNew()), Z.apush(_t1770, Z.dup(Z.index(v_e, 2))), _t1770)));
    Z.setLine(471);
    (v_i = f_zs_invoke(Z.dup(v_this), "expr", ((_t1771 = Z.arrNew()), Z.apush(_t1771, Z.dup(Z.index(v_e, 3))), _t1771)));
    Z.setLine(472);
    return f_zs_invoke(Z.dup(v_this), "vcall", ((_t1772 = Z.arrNew()), Z.apush(_t1772, "zv_index"), Z.apush(_t1772, ((_t1773 = Z.arrNew()), Z.apush(_t1773, Z.dup(v_b)), Z.apush(_t1773, Z.dup(v_i)), _t1773)), _t1772));
  }
  Z.setLine(474);
  if (Z.truthy(Z.ident(v_k, ":Unary"))) {
    Z.setLine(475);
    (v_x = f_zs_invoke(Z.dup(v_this), "expr", ((_t1774 = Z.arrNew()), Z.apush(_t1774, Z.dup(Z.index(v_e, 3))), _t1774)));
    Z.setLine(476);
    if (Z.truthy(Z.ident(Z.index(v_e, 2), "Not"))) {
      Z.setLine(477);
      (v_t = f_zs_invoke(Z.dup(v_this), "truthy", ((_t1775 = Z.arrNew()), Z.apush(_t1775, Z.dup(v_x)), _t1775)));
      Z.setLine(478);
      (v_n = f_zs_invoke(Z.dup(v_this), "r", ((_t1776 = Z.arrNew()), _t1776)));
      Z.setLine(479);
      f_zs_invoke(Z.dup(v_this), "line", ((_t1777 = Z.arrNew()), Z.apush(_t1777, Z.concat(Z.concat(Z.concat(v_n, " = xor i1 "), v_t), ", true")), _t1777));
      Z.setLine(480);
      return f_zs_invoke(Z.dup(v_this), "boolOf", ((_t1778 = Z.arrNew()), Z.apush(_t1778, Z.dup(v_n)), _t1778));
    }
    Z.setLine(482);
    if (Z.truthy(Z.ident(Z.index(v_e, 2), "Neg"))) {
      Z.setLine(482);
      return f_zs_invoke(Z.dup(v_this), "vcall", ((_t1779 = Z.arrNew()), Z.apush(_t1779, "zv_neg"), Z.apush(_t1779, ((_t1780 = Z.arrNew()), Z.apush(_t1780, Z.dup(v_x)), _t1780)), _t1779));
    }
    Z.setLine(483);
    if (Z.truthy(Z.ident(Z.index(v_e, 2), "BitNot"))) {
      Z.setLine(483);
      return f_zs_invoke(Z.dup(v_this), "vcall", ((_t1781 = Z.arrNew()), Z.apush(_t1781, "zv_bitnot"), Z.apush(_t1781, ((_t1782 = Z.arrNew()), Z.apush(_t1782, Z.dup(v_x)), _t1782)), _t1781));
    }
    Z.setLine(484);
    return Z.dup(v_x);
  }
  Z.setLine(486);
  if (Z.truthy(Z.ident(v_k, ":Binary"))) {
    Z.setLine(487);
    (v_op = Z.dup(Z.index(v_e, 2)));
    Z.setLine(488);
    if (Z.truthy((Z.truthy(Z.ident(v_op, "And")) || Z.truthy(Z.ident(v_op, "Or"))))) {
      Z.setLine(488);
      return f_zs_invoke(Z.dup(v_this), "shortCircuit", ((_t1783 = Z.arrNew()), Z.apush(_t1783, Z.ident(v_op, "And")), Z.apush(_t1783, Z.dup(Z.index(v_e, 3))), Z.apush(_t1783, Z.dup(Z.index(v_e, 4))), _t1783));
    }
    Z.setLine(489);
    if (Z.truthy(Z.ident(v_op, "Coalesce"))) {
      Z.setLine(489);
      return f_zs_invoke(Z.dup(v_this), "coalesceWith", ((_t1784 = Z.arrNew()), Z.apush(_t1784, f_zs_invoke(Z.dup(v_this), "quiet", ((_t1785 = Z.arrNew()), Z.apush(_t1785, Z.dup(Z.index(v_e, 3))), _t1785))), Z.apush(_t1784, Z.dup(Z.index(v_e, 4))), _t1784));
    }
    Z.setLine(490);
    (v_a = f_zs_invoke(Z.dup(v_this), "expr", ((_t1786 = Z.arrNew()), Z.apush(_t1786, Z.dup(Z.index(v_e, 3))), _t1786)));
    Z.setLine(491);
    (v_b = f_zs_invoke(Z.dup(v_this), "expr", ((_t1787 = Z.arrNew()), Z.apush(_t1787, Z.dup(Z.index(v_e, 4))), _t1787)));
    Z.setLine(492);
    return f_zs_invoke(Z.dup(v_this), "binop", ((_t1788 = Z.arrNew()), Z.apush(_t1788, Z.dup(v_op)), Z.apush(_t1788, Z.dup(v_a)), Z.apush(_t1788, Z.dup(v_b)), _t1788));
  }
  Z.setLine(494);
  if (Z.truthy(Z.ident(v_k, ":Assign"))) {
    Z.setLine(494);
    return f_zs_invoke(Z.dup(v_this), "assign", ((_t1789 = Z.arrNew()), Z.apush(_t1789, Z.dup(v_e)), _t1789));
  }
  Z.setLine(495);
  if (Z.truthy(Z.ident(v_k, ":AssignOp"))) {
    Z.setLine(495);
    return f_zs_invoke(Z.dup(v_this), "assignop", ((_t1790 = Z.arrNew()), Z.apush(_t1790, Z.dup(v_e)), _t1790));
  }
  Z.setLine(496);
  if (Z.truthy(Z.ident(v_k, ":IncDec"))) {
    Z.setLine(496);
    return f_zs_invoke(Z.dup(v_this), "incdec", ((_t1791 = Z.arrNew()), Z.apush(_t1791, Z.dup(v_e)), _t1791));
  }
  Z.setLine(497);
  if (Z.truthy(Z.ident(v_k, ":Ternary"))) {
    Z.setLine(497);
    return f_zs_invoke(Z.dup(v_this), "ternary", ((_t1792 = Z.arrNew()), Z.apush(_t1792, Z.dup(v_e)), _t1792));
  }
  Z.setLine(498);
  if (Z.truthy(Z.ident(v_k, ":Call"))) {
    Z.setLine(498);
    return f_zs_invoke(Z.dup(v_this), "call", ((_t1793 = Z.arrNew()), Z.apush(_t1793, Z.dup(v_e)), _t1793));
  }
  Z.setLine(499);
  Z.raise(new Z.ZExc(0, Z.concat(Z.concat(Z.concat(Z.concat("emit_llvm: wyrażenie ", v_k), " (linia "), Z.index(v_e, 1)), ")")));
  return null;
}
function f_LlEmitter__shortCircuit(v_this, v_isAnd, v_l, v_r) {
  let v_x = null, v_t = null, v_sl = null, v_lr = null, v_lj = null, v_y = null, v_ty = null;
  let _t1794 = null, _t1795 = null, _t1796 = null, _t1797 = null, _t1798 = null, _t1799 = null, _t1800 = null, _t1801 = null, _t1802 = null, _t1803 = null, _t1804 = null, _t1805 = null, _t1806 = null, _t1807 = null, _t1808 = null, _t1809 = null;
  Z.setLine(503);
  (v_x = f_zs_invoke(Z.dup(v_this), "expr", ((_t1794 = Z.arrNew()), Z.apush(_t1794, Z.dup(v_l)), _t1794)));
  Z.setLine(504);
  (v_t = f_zs_invoke(Z.dup(v_this), "truthy", ((_t1795 = Z.arrNew()), Z.apush(_t1795, Z.dup(v_x)), _t1795)));
  Z.setLine(505);
  (v_sl = f_zs_invoke(Z.dup(v_this), "slot", ((_t1796 = Z.arrNew()), _t1796)));
  Z.setLine(506);
  f_zs_invoke(Z.dup(v_this), "storeTo", ((_t1797 = Z.arrNew()), Z.apush(_t1797, Z.dup(v_sl)), Z.apush(_t1797, f_zs_invoke(Z.dup(v_this), "boolOf", ((_t1798 = Z.arrNew()), Z.apush(_t1798, Z.dup(v_t)), _t1798))), _t1797));
  Z.setLine(507);
  (v_lr = f_zs_invoke(Z.dup(v_this), "newLabel", ((_t1799 = Z.arrNew()), Z.apush(_t1799, "sc"), _t1799)));
  Z.setLine(508);
  (v_lj = f_zs_invoke(Z.dup(v_this), "newLabel", ((_t1800 = Z.arrNew()), Z.apush(_t1800, "scj"), _t1800)));
  Z.setLine(509);
  if (Z.truthy(v_isAnd)) {
    Z.setLine(509);
    f_zs_invoke(Z.dup(v_this), "terminate", ((_t1801 = Z.arrNew()), Z.apush(_t1801, Z.concat(Z.concat(Z.concat(Z.concat(Z.concat("br i1 ", v_t), ", label %"), v_lr), ", label %"), v_lj)), _t1801));
  } else {
    Z.setLine(510);
    f_zs_invoke(Z.dup(v_this), "terminate", ((_t1802 = Z.arrNew()), Z.apush(_t1802, Z.concat(Z.concat(Z.concat(Z.concat(Z.concat("br i1 ", v_t), ", label %"), v_lj), ", label %"), v_lr)), _t1802));
  }
  Z.setLine(511);
  f_zs_invoke(Z.dup(v_this), "label", ((_t1803 = Z.arrNew()), Z.apush(_t1803, Z.dup(v_lr)), _t1803));
  Z.setLine(512);
  (v_y = f_zs_invoke(Z.dup(v_this), "expr", ((_t1804 = Z.arrNew()), Z.apush(_t1804, Z.dup(v_r)), _t1804)));
  Z.setLine(513);
  (v_ty = f_zs_invoke(Z.dup(v_this), "truthy", ((_t1805 = Z.arrNew()), Z.apush(_t1805, Z.dup(v_y)), _t1805)));
  Z.setLine(514);
  f_zs_invoke(Z.dup(v_this), "storeTo", ((_t1806 = Z.arrNew()), Z.apush(_t1806, Z.dup(v_sl)), Z.apush(_t1806, f_zs_invoke(Z.dup(v_this), "boolOf", ((_t1807 = Z.arrNew()), Z.apush(_t1807, Z.dup(v_ty)), _t1807))), _t1806));
  Z.setLine(515);
  f_zs_invoke(Z.dup(v_this), "label", ((_t1808 = Z.arrNew()), Z.apush(_t1808, Z.dup(v_lj)), _t1808));
  Z.setLine(516);
  return f_zs_invoke(Z.dup(v_this), "loadFrom", ((_t1809 = Z.arrNew()), Z.apush(_t1809, Z.dup(v_sl)), _t1809));
  return null;
}
function f_LlEmitter__ternary(v_this, v_e) {
  let v_sl = null, v_lt = null, v_lf = null, v_lj = null, v_c = null, v_t = null, v_a = null, v_b = null;
  let _t1810 = null, _t1811 = null, _t1812 = null, _t1813 = null, _t1814 = null, _t1815 = null, _t1816 = null, _t1817 = null, _t1818 = null, _t1819 = null, _t1820 = null, _t1821 = null, _t1822 = null, _t1823 = null, _t1824 = null, _t1825 = null, _t1826 = null, _t1827 = null, _t1828 = null, _t1829 = null;
  Z.setLine(520);
  (v_sl = f_zs_invoke(Z.dup(v_this), "slot", ((_t1810 = Z.arrNew()), _t1810)));
  Z.setLine(521);
  (v_lt = f_zs_invoke(Z.dup(v_this), "newLabel", ((_t1811 = Z.arrNew()), Z.apush(_t1811, "tt"), _t1811)));
  Z.setLine(522);
  (v_lf = f_zs_invoke(Z.dup(v_this), "newLabel", ((_t1812 = Z.arrNew()), Z.apush(_t1812, "tf"), _t1812)));
  Z.setLine(523);
  (v_lj = f_zs_invoke(Z.dup(v_this), "newLabel", ((_t1813 = Z.arrNew()), Z.apush(_t1813, "tj"), _t1813)));
  Z.setLine(524);
  if (Z.truthy(Z.ident(Z.index(v_e, 3), null))) {
    Z.setLine(525);
    (v_c = f_zs_invoke(Z.dup(v_this), "expr", ((_t1814 = Z.arrNew()), Z.apush(_t1814, Z.dup(Z.index(v_e, 2))), _t1814)));
    Z.setLine(526);
    f_zs_invoke(Z.dup(v_this), "storeTo", ((_t1815 = Z.arrNew()), Z.apush(_t1815, Z.dup(v_sl)), Z.apush(_t1815, Z.dup(v_c)), _t1815));
    Z.setLine(527);
    (v_t = f_zs_invoke(Z.dup(v_this), "truthy", ((_t1816 = Z.arrNew()), Z.apush(_t1816, Z.dup(v_c)), _t1816)));
    Z.setLine(528);
    f_zs_invoke(Z.dup(v_this), "terminate", ((_t1817 = Z.arrNew()), Z.apush(_t1817, Z.concat(Z.concat(Z.concat(Z.concat(Z.concat("br i1 ", v_t), ", label %"), v_lj), ", label %"), v_lf)), _t1817));
  } else {
    Z.setLine(530);
    (v_c = f_zs_invoke(Z.dup(v_this), "expr", ((_t1818 = Z.arrNew()), Z.apush(_t1818, Z.dup(Z.index(v_e, 2))), _t1818)));
    Z.setLine(531);
    (v_t = f_zs_invoke(Z.dup(v_this), "truthy", ((_t1819 = Z.arrNew()), Z.apush(_t1819, Z.dup(v_c)), _t1819)));
    Z.setLine(532);
    f_zs_invoke(Z.dup(v_this), "terminate", ((_t1820 = Z.arrNew()), Z.apush(_t1820, Z.concat(Z.concat(Z.concat(Z.concat(Z.concat("br i1 ", v_t), ", label %"), v_lt), ", label %"), v_lf)), _t1820));
    Z.setLine(533);
    f_zs_invoke(Z.dup(v_this), "label", ((_t1821 = Z.arrNew()), Z.apush(_t1821, Z.dup(v_lt)), _t1821));
    Z.setLine(534);
    (v_a = f_zs_invoke(Z.dup(v_this), "expr", ((_t1822 = Z.arrNew()), Z.apush(_t1822, Z.dup(Z.index(v_e, 3))), _t1822)));
    Z.setLine(535);
    f_zs_invoke(Z.dup(v_this), "storeTo", ((_t1823 = Z.arrNew()), Z.apush(_t1823, Z.dup(v_sl)), Z.apush(_t1823, Z.dup(v_a)), _t1823));
    Z.setLine(536);
    f_zs_invoke(Z.dup(v_this), "terminate", ((_t1824 = Z.arrNew()), Z.apush(_t1824, Z.concat("br label %", v_lj)), _t1824));
  }
  Z.setLine(538);
  f_zs_invoke(Z.dup(v_this), "label", ((_t1825 = Z.arrNew()), Z.apush(_t1825, Z.dup(v_lf)), _t1825));
  Z.setLine(539);
  (v_b = f_zs_invoke(Z.dup(v_this), "expr", ((_t1826 = Z.arrNew()), Z.apush(_t1826, Z.dup(Z.index(v_e, 4))), _t1826)));
  Z.setLine(540);
  f_zs_invoke(Z.dup(v_this), "storeTo", ((_t1827 = Z.arrNew()), Z.apush(_t1827, Z.dup(v_sl)), Z.apush(_t1827, Z.dup(v_b)), _t1827));
  Z.setLine(541);
  f_zs_invoke(Z.dup(v_this), "label", ((_t1828 = Z.arrNew()), Z.apush(_t1828, Z.dup(v_lj)), _t1828));
  Z.setLine(542);
  return f_zs_invoke(Z.dup(v_this), "loadFrom", ((_t1829 = Z.arrNew()), Z.apush(_t1829, Z.dup(v_sl)), _t1829));
  return null;
}
function f_LlEmitter__setLine(v_this, v_n) {
  let _t1830 = null;
  Z.setLine(546);
  f_zs_invoke(Z.dup(v_this), "line", ((_t1830 = Z.arrNew()), Z.apush(_t1830, Z.concat(Z.concat("store i64 ", v_n), ", ptr @zs_line, align 8")), _t1830));
  return null;
}
function f_LlEmitter__block(v_this, v_list) {
  let v_s = null;
  let _t1831 = null;
  Z.setLine(548);
  {
    const _it174 = Z.foreachArr(Z.dup(v_list));
    L174: for (let _i174 = 0; _i174 < _it174.keys.length; _i174++) {
      v_s = _it174.vals[_i174];
      Z.setLine(548);
      f_zs_invoke(Z.dup(v_this), "stmt", ((_t1831 = Z.arrNew()), Z.apush(_t1831, Z.dup(v_s)), _t1831));
    }
  }
  return null;
}
function f_LlEmitter__regionBegin(v_this, v_loop, v_body, v_hdr, v_pre, v_id) {
  let v___r180 = null, v___w181 = null, v_names = null, v_slot = null, v___r182 = null, v___w183 = null, v_d = null, v___r184 = null, v___w185 = null;
  let _t1832 = null, _t1833 = null, _t1834 = null, _t1835 = null;
  Z.setLine(552);
  if (Z.truthy((Z.cmp(Z.B.count(Z.B.zs_obj_get(v_this, "tries")), 0) > 0))) {
    Z.setLine(552);
    (v___r180 = null);
    Z.setLine(552);
    (v___w181 = Z.B.zs_obj_take(v_this, "rdStack"));
    Z.setLine(552);
    Z.apush((v___w181 = Z.wr(v___w181)), Z.dup(v___r180));
    Z.setLine(552);
    Z.B.zs_obj_put(v_this, "rdStack", v___w181);
    Z.setLine(552);
    return null;
  }
  Z.setLine(553);
  (v_names = f_Workspace_regions__region_carry(Z.dup(v_loop), Z.dup(v_body), Z.dup(v_hdr), Z.dup(v_pre), Z.B.zs_obj_get(v_this, "fnCounts")));
  Z.setLine(554);
  (v_slot = Z.concat("%rdslot", v_id));
  Z.setLine(555);
  (v___r182 = Z.concat(Z.concat("  ", v_slot), " = alloca i32, align 4"));
  Z.setLine(555);
  (v___w183 = Z.B.zs_obj_take(v_this, "allocas"));
  Z.setLine(555);
  Z.apush((v___w183 = Z.wr(v___w183)), Z.dup(v___r182));
  Z.setLine(555);
  Z.B.zs_obj_put(v_this, "allocas", v___w183);
  Z.setLine(556);
  (v_d = f_zs_invoke(Z.dup(v_this), "rt", ((_t1832 = Z.arrNew()), Z.apush(_t1832, "zs_cur_depth"), Z.apush(_t1832, "i32"), Z.apush(_t1832, ((_t1833 = Z.arrNew()), _t1833)), _t1832)));
  Z.setLine(557);
  f_zs_invoke(Z.dup(v_this), "line", ((_t1834 = Z.arrNew()), Z.apush(_t1834, Z.concat(Z.concat(Z.concat(Z.concat("store i32 ", v_d), ", ptr "), v_slot), ", align 4")), _t1834));
  Z.setLine(558);
  (v___r184 = ((_t1835 = Z.arrNew()), Z.apush(_t1835, Z.dup(v_slot)), Z.apush(_t1835, Z.dup(v_names)), _t1835));
  Z.setLine(558);
  (v___w185 = Z.B.zs_obj_take(v_this, "rdStack"));
  Z.setLine(558);
  Z.apush((v___w185 = Z.wr(v___w185)), Z.dup(v___r184));
  Z.setLine(558);
  Z.B.zs_obj_put(v_this, "rdStack", v___w185);
  return null;
}
function f_LlEmitter__regionEnter(v_this) {
  let v_r = null;
  let _t1836 = null, _t1837 = null;
  Z.setLine(561);
  (v_r = Z.dup(Z.index(Z.B.zs_obj_get(v_this, "rdStack"), Z.sub(Z.B.count(Z.B.zs_obj_get(v_this, "rdStack")), 1))));
  Z.setLine(562);
  if (Z.truthy(Z.ident(v_r, null))) {
    Z.setLine(562);
    return null;
  }
  Z.setLine(563);
  f_zs_invoke(Z.dup(v_this), "rt", ((_t1836 = Z.arrNew()), Z.apush(_t1836, "zs_enter"), Z.apush(_t1836, "i32"), Z.apush(_t1836, ((_t1837 = Z.arrNew()), _t1837)), _t1836));
  return null;
}
function f_LlEmitter__regionExit(v_this) {
  let v_r = null, v_l = null, v_n = null, v_v = null, v_c = null;
  let _t1838 = null, _t1839 = null, _t1840 = null, _t1841 = null, _t1842 = null, _t1843 = null, _t1844 = null, _t1845 = null, _t1846 = null, _t1847 = null, _t1848 = null, _t1849 = null, _t1850 = null;
  Z.setLine(566);
  (v_r = Z.dup(Z.index(Z.B.zs_obj_get(v_this, "rdStack"), Z.sub(Z.B.count(Z.B.zs_obj_get(v_this, "rdStack")), 1))));
  Z.setLine(567);
  if (Z.truthy(Z.ident(v_r, null))) {
    Z.setLine(567);
    return null;
  }
  Z.setLine(568);
  (v_l = f_zs_invoke(Z.dup(v_this), "r", ((_t1838 = Z.arrNew()), _t1838)));
  Z.setLine(569);
  f_zs_invoke(Z.dup(v_this), "line", ((_t1839 = Z.arrNew()), Z.apush(_t1839, Z.concat(Z.concat(Z.concat(v_l, " = load i32, ptr "), Z.index(v_r, 0)), ", align 4")), _t1839));
  Z.setLine(570);
  {
    const _it175 = Z.foreachArr(Z.dup(Z.index(Z.index(v_r, 1), 0)));
    L175: for (let _i175 = 0; _i175 < _it175.keys.length; _i175++) {
      v_n = _it175.vals[_i175];
      Z.setLine(571);
      (v_v = f_zs_invoke(Z.dup(v_this), "load", ((_t1840 = Z.arrNew()), Z.apush(_t1840, Z.dup(v_n)), _t1840)));
      Z.setLine(572);
      (v_c = f_zs_invoke(Z.dup(v_this), "rt", ((_t1841 = Z.arrNew()), Z.apush(_t1841, "zs_carry_v"), Z.apush(_t1841, "V"), Z.apush(_t1841, ((_t1842 = Z.arrNew()), Z.apush(_t1842, ((_t1843 = Z.arrNew()), Z.apush(_t1843, "V"), Z.apush(_t1843, Z.dup(v_v)), _t1843)), Z.apush(_t1842, ((_t1844 = Z.arrNew()), Z.apush(_t1844, "i32"), Z.apush(_t1844, Z.dup(v_l)), _t1844)), _t1842)), _t1841)));
      Z.setLine(573);
      f_zs_invoke(Z.dup(v_this), "store", ((_t1845 = Z.arrNew()), Z.apush(_t1845, Z.dup(v_n)), Z.apush(_t1845, Z.dup(v_c)), _t1845));
    }
  }
  Z.setLine(575);
  f_zs_invoke(Z.dup(v_this), "rt", ((_t1846 = Z.arrNew()), Z.apush(_t1846, "zs_pop"), Z.apush(_t1846, "void"), Z.apush(_t1846, ((_t1847 = Z.arrNew()), Z.apush(_t1847, ((_t1848 = Z.arrNew()), Z.apush(_t1848, "i32"), Z.apush(_t1848, Z.dup(v_l)), _t1848)), _t1847)), _t1846));
  Z.setLine(576);
  {
    const _it176 = Z.foreachArr(Z.dup(Z.index(Z.index(v_r, 1), 1)));
    L176: for (let _i176 = 0; _i176 < _it176.keys.length; _i176++) {
      v_n = _it176.vals[_i176];
      Z.setLine(576);
      f_zs_invoke(Z.dup(v_this), "store", ((_t1849 = Z.arrNew()), Z.apush(_t1849, Z.dup(v_n)), Z.apush(_t1849, f_zs_invoke(Z.dup(v_this), "nullv", ((_t1850 = Z.arrNew()), _t1850))), _t1849));
    }
  }
  return null;
}
function f_LlEmitter__regionEnd(v_this) {
  Z.setLine(578);
  Z.B.zs_obj_set(v_this, "rdStack", Z.B.array_slice(Z.B.zs_obj_get(v_this, "rdStack"), 0, Z.sub(Z.B.count(Z.B.zs_obj_get(v_this, "rdStack")), 1)));
  return null;
}
function f_LlEmitter__pushLoop(v_this) {
  let v___r186 = null, v___w187 = null;
  let _t1851 = null;
  Z.setLine(580);
  Z.B.zs_obj_set(v_this, "loopId", Z.add(Z.B.zs_obj_get(v_this, "loopId"), 1));
  Z.setLine(580);
  (v___r186 = ((_t1851 = Z.arrNew()), Z.apush(_t1851, Z.B.zs_obj_get(v_this, "loopId")), Z.apush(_t1851, "loop"), Z.apush(_t1851, Z.B.count(Z.B.zs_obj_get(v_this, "tries"))), _t1851));
  Z.setLine(580);
  (v___w187 = Z.B.zs_obj_take(v_this, "loops"));
  Z.setLine(580);
  Z.apush((v___w187 = Z.wr(v___w187)), Z.dup(v___r186));
  Z.setLine(580);
  Z.B.zs_obj_put(v_this, "loops", v___w187);
  Z.setLine(580);
  return Z.B.zs_obj_get(v_this, "loopId");
  return null;
}
function f_LlEmitter__popLoop(v_this) {
  Z.setLine(581);
  Z.B.zs_obj_set(v_this, "loops", Z.B.array_slice(Z.B.zs_obj_get(v_this, "loops"), 0, Z.sub(Z.B.count(Z.B.zs_obj_get(v_this, "loops")), 1)));
  return null;
}
function f_LlEmitter__jumpOut(v_this, v_depth) {
  let v_saved = null, v_i = null, v_e = null;
  let _t1852 = null, _t1853 = null, _t1854 = null, _t1855 = null, _t1856 = null;
  Z.setLine(584);
  (v_saved = Z.B.zs_obj_get(v_this, "tries"));
  Z.setLine(585);
  (v_i = Z.sub(Z.B.count(v_saved), 1));
  L177: for (; Z.truthy((Z.cmp(v_i, v_depth) >= 0)); ((_t1852 = v_i), (v_i = Z.sub(_t1852, 1)), _t1852)) {
    Z.setLine(586);
    (v_e = Z.dup(Z.index(v_saved, v_i)));
    Z.setLine(587);
    f_zs_invoke(Z.dup(v_this), "rt", ((_t1853 = Z.arrNew()), Z.apush(_t1853, "zl_try_leave"), Z.apush(_t1853, "void"), Z.apush(_t1853, ((_t1854 = Z.arrNew()), Z.apush(_t1854, ((_t1855 = Z.arrNew()), Z.apush(_t1855, "ptr"), Z.apush(_t1855, Z.dup(Z.index(v_e, 1))), _t1855)), _t1854)), _t1853));
    Z.setLine(588);
    if (Z.truthy(Z.ident(Z.index(v_e, 0), "finally"))) {
      Z.setLine(589);
      Z.B.zs_obj_set(v_this, "tries", Z.B.array_slice(v_saved, 0, v_i));
      Z.setLine(590);
      f_zs_invoke(Z.dup(v_this), "block", ((_t1856 = Z.arrNew()), Z.apush(_t1856, Z.dup(Z.index(v_e, 2))), _t1856));
    }
  }
  Z.setLine(593);
  Z.B.zs_obj_set(v_this, "tries", v_saved);
  return null;
}
function f_LlEmitter__catchCond(v_this, v_types, v_x) {
  let v_acc = null, v_t = null, v_c = null, v_v = null, v_o = null;
  let _t1857 = null, _t1858 = null, _t1859 = null, _t1860 = null, _t1861 = null, _t1862 = null, _t1863 = null, _t1864 = null;
  Z.setLine(598);
  (v_acc = null);
  Z.setLine(599);
  {
    const _it178 = Z.foreachArr(Z.dup(v_types));
    L178: for (let _i178 = 0; _i178 < _it178.keys.length; _i178++) {
      v_t = _it178.vals[_i178];
      Z.setLine(600);
      if (Z.truthy((Z.truthy(Z.ident(v_t, "Throwable")) || Z.truthy(Z.ident(v_t, "Exception"))))) {
        Z.setLine(600);
        (v_c = "true");
      } else {
        Z.setLine(602);
        (v_v = f_zs_invoke(Z.dup(v_this), "rt", ((_t1857 = Z.arrNew()), Z.apush(_t1857, "zv_exc_is"), Z.apush(_t1857, "i32"), Z.apush(_t1857, ((_t1858 = Z.arrNew()), Z.apush(_t1858, ((_t1859 = Z.arrNew()), Z.apush(_t1859, "V"), Z.apush(_t1859, Z.dup(v_x)), _t1859)), Z.apush(_t1858, ((_t1860 = Z.arrNew()), Z.apush(_t1860, "i32"), Z.apush(_t1860, "1"), _t1860)), _t1858)), _t1857)));
        Z.setLine(603);
        (v_c = f_zs_invoke(Z.dup(v_this), "r", ((_t1861 = Z.arrNew()), _t1861)));
        Z.setLine(604);
        f_zs_invoke(Z.dup(v_this), "line", ((_t1862 = Z.arrNew()), Z.apush(_t1862, Z.concat(Z.concat(Z.concat(v_c, " = icmp ne i32 "), v_v), ", 0")), _t1862));
      }
      Z.setLine(606);
      if (Z.truthy(Z.ident(v_acc, null))) {
        Z.setLine(606);
        (v_acc = Z.dup(v_c));
      } else {
        Z.setLine(608);
        (v_o = f_zs_invoke(Z.dup(v_this), "r", ((_t1863 = Z.arrNew()), _t1863)));
        Z.setLine(609);
        f_zs_invoke(Z.dup(v_this), "line", ((_t1864 = Z.arrNew()), Z.apush(_t1864, Z.concat(Z.concat(Z.concat(Z.concat(v_o, " = or i1 "), v_acc), ", "), v_c)), _t1864));
        Z.setLine(610);
        (v_acc = Z.dup(v_o));
      }
    }
  }
  Z.setLine(613);
  return Z.dup(v_acc);
  return null;
}
function f_LlEmitter__handler(v_this) {
  let v_h = null, v___r188 = null, v___w189 = null;
  Z.setLine(618);
  Z.B.zs_obj_set(v_this, "hid", Z.add(Z.B.zs_obj_get(v_this, "hid"), 1));
  Z.setLine(619);
  (v_h = Z.concat("%h", Z.B.zs_obj_get(v_this, "hid")));
  Z.setLine(620);
  (v___r188 = Z.concat(Z.concat("  ", v_h), " = alloca [512 x i8], align 16"));
  Z.setLine(620);
  (v___w189 = Z.B.zs_obj_take(v_this, "allocas"));
  Z.setLine(620);
  Z.apush((v___w189 = Z.wr(v___w189)), Z.dup(v___r188));
  Z.setLine(620);
  Z.B.zs_obj_put(v_this, "allocas", v___w189);
  Z.setLine(621);
  return Z.dup(v_h);
  return null;
}
function f_LlEmitter__jb(v_this, v_h) {
  let v_p = null;
  let _t1865 = null, _t1866 = null;
  Z.setLine(625);
  (v_p = f_zs_invoke(Z.dup(v_this), "r", ((_t1865 = Z.arrNew()), _t1865)));
  Z.setLine(626);
  f_zs_invoke(Z.dup(v_this), "line", ((_t1866 = Z.arrNew()), Z.apush(_t1866, Z.concat(Z.concat(Z.concat(v_p, " = getelementptr inbounds i8, ptr "), v_h), ", i64 16")), _t1866));
  Z.setLine(627);
  return Z.dup(v_p);
  return null;
}
function f_LlEmitter__tryCatch(v_this, v_body, v_catches) {
  let v_h = null, v_sj = null, v_z = null, v_lb = null, v_lc = null, v_le = null, v___r190 = null, v___w191 = null, v_x = null, v_xs = null, v_c = null, v_xv = null, v_cond = null, v_lm = null, v_ln = null;
  let _t1867 = null, _t1868 = null, _t1869 = null, _t1870 = null, _t1871 = null, _t1872 = null, _t1873 = null, _t1874 = null, _t1875 = null, _t1876 = null, _t1877 = null, _t1878 = null, _t1879 = null, _t1880 = null, _t1881 = null, _t1882 = null, _t1883 = null, _t1884 = null, _t1885 = null, _t1886 = null, _t1887 = null, _t1888 = null, _t1889 = null, _t1890 = null, _t1891 = null, _t1892 = null, _t1893 = null, _t1894 = null, _t1895 = null, _t1896 = null, _t1897 = null, _t1898 = null, _t1899 = null, _t1900 = null, _t1901 = null, _t1902 = null, _t1903 = null, _t1904 = null, _t1905 = null, _t1906 = null, _t1907 = null, _t1908 = null, _t1909 = null, _t1910 = null, _t1911 = null;
  Z.setLine(631);
  (v_h = f_zs_invoke(Z.dup(v_this), "handler", ((_t1867 = Z.arrNew()), _t1867)));
  Z.setLine(632);
  f_zs_invoke(Z.dup(v_this), "rt", ((_t1868 = Z.arrNew()), Z.apush(_t1868, "zl_try_enter"), Z.apush(_t1868, "void"), Z.apush(_t1868, ((_t1869 = Z.arrNew()), Z.apush(_t1869, ((_t1870 = Z.arrNew()), Z.apush(_t1870, "ptr"), Z.apush(_t1870, Z.dup(v_h)), _t1870)), _t1869)), _t1868));
  Z.setLine(633);
  (v_sj = f_zs_invoke(Z.dup(v_this), "r", ((_t1871 = Z.arrNew()), _t1871)));
  Z.setLine(634);
  f_zs_invoke(Z.dup(v_this), "line", ((_t1872 = Z.arrNew()), Z.apush(_t1872, Z.concat(Z.concat(Z.concat(v_sj, " = call i32 @_setjmp(ptr "), f_zs_invoke(Z.dup(v_this), "jb", ((_t1873 = Z.arrNew()), Z.apush(_t1873, Z.dup(v_h)), _t1873))), ") returns_twice")), _t1872));
  Z.setLine(635);
  (v_z = f_zs_invoke(Z.dup(v_this), "r", ((_t1874 = Z.arrNew()), _t1874)));
  Z.setLine(636);
  f_zs_invoke(Z.dup(v_this), "line", ((_t1875 = Z.arrNew()), Z.apush(_t1875, Z.concat(Z.concat(Z.concat(v_z, " = icmp eq i32 "), v_sj), ", 0")), _t1875));
  Z.setLine(637);
  (v_lb = f_zs_invoke(Z.dup(v_this), "newLabel", ((_t1876 = Z.arrNew()), Z.apush(_t1876, "try"), _t1876)));
  Z.setLine(638);
  (v_lc = f_zs_invoke(Z.dup(v_this), "newLabel", ((_t1877 = Z.arrNew()), Z.apush(_t1877, "catch"), _t1877)));
  Z.setLine(639);
  (v_le = f_zs_invoke(Z.dup(v_this), "newLabel", ((_t1878 = Z.arrNew()), Z.apush(_t1878, "tryend"), _t1878)));
  Z.setLine(640);
  f_zs_invoke(Z.dup(v_this), "terminate", ((_t1879 = Z.arrNew()), Z.apush(_t1879, Z.concat(Z.concat(Z.concat(Z.concat(Z.concat("br i1 ", v_z), ", label %"), v_lb), ", label %"), v_lc)), _t1879));
  Z.setLine(641);
  f_zs_invoke(Z.dup(v_this), "label", ((_t1880 = Z.arrNew()), Z.apush(_t1880, Z.dup(v_lb)), _t1880));
  Z.setLine(642);
  (v___r190 = ((_t1881 = Z.arrNew()), Z.apush(_t1881, "catch"), Z.apush(_t1881, Z.dup(v_h)), Z.apush(_t1881, null), _t1881));
  Z.setLine(642);
  (v___w191 = Z.B.zs_obj_take(v_this, "tries"));
  Z.setLine(642);
  Z.apush((v___w191 = Z.wr(v___w191)), Z.dup(v___r190));
  Z.setLine(642);
  Z.B.zs_obj_put(v_this, "tries", v___w191);
  Z.setLine(643);
  f_zs_invoke(Z.dup(v_this), "block", ((_t1882 = Z.arrNew()), Z.apush(_t1882, Z.dup(v_body)), _t1882));
  Z.setLine(644);
  Z.B.zs_obj_set(v_this, "tries", Z.B.array_slice(Z.B.zs_obj_get(v_this, "tries"), 0, Z.sub(Z.B.count(Z.B.zs_obj_get(v_this, "tries")), 1)));
  Z.setLine(645);
  f_zs_invoke(Z.dup(v_this), "rt", ((_t1883 = Z.arrNew()), Z.apush(_t1883, "zl_try_leave"), Z.apush(_t1883, "void"), Z.apush(_t1883, ((_t1884 = Z.arrNew()), Z.apush(_t1884, ((_t1885 = Z.arrNew()), Z.apush(_t1885, "ptr"), Z.apush(_t1885, Z.dup(v_h)), _t1885)), _t1884)), _t1883));
  Z.setLine(646);
  f_zs_invoke(Z.dup(v_this), "terminate", ((_t1886 = Z.arrNew()), Z.apush(_t1886, Z.concat("br label %", v_le)), _t1886));
  Z.setLine(647);
  f_zs_invoke(Z.dup(v_this), "label", ((_t1887 = Z.arrNew()), Z.apush(_t1887, Z.dup(v_lc)), _t1887));
  Z.setLine(648);
  f_zs_invoke(Z.dup(v_this), "rt", ((_t1888 = Z.arrNew()), Z.apush(_t1888, "zl_try_leave"), Z.apush(_t1888, "void"), Z.apush(_t1888, ((_t1889 = Z.arrNew()), Z.apush(_t1889, ((_t1890 = Z.arrNew()), Z.apush(_t1890, "ptr"), Z.apush(_t1890, Z.dup(v_h)), _t1890)), _t1889)), _t1888));
  Z.setLine(649);
  (v_x = f_zs_invoke(Z.dup(v_this), "rt", ((_t1891 = Z.arrNew()), Z.apush(_t1891, "zl_cur_exc"), Z.apush(_t1891, "V"), Z.apush(_t1891, ((_t1892 = Z.arrNew()), _t1892)), _t1891)));
  Z.setLine(650);
  (v_xs = f_zs_invoke(Z.dup(v_this), "slot", ((_t1893 = Z.arrNew()), _t1893)));
  Z.setLine(651);
  f_zs_invoke(Z.dup(v_this), "storeTo", ((_t1894 = Z.arrNew()), Z.apush(_t1894, Z.dup(v_xs)), Z.apush(_t1894, Z.dup(v_x)), _t1894));
  Z.setLine(652);
  {
    const _it179 = Z.foreachArr(Z.dup(v_catches));
    L179: for (let _i179 = 0; _i179 < _it179.keys.length; _i179++) {
      v_c = _it179.vals[_i179];
      Z.setLine(653);
      (v_xv = f_zs_invoke(Z.dup(v_this), "loadFrom", ((_t1895 = Z.arrNew()), Z.apush(_t1895, Z.dup(v_xs)), _t1895)));
      Z.setLine(654);
      (v_cond = f_zs_invoke(Z.dup(v_this), "catchCond", ((_t1896 = Z.arrNew()), Z.apush(_t1896, Z.dup(Z.index(v_c, 2))), Z.apush(_t1896, Z.dup(v_xv)), _t1896)));
      Z.setLine(655);
      (v_lm = f_zs_invoke(Z.dup(v_this), "newLabel", ((_t1897 = Z.arrNew()), Z.apush(_t1897, "cmatch"), _t1897)));
      Z.setLine(656);
      (v_ln = f_zs_invoke(Z.dup(v_this), "newLabel", ((_t1898 = Z.arrNew()), Z.apush(_t1898, "cnext"), _t1898)));
      Z.setLine(657);
      f_zs_invoke(Z.dup(v_this), "terminate", ((_t1899 = Z.arrNew()), Z.apush(_t1899, Z.concat(Z.concat(Z.concat(Z.concat(Z.concat("br i1 ", v_cond), ", label %"), v_lm), ", label %"), v_ln)), _t1899));
      Z.setLine(658);
      f_zs_invoke(Z.dup(v_this), "label", ((_t1900 = Z.arrNew()), Z.apush(_t1900, Z.dup(v_lm)), _t1900));
      Z.setLine(659);
      if (Z.truthy(!Z.ident(Z.index(v_c, 3), null))) {
        Z.setLine(659);
        f_zs_invoke(Z.dup(v_this), "store", ((_t1901 = Z.arrNew()), Z.apush(_t1901, Z.dup(Z.index(v_c, 3))), Z.apush(_t1901, f_zs_invoke(Z.dup(v_this), "loadFrom", ((_t1902 = Z.arrNew()), Z.apush(_t1902, Z.dup(v_xs)), _t1902))), _t1901));
      }
      Z.setLine(660);
      f_zs_invoke(Z.dup(v_this), "block", ((_t1903 = Z.arrNew()), Z.apush(_t1903, Z.dup(Z.index(v_c, 4))), _t1903));
      Z.setLine(661);
      f_zs_invoke(Z.dup(v_this), "terminate", ((_t1904 = Z.arrNew()), Z.apush(_t1904, Z.concat("br label %", v_le)), _t1904));
      Z.setLine(662);
      f_zs_invoke(Z.dup(v_this), "label", ((_t1905 = Z.arrNew()), Z.apush(_t1905, Z.dup(v_ln)), _t1905));
    }
  }
  Z.setLine(664);
  f_zs_invoke(Z.dup(v_this), "rt", ((_t1906 = Z.arrNew()), Z.apush(_t1906, "zs_reraise"), Z.apush(_t1906, "void"), Z.apush(_t1906, ((_t1907 = Z.arrNew()), Z.apush(_t1907, ((_t1908 = Z.arrNew()), Z.apush(_t1908, "V"), Z.apush(_t1908, f_zs_invoke(Z.dup(v_this), "loadFrom", ((_t1909 = Z.arrNew()), Z.apush(_t1909, Z.dup(v_xs)), _t1909))), _t1908)), _t1907)), _t1906));
  Z.setLine(665);
  f_zs_invoke(Z.dup(v_this), "terminate", ((_t1910 = Z.arrNew()), Z.apush(_t1910, "unreachable"), _t1910));
  Z.setLine(666);
  f_zs_invoke(Z.dup(v_this), "label", ((_t1911 = Z.arrNew()), Z.apush(_t1911, Z.dup(v_le)), _t1911));
  return null;
}
function f_LlEmitter__tryStmt(v_this, v_s) {
  let v_body = null, v_catches = null, v_fin = null, v_h = null, v_pend = null, v_exc = null, v_sj = null, v_z = null, v_lb = null, v_lc = null, v_lf = null, v___r192 = null, v___w193 = null, v_p = null, v_pt = null, v_pc = null, v_lr = null, v_ld = null;
  let _t1912 = null, _t1913 = null, _t1914 = null, _t1915 = null, _t1916 = null, _t1917 = null, _t1918 = null, _t1919 = null, _t1920 = null, _t1921 = null, _t1922 = null, _t1923 = null, _t1924 = null, _t1925 = null, _t1926 = null, _t1927 = null, _t1928 = null, _t1929 = null, _t1930 = null, _t1931 = null, _t1932 = null, _t1933 = null, _t1934 = null, _t1935 = null, _t1936 = null, _t1937 = null, _t1938 = null, _t1939 = null, _t1940 = null, _t1941 = null, _t1942 = null, _t1943 = null, _t1944 = null, _t1945 = null, _t1946 = null, _t1947 = null, _t1948 = null, _t1949 = null, _t1950 = null, _t1951 = null, _t1952 = null, _t1953 = null, _t1954 = null, _t1955 = null, _t1956 = null, _t1957 = null, _t1958 = null, _t1959 = null, _t1960 = null, _t1961 = null, _t1962 = null, _t1963 = null, _t1964 = null, _t1965 = null;
  Z.setLine(670);
  (v_body = Z.dup(Z.index(v_s, 2)));
  Z.setLine(671);
  (v_catches = Z.dup(Z.index(v_s, 3)));
  Z.setLine(672);
  (v_fin = Z.dup(Z.index(v_s, 4)));
  Z.setLine(673);
  if (Z.truthy(Z.ident(v_fin, null))) {
    Z.setLine(673);
    f_zs_invoke(Z.dup(v_this), "tryCatch", ((_t1912 = Z.arrNew()), Z.apush(_t1912, Z.dup(v_body)), Z.apush(_t1912, Z.dup(v_catches)), _t1912));
    Z.setLine(673);
    return null;
  }
  Z.setLine(674);
  (v_h = f_zs_invoke(Z.dup(v_this), "handler", ((_t1913 = Z.arrNew()), _t1913)));
  Z.setLine(675);
  (v_pend = f_zs_invoke(Z.dup(v_this), "slot", ((_t1914 = Z.arrNew()), _t1914)));
  Z.setLine(676);
  (v_exc = f_zs_invoke(Z.dup(v_this), "slot", ((_t1915 = Z.arrNew()), _t1915)));
  Z.setLine(677);
  f_zs_invoke(Z.dup(v_this), "storeTo", ((_t1916 = Z.arrNew()), Z.apush(_t1916, Z.dup(v_pend)), Z.apush(_t1916, f_zs_invoke(Z.dup(v_this), "mkv", ((_t1917 = Z.arrNew()), Z.apush(_t1917, 2), Z.apush(_t1917, "0"), _t1917))), _t1916));
  Z.setLine(678);
  f_zs_invoke(Z.dup(v_this), "storeTo", ((_t1918 = Z.arrNew()), Z.apush(_t1918, Z.dup(v_exc)), Z.apush(_t1918, f_zs_invoke(Z.dup(v_this), "nullv", ((_t1919 = Z.arrNew()), _t1919))), _t1918));
  Z.setLine(679);
  f_zs_invoke(Z.dup(v_this), "rt", ((_t1920 = Z.arrNew()), Z.apush(_t1920, "zl_try_enter"), Z.apush(_t1920, "void"), Z.apush(_t1920, ((_t1921 = Z.arrNew()), Z.apush(_t1921, ((_t1922 = Z.arrNew()), Z.apush(_t1922, "ptr"), Z.apush(_t1922, Z.dup(v_h)), _t1922)), _t1921)), _t1920));
  Z.setLine(680);
  (v_sj = f_zs_invoke(Z.dup(v_this), "r", ((_t1923 = Z.arrNew()), _t1923)));
  Z.setLine(681);
  f_zs_invoke(Z.dup(v_this), "line", ((_t1924 = Z.arrNew()), Z.apush(_t1924, Z.concat(Z.concat(Z.concat(v_sj, " = call i32 @_setjmp(ptr "), f_zs_invoke(Z.dup(v_this), "jb", ((_t1925 = Z.arrNew()), Z.apush(_t1925, Z.dup(v_h)), _t1925))), ") returns_twice")), _t1924));
  Z.setLine(682);
  (v_z = f_zs_invoke(Z.dup(v_this), "r", ((_t1926 = Z.arrNew()), _t1926)));
  Z.setLine(683);
  f_zs_invoke(Z.dup(v_this), "line", ((_t1927 = Z.arrNew()), Z.apush(_t1927, Z.concat(Z.concat(Z.concat(v_z, " = icmp eq i32 "), v_sj), ", 0")), _t1927));
  Z.setLine(684);
  (v_lb = f_zs_invoke(Z.dup(v_this), "newLabel", ((_t1928 = Z.arrNew()), Z.apush(_t1928, "fbody"), _t1928)));
  Z.setLine(685);
  (v_lc = f_zs_invoke(Z.dup(v_this), "newLabel", ((_t1929 = Z.arrNew()), Z.apush(_t1929, "fexc"), _t1929)));
  Z.setLine(686);
  (v_lf = f_zs_invoke(Z.dup(v_this), "newLabel", ((_t1930 = Z.arrNew()), Z.apush(_t1930, "ffin"), _t1930)));
  Z.setLine(687);
  f_zs_invoke(Z.dup(v_this), "terminate", ((_t1931 = Z.arrNew()), Z.apush(_t1931, Z.concat(Z.concat(Z.concat(Z.concat(Z.concat("br i1 ", v_z), ", label %"), v_lb), ", label %"), v_lc)), _t1931));
  Z.setLine(688);
  f_zs_invoke(Z.dup(v_this), "label", ((_t1932 = Z.arrNew()), Z.apush(_t1932, Z.dup(v_lb)), _t1932));
  Z.setLine(689);
  (v___r192 = ((_t1933 = Z.arrNew()), Z.apush(_t1933, "finally"), Z.apush(_t1933, Z.dup(v_h)), Z.apush(_t1933, Z.dup(v_fin)), _t1933));
  Z.setLine(689);
  (v___w193 = Z.B.zs_obj_take(v_this, "tries"));
  Z.setLine(689);
  Z.apush((v___w193 = Z.wr(v___w193)), Z.dup(v___r192));
  Z.setLine(689);
  Z.B.zs_obj_put(v_this, "tries", v___w193);
  Z.setLine(690);
  if (Z.truthy((Z.cmp(Z.B.count(v_catches), 0) > 0))) {
    Z.setLine(690);
    f_zs_invoke(Z.dup(v_this), "tryCatch", ((_t1934 = Z.arrNew()), Z.apush(_t1934, Z.dup(v_body)), Z.apush(_t1934, Z.dup(v_catches)), _t1934));
  } else {
    Z.setLine(690);
    f_zs_invoke(Z.dup(v_this), "block", ((_t1935 = Z.arrNew()), Z.apush(_t1935, Z.dup(v_body)), _t1935));
  }
  Z.setLine(691);
  Z.B.zs_obj_set(v_this, "tries", Z.B.array_slice(Z.B.zs_obj_get(v_this, "tries"), 0, Z.sub(Z.B.count(Z.B.zs_obj_get(v_this, "tries")), 1)));
  Z.setLine(692);
  f_zs_invoke(Z.dup(v_this), "rt", ((_t1936 = Z.arrNew()), Z.apush(_t1936, "zl_try_leave"), Z.apush(_t1936, "void"), Z.apush(_t1936, ((_t1937 = Z.arrNew()), Z.apush(_t1937, ((_t1938 = Z.arrNew()), Z.apush(_t1938, "ptr"), Z.apush(_t1938, Z.dup(v_h)), _t1938)), _t1937)), _t1936));
  Z.setLine(693);
  f_zs_invoke(Z.dup(v_this), "terminate", ((_t1939 = Z.arrNew()), Z.apush(_t1939, Z.concat("br label %", v_lf)), _t1939));
  Z.setLine(694);
  f_zs_invoke(Z.dup(v_this), "label", ((_t1940 = Z.arrNew()), Z.apush(_t1940, Z.dup(v_lc)), _t1940));
  Z.setLine(695);
  f_zs_invoke(Z.dup(v_this), "rt", ((_t1941 = Z.arrNew()), Z.apush(_t1941, "zl_try_leave"), Z.apush(_t1941, "void"), Z.apush(_t1941, ((_t1942 = Z.arrNew()), Z.apush(_t1942, ((_t1943 = Z.arrNew()), Z.apush(_t1943, "ptr"), Z.apush(_t1943, Z.dup(v_h)), _t1943)), _t1942)), _t1941));
  Z.setLine(696);
  f_zs_invoke(Z.dup(v_this), "storeTo", ((_t1944 = Z.arrNew()), Z.apush(_t1944, Z.dup(v_exc)), Z.apush(_t1944, f_zs_invoke(Z.dup(v_this), "rt", ((_t1945 = Z.arrNew()), Z.apush(_t1945, "zl_cur_exc"), Z.apush(_t1945, "V"), Z.apush(_t1945, ((_t1946 = Z.arrNew()), _t1946)), _t1945))), _t1944));
  Z.setLine(697);
  f_zs_invoke(Z.dup(v_this), "storeTo", ((_t1947 = Z.arrNew()), Z.apush(_t1947, Z.dup(v_pend)), Z.apush(_t1947, f_zs_invoke(Z.dup(v_this), "mkv", ((_t1948 = Z.arrNew()), Z.apush(_t1948, 2), Z.apush(_t1948, "1"), _t1948))), _t1947));
  Z.setLine(698);
  f_zs_invoke(Z.dup(v_this), "label", ((_t1949 = Z.arrNew()), Z.apush(_t1949, Z.dup(v_lf)), _t1949));
  Z.setLine(699);
  f_zs_invoke(Z.dup(v_this), "block", ((_t1950 = Z.arrNew()), Z.apush(_t1950, Z.dup(v_fin)), _t1950));
  Z.setLine(700);
  (v_p = f_zs_invoke(Z.dup(v_this), "loadFrom", ((_t1951 = Z.arrNew()), Z.apush(_t1951, Z.dup(v_pend)), _t1951)));
  Z.setLine(701);
  (v_pt = f_zs_invoke(Z.dup(v_this), "r", ((_t1952 = Z.arrNew()), _t1952)));
  Z.setLine(702);
  f_zs_invoke(Z.dup(v_this), "line", ((_t1953 = Z.arrNew()), Z.apush(_t1953, Z.concat(Z.concat(Z.concat(v_pt, " = extractvalue { i64, i64 } "), v_p), ", 1")), _t1953));
  Z.setLine(703);
  (v_pc = f_zs_invoke(Z.dup(v_this), "r", ((_t1954 = Z.arrNew()), _t1954)));
  Z.setLine(704);
  f_zs_invoke(Z.dup(v_this), "line", ((_t1955 = Z.arrNew()), Z.apush(_t1955, Z.concat(Z.concat(Z.concat(v_pc, " = icmp ne i64 "), v_pt), ", 0")), _t1955));
  Z.setLine(705);
  (v_lr = f_zs_invoke(Z.dup(v_this), "newLabel", ((_t1956 = Z.arrNew()), Z.apush(_t1956, "frethrow"), _t1956)));
  Z.setLine(706);
  (v_ld = f_zs_invoke(Z.dup(v_this), "newLabel", ((_t1957 = Z.arrNew()), Z.apush(_t1957, "fdone"), _t1957)));
  Z.setLine(707);
  f_zs_invoke(Z.dup(v_this), "terminate", ((_t1958 = Z.arrNew()), Z.apush(_t1958, Z.concat(Z.concat(Z.concat(Z.concat(Z.concat("br i1 ", v_pc), ", label %"), v_lr), ", label %"), v_ld)), _t1958));
  Z.setLine(708);
  f_zs_invoke(Z.dup(v_this), "label", ((_t1959 = Z.arrNew()), Z.apush(_t1959, Z.dup(v_lr)), _t1959));
  Z.setLine(709);
  f_zs_invoke(Z.dup(v_this), "rt", ((_t1960 = Z.arrNew()), Z.apush(_t1960, "zs_reraise"), Z.apush(_t1960, "void"), Z.apush(_t1960, ((_t1961 = Z.arrNew()), Z.apush(_t1961, ((_t1962 = Z.arrNew()), Z.apush(_t1962, "V"), Z.apush(_t1962, f_zs_invoke(Z.dup(v_this), "loadFrom", ((_t1963 = Z.arrNew()), Z.apush(_t1963, Z.dup(v_exc)), _t1963))), _t1962)), _t1961)), _t1960));
  Z.setLine(710);
  f_zs_invoke(Z.dup(v_this), "terminate", ((_t1964 = Z.arrNew()), Z.apush(_t1964, "unreachable"), _t1964));
  Z.setLine(711);
  f_zs_invoke(Z.dup(v_this), "label", ((_t1965 = Z.arrNew()), Z.apush(_t1965, Z.dup(v_ld)), _t1965));
  return null;
}
function f_LlEmitter__chkType(v_this, v_types, v_v, v_what) {
  let _t1966 = null, _t1967 = null, _t1968 = null, _t1969 = null, _t1970 = null, _t1971 = null, _t1972 = null, _t1973 = null;
  Z.setLine(715);
  if (Z.truthy((Z.truthy(Z.ident(Z.B.count(v_types), 1)) && Z.truthy(Z.B.in_array(Z.index(v_types, 0), ((_t1966 = Z.arrNew()), Z.apush(_t1966, "int"), Z.apush(_t1966, "float"), Z.apush(_t1966, "string"), Z.apush(_t1966, "bool"), Z.apush(_t1966, "array"), _t1966)))))) {
    Z.setLine(716);
    return f_zs_invoke(Z.dup(v_this), "rt", ((_t1967 = Z.arrNew()), Z.apush(_t1967, "zv_chk"), Z.apush(_t1967, "V"), Z.apush(_t1967, ((_t1968 = Z.arrNew()), Z.apush(_t1968, ((_t1969 = Z.arrNew()), Z.apush(_t1969, "V"), Z.apush(_t1969, Z.dup(v_v)), _t1969)), Z.apush(_t1968, ((_t1970 = Z.arrNew()), Z.apush(_t1970, "ptr"), Z.apush(_t1970, f_zs_invoke(Z.dup(v_this), "cstr", ((_t1971 = Z.arrNew()), Z.apush(_t1971, Z.dup(Z.index(v_types, 0))), _t1971))), _t1970)), Z.apush(_t1968, ((_t1972 = Z.arrNew()), Z.apush(_t1972, "ptr"), Z.apush(_t1972, f_zs_invoke(Z.dup(v_this), "cstr", ((_t1973 = Z.arrNew()), Z.apush(_t1973, Z.dup(v_what)), _t1973))), _t1972)), _t1968)), _t1967));
  }
  Z.setLine(718);
  return Z.dup(v_v);
  return null;
}
function f_LlEmitter__stmt(v_this, v_s) {
  let v_k = null, v_line = null, v_vals = null, v_e = null, v_first = null, v_x = null, v_c = null, v_lt = null, v_le = null, v_lj = null, v_id = null, v_lc = null, v_lb = null, v_lbody = null, v_ltop = null, v_ltest = null, v_lstep = null, v_hdr = null, v_it = null, v_itSlot = null, v_tg = null, v_isArr = null, v_lok = null, v_lbad = null, v_n = null, v_iSlot = null, v___r194 = null, v___w195 = null, v_lhead = null, v_i = null, v_cnd = null, v_cur = null, v_v = null, v_kv = null, v_i2 = null, v_i3 = null, v_sv = null, v_svSlot = null, v_labels = null, v_def = null, v_cv = null, v_eq = null, v_p = null, v_lnext = null, v_ret = null, v_rv = null, v_lv = null, v_lp = null, v_msg = null, v_ex = null, v_tv = null;
  let _t1974 = null, _t1975 = null, _t1976 = null, _t1977 = null, _t1978 = null, _t1979 = null, _t1980 = null, _t1981 = null, _t1982 = null, _t1983 = null, _t1984 = null, _t1985 = null, _t1986 = null, _t1987 = null, _t1988 = null, _t1989 = null, _t1990 = null, _t1991 = null, _t1992 = null, _t1993 = null, _t1994 = null, _t1995 = null, _t1996 = null, _t1997 = null, _t1998 = null, _t1999 = null, _t2000 = null, _t2001 = null, _t2002 = null, _t2003 = null, _t2004 = null, _t2005 = null, _t2006 = null, _t2007 = null, _t2008 = null, _t2009 = null, _t2010 = null, _t2011 = null, _t2012 = null, _t2013 = null, _t2014 = null, _t2015 = null, _t2016 = null, _t2017 = null, _t2018 = null, _t2019 = null, _t2020 = null, _t2021 = null, _t2022 = null, _t2023 = null, _t2024 = null, _t2025 = null, _t2026 = null, _t2027 = null, _t2028 = null, _t2029 = null, _t2030 = null, _t2031 = null, _t2032 = null, _t2033 = null, _t2034 = null, _t2035 = null, _t2036 = null, _t2037 = null, _t2038 = null, _t2039 = null, _t2040 = null, _t2041 = null, _t2042 = null, _t2043 = null, _t2044 = null, _t2045 = null, _t2046 = null, _t2047 = null, _t2048 = null, _t2049 = null, _t2050 = null, _t2051 = null, _t2052 = null, _t2053 = null, _t2054 = null, _t2055 = null, _t2056 = null, _t2057 = null, _t2058 = null, _t2059 = null, _t2060 = null, _t2061 = null, _t2062 = null, _t2063 = null, _t2064 = null, _t2065 = null, _t2066 = null, _t2067 = null, _t2068 = null, _t2069 = null, _t2070 = null, _t2071 = null, _t2072 = null, _t2073 = null, _t2074 = null, _t2075 = null, _t2076 = null, _t2077 = null, _t2078 = null, _t2079 = null, _t2080 = null, _t2081 = null, _t2082 = null, _t2083 = null, _t2084 = null, _t2085 = null, _t2086 = null, _t2087 = null, _t2088 = null, _t2089 = null, _t2090 = null, _t2091 = null, _t2092 = null, _t2093 = null, _t2094 = null, _t2095 = null, _t2096 = null, _t2097 = null, _t2098 = null, _t2099 = null, _t2100 = null, _t2101 = null, _t2102 = null, _t2103 = null, _t2104 = null, _t2105 = null, _t2106 = null, _t2107 = null, _t2108 = null, _t2109 = null, _t2110 = null, _t2111 = null, _t2112 = null, _t2113 = null, _t2114 = null, _t2115 = null, _t2116 = null, _t2117 = null, _t2118 = null, _t2119 = null, _t2120 = null, _t2121 = null, _t2122 = null, _t2123 = null, _t2124 = null, _t2125 = null, _t2126 = null, _t2127 = null, _t2128 = null, _t2129 = null, _t2130 = null, _t2131 = null, _t2132 = null, _t2133 = null, _t2134 = null, _t2135 = null, _t2136 = null, _t2137 = null, _t2138 = null, _t2139 = null, _t2140 = null, _t2141 = null, _t2142 = null, _t2143 = null, _t2144 = null, _t2145 = null, _t2146 = null, _t2147 = null, _t2148 = null, _t2149 = null, _t2150 = null, _t2151 = null, _t2152 = null, _t2153 = null, _t2154 = null, _t2155 = null, _t2156 = null, _t2157 = null, _t2158 = null, _t2159 = null, _t2160 = null, _t2161 = null, _t2162 = null, _t2163 = null, _t2164 = null, _t2165 = null, _t2166 = null, _t2167 = null, _t2168 = null, _t2169 = null, _t2170 = null, _t2171 = null, _t2172 = null, _t2173 = null, _t2174 = null, _t2175 = null, _t2176 = null, _t2177 = null, _t2178 = null, _t2179 = null, _t2180 = null, _t2181 = null, _t2182 = null;
  Z.setLine(722);
  (v_k = Z.dup(Z.index(v_s, 0)));
  Z.setLine(723);
  (v_line = Z.dup(Z.index(v_s, 1)));
  Z.setLine(724);
  if (Z.truthy(Z.ident(v_k, ":Expr"))) {
    Z.setLine(724);
    f_zs_invoke(Z.dup(v_this), "setLine", ((_t1974 = Z.arrNew()), Z.apush(_t1974, Z.dup(v_line)), _t1974));
    Z.setLine(724);
    f_zs_invoke(Z.dup(v_this), "expr", ((_t1975 = Z.arrNew()), Z.apush(_t1975, Z.dup(Z.index(v_s, 2))), _t1975));
    Z.setLine(724);
    return null;
  }
  Z.setLine(725);
  if (Z.truthy(Z.ident(v_k, ":Echo"))) {
    Z.setLine(726);
    f_zs_invoke(Z.dup(v_this), "setLine", ((_t1976 = Z.arrNew()), Z.apush(_t1976, Z.dup(v_line)), _t1976));
    Z.setLine(727);
    (v_vals = ((_t1977 = Z.arrNew()), _t1977));
    Z.setLine(728);
    {
      const _it180 = Z.foreachArr(Z.dup(Z.index(v_s, 2)));
      L180: for (let _i180 = 0; _i180 < _it180.keys.length; _i180++) {
        v_e = _it180.vals[_i180];
        Z.setLine(728);
        Z.apush((v_vals = Z.wr(v_vals)), f_zs_invoke(Z.dup(v_this), "expr", ((_t1978 = Z.arrNew()), Z.apush(_t1978, Z.dup(v_e)), _t1978)));
      }
    }
    Z.setLine(729);
    (v_first = 1);
    Z.setLine(730);
    {
      const _it181 = Z.foreachArr(Z.dup(v_vals));
      L181: for (let _i181 = 0; _i181 < _it181.keys.length; _i181++) {
        v_x = _it181.vals[_i181];
        Z.setLine(730);
        f_zs_invoke(Z.dup(v_this), "rt", ((_t1979 = Z.arrNew()), Z.apush(_t1979, "zs_echo_v"), Z.apush(_t1979, "void"), Z.apush(_t1979, ((_t1980 = Z.arrNew()), Z.apush(_t1980, ((_t1981 = Z.arrNew()), Z.apush(_t1981, "V"), Z.apush(_t1981, Z.dup(v_x)), _t1981)), Z.apush(_t1980, ((_t1982 = Z.arrNew()), Z.apush(_t1982, "i32"), Z.apush(_t1982, Z.concat("", v_first)), _t1982)), _t1980)), _t1979));
        Z.setLine(730);
        (v_first = 0);
      }
    }
    Z.setLine(731);
    f_zs_invoke(Z.dup(v_this), "rt", ((_t1983 = Z.arrNew()), Z.apush(_t1983, "zs_echo_end"), Z.apush(_t1983, "void"), Z.apush(_t1983, ((_t1984 = Z.arrNew()), _t1984)), _t1983));
    Z.setLine(732);
    return null;
  }
  Z.setLine(734);
  if (Z.truthy(Z.ident(v_k, ":Block"))) {
    Z.setLine(734);
    f_zs_invoke(Z.dup(v_this), "block", ((_t1985 = Z.arrNew()), Z.apush(_t1985, Z.dup(Z.index(v_s, 2))), _t1985));
    Z.setLine(734);
    return null;
  }
  Z.setLine(735);
  if (Z.truthy(Z.ident(v_k, ":If"))) {
    Z.setLine(736);
    f_zs_invoke(Z.dup(v_this), "setLine", ((_t1986 = Z.arrNew()), Z.apush(_t1986, Z.dup(v_line)), _t1986));
    Z.setLine(737);
    (v_c = f_zs_invoke(Z.dup(v_this), "truthy", ((_t1987 = Z.arrNew()), Z.apush(_t1987, f_zs_invoke(Z.dup(v_this), "expr", ((_t1988 = Z.arrNew()), Z.apush(_t1988, Z.dup(Z.index(v_s, 2))), _t1988))), _t1987)));
    Z.setLine(738);
    (v_lt = f_zs_invoke(Z.dup(v_this), "newLabel", ((_t1989 = Z.arrNew()), Z.apush(_t1989, "then"), _t1989)));
    Z.setLine(739);
    (v_le = f_zs_invoke(Z.dup(v_this), "newLabel", ((_t1990 = Z.arrNew()), Z.apush(_t1990, "else"), _t1990)));
    Z.setLine(740);
    (v_lj = f_zs_invoke(Z.dup(v_this), "newLabel", ((_t1991 = Z.arrNew()), Z.apush(_t1991, "endif"), _t1991)));
    Z.setLine(741);
    f_zs_invoke(Z.dup(v_this), "terminate", ((_t1992 = Z.arrNew()), Z.apush(_t1992, Z.concat(Z.concat(Z.concat(Z.concat(Z.concat("br i1 ", v_c), ", label %"), v_lt), ", label %"), (Z.truthy(!Z.ident(Z.index(v_s, 4), null)) ? v_le : v_lj))), _t1992));
    Z.setLine(742);
    f_zs_invoke(Z.dup(v_this), "label", ((_t1993 = Z.arrNew()), Z.apush(_t1993, Z.dup(v_lt)), _t1993));
    Z.setLine(743);
    f_zs_invoke(Z.dup(v_this), "block", ((_t1994 = Z.arrNew()), Z.apush(_t1994, Z.dup(Z.index(v_s, 3))), _t1994));
    Z.setLine(744);
    f_zs_invoke(Z.dup(v_this), "terminate", ((_t1995 = Z.arrNew()), Z.apush(_t1995, Z.concat("br label %", v_lj)), _t1995));
    Z.setLine(745);
    if (Z.truthy(!Z.ident(Z.index(v_s, 4), null))) {
      Z.setLine(746);
      f_zs_invoke(Z.dup(v_this), "label", ((_t1996 = Z.arrNew()), Z.apush(_t1996, Z.dup(v_le)), _t1996));
      Z.setLine(747);
      f_zs_invoke(Z.dup(v_this), "block", ((_t1997 = Z.arrNew()), Z.apush(_t1997, Z.dup(Z.index(v_s, 4))), _t1997));
      Z.setLine(748);
      f_zs_invoke(Z.dup(v_this), "terminate", ((_t1998 = Z.arrNew()), Z.apush(_t1998, Z.concat("br label %", v_lj)), _t1998));
    }
    Z.setLine(750);
    f_zs_invoke(Z.dup(v_this), "label", ((_t1999 = Z.arrNew()), Z.apush(_t1999, Z.dup(v_lj)), _t1999));
    Z.setLine(751);
    return null;
  }
  Z.setLine(753);
  if (Z.truthy(Z.ident(v_k, ":While"))) {
    Z.setLine(754);
    (v_id = f_zs_invoke(Z.dup(v_this), "pushLoop", ((_t2000 = Z.arrNew()), _t2000)));
    Z.setLine(755);
    (v_lc = Z.concat("cont_", v_id));
    Z.setLine(756);
    (v_lb = Z.concat("brk_", v_id));
    Z.setLine(757);
    (v_lbody = f_zs_invoke(Z.dup(v_this), "newLabel", ((_t2001 = Z.arrNew()), Z.apush(_t2001, "wbody"), _t2001)));
    Z.setLine(758);
    f_zs_invoke(Z.dup(v_this), "regionBegin", ((_t2002 = Z.arrNew()), Z.apush(_t2002, Z.dup(v_s)), Z.apush(_t2002, Z.dup(Z.index(v_s, 3))), Z.apush(_t2002, ((_t2003 = Z.arrNew()), Z.apush(_t2003, Z.dup(Z.index(v_s, 2))), _t2003)), Z.apush(_t2002, ((_t2004 = Z.arrNew()), _t2004)), Z.apush(_t2002, Z.dup(v_id)), _t2002));
    Z.setLine(759);
    f_zs_invoke(Z.dup(v_this), "terminate", ((_t2005 = Z.arrNew()), Z.apush(_t2005, Z.concat("br label %", v_lc)), _t2005));
    Z.setLine(760);
    f_zs_invoke(Z.dup(v_this), "label", ((_t2006 = Z.arrNew()), Z.apush(_t2006, Z.dup(v_lc)), _t2006));
    Z.setLine(761);
    f_zs_invoke(Z.dup(v_this), "regionExit", ((_t2007 = Z.arrNew()), _t2007));
    Z.setLine(762);
    f_zs_invoke(Z.dup(v_this), "setLine", ((_t2008 = Z.arrNew()), Z.apush(_t2008, Z.dup(v_line)), _t2008));
    Z.setLine(763);
    (v_c = f_zs_invoke(Z.dup(v_this), "truthy", ((_t2009 = Z.arrNew()), Z.apush(_t2009, f_zs_invoke(Z.dup(v_this), "expr", ((_t2010 = Z.arrNew()), Z.apush(_t2010, Z.dup(Z.index(v_s, 2))), _t2010))), _t2009)));
    Z.setLine(764);
    f_zs_invoke(Z.dup(v_this), "terminate", ((_t2011 = Z.arrNew()), Z.apush(_t2011, Z.concat(Z.concat(Z.concat(Z.concat(Z.concat("br i1 ", v_c), ", label %"), v_lbody), ", label %"), v_lb)), _t2011));
    Z.setLine(765);
    f_zs_invoke(Z.dup(v_this), "label", ((_t2012 = Z.arrNew()), Z.apush(_t2012, Z.dup(v_lbody)), _t2012));
    Z.setLine(766);
    f_zs_invoke(Z.dup(v_this), "regionEnter", ((_t2013 = Z.arrNew()), _t2013));
    Z.setLine(767);
    f_zs_invoke(Z.dup(v_this), "block", ((_t2014 = Z.arrNew()), Z.apush(_t2014, Z.dup(Z.index(v_s, 3))), _t2014));
    Z.setLine(768);
    f_zs_invoke(Z.dup(v_this), "terminate", ((_t2015 = Z.arrNew()), Z.apush(_t2015, Z.concat("br label %", v_lc)), _t2015));
    Z.setLine(769);
    f_zs_invoke(Z.dup(v_this), "label", ((_t2016 = Z.arrNew()), Z.apush(_t2016, Z.dup(v_lb)), _t2016));
    Z.setLine(770);
    f_zs_invoke(Z.dup(v_this), "regionExit", ((_t2017 = Z.arrNew()), _t2017));
    Z.setLine(771);
    f_zs_invoke(Z.dup(v_this), "regionEnd", ((_t2018 = Z.arrNew()), _t2018));
    Z.setLine(772);
    f_zs_invoke(Z.dup(v_this), "popLoop", ((_t2019 = Z.arrNew()), _t2019));
    Z.setLine(773);
    return null;
  }
  Z.setLine(775);
  if (Z.truthy(Z.ident(v_k, ":DoWhile"))) {
    Z.setLine(776);
    (v_id = f_zs_invoke(Z.dup(v_this), "pushLoop", ((_t2020 = Z.arrNew()), _t2020)));
    Z.setLine(777);
    (v_lc = Z.concat("cont_", v_id));
    Z.setLine(778);
    (v_lb = Z.concat("brk_", v_id));
    Z.setLine(779);
    (v_ltop = f_zs_invoke(Z.dup(v_this), "newLabel", ((_t2021 = Z.arrNew()), Z.apush(_t2021, "dtop"), _t2021)));
    Z.setLine(780);
    f_zs_invoke(Z.dup(v_this), "regionBegin", ((_t2022 = Z.arrNew()), Z.apush(_t2022, Z.dup(v_s)), Z.apush(_t2022, Z.dup(Z.index(v_s, 2))), Z.apush(_t2022, ((_t2023 = Z.arrNew()), Z.apush(_t2023, Z.dup(Z.index(v_s, 3))), _t2023)), Z.apush(_t2022, ((_t2024 = Z.arrNew()), _t2024)), Z.apush(_t2022, Z.dup(v_id)), _t2022));
    Z.setLine(781);
    f_zs_invoke(Z.dup(v_this), "terminate", ((_t2025 = Z.arrNew()), Z.apush(_t2025, Z.concat("br label %", v_ltop)), _t2025));
    Z.setLine(782);
    f_zs_invoke(Z.dup(v_this), "label", ((_t2026 = Z.arrNew()), Z.apush(_t2026, Z.dup(v_ltop)), _t2026));
    Z.setLine(783);
    f_zs_invoke(Z.dup(v_this), "regionEnter", ((_t2027 = Z.arrNew()), _t2027));
    Z.setLine(784);
    f_zs_invoke(Z.dup(v_this), "block", ((_t2028 = Z.arrNew()), Z.apush(_t2028, Z.dup(Z.index(v_s, 2))), _t2028));
    Z.setLine(785);
    f_zs_invoke(Z.dup(v_this), "terminate", ((_t2029 = Z.arrNew()), Z.apush(_t2029, Z.concat("br label %", v_lc)), _t2029));
    Z.setLine(786);
    f_zs_invoke(Z.dup(v_this), "label", ((_t2030 = Z.arrNew()), Z.apush(_t2030, Z.dup(v_lc)), _t2030));
    Z.setLine(787);
    f_zs_invoke(Z.dup(v_this), "regionExit", ((_t2031 = Z.arrNew()), _t2031));
    Z.setLine(788);
    f_zs_invoke(Z.dup(v_this), "setLine", ((_t2032 = Z.arrNew()), Z.apush(_t2032, Z.dup(v_line)), _t2032));
    Z.setLine(789);
    (v_c = f_zs_invoke(Z.dup(v_this), "truthy", ((_t2033 = Z.arrNew()), Z.apush(_t2033, f_zs_invoke(Z.dup(v_this), "expr", ((_t2034 = Z.arrNew()), Z.apush(_t2034, Z.dup(Z.index(v_s, 3))), _t2034))), _t2033)));
    Z.setLine(790);
    f_zs_invoke(Z.dup(v_this), "terminate", ((_t2035 = Z.arrNew()), Z.apush(_t2035, Z.concat(Z.concat(Z.concat(Z.concat(Z.concat("br i1 ", v_c), ", label %"), v_ltop), ", label %"), v_lb)), _t2035));
    Z.setLine(791);
    f_zs_invoke(Z.dup(v_this), "label", ((_t2036 = Z.arrNew()), Z.apush(_t2036, Z.dup(v_lb)), _t2036));
    Z.setLine(792);
    f_zs_invoke(Z.dup(v_this), "regionExit", ((_t2037 = Z.arrNew()), _t2037));
    Z.setLine(793);
    f_zs_invoke(Z.dup(v_this), "regionEnd", ((_t2038 = Z.arrNew()), _t2038));
    Z.setLine(794);
    f_zs_invoke(Z.dup(v_this), "popLoop", ((_t2039 = Z.arrNew()), _t2039));
    Z.setLine(795);
    return null;
  }
  Z.setLine(797);
  if (Z.truthy(Z.ident(v_k, ":For"))) {
    Z.setLine(798);
    (v_id = f_zs_invoke(Z.dup(v_this), "pushLoop", ((_t2040 = Z.arrNew()), _t2040)));
    Z.setLine(799);
    (v_lc = Z.concat("cont_", v_id));
    Z.setLine(800);
    (v_lb = Z.concat("brk_", v_id));
    Z.setLine(801);
    (v_ltest = f_zs_invoke(Z.dup(v_this), "newLabel", ((_t2041 = Z.arrNew()), Z.apush(_t2041, "ftest"), _t2041)));
    Z.setLine(802);
    (v_lbody = f_zs_invoke(Z.dup(v_this), "newLabel", ((_t2042 = Z.arrNew()), Z.apush(_t2042, "fbody"), _t2042)));
    Z.setLine(803);
    (v_lstep = f_zs_invoke(Z.dup(v_this), "newLabel", ((_t2043 = Z.arrNew()), Z.apush(_t2043, "fstep"), _t2043)));
    Z.setLine(804);
    (v_hdr = Z.dup(Z.index(v_s, 4)));
    Z.setLine(805);
    Z.apush((v_hdr = Z.wr(v_hdr)), Z.dup(Z.index(v_s, 3)));
    Z.setLine(806);
    f_zs_invoke(Z.dup(v_this), "regionBegin", ((_t2044 = Z.arrNew()), Z.apush(_t2044, Z.dup(v_s)), Z.apush(_t2044, Z.dup(Z.index(v_s, 5))), Z.apush(_t2044, Z.dup(v_hdr)), Z.apush(_t2044, ((_t2045 = Z.arrNew()), _t2045)), Z.apush(_t2044, Z.dup(v_id)), _t2044));
    Z.setLine(807);
    {
      const _it182 = Z.foreachArr(Z.dup(Z.index(v_s, 2)));
      L182: for (let _i182 = 0; _i182 < _it182.keys.length; _i182++) {
        v_e = _it182.vals[_i182];
        Z.setLine(807);
        f_zs_invoke(Z.dup(v_this), "setLine", ((_t2046 = Z.arrNew()), Z.apush(_t2046, Z.dup(v_line)), _t2046));
        Z.setLine(807);
        f_zs_invoke(Z.dup(v_this), "expr", ((_t2047 = Z.arrNew()), Z.apush(_t2047, Z.dup(v_e)), _t2047));
      }
    }
    Z.setLine(808);
    f_zs_invoke(Z.dup(v_this), "terminate", ((_t2048 = Z.arrNew()), Z.apush(_t2048, Z.concat("br label %", v_ltest)), _t2048));
    Z.setLine(809);
    f_zs_invoke(Z.dup(v_this), "label", ((_t2049 = Z.arrNew()), Z.apush(_t2049, Z.dup(v_ltest)), _t2049));
    Z.setLine(810);
    if (Z.truthy(!Z.ident(Z.index(v_s, 3), null))) {
      Z.setLine(811);
      f_zs_invoke(Z.dup(v_this), "setLine", ((_t2050 = Z.arrNew()), Z.apush(_t2050, Z.dup(v_line)), _t2050));
      Z.setLine(812);
      (v_c = f_zs_invoke(Z.dup(v_this), "truthy", ((_t2051 = Z.arrNew()), Z.apush(_t2051, f_zs_invoke(Z.dup(v_this), "expr", ((_t2052 = Z.arrNew()), Z.apush(_t2052, Z.dup(Z.index(v_s, 3))), _t2052))), _t2051)));
      Z.setLine(813);
      f_zs_invoke(Z.dup(v_this), "terminate", ((_t2053 = Z.arrNew()), Z.apush(_t2053, Z.concat(Z.concat(Z.concat(Z.concat(Z.concat("br i1 ", v_c), ", label %"), v_lbody), ", label %"), v_lb)), _t2053));
    } else {
      Z.setLine(814);
      f_zs_invoke(Z.dup(v_this), "terminate", ((_t2054 = Z.arrNew()), Z.apush(_t2054, Z.concat("br label %", v_lbody)), _t2054));
    }
    Z.setLine(815);
    f_zs_invoke(Z.dup(v_this), "label", ((_t2055 = Z.arrNew()), Z.apush(_t2055, Z.dup(v_lbody)), _t2055));
    Z.setLine(816);
    f_zs_invoke(Z.dup(v_this), "regionEnter", ((_t2056 = Z.arrNew()), _t2056));
    Z.setLine(817);
    f_zs_invoke(Z.dup(v_this), "block", ((_t2057 = Z.arrNew()), Z.apush(_t2057, Z.dup(Z.index(v_s, 5))), _t2057));
    Z.setLine(818);
    f_zs_invoke(Z.dup(v_this), "terminate", ((_t2058 = Z.arrNew()), Z.apush(_t2058, Z.concat("br label %", v_lc)), _t2058));
    Z.setLine(819);
    f_zs_invoke(Z.dup(v_this), "label", ((_t2059 = Z.arrNew()), Z.apush(_t2059, Z.dup(v_lc)), _t2059));
    Z.setLine(820);
    f_zs_invoke(Z.dup(v_this), "regionExit", ((_t2060 = Z.arrNew()), _t2060));
    Z.setLine(821);
    {
      const _it183 = Z.foreachArr(Z.dup(Z.index(v_s, 4)));
      L183: for (let _i183 = 0; _i183 < _it183.keys.length; _i183++) {
        v_e = _it183.vals[_i183];
        Z.setLine(821);
        f_zs_invoke(Z.dup(v_this), "expr", ((_t2061 = Z.arrNew()), Z.apush(_t2061, Z.dup(v_e)), _t2061));
      }
    }
    Z.setLine(822);
    f_zs_invoke(Z.dup(v_this), "terminate", ((_t2062 = Z.arrNew()), Z.apush(_t2062, Z.concat("br label %", v_ltest)), _t2062));
    Z.setLine(823);
    f_zs_invoke(Z.dup(v_this), "label", ((_t2063 = Z.arrNew()), Z.apush(_t2063, Z.dup(v_lb)), _t2063));
    Z.setLine(824);
    f_zs_invoke(Z.dup(v_this), "regionExit", ((_t2064 = Z.arrNew()), _t2064));
    Z.setLine(825);
    f_zs_invoke(Z.dup(v_this), "regionEnd", ((_t2065 = Z.arrNew()), _t2065));
    Z.setLine(826);
    f_zs_invoke(Z.dup(v_this), "popLoop", ((_t2066 = Z.arrNew()), _t2066));
    Z.setLine(827);
    return null;
  }
  Z.setLine(829);
  if (Z.truthy(Z.ident(v_k, ":Foreach"))) {
    Z.setLine(830);
    (v_id = f_zs_invoke(Z.dup(v_this), "pushLoop", ((_t2067 = Z.arrNew()), _t2067)));
    Z.setLine(831);
    (v_lc = Z.concat("cont_", v_id));
    Z.setLine(832);
    (v_lb = Z.concat("brk_", v_id));
    Z.setLine(833);
    f_zs_invoke(Z.dup(v_this), "setLine", ((_t2068 = Z.arrNew()), Z.apush(_t2068, Z.dup(v_line)), _t2068));
    Z.setLine(834);
    (v_it = f_zs_invoke(Z.dup(v_this), "val", ((_t2069 = Z.arrNew()), Z.apush(_t2069, Z.dup(Z.index(v_s, 2))), _t2069)));
    Z.setLine(835);
    f_zs_invoke(Z.dup(v_this), "regionBegin", ((_t2070 = Z.arrNew()), Z.apush(_t2070, Z.dup(v_s)), Z.apush(_t2070, Z.dup(Z.index(v_s, 5))), Z.apush(_t2070, ((_t2071 = Z.arrNew()), _t2071)), Z.apush(_t2070, ((_t2072 = Z.arrNew()), Z.apush(_t2072, Z.dup(Z.index(v_s, 3))), Z.apush(_t2072, Z.dup(Z.index(v_s, 4))), _t2072)), Z.apush(_t2070, Z.dup(v_id)), _t2070));
    Z.setLine(836);
    (v_itSlot = f_zs_invoke(Z.dup(v_this), "slot", ((_t2073 = Z.arrNew()), _t2073)));
    Z.setLine(837);
    f_zs_invoke(Z.dup(v_this), "storeTo", ((_t2074 = Z.arrNew()), Z.apush(_t2074, Z.dup(v_itSlot)), Z.apush(_t2074, Z.dup(v_it)), _t2074));
    Z.setLine(838);
    (v_tg = f_zs_invoke(Z.dup(v_this), "r", ((_t2075 = Z.arrNew()), _t2075)));
    Z.setLine(839);
    f_zs_invoke(Z.dup(v_this), "line", ((_t2076 = Z.arrNew()), Z.apush(_t2076, Z.concat(Z.concat(Z.concat(v_tg, " = extractvalue { i64, i64 } "), v_it), ", 0")), _t2076));
    Z.setLine(840);
    (v_isArr = f_zs_invoke(Z.dup(v_this), "r", ((_t2077 = Z.arrNew()), _t2077)));
    Z.setLine(841);
    f_zs_invoke(Z.dup(v_this), "line", ((_t2078 = Z.arrNew()), Z.apush(_t2078, Z.concat(Z.concat(Z.concat(v_isArr, " = icmp eq i64 "), v_tg), ", 5")), _t2078));
    Z.setLine(842);
    (v_lok = f_zs_invoke(Z.dup(v_this), "newLabel", ((_t2079 = Z.arrNew()), Z.apush(_t2079, "fe_ok"), _t2079)));
    Z.setLine(843);
    (v_lbad = f_zs_invoke(Z.dup(v_this), "newLabel", ((_t2080 = Z.arrNew()), Z.apush(_t2080, "fe_bad"), _t2080)));
    Z.setLine(844);
    f_zs_invoke(Z.dup(v_this), "terminate", ((_t2081 = Z.arrNew()), Z.apush(_t2081, Z.concat(Z.concat(Z.concat(Z.concat(Z.concat("br i1 ", v_isArr), ", label %"), v_lok), ", label %"), v_lbad)), _t2081));
    Z.setLine(845);
    f_zs_invoke(Z.dup(v_this), "label", ((_t2082 = Z.arrNew()), Z.apush(_t2082, Z.dup(v_lbad)), _t2082));
    Z.setLine(846);
    f_zs_invoke(Z.dup(v_this), "rt", ((_t2083 = Z.arrNew()), Z.apush(_t2083, "zl_foreach_die"), Z.apush(_t2083, "void"), Z.apush(_t2083, ((_t2084 = Z.arrNew()), Z.apush(_t2084, ((_t2085 = Z.arrNew()), Z.apush(_t2085, "V"), Z.apush(_t2085, Z.dup(v_it)), _t2085)), _t2084)), _t2083));
    Z.setLine(847);
    f_zs_invoke(Z.dup(v_this), "terminate", ((_t2086 = Z.arrNew()), Z.apush(_t2086, "unreachable"), _t2086));
    Z.setLine(848);
    f_zs_invoke(Z.dup(v_this), "label", ((_t2087 = Z.arrNew()), Z.apush(_t2087, Z.dup(v_lok)), _t2087));
    Z.setLine(849);
    (v_n = f_zs_invoke(Z.dup(v_this), "rt", ((_t2088 = Z.arrNew()), Z.apush(_t2088, "zs_array_len"), Z.apush(_t2088, "i64"), Z.apush(_t2088, ((_t2089 = Z.arrNew()), Z.apush(_t2089, ((_t2090 = Z.arrNew()), Z.apush(_t2090, "V"), Z.apush(_t2090, Z.dup(v_it)), _t2090)), _t2089)), _t2088)));
    Z.setLine(850);
    (v_iSlot = f_zs_invoke(Z.dup(v_this), "r", ((_t2091 = Z.arrNew()), _t2091)));
    Z.setLine(851);
    (v___r194 = Z.concat(Z.concat("  ", v_iSlot), " = alloca i64, align 8"));
    Z.setLine(851);
    (v___w195 = Z.B.zs_obj_take(v_this, "allocas"));
    Z.setLine(851);
    Z.apush((v___w195 = Z.wr(v___w195)), Z.dup(v___r194));
    Z.setLine(851);
    Z.B.zs_obj_put(v_this, "allocas", v___w195);
    Z.setLine(852);
    f_zs_invoke(Z.dup(v_this), "line", ((_t2092 = Z.arrNew()), Z.apush(_t2092, Z.concat(Z.concat("store i64 0, ptr ", v_iSlot), ", align 8")), _t2092));
    Z.setLine(853);
    (v_lhead = f_zs_invoke(Z.dup(v_this), "newLabel", ((_t2093 = Z.arrNew()), Z.apush(_t2093, "fe_head"), _t2093)));
    Z.setLine(854);
    (v_lbody = f_zs_invoke(Z.dup(v_this), "newLabel", ((_t2094 = Z.arrNew()), Z.apush(_t2094, "fe_body"), _t2094)));
    Z.setLine(855);
    f_zs_invoke(Z.dup(v_this), "terminate", ((_t2095 = Z.arrNew()), Z.apush(_t2095, Z.concat("br label %", v_lhead)), _t2095));
    Z.setLine(856);
    f_zs_invoke(Z.dup(v_this), "label", ((_t2096 = Z.arrNew()), Z.apush(_t2096, Z.dup(v_lhead)), _t2096));
    Z.setLine(857);
    (v_i = f_zs_invoke(Z.dup(v_this), "r", ((_t2097 = Z.arrNew()), _t2097)));
    Z.setLine(858);
    f_zs_invoke(Z.dup(v_this), "line", ((_t2098 = Z.arrNew()), Z.apush(_t2098, Z.concat(Z.concat(Z.concat(v_i, " = load i64, ptr "), v_iSlot), ", align 8")), _t2098));
    Z.setLine(859);
    (v_cnd = f_zs_invoke(Z.dup(v_this), "r", ((_t2099 = Z.arrNew()), _t2099)));
    Z.setLine(860);
    f_zs_invoke(Z.dup(v_this), "line", ((_t2100 = Z.arrNew()), Z.apush(_t2100, Z.concat(Z.concat(Z.concat(Z.concat(v_cnd, " = icmp slt i64 "), v_i), ", "), v_n)), _t2100));
    Z.setLine(861);
    f_zs_invoke(Z.dup(v_this), "terminate", ((_t2101 = Z.arrNew()), Z.apush(_t2101, Z.concat(Z.concat(Z.concat(Z.concat(Z.concat("br i1 ", v_cnd), ", label %"), v_lbody), ", label %"), v_lb)), _t2101));
    Z.setLine(862);
    f_zs_invoke(Z.dup(v_this), "label", ((_t2102 = Z.arrNew()), Z.apush(_t2102, Z.dup(v_lbody)), _t2102));
    Z.setLine(863);
    (v_cur = f_zs_invoke(Z.dup(v_this), "loadFrom", ((_t2103 = Z.arrNew()), Z.apush(_t2103, Z.dup(v_itSlot)), _t2103)));
    Z.setLine(864);
    (v_v = f_zs_invoke(Z.dup(v_this), "rt", ((_t2104 = Z.arrNew()), Z.apush(_t2104, "zv_get_raw"), Z.apush(_t2104, "V"), Z.apush(_t2104, ((_t2105 = Z.arrNew()), Z.apush(_t2105, ((_t2106 = Z.arrNew()), Z.apush(_t2106, "V"), Z.apush(_t2106, Z.dup(v_cur)), _t2106)), Z.apush(_t2105, ((_t2107 = Z.arrNew()), Z.apush(_t2107, "i64"), Z.apush(_t2107, Z.dup(v_i)), _t2107)), _t2105)), _t2104)));
    Z.setLine(865);
    f_zs_invoke(Z.dup(v_this), "store", ((_t2108 = Z.arrNew()), Z.apush(_t2108, Z.dup(Z.index(v_s, 4))), Z.apush(_t2108, Z.dup(v_v)), _t2108));
    Z.setLine(866);
    if (Z.truthy(!Z.ident(Z.index(v_s, 3), null))) {
      Z.setLine(867);
      (v_kv = f_zs_invoke(Z.dup(v_this), "rt", ((_t2109 = Z.arrNew()), Z.apush(_t2109, "zv_key_at"), Z.apush(_t2109, "V"), Z.apush(_t2109, ((_t2110 = Z.arrNew()), Z.apush(_t2110, ((_t2111 = Z.arrNew()), Z.apush(_t2111, "V"), Z.apush(_t2111, Z.dup(v_cur)), _t2111)), Z.apush(_t2110, ((_t2112 = Z.arrNew()), Z.apush(_t2112, "i64"), Z.apush(_t2112, Z.dup(v_i)), _t2112)), _t2110)), _t2109)));
      Z.setLine(868);
      f_zs_invoke(Z.dup(v_this), "store", ((_t2113 = Z.arrNew()), Z.apush(_t2113, Z.dup(Z.index(v_s, 3))), Z.apush(_t2113, Z.dup(v_kv)), _t2113));
    }
    Z.setLine(870);
    f_zs_invoke(Z.dup(v_this), "regionEnter", ((_t2114 = Z.arrNew()), _t2114));
    Z.setLine(871);
    f_zs_invoke(Z.dup(v_this), "block", ((_t2115 = Z.arrNew()), Z.apush(_t2115, Z.dup(Z.index(v_s, 5))), _t2115));
    Z.setLine(872);
    f_zs_invoke(Z.dup(v_this), "terminate", ((_t2116 = Z.arrNew()), Z.apush(_t2116, Z.concat("br label %", v_lc)), _t2116));
    Z.setLine(873);
    f_zs_invoke(Z.dup(v_this), "label", ((_t2117 = Z.arrNew()), Z.apush(_t2117, Z.dup(v_lc)), _t2117));
    Z.setLine(874);
    f_zs_invoke(Z.dup(v_this), "regionExit", ((_t2118 = Z.arrNew()), _t2118));
    Z.setLine(875);
    (v_i2 = f_zs_invoke(Z.dup(v_this), "r", ((_t2119 = Z.arrNew()), _t2119)));
    Z.setLine(876);
    f_zs_invoke(Z.dup(v_this), "line", ((_t2120 = Z.arrNew()), Z.apush(_t2120, Z.concat(Z.concat(Z.concat(v_i2, " = load i64, ptr "), v_iSlot), ", align 8")), _t2120));
    Z.setLine(877);
    (v_i3 = f_zs_invoke(Z.dup(v_this), "r", ((_t2121 = Z.arrNew()), _t2121)));
    Z.setLine(878);
    f_zs_invoke(Z.dup(v_this), "line", ((_t2122 = Z.arrNew()), Z.apush(_t2122, Z.concat(Z.concat(Z.concat(v_i3, " = add i64 "), v_i2), ", 1")), _t2122));
    Z.setLine(879);
    f_zs_invoke(Z.dup(v_this), "line", ((_t2123 = Z.arrNew()), Z.apush(_t2123, Z.concat(Z.concat(Z.concat(Z.concat("store i64 ", v_i3), ", ptr "), v_iSlot), ", align 8")), _t2123));
    Z.setLine(880);
    f_zs_invoke(Z.dup(v_this), "terminate", ((_t2124 = Z.arrNew()), Z.apush(_t2124, Z.concat("br label %", v_lhead)), _t2124));
    Z.setLine(881);
    f_zs_invoke(Z.dup(v_this), "label", ((_t2125 = Z.arrNew()), Z.apush(_t2125, Z.dup(v_lb)), _t2125));
    Z.setLine(882);
    f_zs_invoke(Z.dup(v_this), "regionExit", ((_t2126 = Z.arrNew()), _t2126));
    Z.setLine(883);
    f_zs_invoke(Z.dup(v_this), "regionEnd", ((_t2127 = Z.arrNew()), _t2127));
    Z.setLine(884);
    f_zs_invoke(Z.dup(v_this), "popLoop", ((_t2128 = Z.arrNew()), _t2128));
    Z.setLine(885);
    return null;
  }
  Z.setLine(887);
  if (Z.truthy(Z.ident(v_k, ":Switch"))) {
    Z.setLine(888);
    (v_id = f_zs_invoke(Z.dup(v_this), "pushLoop", ((_t2129 = Z.arrNew()), _t2129)));
    Z.setLine(889);
    (v_lb = Z.concat("brk_", v_id));
    Z.setLine(890);
    (v_lc = Z.concat("cont_", v_id));
    Z.setLine(891);
    f_zs_invoke(Z.dup(v_this), "setLine", ((_t2130 = Z.arrNew()), Z.apush(_t2130, Z.dup(v_line)), _t2130));
    Z.setLine(892);
    (v_sv = f_zs_invoke(Z.dup(v_this), "expr", ((_t2131 = Z.arrNew()), Z.apush(_t2131, Z.dup(Z.index(v_s, 2))), _t2131)));
    Z.setLine(893);
    (v_svSlot = f_zs_invoke(Z.dup(v_this), "slot", ((_t2132 = Z.arrNew()), _t2132)));
    Z.setLine(894);
    f_zs_invoke(Z.dup(v_this), "storeTo", ((_t2133 = Z.arrNew()), Z.apush(_t2133, Z.dup(v_svSlot)), Z.apush(_t2133, Z.dup(v_sv)), _t2133));
    Z.setLine(895);
    (v_n = Z.B.count(Z.index(v_s, 3)));
    Z.setLine(896);
    (v_labels = ((_t2134 = Z.arrNew()), _t2134));
    Z.setLine(897);
    (v_i = 0);
    L184: for (; Z.truthy((Z.cmp(v_i, v_n) < 0)); ((_t2135 = v_i), (v_i = Z.add(_t2135, 1)), _t2135)) {
      Z.setLine(897);
      Z.apush((v_labels = Z.wr(v_labels)), f_zs_invoke(Z.dup(v_this), "newLabel", ((_t2136 = Z.arrNew()), Z.apush(_t2136, "case"), _t2136)));
    }
    Z.setLine(898);
    (v_def = Z.neg(1));
    Z.setLine(899);
    (v_i = 0);
    L185: for (; Z.truthy((Z.cmp(v_i, v_n) < 0)); ((_t2137 = v_i), (v_i = Z.add(_t2137, 1)), _t2137)) {
      Z.setLine(900);
      (v_c = Z.dup(Z.index(Z.index(v_s, 3), v_i)));
      Z.setLine(901);
      if (Z.truthy(Z.ident(Z.index(v_c, 2), null))) {
        Z.setLine(901);
        (v_def = Z.dup(v_i));
        continue L185;
      }
      Z.setLine(902);
      (v_cv = f_zs_invoke(Z.dup(v_this), "expr", ((_t2138 = Z.arrNew()), Z.apush(_t2138, Z.dup(Z.index(v_c, 2))), _t2138)));
      Z.setLine(903);
      (v_eq = f_zs_invoke(Z.dup(v_this), "rt", ((_t2139 = Z.arrNew()), Z.apush(_t2139, "zv_eq"), Z.apush(_t2139, "i32"), Z.apush(_t2139, ((_t2140 = Z.arrNew()), Z.apush(_t2140, ((_t2141 = Z.arrNew()), Z.apush(_t2141, "V"), Z.apush(_t2141, f_zs_invoke(Z.dup(v_this), "loadFrom", ((_t2142 = Z.arrNew()), Z.apush(_t2142, Z.dup(v_svSlot)), _t2142))), _t2141)), Z.apush(_t2140, ((_t2143 = Z.arrNew()), Z.apush(_t2143, "V"), Z.apush(_t2143, Z.dup(v_cv)), _t2143)), _t2140)), _t2139)));
      Z.setLine(904);
      (v_p = f_zs_invoke(Z.dup(v_this), "r", ((_t2144 = Z.arrNew()), _t2144)));
      Z.setLine(905);
      f_zs_invoke(Z.dup(v_this), "line", ((_t2145 = Z.arrNew()), Z.apush(_t2145, Z.concat(Z.concat(Z.concat(v_p, " = icmp ne i32 "), v_eq), ", 0")), _t2145));
      Z.setLine(906);
      (v_lnext = f_zs_invoke(Z.dup(v_this), "newLabel", ((_t2146 = Z.arrNew()), Z.apush(_t2146, "cmp"), _t2146)));
      Z.setLine(907);
      f_zs_invoke(Z.dup(v_this), "terminate", ((_t2147 = Z.arrNew()), Z.apush(_t2147, Z.concat(Z.concat(Z.concat(Z.concat(Z.concat("br i1 ", v_p), ", label %"), Z.index(v_labels, v_i)), ", label %"), v_lnext)), _t2147));
      Z.setLine(908);
      f_zs_invoke(Z.dup(v_this), "label", ((_t2148 = Z.arrNew()), Z.apush(_t2148, Z.dup(v_lnext)), _t2148));
    }
    Z.setLine(910);
    f_zs_invoke(Z.dup(v_this), "terminate", ((_t2149 = Z.arrNew()), Z.apush(_t2149, Z.concat("br label %", (Z.truthy((Z.cmp(v_def, 0) >= 0)) ? Z.index(v_labels, v_def) : v_lb))), _t2149));
    Z.setLine(911);
    (v_i = 0);
    L186: for (; Z.truthy((Z.cmp(v_i, v_n) < 0)); ((_t2150 = v_i), (v_i = Z.add(_t2150, 1)), _t2150)) {
      Z.setLine(912);
      f_zs_invoke(Z.dup(v_this), "label", ((_t2151 = Z.arrNew()), Z.apush(_t2151, Z.dup(Z.index(v_labels, v_i))), _t2151));
      Z.setLine(913);
      f_zs_invoke(Z.dup(v_this), "block", ((_t2152 = Z.arrNew()), Z.apush(_t2152, Z.dup(Z.index(Z.index(Z.index(v_s, 3), v_i), 3))), _t2152));
    }
    Z.setLine(915);
    f_zs_invoke(Z.dup(v_this), "terminate", ((_t2153 = Z.arrNew()), Z.apush(_t2153, Z.concat("br label %", v_lb)), _t2153));
    Z.setLine(916);
    f_zs_invoke(Z.dup(v_this), "label", ((_t2154 = Z.arrNew()), Z.apush(_t2154, Z.dup(v_lb)), _t2154));
    Z.setLine(917);
    f_zs_invoke(Z.dup(v_this), "label", ((_t2155 = Z.arrNew()), Z.apush(_t2155, Z.dup(v_lc)), _t2155));
    Z.setLine(918);
    f_zs_invoke(Z.dup(v_this), "popLoop", ((_t2156 = Z.arrNew()), _t2156));
    Z.setLine(919);
    return null;
  }
  Z.setLine(921);
  if (Z.truthy(Z.ident(v_k, ":Return"))) {
    Z.setLine(922);
    f_zs_invoke(Z.dup(v_this), "setLine", ((_t2157 = Z.arrNew()), Z.apush(_t2157, Z.dup(v_line)), _t2157));
    Z.setLine(923);
    (v_v = (Z.truthy(Z.ident(Z.index(v_s, 2), null)) ? f_zs_invoke(Z.dup(v_this), "nullv", ((_t2158 = Z.arrNew()), _t2158)) : f_zs_invoke(Z.dup(v_this), "val", ((_t2159 = Z.arrNew()), Z.apush(_t2159, Z.dup(Z.index(v_s, 2))), _t2159))));
    Z.setLine(924);
    (v_ret = (((_t2160 = Z.indexOpt(Z.indexOpt(Z.indexOpt(Z.B.zs_obj_get(v_this, "ir"), "funcs"), Z.B.zs_obj_get(v_this, "curFunc")), "ret")) !== null) ? _t2160 : ((_t2161 = Z.arrNew()), _t2161)));
    Z.setLine(925);
    (v_rv = f_zs_invoke(Z.dup(v_this), "chkType", ((_t2162 = Z.arrNew()), Z.apush(_t2162, Z.dup(v_ret)), Z.apush(_t2162, Z.dup(v_v)), Z.apush(_t2162, Z.concat("wartość zwracana funkcji ", Z.B.zs_obj_get(v_this, "curFunc"))), _t2162)));
    Z.setLine(926);
    if (Z.truthy((Z.cmp(Z.B.count(Z.B.zs_obj_get(v_this, "tries")), 0) > 0))) {
      Z.setLine(926);
      f_zs_invoke(Z.dup(v_this), "jumpOut", ((_t2163 = Z.arrNew()), Z.apush(_t2163, 0), _t2163));
    }
    Z.setLine(927);
    f_zs_invoke(Z.dup(v_this), "terminate", ((_t2164 = Z.arrNew()), Z.apush(_t2164, Z.concat("ret { i64, i64 } ", v_rv)), _t2164));
    Z.setLine(928);
    return null;
  }
  Z.setLine(930);
  if (Z.truthy((Z.truthy(Z.ident(v_k, ":Break")) || Z.truthy(Z.ident(v_k, ":Continue"))))) {
    Z.setLine(931);
    (v_lv = Z.dup(Z.index(v_s, 2)));
    Z.setLine(932);
    (v_i = Z.sub(Z.B.count(Z.B.zs_obj_get(v_this, "loops")), v_lv));
    Z.setLine(933);
    if (Z.truthy((Z.cmp(v_i, 0) < 0))) {
      Z.setLine(933);
      Z.raise(new Z.ZExc(0, Z.concat(Z.concat(Z.concat(Z.concat("emit_llvm: break/continue ", v_lv), " poza pętlą (linia "), v_line), ")")));
    }
    Z.setLine(934);
    (v_lp = Z.dup(Z.index(Z.B.zs_obj_get(v_this, "loops"), v_i)));
    Z.setLine(935);
    f_zs_invoke(Z.dup(v_this), "jumpOut", ((_t2165 = Z.arrNew()), Z.apush(_t2165, Z.dup(Z.index(v_lp, 2))), _t2165));
    Z.setLine(936);
    f_zs_invoke(Z.dup(v_this), "terminate", ((_t2166 = Z.arrNew()), Z.apush(_t2166, Z.concat(Z.concat("br label %", (Z.truthy(Z.ident(v_k, ":Break")) ? "brk_" : "cont_")), Z.index(v_lp, 0))), _t2166));
    Z.setLine(937);
    return null;
  }
  Z.setLine(939);
  if (Z.truthy(Z.ident(v_k, ":Try"))) {
    Z.setLine(939);
    f_zs_invoke(Z.dup(v_this), "tryStmt", ((_t2167 = Z.arrNew()), Z.apush(_t2167, Z.dup(v_s)), _t2167));
    Z.setLine(939);
    return null;
  }
  Z.setLine(940);
  if (Z.truthy(Z.ident(v_k, ":Throw"))) {
    Z.setLine(941);
    (v_x = Z.dup(Z.index(v_s, 2)));
    Z.setLine(942);
    f_zs_invoke(Z.dup(v_this), "setLine", ((_t2168 = Z.arrNew()), Z.apush(_t2168, Z.dup(v_line)), _t2168));
    Z.setLine(943);
    if (Z.truthy(Z.ident(Z.index(v_x, 0), ":New"))) {
      Z.setLine(944);
      (v_msg = (Z.truthy((Z.cmp(Z.B.count(Z.index(v_x, 3)), 0) > 0)) ? f_zs_invoke(Z.dup(v_this), "expr", ((_t2169 = Z.arrNew()), Z.apush(_t2169, Z.dup(Z.index(Z.index(Z.index(v_x, 3), 0), 3))), _t2169)) : f_zs_invoke(Z.dup(v_this), "emptyStr", ((_t2170 = Z.arrNew()), _t2170))));
      Z.setLine(945);
      (v_ex = f_zs_invoke(Z.dup(v_this), "rt", ((_t2171 = Z.arrNew()), Z.apush(_t2171, "zv_exc_new"), Z.apush(_t2171, "V"), Z.apush(_t2171, ((_t2172 = Z.arrNew()), Z.apush(_t2172, ((_t2173 = Z.arrNew()), Z.apush(_t2173, "i32"), Z.apush(_t2173, (Z.truthy(Z.ident(Z.index(v_x, 2), "Error")) ? "1" : "0")), _t2173)), Z.apush(_t2172, ((_t2174 = Z.arrNew()), Z.apush(_t2174, "V"), Z.apush(_t2174, Z.dup(v_msg)), _t2174)), _t2172)), _t2171)));
      Z.setLine(946);
      f_zs_invoke(Z.dup(v_this), "rt", ((_t2175 = Z.arrNew()), Z.apush(_t2175, "zs_raise"), Z.apush(_t2175, "void"), Z.apush(_t2175, ((_t2176 = Z.arrNew()), Z.apush(_t2176, ((_t2177 = Z.arrNew()), Z.apush(_t2177, "V"), Z.apush(_t2177, Z.dup(v_ex)), _t2177)), _t2176)), _t2175));
    } else {
      Z.setLine(947);
      (v_tv = f_zs_invoke(Z.dup(v_this), "expr", ((_t2178 = Z.arrNew()), Z.apush(_t2178, Z.dup(v_x)), _t2178)));
      Z.setLine(947);
      f_zs_invoke(Z.dup(v_this), "setLine", ((_t2179 = Z.arrNew()), Z.apush(_t2179, Z.dup(v_line)), _t2179));
      Z.setLine(947);
      f_zs_invoke(Z.dup(v_this), "vcall", ((_t2180 = Z.arrNew()), Z.apush(_t2180, "b_throw_v"), Z.apush(_t2180, ((_t2181 = Z.arrNew()), Z.apush(_t2181, Z.dup(v_tv)), _t2181)), _t2180));
    }
    Z.setLine(948);
    f_zs_invoke(Z.dup(v_this), "terminate", ((_t2182 = Z.arrNew()), Z.apush(_t2182, "unreachable"), _t2182));
    Z.setLine(949);
    return null;
  }
  Z.setLine(951);
  Z.raise(new Z.ZExc(0, Z.concat(Z.concat(Z.concat(Z.concat("emit_llvm: instrukcja ", v_k), " (linia "), v_line), ")")));
  return null;
}
function f_LlEmitter__emptyStr(v_this) {
  let v_i = null, v_p = null;
  let _t2183 = null, _t2184 = null, _t2185 = null, _t2186 = null;
  Z.setLine(955);
  (v_i = f_zs_invoke(Z.dup(v_this), "strSlot", ((_t2183 = Z.arrNew()), Z.apush(_t2183, ""), _t2183)));
  Z.setLine(956);
  (v_p = f_zs_invoke(Z.dup(v_this), "r", ((_t2184 = Z.arrNew()), _t2184)));
  Z.setLine(957);
  f_zs_invoke(Z.dup(v_this), "line", ((_t2185 = Z.arrNew()), Z.apush(_t2185, Z.concat(Z.concat(v_p, " = getelementptr inbounds { i64, i64 }, ptr @S, i64 "), v_i)), _t2185));
  Z.setLine(958);
  return f_zs_invoke(Z.dup(v_this), "loadFrom", ((_t2186 = Z.arrNew()), Z.apush(_t2186, Z.dup(v_p)), _t2186));
  return null;
}
function f_LlEmitter__beginFunc(v_this, v_vol) {
  let _t2187 = null, _t2188 = null, _t2189 = null, _t2190 = null;
  Z.setLine(963);
  Z.B.zs_obj_set(v_this, "code", ((_t2187 = Z.arrNew()), _t2187));
  Z.setLine(964);
  Z.B.zs_obj_set(v_this, "allocas", ((_t2188 = Z.arrNew()), _t2188));
  Z.setLine(965);
  Z.B.zs_obj_set(v_this, "loops", ((_t2189 = Z.arrNew()), _t2189));
  Z.setLine(966);
  Z.B.zs_obj_set(v_this, "tries", ((_t2190 = Z.arrNew()), _t2190));
  Z.setLine(967);
  Z.B.zs_obj_set(v_this, "term", false);
  Z.setLine(968);
  Z.B.zs_obj_set(v_this, "vol", (Z.truthy(v_vol) ? "volatile " : ""));
  return null;
}
function f_LlEmitter__initLocals(v_this, v_locals, v_params) {
  let v_n = null, v___r196 = null, v___w197 = null;
  let _t2191 = null, _t2192 = null, _t2193 = null;
  Z.setLine(972);
  Z.B.zs_obj_set(v_this, "known", v_locals);
  Z.setLine(973);
  {
    const _it187 = Z.foreachArr(Z.dup(v_locals));
    L187: for (let _i187 = 0; _i187 < _it187.keys.length; _i187++) {
      v_n = _it187.vals[_i187];
      Z.setLine(974);
      (v___r196 = Z.concat(Z.concat("  ", f_zs_invoke(Z.dup(v_this), "ident", ((_t2191 = Z.arrNew()), Z.apush(_t2191, Z.dup(v_n)), _t2191))), " = alloca { i64, i64 }, align 8"));
      Z.setLine(974);
      (v___w197 = Z.B.zs_obj_take(v_this, "allocas"));
      Z.setLine(974);
      Z.apush((v___w197 = Z.wr(v___w197)), Z.dup(v___r196));
      Z.setLine(974);
      Z.B.zs_obj_put(v_this, "allocas", v___w197);
    }
  }
  Z.setLine(976);
  {
    const _it188 = Z.foreachArr(Z.dup(v_locals));
    L188: for (let _i188 = 0; _i188 < _it188.keys.length; _i188++) {
      v_n = _it188.vals[_i188];
      Z.setLine(977);
      if (Z.truthy(!Z.truthy(Z.B.in_array(v_n, v_params)))) {
        Z.setLine(977);
        f_zs_invoke(Z.dup(v_this), "store", ((_t2192 = Z.arrNew()), Z.apush(_t2192, Z.dup(v_n)), Z.apush(_t2192, f_zs_invoke(Z.dup(v_this), "nullv", ((_t2193 = Z.arrNew()), _t2193))), _t2192));
      }
    }
  }
  return null;
}
function f_LlEmitter__finishFunc(v_this, v_header, v_kind) {
  let v_out = null, v_a = null, v_c = null;
  let _t2194 = null, _t2195 = null, _t2196 = null;
  Z.setLine(982);
  if (Z.truthy(!Z.truthy(Z.B.zs_obj_get(v_this, "term")))) {
    Z.setLine(983);
    if (Z.truthy(Z.ident(v_kind, "V"))) {
      Z.setLine(983);
      f_zs_invoke(Z.dup(v_this), "terminate", ((_t2194 = Z.arrNew()), Z.apush(_t2194, "ret { i64, i64 } zeroinitializer"), _t2194));
    } else {
      Z.setLine(984);
      f_zs_invoke(Z.dup(v_this), "terminate", ((_t2195 = Z.arrNew()), Z.apush(_t2195, "ret i32 0"), _t2195));
    }
  }
  Z.setLine(986);
  (v_out = ((_t2196 = Z.arrNew()), Z.apush(_t2196, Z.concat(v_header, " {")), Z.apush(_t2196, "entry:"), _t2196));
  Z.setLine(987);
  {
    const _it189 = Z.foreachArr(Z.B.zs_obj_get(v_this, "allocas"));
    L189: for (let _i189 = 0; _i189 < _it189.keys.length; _i189++) {
      v_a = _it189.vals[_i189];
      Z.setLine(987);
      Z.apush((v_out = Z.wr(v_out)), Z.dup(v_a));
    }
  }
  Z.setLine(988);
  Z.apush((v_out = Z.wr(v_out)), "  br label %body");
  Z.setLine(989);
  Z.apush((v_out = Z.wr(v_out)), "body:");
  Z.setLine(990);
  {
    const _it190 = Z.foreachArr(Z.B.zs_obj_get(v_this, "code"));
    L190: for (let _i190 = 0; _i190 < _it190.keys.length; _i190++) {
      v_c = _it190.vals[_i190];
      Z.setLine(990);
      Z.apush((v_out = Z.wr(v_out)), Z.dup(v_c));
    }
  }
  Z.setLine(991);
  Z.apush((v_out = Z.wr(v_out)), "}");
  Z.setLine(992);
  Z.apush((v_out = Z.wr(v_out)), "");
  Z.setLine(993);
  return Z.dup(v_out);
  return null;
}
function f_LlEmitter__funcDef(v_this, v_name) {
  let v_f = null, v_pn = null, v_sig = null, v_p = null, v_i = null, v_r0 = null, v_r1 = null, v_v = null, v_inner = null, v_w = null, v_args = null, v_l = null;
  let _t2197 = null, _t2198 = null, _t2199 = null, _t2200 = null, _t2201 = null, _t2202 = null, _t2203 = null, _t2204 = null, _t2205 = null, _t2206 = null, _t2207 = null, _t2208 = null, _t2209 = null, _t2210 = null, _t2211 = null, _t2212 = null, _t2213 = null, _t2214 = null, _t2215 = null, _t2216 = null, _t2217 = null, _t2218 = null, _t2219 = null, _t2220 = null, _t2221 = null;
  Z.setLine(997);
  (v_f = Z.dup(Z.index(Z.index(Z.B.zs_obj_get(v_this, "ir"), "funcs"), v_name)));
  Z.setLine(998);
  Z.B.zs_obj_set(v_this, "curFunc", v_name);
  Z.setLine(999);
  Z.B.zs_obj_set(v_this, "fnCounts", f_Workspace_regions__var_counts(Z.dup(Z.index(v_f, "body")), ((_t2197 = Z.arrNew()), _t2197)));
  Z.setLine(1000);
  f_zs_invoke(Z.dup(v_this), "beginFunc", ((_t2198 = Z.arrNew()), Z.apush(_t2198, Z.dup(Z.index(v_f, "has_try"))), _t2198));
  Z.setLine(1001);
  (v_pn = ((_t2199 = Z.arrNew()), _t2199));
  Z.setLine(1002);
  (v_sig = ((_t2200 = Z.arrNew()), _t2200));
  Z.setLine(1003);
  {
    const _it191 = Z.foreachArr(Z.dup(Z.index(v_f, "params")));
    L191: for (let _i191 = 0; _i191 < _it191.keys.length; _i191++) {
      v_p = _it191.vals[_i191];
      Z.setLine(1003);
      Z.apush((v_pn = Z.wr(v_pn)), Z.dup(Z.index(v_p, 2)));
    }
  }
  Z.setLine(1004);
  (v_i = 0);
  Z.setLine(1005);
  {
    const _it192 = Z.foreachArr(Z.dup(Z.index(v_f, "params")));
    L192: for (let _i192 = 0; _i192 < _it192.keys.length; _i192++) {
      v_p = _it192.vals[_i192];
      Z.setLine(1005);
      Z.apush((v_sig = Z.wr(v_sig)), Z.concat(Z.concat(Z.concat(Z.concat("i64 %a", v_i), "x, i64 %a"), v_i), "y"));
      Z.setLine(1005);
      ((_t2201 = v_i), (v_i = Z.add(_t2201, 1)), _t2201);
    }
  }
  Z.setLine(1006);
  f_zs_invoke(Z.dup(v_this), "initLocals", ((_t2202 = Z.arrNew()), Z.apush(_t2202, Z.dup(Z.index(v_f, "locals"))), Z.apush(_t2202, Z.dup(v_pn)), _t2202));
  Z.setLine(1007);
  (v_i = 0);
  Z.setLine(1008);
  {
    const _it193 = Z.foreachArr(Z.dup(Z.index(v_f, "params")));
    L193: for (let _i193 = 0; _i193 < _it193.keys.length; _i193++) {
      v_p = _it193.vals[_i193];
      Z.setLine(1009);
      (v_r0 = f_zs_invoke(Z.dup(v_this), "r", ((_t2203 = Z.arrNew()), _t2203)));
      Z.setLine(1010);
      (v_r1 = f_zs_invoke(Z.dup(v_this), "r", ((_t2204 = Z.arrNew()), _t2204)));
      Z.setLine(1011);
      f_zs_invoke(Z.dup(v_this), "line", ((_t2205 = Z.arrNew()), Z.apush(_t2205, Z.concat(Z.concat(Z.concat(v_r0, " = insertvalue { i64, i64 } undef, i64 %a"), v_i), "x, 0")), _t2205));
      Z.setLine(1012);
      f_zs_invoke(Z.dup(v_this), "line", ((_t2206 = Z.arrNew()), Z.apush(_t2206, Z.concat(Z.concat(Z.concat(Z.concat(Z.concat(v_r1, " = insertvalue { i64, i64 } "), v_r0), ", i64 %a"), v_i), "y, 1")), _t2206));
      Z.setLine(1013);
      (v_v = Z.dup(v_r1));
      Z.setLine(1014);
      if (Z.truthy((Z.truthy(Z.ident(Z.B.count(Z.index(v_p, 3)), 1)) && Z.truthy(Z.B.in_array(Z.index(Z.index(v_p, 3), 0), ((_t2207 = Z.arrNew()), Z.apush(_t2207, "int"), Z.apush(_t2207, "float"), Z.apush(_t2207, "string"), Z.apush(_t2207, "bool"), Z.apush(_t2207, "array"), _t2207)))))) {
        Z.setLine(1015);
        (v_v = f_zs_invoke(Z.dup(v_this), "rt", ((_t2208 = Z.arrNew()), Z.apush(_t2208, "zv_chk"), Z.apush(_t2208, "V"), Z.apush(_t2208, ((_t2209 = Z.arrNew()), Z.apush(_t2209, ((_t2210 = Z.arrNew()), Z.apush(_t2210, "V"), Z.apush(_t2210, Z.dup(v_r1)), _t2210)), Z.apush(_t2209, ((_t2211 = Z.arrNew()), Z.apush(_t2211, "ptr"), Z.apush(_t2211, f_zs_invoke(Z.dup(v_this), "cstr", ((_t2212 = Z.arrNew()), Z.apush(_t2212, Z.dup(Z.index(Z.index(v_p, 3), 0))), _t2212))), _t2211)), Z.apush(_t2209, ((_t2213 = Z.arrNew()), Z.apush(_t2213, "ptr"), Z.apush(_t2213, f_zs_invoke(Z.dup(v_this), "cstr", ((_t2214 = Z.arrNew()), Z.apush(_t2214, Z.concat(Z.concat(Z.concat("argument $", Z.index(v_p, 2)), " funkcji "), v_name)), _t2214))), _t2213)), _t2209)), _t2208)));
      }
      Z.setLine(1017);
      f_zs_invoke(Z.dup(v_this), "store", ((_t2215 = Z.arrNew()), Z.apush(_t2215, Z.dup(Z.index(v_p, 2))), Z.apush(_t2215, Z.dup(v_v)), _t2215));
      Z.setLine(1018);
      ((_t2216 = v_i), (v_i = Z.add(_t2216, 1)), _t2216);
    }
  }
  Z.setLine(1020);
  f_zs_invoke(Z.dup(v_this), "block", ((_t2217 = Z.arrNew()), Z.apush(_t2217, Z.dup(Z.index(v_f, "body"))), _t2217));
  Z.setLine(1021);
  (v_inner = f_zs_invoke(Z.dup(v_this), "finishFunc", ((_t2218 = Z.arrNew()), Z.apush(_t2218, Z.concat(Z.concat(Z.concat(Z.concat("define internal { i64, i64 } @\"f_", v_name), "__z\"("), Z.B.join(v_sig, ", ")), ")")), Z.apush(_t2218, "V"), _t2218)));
  Z.setLine(1023);
  (v_w = ((_t2219 = Z.arrNew()), _t2219));
  Z.setLine(1024);
  Z.apush((v_w = Z.wr(v_w)), Z.concat(Z.concat(Z.concat(Z.concat("define internal { i64, i64 } @\"f_", v_name), "\"("), Z.B.join(v_sig, ", ")), ") {"));
  Z.setLine(1025);
  Z.apush((v_w = Z.wr(v_w)), "entry:");
  Z.setLine(1026);
  Z.apush((v_w = Z.wr(v_w)), "  %lv = call i32 @zs_enter()");
  Z.setLine(1027);
  (v_args = ((_t2220 = Z.arrNew()), _t2220));
  Z.setLine(1028);
  (v_i = 0);
  Z.setLine(1029);
  {
    const _it194 = Z.foreachArr(Z.dup(Z.index(v_f, "params")));
    L194: for (let _i194 = 0; _i194 < _it194.keys.length; _i194++) {
      v_p = _it194.vals[_i194];
      Z.setLine(1029);
      Z.apush((v_args = Z.wr(v_args)), Z.concat(Z.concat(Z.concat(Z.concat("i64 %a", v_i), "x, i64 %a"), v_i), "y"));
      Z.setLine(1029);
      ((_t2221 = v_i), (v_i = Z.add(_t2221, 1)), _t2221);
    }
  }
  Z.setLine(1030);
  Z.apush((v_w = Z.wr(v_w)), Z.concat(Z.concat(Z.concat(Z.concat("  %r = call { i64, i64 } @\"f_", v_name), "__z\"("), Z.B.join(v_args, ", ")), ")"));
  Z.setLine(1031);
  Z.apush((v_w = Z.wr(v_w)), "  %rx = extractvalue { i64, i64 } %r, 0");
  Z.setLine(1032);
  Z.apush((v_w = Z.wr(v_w)), "  %ry = extractvalue { i64, i64 } %r, 1");
  Z.setLine(1033);
  Z.apush((v_w = Z.wr(v_w)), "  %o = call { i64, i64 } @zs_leave(i32 %lv, i64 %rx, i64 %ry)");
  Z.setLine(1034);
  Z.apush((v_w = Z.wr(v_w)), "  ret { i64, i64 } %o");
  Z.setLine(1035);
  Z.apush((v_w = Z.wr(v_w)), "}");
  Z.setLine(1036);
  Z.apush((v_w = Z.wr(v_w)), "");
  Z.setLine(1037);
  {
    const _it195 = Z.foreachArr(Z.dup(v_w));
    L195: for (let _i195 = 0; _i195 < _it195.keys.length; _i195++) {
      v_l = _it195.vals[_i195];
      Z.setLine(1037);
      Z.apush((v_inner = Z.wr(v_inner)), Z.dup(v_l));
    }
  }
  Z.setLine(1038);
  return Z.dup(v_inner);
  return null;
}
function f_LlEmitter__generate(v_this, v_triple) {
  let v_ir = null, v_funcs = null, v_name = null, v_l = null, v_topLines = null, v_o = null, v_d = null, v_sc = null, v_i = null, v_c = null, v_s = null;
  let _t2222 = null, _t2223 = null, _t2224 = null, _t2225 = null, _t2226 = null, _t2227 = null, _t2228 = null, _t2229 = null, _t2230 = null, _t2231 = null, _t2232 = null, _t2233 = null, _t2234 = null, _t2235 = null, _t2236 = null;
  Z.setLine(1042);
  (v_ir = Z.B.zs_obj_get(v_this, "ir"));
  Z.setLine(1043);
  (v_funcs = ((_t2222 = Z.arrNew()), _t2222));
  Z.setLine(1044);
  {
    const _it196 = Z.foreachArr(Z.dup(Z.index(v_ir, "order")));
    L196: for (let _i196 = 0; _i196 < _it196.keys.length; _i196++) {
      v_name = _it196.vals[_i196];
      Z.setLine(1044);
      {
        const _it197 = Z.foreachArr(f_zs_invoke(Z.dup(v_this), "funcDef", ((_t2223 = Z.arrNew()), Z.apush(_t2223, Z.dup(v_name)), _t2223)));
        L197: for (let _i197 = 0; _i197 < _it197.keys.length; _i197++) {
          v_l = _it197.vals[_i197];
          Z.setLine(1044);
          Z.apush((v_funcs = Z.wr(v_funcs)), Z.dup(v_l));
        }
      }
    }
  }
  Z.setLine(1045);
  Z.B.zs_obj_set(v_this, "curFunc", "");
  Z.setLine(1046);
  Z.B.zs_obj_set(v_this, "fnCounts", f_Workspace_regions__var_counts(Z.dup(Z.index(v_ir, "top")), ((_t2224 = Z.arrNew()), _t2224)));
  Z.setLine(1047);
  f_zs_invoke(Z.dup(v_this), "beginFunc", ((_t2225 = Z.arrNew()), Z.apush(_t2225, Z.dup(Z.index(v_ir, "top_has_try"))), _t2225));
  Z.setLine(1048);
  f_zs_invoke(Z.dup(v_this), "initLocals", ((_t2226 = Z.arrNew()), Z.apush(_t2226, Z.dup(Z.index(v_ir, "toplocals"))), Z.apush(_t2226, ((_t2227 = Z.arrNew()), _t2227)), _t2226));
  Z.setLine(1049);
  f_zs_invoke(Z.dup(v_this), "block", ((_t2228 = Z.arrNew()), Z.apush(_t2228, Z.dup(Z.index(v_ir, "top"))), _t2228));
  Z.setLine(1050);
  (v_topLines = f_zs_invoke(Z.dup(v_this), "finishFunc", ((_t2229 = Z.arrNew()), Z.apush(_t2229, "define internal i32 @zs_top()"), Z.apush(_t2229, "i32"), _t2229)));
  Z.setLine(1052);
  (v_o = ((_t2230 = Z.arrNew()), _t2230));
  Z.setLine(1053);
  Z.apush((v_o = Z.wr(v_o)), "; wygenerowane przez zsc (backend LLVM, Z# 0.0.1) — nie edytuj");
  Z.setLine(1054);
  Z.apush((v_o = Z.wr(v_o)), Z.concat(Z.concat("target triple = \"", v_triple), "\""));
  Z.setLine(1055);
  Z.apush((v_o = Z.wr(v_o)), "");
  Z.setLine(1056);
  {
    const _it198 = Z.foreachArr(f_zs_invoke(Z.dup(v_this), "decls", ((_t2231 = Z.arrNew()), _t2231)));
    L198: for (let _i198 = 0; _i198 < _it198.keys.length; _i198++) {
      v_d = _it198.vals[_i198];
      Z.setLine(1056);
      Z.apush((v_o = Z.wr(v_o)), Z.dup(v_d));
    }
  }
  Z.setLine(1057);
  Z.apush((v_o = Z.wr(v_o)), "attributes #0 = { returns_twice }");
  Z.setLine(1058);
  Z.apush((v_o = Z.wr(v_o)), "");
  Z.setLine(1059);
  (v_sc = (Z.truthy((Z.cmp(Z.B.count(Z.B.zs_obj_get(v_this, "strList")), 0) > 0)) ? Z.B.count(Z.B.zs_obj_get(v_this, "strList")) : 1));
  Z.setLine(1060);
  Z.apush((v_o = Z.wr(v_o)), Z.concat(Z.concat("@S = internal global [", v_sc), " x { i64, i64 }] zeroinitializer, align 16"));
  Z.setLine(1061);
  (v_i = 0);
  Z.setLine(1062);
  {
    const _it199 = Z.foreachArr(Z.B.zs_obj_get(v_this, "cstrList"));
    L199: for (let _i199 = 0; _i199 < _it199.keys.length; _i199++) {
      v_c = _it199.vals[_i199];
      Z.setLine(1063);
      Z.apush((v_o = Z.wr(v_o)), Z.concat(Z.concat(Z.concat(Z.concat(Z.concat(Z.concat("@.c", v_i), " = private unnamed_addr constant ["), Z.add(Z.B.strlen(v_c), 1)), " x i8] c\""), f_zs_invoke(Z.dup(v_this), "esc", ((_t2232 = Z.arrNew()), Z.apush(_t2232, Z.dup(v_c)), _t2232))), "\\00\", align 1"));
      Z.setLine(1064);
      ((_t2233 = v_i), (v_i = Z.add(_t2233, 1)), _t2233);
    }
  }
  Z.setLine(1066);
  (v_i = 0);
  Z.setLine(1067);
  {
    const _it200 = Z.foreachArr(Z.B.zs_obj_get(v_this, "strList"));
    L200: for (let _i200 = 0; _i200 < _it200.keys.length; _i200++) {
      v_s = _it200.vals[_i200];
      Z.setLine(1068);
      Z.apush((v_o = Z.wr(v_o)), Z.concat(Z.concat(Z.concat(Z.concat(Z.concat(Z.concat("@.s", v_i), " = private unnamed_addr constant ["), Z.add(Z.B.strlen(v_s), 1)), " x i8] c\""), f_zs_invoke(Z.dup(v_this), "esc", ((_t2234 = Z.arrNew()), Z.apush(_t2234, Z.dup(v_s)), _t2234))), "\\00\", align 1"));
      Z.setLine(1069);
      ((_t2235 = v_i), (v_i = Z.add(_t2235, 1)), _t2235);
    }
  }
  Z.setLine(1071);
  Z.apush((v_o = Z.wr(v_o)), "");
  Z.setLine(1072);
  Z.apush((v_o = Z.wr(v_o)), "define internal void @zs_strings_init() {");
  Z.setLine(1073);
  Z.apush((v_o = Z.wr(v_o)), "entry:");
  Z.setLine(1074);
  (v_i = 0);
  Z.setLine(1075);
  {
    const _it201 = Z.foreachArr(Z.B.zs_obj_get(v_this, "strList"));
    L201: for (let _i201 = 0; _i201 < _it201.keys.length; _i201++) {
      v_s = _it201.vals[_i201];
      Z.setLine(1076);
      Z.apush((v_o = Z.wr(v_o)), Z.concat(Z.concat(Z.concat(Z.concat(Z.concat(Z.concat("  %r", v_i), " = call { i64, i64 } @zv_strn(ptr @.s"), v_i), ", i64 "), Z.B.strlen(v_s)), ")"));
      Z.setLine(1077);
      Z.apush((v_o = Z.wr(v_o)), Z.concat(Z.concat(Z.concat("  %p", v_i), " = getelementptr inbounds { i64, i64 }, ptr @S, i64 "), v_i));
      Z.setLine(1078);
      Z.apush((v_o = Z.wr(v_o)), Z.concat(Z.concat(Z.concat(Z.concat("  store { i64, i64 } %r", v_i), ", ptr %p"), v_i), ", align 8"));
      Z.setLine(1079);
      ((_t2236 = v_i), (v_i = Z.add(_t2236, 1)), _t2236);
    }
  }
  Z.setLine(1081);
  Z.apush((v_o = Z.wr(v_o)), "  ret void");
  Z.setLine(1082);
  Z.apush((v_o = Z.wr(v_o)), "}");
  Z.setLine(1083);
  Z.apush((v_o = Z.wr(v_o)), "");
  Z.setLine(1084);
  {
    const _it202 = Z.foreachArr(Z.dup(v_funcs));
    L202: for (let _i202 = 0; _i202 < _it202.keys.length; _i202++) {
      v_l = _it202.vals[_i202];
      Z.setLine(1084);
      Z.apush((v_o = Z.wr(v_o)), Z.dup(v_l));
    }
  }
  Z.setLine(1085);
  {
    const _it203 = Z.foreachArr(Z.dup(v_topLines));
    L203: for (let _i203 = 0; _i203 < _it203.keys.length; _i203++) {
      v_l = _it203.vals[_i203];
      Z.setLine(1085);
      Z.apush((v_o = Z.wr(v_o)), Z.dup(v_l));
    }
  }
  Z.setLine(1086);
  Z.apush((v_o = Z.wr(v_o)), "define i32 @main(i32 %argc, ptr %argv) {");
  Z.setLine(1087);
  Z.apush((v_o = Z.wr(v_o)), "entry:");
  Z.setLine(1088);
  Z.apush((v_o = Z.wr(v_o)), "  call void @zs_init(i32 %argc, ptr %argv)");
  Z.setLine(1089);
  Z.apush((v_o = Z.wr(v_o)), "  call void @zs_strings_init()");
  Z.setLine(1090);
  Z.apush((v_o = Z.wr(v_o)), "  %top_lv = call i32 @zs_enter()");
  Z.setLine(1091);
  Z.apush((v_o = Z.wr(v_o)), "  %rc = call i32 @zs_top()");
  Z.setLine(1092);
  if (Z.truthy((Z.truthy(Z.B.has_key(Z.index(v_ir, "funcs"), "main")) && Z.truthy(!Z.truthy(Z.index(v_ir, "calls_main")))))) {
    Z.setLine(1093);
    Z.apush((v_o = Z.wr(v_o)), "  %m = call { i64, i64 } @\"f_main\"()");
    Z.setLine(1094);
    Z.apush((v_o = Z.wr(v_o)), "  %mt = extractvalue { i64, i64 } %m, 0");
    Z.setLine(1095);
    Z.apush((v_o = Z.wr(v_o)), "  %mi = extractvalue { i64, i64 } %m, 1");
    Z.setLine(1096);
    Z.apush((v_o = Z.wr(v_o)), "  %isint = icmp eq i64 %mt, 2");
    Z.setLine(1097);
    Z.apush((v_o = Z.wr(v_o)), "  %mc = trunc i64 %mi to i32");
    Z.setLine(1098);
    Z.apush((v_o = Z.wr(v_o)), "  %rc2 = select i1 %isint, i32 %mc, i32 %rc");
    Z.setLine(1099);
    Z.apush((v_o = Z.wr(v_o)), "  call void @zs_shutdown()");
    Z.setLine(1100);
    Z.apush((v_o = Z.wr(v_o)), "  ret i32 %rc2");
  } else {
    Z.setLine(1102);
    Z.apush((v_o = Z.wr(v_o)), "  call void @zs_shutdown()");
    Z.setLine(1103);
    Z.apush((v_o = Z.wr(v_o)), "  ret i32 %rc");
  }
  Z.setLine(1105);
  Z.apush((v_o = Z.wr(v_o)), "}");
  Z.setLine(1106);
  return Z.concat(Z.B.join(v_o, "\n"), "\n");
  return null;
}
function f_LlEmitter__decls(v_this) {
  let v_d = null, v_v = null, v_f = null, v_mod = null, v_fns = null, v_fn = null, v_ar = null, v_n = null, v_ps = null, v_i = null;
  let _t2237 = null, _t2238 = null, _t2239 = null, _t2240 = null, _t2241 = null, _t2242 = null, _t2243 = null, _t2244 = null, _t2245 = null, _t2246 = null, _t2247 = null, _t2248 = null, _t2249 = null;
  Z.setLine(1110);
  (v_d = ((_t2237 = Z.arrNew()), _t2237));
  Z.setLine(1111);
  (v_v = "i64, i64");
  Z.setLine(1112);
  Z.apush((v_d = Z.wr(v_d)), "declare void @zs_init(i32, ptr)");
  Z.setLine(1113);
  Z.apush((v_d = Z.wr(v_d)), "declare void @zs_shutdown()");
  Z.setLine(1114);
  Z.apush((v_d = Z.wr(v_d)), "declare i32 @zs_enter()");
  Z.setLine(1115);
  Z.apush((v_d = Z.wr(v_d)), "declare { i64, i64 } @zs_leave(i32, i64, i64)");
  Z.setLine(1116);
  Z.apush((v_d = Z.wr(v_d)), "declare { i64, i64 } @zs_carry_v(i64, i64, i32)");
  Z.setLine(1117);
  Z.apush((v_d = Z.wr(v_d)), "declare void @zs_pop(i32)");
  Z.setLine(1118);
  Z.apush((v_d = Z.wr(v_d)), "declare i32 @zs_cur_depth()");
  Z.setLine(1119);
  Z.apush((v_d = Z.wr(v_d)), "declare { i64, i64 } @zv_strn(ptr, i64)");
  Z.setLine(1120);
  Z.apush((v_d = Z.wr(v_d)), "declare { i64, i64 } @zl_float_lit(ptr)");
  Z.setLine(1121);
  Z.apush((v_d = Z.wr(v_d)), "declare void @zl_try_enter(ptr)");
  Z.setLine(1122);
  Z.apush((v_d = Z.wr(v_d)), "declare void @zl_try_leave(ptr)");
  Z.setLine(1123);
  Z.apush((v_d = Z.wr(v_d)), "declare { i64, i64 } @zl_cur_exc()");
  Z.setLine(1124);
  Z.apush((v_d = Z.wr(v_d)), Z.concat(Z.concat("declare void @zl_foreach_die(", v_v), ")"));
  Z.setLine(1125);
  Z.apush((v_d = Z.wr(v_d)), "declare { i64, i64 } @zl_undef_var(ptr)");
  Z.setLine(1126);
  Z.apush((v_d = Z.wr(v_d)), "declare i32 @_setjmp(ptr) #0");
  Z.setLine(1127);
  Z.apush((v_d = Z.wr(v_d)), "@zs_line = external global i64, align 8");
  Z.setLine(1128);
  Z.apush((v_d = Z.wr(v_d)), Z.concat(Z.concat("declare i32 @zv_truthy(", v_v), ")"));
  Z.setLine(1129);
  Z.apush((v_d = Z.wr(v_d)), Z.concat(Z.concat(Z.concat(Z.concat("declare i32 @zv_eq(", v_v), ", "), v_v), ")"));
  Z.setLine(1130);
  Z.apush((v_d = Z.wr(v_d)), Z.concat(Z.concat(Z.concat(Z.concat("declare i32 @zv_ident(", v_v), ", "), v_v), ")"));
  Z.setLine(1131);
  Z.apush((v_d = Z.wr(v_d)), Z.concat(Z.concat(Z.concat(Z.concat("declare i32 @zv_cmp(", v_v), ", "), v_v), ")"));
  Z.setLine(1132);
  Z.apush((v_d = Z.wr(v_d)), Z.concat(Z.concat("declare i32 @zv_exc_is(", v_v), ", i32)"));
  Z.setLine(1133);
  Z.apush((v_d = Z.wr(v_d)), Z.concat(Z.concat("declare i64 @zs_array_len(", v_v), ")"));
  Z.setLine(1134);
  Z.apush((v_d = Z.wr(v_d)), "declare { i64, i64 } @zv_arr_new(i64)");
  Z.setLine(1135);
  Z.apush((v_d = Z.wr(v_d)), Z.concat(Z.concat(Z.concat(Z.concat("declare void @zv_append(", v_v), ", "), v_v), ")"));
  Z.setLine(1136);
  Z.apush((v_d = Z.wr(v_d)), Z.concat(Z.concat(Z.concat(Z.concat(Z.concat(Z.concat("declare void @zv_set(", v_v), ", "), v_v), ", "), v_v), ")"));
  Z.setLine(1137);
  Z.apush((v_d = Z.wr(v_d)), Z.concat(Z.concat("declare { i64, i64 } @zv_get_raw(", v_v), ", i64)"));
  Z.setLine(1138);
  Z.apush((v_d = Z.wr(v_d)), Z.concat(Z.concat("declare { i64, i64 } @zv_key_at(", v_v), ", i64)"));
  Z.setLine(1139);
  Z.apush((v_d = Z.wr(v_d)), Z.concat(Z.concat("declare { i64, i64 } @zv_exc_new(i32, ", v_v), ")"));
  Z.setLine(1140);
  Z.apush((v_d = Z.wr(v_d)), Z.concat(Z.concat("declare void @zs_raise(", v_v), ")"));
  Z.setLine(1141);
  Z.apush((v_d = Z.wr(v_d)), Z.concat(Z.concat("declare void @zs_reraise(", v_v), ")"));
  Z.setLine(1142);
  Z.apush((v_d = Z.wr(v_d)), Z.concat(Z.concat("declare { i64, i64 } @zv_chk(", v_v), ", ptr, ptr)"));
  Z.setLine(1143);
  Z.apush((v_d = Z.wr(v_d)), Z.concat(Z.concat("declare void @zs_echo_v(", v_v), ", i32)"));
  Z.setLine(1144);
  Z.apush((v_d = Z.wr(v_d)), "declare void @zs_echo_end()");
  Z.setLine(1145);
  Z.apush((v_d = Z.wr(v_d)), Z.concat(Z.concat("declare void @zs_necho_v(", v_v), ")"));
  Z.setLine(1146);
  Z.apush((v_d = Z.wr(v_d)), Z.concat(Z.concat("declare void @zs_eecho_v(", v_v), ", i32)"));
  Z.setLine(1147);
  Z.apush((v_d = Z.wr(v_d)), "declare void @zs_eecho_end()");
  Z.setLine(1148);
  Z.apush((v_d = Z.wr(v_d)), Z.concat(Z.concat("declare { i64, i64 } @s_exit(", v_v), ")"));
  Z.setLine(1149);
  Z.apush((v_d = Z.wr(v_d)), Z.concat(Z.concat(Z.concat(Z.concat(Z.concat(Z.concat("declare { i64, i64 } @b_substr(", v_v), ", "), v_v), ", "), v_v), ", i32)"));
  Z.setLine(1150);
  {
    const _it204 = Z.foreachArr(((_t2238 = Z.arrNew()), Z.apush(_t2238, "zv_dup"), Z.apush(_t2238, "zv_wr"), Z.apush(_t2238, "zv_neg"), Z.apush(_t2238, "zv_bitnot"), Z.apush(_t2238, "b_getmessage"), Z.apush(_t2238, "b_zs_obj_new"), Z.apush(_t2238, "b_zs_obj_class"), Z.apush(_t2238, "b_zs_no_class"), Z.apush(_t2238, "b_zs_fn_id"), Z.apush(_t2238, "b_zs_fn_cap"), Z.apush(_t2238, "b_is_callable"), Z.apush(_t2238, "b_zs_sget"), Z.apush(_t2238, "b_throw_v"), Z.apush(_t2238, "b_dump"), Z.apush(_t2238, "b_count"), Z.apush(_t2238, "b_strlen"), Z.apush(_t2238, "b_typeof"), Z.apush(_t2238, "b_is_int"), Z.apush(_t2238, "b_is_float"), Z.apush(_t2238, "b_is_string"), Z.apush(_t2238, "b_is_bool"), Z.apush(_t2238, "b_is_array"), Z.apush(_t2238, "b_is_null"), Z.apush(_t2238, "b_strval"), Z.apush(_t2238, "b_boolval"), Z.apush(_t2238, "b_intval"), Z.apush(_t2238, "b_floatval"), Z.apush(_t2238, "b_ord"), Z.apush(_t2238, "b_chr"), Z.apush(_t2238, "b_trim"), Z.apush(_t2238, "b_keys"), Z.apush(_t2238, "b_values"), Z.apush(_t2238, "b_upper"), Z.apush(_t2238, "b_lower"), Z.apush(_t2238, "b_chars"), Z.apush(_t2238, "b_reverse"), Z.apush(_t2238, "b_sort"), Z.apush(_t2238, "b_to_hex"), Z.apush(_t2238, "b_is_digit"), Z.apush(_t2238, "b_is_alpha"), Z.apush(_t2238, "b_is_alnum"), Z.apush(_t2238, "b_is_space"), Z.apush(_t2238, "b_is_hex_digit"), Z.apush(_t2238, "m_Math_sqrt"), Z.apush(_t2238, "m_Math_floor"), Z.apush(_t2238, "m_Math_ceil"), Z.apush(_t2238, "m_Math_round"), Z.apush(_t2238, "m_Math_abs"), _t2238));
    L204: for (let _i204 = 0; _i204 < _it204.keys.length; _i204++) {
      v_f = _it204.vals[_i204];
      Z.setLine(1156);
      Z.apush((v_d = Z.wr(v_d)), Z.concat(Z.concat(Z.concat(Z.concat("declare { i64, i64 } @", v_f), "("), v_v), ")"));
    }
  }
  Z.setLine(1158);
  {
    const _it205 = Z.foreachArr(((_t2239 = Z.arrNew()), Z.apush(_t2239, "zv_add"), Z.apush(_t2239, "zv_sub"), Z.apush(_t2239, "zv_mul"), Z.apush(_t2239, "zv_div"), Z.apush(_t2239, "zv_mod"), Z.apush(_t2239, "zv_pow"), Z.apush(_t2239, "zv_concat"), Z.apush(_t2239, "zv_bitand"), Z.apush(_t2239, "zv_bitor"), Z.apush(_t2239, "zv_bitxor"), Z.apush(_t2239, "zv_shl"), Z.apush(_t2239, "zv_shr"), Z.apush(_t2239, "zv_index"), Z.apush(_t2239, "zv_index_opt"), Z.apush(_t2239, "b_contains"), Z.apush(_t2239, "b_starts_with"), Z.apush(_t2239, "b_ends_with"), Z.apush(_t2239, "b_index_of"), Z.apush(_t2239, "b_repeat"), Z.apush(_t2239, "b_join"), Z.apush(_t2239, "b_in_array"), Z.apush(_t2239, "b_range"), Z.apush(_t2239, "b_has_key"), Z.apush(_t2239, "b_pad_left"), Z.apush(_t2239, "b_pad_right"), Z.apush(_t2239, "b_array_slice"), Z.apush(_t2239, "b_push"), Z.apush(_t2239, "m_Math_min"), Z.apush(_t2239, "m_Math_max"), Z.apush(_t2239, "m_Math_pow"), Z.apush(_t2239, "b_split"), Z.apush(_t2239, "b_zs_obj_get"), Z.apush(_t2239, "b_zs_obj_take"), Z.apush(_t2239, "b_zs_no_method"), Z.apush(_t2239, "b_zs_mkfn"), Z.apush(_t2239, "b_zs_sset"), _t2239));
    L205: for (let _i205 = 0; _i205 < _it205.keys.length; _i205++) {
      v_f = _it205.vals[_i205];
      Z.setLine(1162);
      Z.apush((v_d = Z.wr(v_d)), Z.concat(Z.concat(Z.concat(Z.concat(Z.concat(Z.concat("declare { i64, i64 } @", v_f), "("), v_v), ", "), v_v), ")"));
    }
  }
  Z.setLine(1164);
  {
    const _it206 = Z.foreachArr(((_t2240 = Z.arrNew()), Z.apush(_t2240, "b_zs_obj_set"), Z.apush(_t2240, "b_zs_obj_put"), Z.apush(_t2240, "b_replace"), Z.apush(_t2240, "b_pad_left3"), Z.apush(_t2240, "b_pad_right3"), Z.apush(_t2240, "b_array_slice3"), _t2240));
    L206: for (let _i206 = 0; _i206 < _it206.keys.length; _i206++) {
      v_f = _it206.vals[_i206];
      Z.setLine(1165);
      Z.apush((v_d = Z.wr(v_d)), Z.concat(Z.concat(Z.concat(Z.concat(Z.concat(Z.concat(Z.concat(Z.concat("declare { i64, i64 } @", v_f), "("), v_v), ", "), v_v), ", "), v_v), ")"));
    }
  }
  Z.setLine(1167);
  {
    const _it207 = Z.foreachArr(((_t2241 = Z.arrNew()), Z.apush(_t2241, "b_read_line"), _t2241));
    L207: for (let _i207 = 0; _i207 < _it207.keys.length; _i207++) {
      v_f = _it207.vals[_i207];
      Z.setLine(1168);
      Z.apush((v_d = Z.wr(v_d)), Z.concat(Z.concat("declare { i64, i64 } @", v_f), "()"));
    }
  }
  Z.setLine(1171);
  {
    const _it208 = Z.foreachArr(((_t2242 = Z.arrNew()), Z.aset(_t2242, "System", ((_t2243 = Z.arrNew()), Z.aset(_t2243, "args", 0), Z.aset(_t2243, "env", 1), Z.aset(_t2243, "os", 0), Z.aset(_t2243, "architecture", 0), Z.aset(_t2243, "time", 0), Z.aset(_t2243, "cpuCount", 0), Z.aset(_t2243, "dirname", 1), Z.aset(_t2243, "resolveImport", 2), Z.aset(_t2243, "version", 0), Z.aset(_t2243, "exit", Z.neg(1)), Z.aset(_t2243, "setEnv", 2), Z.aset(_t2243, "unsetEnv", 1), Z.aset(_t2243, "environ", 0), Z.aset(_t2243, "cwd", 0), Z.aset(_t2243, "chdir", 1), Z.aset(_t2243, "pid", 0), Z.aset(_t2243, "hostname", 0), Z.aset(_t2243, "bytes", 1), Z.aset(_t2243, "fromBytes", 1), Z.aset(_t2243, "nowNanos", 0), Z.aset(_t2243, "monotonic", 0), Z.aset(_t2243, "sleep", 1), Z.aset(_t2243, "localOffset", 1), Z.aset(_t2243, "gc", 0), Z.aset(_t2243, "gcStats", 0), _t2243)), Z.aset(_t2242, "File", ((_t2244 = Z.arrNew()), Z.aset(_t2244, "read", 1), Z.aset(_t2244, "write", 2), Z.aset(_t2244, "append", 2), Z.aset(_t2244, "exists", 1), Z.aset(_t2244, "delete", 1), Z.aset(_t2244, "stat", 1), Z.aset(_t2244, "rename", 2), Z.aset(_t2244, "realpath", 1), Z.aset(_t2244, "chmod", 2), Z.aset(_t2244, "symlink", 2), Z.aset(_t2244, "readlink", 1), _t2244)), Z.aset(_t2242, "Directory", ((_t2245 = Z.arrNew()), Z.aset(_t2245, "create", 1), Z.aset(_t2245, "exists", 1), Z.aset(_t2245, "list", 1), Z.aset(_t2245, "remove", 1), _t2245)), Z.aset(_t2242, "Process", ((_t2246 = Z.arrNew()), Z.aset(_t2246, "run", Z.neg(1)), Z.aset(_t2246, "exec", Z.neg(1)), _t2246)), Z.aset(_t2242, "Socket", ((_t2247 = Z.arrNew()), Z.aset(_t2247, "tcpConnect", 3), Z.aset(_t2247, "tcpListen", 2), Z.aset(_t2247, "accept", 1), Z.aset(_t2247, "read", 2), Z.aset(_t2247, "write", 2), Z.aset(_t2247, "close", 1), Z.aset(_t2247, "setTimeout", 2), Z.aset(_t2247, "udpBind", 2), Z.aset(_t2247, "sendTo", 4), Z.aset(_t2247, "recvFrom", 2), Z.aset(_t2247, "resolve", 1), Z.aset(_t2247, "localAddr", 1), Z.aset(_t2247, "peerAddr", 1), _t2247)), _t2242));
    L208: for (let _i208 = 0; _i208 < _it208.keys.length; _i208++) {
      v_fns = _it208.vals[_i208];
      v_mod = _it208.keys[_i208];
      Z.setLine(1172);
      {
        const _it209 = Z.foreachArr(Z.dup(v_fns));
        L209: for (let _i209 = 0; _i209 < _it209.keys.length; _i209++) {
          v_ar = _it209.vals[_i209];
          v_fn = _it209.keys[_i209];
          Z.setLine(1173);
          if (Z.truthy((Z.truthy(Z.ident(v_mod, "System")) && Z.truthy(Z.ident(v_fn, "exit"))))) {
            continue L209;
          }
          Z.setLine(1174);
          (v_n = (Z.truthy((Z.cmp(v_ar, 0) < 0)) ? 2 : v_ar));
          Z.setLine(1175);
          (v_ps = ((_t2248 = Z.arrNew()), _t2248));
          Z.setLine(1176);
          (v_i = 0);
          L210: for (; Z.truthy((Z.cmp(v_i, v_n) < 0)); ((_t2249 = v_i), (v_i = Z.add(_t2249, 1)), _t2249)) {
            Z.setLine(1176);
            Z.apush((v_ps = Z.wr(v_ps)), Z.dup(v_v));
          }
          Z.setLine(1177);
          Z.apush((v_d = Z.wr(v_d)), Z.concat(Z.concat(Z.concat(Z.concat(Z.concat(Z.concat("declare { i64, i64 } @m_", v_mod), "_"), v_fn), "("), Z.B.join(v_ps, ", ")), ")"));
        }
      }
    }
  }
  Z.setLine(1180);
  return Z.dup(v_d);
  return null;
}
function f_LlEmitter__new(v_ir) {
  let v___o = null;
  Z.setLine(13);
  (v___o = Z.B.zs_obj_new("LlEmitter"));
  Z.setLine(13);
  Z.B.zs_obj_set(v___o, "ir", null);
  Z.setLine(13);
  Z.B.zs_obj_set(v___o, "code", null);
  Z.setLine(13);
  Z.B.zs_obj_set(v___o, "allocas", null);
  Z.setLine(13);
  Z.B.zs_obj_set(v___o, "globals", null);
  Z.setLine(13);
  Z.B.zs_obj_set(v___o, "strs", null);
  Z.setLine(13);
  Z.B.zs_obj_set(v___o, "strList", null);
  Z.setLine(13);
  Z.B.zs_obj_set(v___o, "cstrs", null);
  Z.setLine(13);
  Z.B.zs_obj_set(v___o, "cstrList", null);
  Z.setLine(13);
  Z.B.zs_obj_set(v___o, "floats", null);
  Z.setLine(13);
  Z.B.zs_obj_set(v___o, "tmp", null);
  Z.setLine(13);
  Z.B.zs_obj_set(v___o, "lbl", null);
  Z.setLine(13);
  Z.B.zs_obj_set(v___o, "loops", null);
  Z.setLine(13);
  Z.B.zs_obj_set(v___o, "loopId", null);
  Z.setLine(13);
  Z.B.zs_obj_set(v___o, "fnCounts", null);
  Z.setLine(13);
  Z.B.zs_obj_set(v___o, "rdStack", null);
  Z.setLine(13);
  Z.B.zs_obj_set(v___o, "tries", null);
  Z.setLine(13);
  Z.B.zs_obj_set(v___o, "hid", null);
  Z.setLine(13);
  Z.B.zs_obj_set(v___o, "curFunc", null);
  Z.setLine(13);
  Z.B.zs_obj_set(v___o, "term", null);
  Z.setLine(13);
  Z.B.zs_obj_set(v___o, "vol", null);
  Z.setLine(13);
  Z.B.zs_obj_set(v___o, "known", null);
  Z.setLine(13);
  Z.B.zs_obj_set(v___o, "slotN", null);
  Z.setLine(13);
  f_LlEmitter____construct(Z.dup(v___o), Z.dup(v_ir));
  Z.setLine(13);
  return Z.dup(v___o);
  return null;
}
function f_Exception____construct(v_this, v_message) {
  Z.setLine(1);
  Z.B.zs_obj_set(v_this, "message", v_message);
  return null;
}
function f_Exception__getMessage(v_this) {
  Z.setLine(1);
  return Z.B.zs_obj_get(v_this, "message");
  return null;
}
function f_Exception__new(v_message) {
  let v___o = null;
  Z.setLine(1);
  (v___o = Z.B.zs_obj_new("Exception"));
  Z.setLine(1);
  Z.B.zs_obj_set(v___o, "message", "");
  Z.setLine(1);
  Z.B.zs_obj_set(v___o, "line", 0);
  Z.setLine(1);
  f_Exception____construct(Z.dup(v___o), Z.dup(v_message));
  Z.setLine(1);
  return Z.dup(v___o);
  return null;
}
function f_Error__new(v_message) {
  let v___o = null;
  Z.setLine(1);
  (v___o = Z.B.zs_obj_new("Error"));
  Z.setLine(1);
  Z.B.zs_obj_set(v___o, "message", "");
  Z.setLine(1);
  Z.B.zs_obj_set(v___o, "line", 0);
  Z.setLine(1);
  f_Exception____construct(Z.dup(v___o), Z.dup(v_message));
  Z.setLine(1);
  return Z.dup(v___o);
  return null;
}
function f_Exception__getMessage__w(v_this, v_args) {
  Z.setLine(1);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 0) >= 0))) {
    Z.setLine(1);
    return f_Exception__getMessage(Z.dup(v_this));
  }
  Z.setLine(1);
  return null;
  return null;
}
function f_Lexer__peek__w(v_this, v_args) {
  Z.setLine(54);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(54);
    return f_Lexer__peek(Z.dup(v_this), 0);
  }
  Z.setLine(54);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 1) >= 0))) {
    Z.setLine(54);
    return f_Lexer__peek(Z.dup(v_this), Z.dup(Z.index(v_args, 0)));
  }
  Z.setLine(54);
  return null;
  return null;
}
function f_Lexer__bump__w(v_this, v_args) {
  Z.setLine(58);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 0) >= 0))) {
    Z.setLine(58);
    return f_Lexer__bump(Z.dup(v_this));
  }
  Z.setLine(58);
  return null;
  return null;
}
function f_Lexer__fail__w(v_this, v_args) {
  Z.setLine(70);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(70);
    Z.raise(new Z.ZExc(1, "fail: brak argumentu $msg"));
  }
  Z.setLine(70);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 1))) {
    Z.setLine(70);
    Z.raise(new Z.ZExc(1, "fail: brak argumentu $line"));
  }
  Z.setLine(70);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 2))) {
    Z.setLine(70);
    Z.raise(new Z.ZExc(1, "fail: brak argumentu $col"));
  }
  Z.setLine(70);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 3) >= 0))) {
    Z.setLine(70);
    return f_Lexer__fail(Z.dup(v_this), Z.dup(Z.index(v_args, 0)), Z.dup(Z.index(v_args, 1)), Z.dup(Z.index(v_args, 2)));
  }
  Z.setLine(70);
  return null;
  return null;
}
function f_Lexer__emit__w(v_this, v_args) {
  Z.setLine(72);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(72);
    Z.raise(new Z.ZExc(1, "emit: brak argumentu $kind"));
  }
  Z.setLine(72);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 1))) {
    Z.setLine(72);
    Z.raise(new Z.ZExc(1, "emit: brak argumentu $text"));
  }
  Z.setLine(72);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 2))) {
    Z.setLine(72);
    Z.raise(new Z.ZExc(1, "emit: brak argumentu $start"));
  }
  Z.setLine(72);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 3))) {
    Z.setLine(72);
    Z.raise(new Z.ZExc(1, "emit: brak argumentu $line"));
  }
  Z.setLine(72);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 4))) {
    Z.setLine(72);
    Z.raise(new Z.ZExc(1, "emit: brak argumentu $col"));
  }
  Z.setLine(72);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 5))) {
    Z.setLine(72);
    return f_Lexer__emit(Z.dup(v_this), Z.dup(Z.index(v_args, 0)), Z.dup(Z.index(v_args, 1)), Z.dup(Z.index(v_args, 2)), Z.dup(Z.index(v_args, 3)), Z.dup(Z.index(v_args, 4)), null);
  }
  Z.setLine(72);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 6) >= 0))) {
    Z.setLine(72);
    return f_Lexer__emit(Z.dup(v_this), Z.dup(Z.index(v_args, 0)), Z.dup(Z.index(v_args, 1)), Z.dup(Z.index(v_args, 2)), Z.dup(Z.index(v_args, 3)), Z.dup(Z.index(v_args, 4)), Z.dup(Z.index(v_args, 5)));
  }
  Z.setLine(72);
  return null;
  return null;
}
function f_Lexer__run__w(v_this, v_args) {
  Z.setLine(77);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 0) >= 0))) {
    Z.setLine(77);
    return f_Lexer__run(Z.dup(v_this));
  }
  Z.setLine(77);
  return null;
  return null;
}
function f_Lexer__skipTrivia__w(v_this, v_args) {
  Z.setLine(98);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 0) >= 0))) {
    Z.setLine(98);
    return f_Lexer__skipTrivia(Z.dup(v_this));
  }
  Z.setLine(98);
  return null;
  return null;
}
function f_Lexer__variable__w(v_this, v_args) {
  Z.setLine(139);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(139);
    Z.raise(new Z.ZExc(1, "variable: brak argumentu $start"));
  }
  Z.setLine(139);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 1))) {
    Z.setLine(139);
    Z.raise(new Z.ZExc(1, "variable: brak argumentu $line"));
  }
  Z.setLine(139);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 2))) {
    Z.setLine(139);
    Z.raise(new Z.ZExc(1, "variable: brak argumentu $col"));
  }
  Z.setLine(139);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 3) >= 0))) {
    Z.setLine(139);
    return f_Lexer__variable(Z.dup(v_this), Z.dup(Z.index(v_args, 0)), Z.dup(Z.index(v_args, 1)), Z.dup(Z.index(v_args, 2)));
  }
  Z.setLine(139);
  return null;
  return null;
}
function f_Lexer__ident__w(v_this, v_args) {
  Z.setLine(148);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(148);
    Z.raise(new Z.ZExc(1, "ident: brak argumentu $start"));
  }
  Z.setLine(148);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 1))) {
    Z.setLine(148);
    Z.raise(new Z.ZExc(1, "ident: brak argumentu $line"));
  }
  Z.setLine(148);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 2))) {
    Z.setLine(148);
    Z.raise(new Z.ZExc(1, "ident: brak argumentu $col"));
  }
  Z.setLine(148);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 3) >= 0))) {
    Z.setLine(148);
    return f_Lexer__ident(Z.dup(v_this), Z.dup(Z.index(v_args, 0)), Z.dup(Z.index(v_args, 1)), Z.dup(Z.index(v_args, 2)));
  }
  Z.setLine(148);
  return null;
  return null;
}
function f_Lexer__digitValue__w(v_this, v_args) {
  Z.setLine(154);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(154);
    Z.raise(new Z.ZExc(1, "digitValue: brak argumentu $c"));
  }
  Z.setLine(154);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 1) >= 0))) {
    Z.setLine(154);
    return f_Lexer__digitValue(Z.dup(v_this), Z.dup(Z.index(v_args, 0)));
  }
  Z.setLine(154);
  return null;
  return null;
}
function f_Lexer__digits__w(v_this, v_args) {
  Z.setLine(163);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 0) >= 0))) {
    Z.setLine(163);
    return f_Lexer__digits(Z.dup(v_this));
  }
  Z.setLine(163);
  return null;
  return null;
}
function f_Lexer__number__w(v_this, v_args) {
  Z.setLine(167);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(167);
    Z.raise(new Z.ZExc(1, "number: brak argumentu $start"));
  }
  Z.setLine(167);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 1))) {
    Z.setLine(167);
    Z.raise(new Z.ZExc(1, "number: brak argumentu $line"));
  }
  Z.setLine(167);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 2))) {
    Z.setLine(167);
    Z.raise(new Z.ZExc(1, "number: brak argumentu $col"));
  }
  Z.setLine(167);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 3) >= 0))) {
    Z.setLine(167);
    return f_Lexer__number(Z.dup(v_this), Z.dup(Z.index(v_args, 0)), Z.dup(Z.index(v_args, 1)), Z.dup(Z.index(v_args, 2)));
  }
  Z.setLine(167);
  return null;
  return null;
}
function f_Lexer__string__w(v_this, v_args) {
  Z.setLine(210);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(210);
    Z.raise(new Z.ZExc(1, "string: brak argumentu $q"));
  }
  Z.setLine(210);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 1))) {
    Z.setLine(210);
    Z.raise(new Z.ZExc(1, "string: brak argumentu $start"));
  }
  Z.setLine(210);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 2))) {
    Z.setLine(210);
    Z.raise(new Z.ZExc(1, "string: brak argumentu $line"));
  }
  Z.setLine(210);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 3))) {
    Z.setLine(210);
    Z.raise(new Z.ZExc(1, "string: brak argumentu $col"));
  }
  Z.setLine(210);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 4) >= 0))) {
    Z.setLine(210);
    return f_Lexer__string(Z.dup(v_this), Z.dup(Z.index(v_args, 0)), Z.dup(Z.index(v_args, 1)), Z.dup(Z.index(v_args, 2)), Z.dup(Z.index(v_args, 3)));
  }
  Z.setLine(210);
  return null;
  return null;
}
function f_Lexer__op__w(v_this, v_args) {
  Z.setLine(232);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(232);
    Z.raise(new Z.ZExc(1, "op: brak argumentu $start"));
  }
  Z.setLine(232);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 1))) {
    Z.setLine(232);
    Z.raise(new Z.ZExc(1, "op: brak argumentu $line"));
  }
  Z.setLine(232);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 2))) {
    Z.setLine(232);
    Z.raise(new Z.ZExc(1, "op: brak argumentu $col"));
  }
  Z.setLine(232);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 3) >= 0))) {
    Z.setLine(232);
    return f_Lexer__op(Z.dup(v_this), Z.dup(Z.index(v_args, 0)), Z.dup(Z.index(v_args, 1)), Z.dup(Z.index(v_args, 2)));
  }
  Z.setLine(232);
  return null;
  return null;
}
function f_Parser__cur__w(v_this, v_args) {
  Z.setLine(68);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 0) >= 0))) {
    Z.setLine(68);
    return f_Parser__cur(Z.dup(v_this));
  }
  Z.setLine(68);
  return null;
  return null;
}
function f_Parser__at__w(v_this, v_args) {
  Z.setLine(69);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(69);
    Z.raise(new Z.ZExc(1, "at: brak argumentu $n"));
  }
  Z.setLine(69);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 1) >= 0))) {
    Z.setLine(69);
    return f_Parser__at(Z.dup(v_this), Z.dup(Z.index(v_args, 0)));
  }
  Z.setLine(69);
  return null;
  return null;
}
function f_Parser__line__w(v_this, v_args) {
  Z.setLine(70);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 0) >= 0))) {
    Z.setLine(70);
    return f_Parser__line(Z.dup(v_this));
  }
  Z.setLine(70);
  return null;
  return null;
}
function f_Parser__atEof__w(v_this, v_args) {
  Z.setLine(71);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 0) >= 0))) {
    Z.setLine(71);
    return f_Parser__atEof(Z.dup(v_this));
  }
  Z.setLine(71);
  return null;
  return null;
}
function f_Parser__bump__w(v_this, v_args) {
  Z.setLine(72);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 0) >= 0))) {
    Z.setLine(72);
    return f_Parser__bump(Z.dup(v_this));
  }
  Z.setLine(72);
  return null;
  return null;
}
function f_Parser__back__w(v_this, v_args) {
  Z.setLine(73);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 0) >= 0))) {
    Z.setLine(73);
    return f_Parser__back(Z.dup(v_this));
  }
  Z.setLine(73);
  return null;
  return null;
}
function f_Parser__fail__w(v_this, v_args) {
  Z.setLine(74);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(74);
    Z.raise(new Z.ZExc(1, "fail: brak argumentu $msg"));
  }
  Z.setLine(74);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 1) >= 0))) {
    Z.setLine(74);
    return f_Parser__fail(Z.dup(v_this), Z.dup(Z.index(v_args, 0)));
  }
  Z.setLine(74);
  return null;
  return null;
}
function f_Parser__isOp__w(v_this, v_args) {
  Z.setLine(75);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(75);
    Z.raise(new Z.ZExc(1, "isOp: brak argumentu $s"));
  }
  Z.setLine(75);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 1) >= 0))) {
    Z.setLine(75);
    return f_Parser__isOp(Z.dup(v_this), Z.dup(Z.index(v_args, 0)));
  }
  Z.setLine(75);
  return null;
  return null;
}
function f_Parser__isKw__w(v_this, v_args) {
  Z.setLine(76);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(76);
    Z.raise(new Z.ZExc(1, "isKw: brak argumentu $s"));
  }
  Z.setLine(76);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 1) >= 0))) {
    Z.setLine(76);
    return f_Parser__isKw(Z.dup(v_this), Z.dup(Z.index(v_args, 0)));
  }
  Z.setLine(76);
  return null;
  return null;
}
function f_Parser__isWord__w(v_this, v_args) {
  Z.setLine(77);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(77);
    Z.raise(new Z.ZExc(1, "isWord: brak argumentu $s"));
  }
  Z.setLine(77);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 1) >= 0))) {
    Z.setLine(77);
    return f_Parser__isWord(Z.dup(v_this), Z.dup(Z.index(v_args, 0)));
  }
  Z.setLine(77);
  return null;
  return null;
}
function f_Parser__isVar__w(v_this, v_args) {
  Z.setLine(78);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 0) >= 0))) {
    Z.setLine(78);
    return f_Parser__isVar(Z.dup(v_this));
  }
  Z.setLine(78);
  return null;
  return null;
}
function f_Parser__eatOp__w(v_this, v_args) {
  Z.setLine(79);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(79);
    Z.raise(new Z.ZExc(1, "eatOp: brak argumentu $s"));
  }
  Z.setLine(79);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 1) >= 0))) {
    Z.setLine(79);
    return f_Parser__eatOp(Z.dup(v_this), Z.dup(Z.index(v_args, 0)));
  }
  Z.setLine(79);
  return null;
  return null;
}
function f_Parser__eatKw__w(v_this, v_args) {
  Z.setLine(80);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(80);
    Z.raise(new Z.ZExc(1, "eatKw: brak argumentu $s"));
  }
  Z.setLine(80);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 1) >= 0))) {
    Z.setLine(80);
    return f_Parser__eatKw(Z.dup(v_this), Z.dup(Z.index(v_args, 0)));
  }
  Z.setLine(80);
  return null;
  return null;
}
function f_Parser__eatWord__w(v_this, v_args) {
  Z.setLine(81);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(81);
    Z.raise(new Z.ZExc(1, "eatWord: brak argumentu $s"));
  }
  Z.setLine(81);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 1) >= 0))) {
    Z.setLine(81);
    return f_Parser__eatWord(Z.dup(v_this), Z.dup(Z.index(v_args, 0)));
  }
  Z.setLine(81);
  return null;
  return null;
}
function f_Parser__expectOp__w(v_this, v_args) {
  Z.setLine(82);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(82);
    Z.raise(new Z.ZExc(1, "expectOp: brak argumentu $s"));
  }
  Z.setLine(82);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 1) >= 0))) {
    Z.setLine(82);
    return f_Parser__expectOp(Z.dup(v_this), Z.dup(Z.index(v_args, 0)));
  }
  Z.setLine(82);
  return null;
  return null;
}
function f_Parser__ident__w(v_this, v_args) {
  Z.setLine(85);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 0) >= 0))) {
    Z.setLine(85);
    return f_Parser__ident(Z.dup(v_this));
  }
  Z.setLine(85);
  return null;
  return null;
}
function f_Parser__varName__w(v_this, v_args) {
  Z.setLine(90);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 0) >= 0))) {
    Z.setLine(90);
    return f_Parser__varName(Z.dup(v_this));
  }
  Z.setLine(90);
  return null;
  return null;
}
function f_Parser__isFuncKw__w(v_this, v_args) {
  Z.setLine(95);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 0) >= 0))) {
    Z.setLine(95);
    return f_Parser__isFuncKw(Z.dup(v_this));
  }
  Z.setLine(95);
  return null;
  return null;
}
function f_Parser__block__w(v_this, v_args) {
  Z.setLine(98);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 0) >= 0))) {
    Z.setLine(98);
    return f_Parser__block(Z.dup(v_this));
  }
  Z.setLine(98);
  return null;
  return null;
}
function f_Parser__body__w(v_this, v_args) {
  Z.setLine(109);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 0) >= 0))) {
    Z.setLine(109);
    return f_Parser__body(Z.dup(v_this));
  }
  Z.setLine(109);
  return null;
  return null;
}
function f_Parser__parenExpr__w(v_this, v_args) {
  Z.setLine(114);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 0) >= 0))) {
    Z.setLine(114);
    return f_Parser__parenExpr(Z.dup(v_this));
  }
  Z.setLine(114);
  return null;
  return null;
}
function f_Parser__path__w(v_this, v_args) {
  Z.setLine(121);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 0) >= 0))) {
    Z.setLine(121);
    return f_Parser__path(Z.dup(v_this));
  }
  Z.setLine(121);
  return null;
  return null;
}
function f_Parser__stmt__w(v_this, v_args) {
  Z.setLine(127);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 0) >= 0))) {
    Z.setLine(127);
    return f_Parser__stmt(Z.dup(v_this));
  }
  Z.setLine(127);
  return null;
  return null;
}
function f_Parser__ifRest__w(v_this, v_args) {
  Z.setLine(194);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(194);
    Z.raise(new Z.ZExc(1, "ifRest: brak argumentu $line"));
  }
  Z.setLine(194);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 1) >= 0))) {
    Z.setLine(194);
    return f_Parser__ifRest(Z.dup(v_this), Z.dup(Z.index(v_args, 0)));
  }
  Z.setLine(194);
  return null;
  return null;
}
function f_Parser__exprList__w(v_this, v_args) {
  Z.setLine(208);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(208);
    Z.raise(new Z.ZExc(1, "exprList: brak argumentu $close"));
  }
  Z.setLine(208);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 1) >= 0))) {
    Z.setLine(208);
    return f_Parser__exprList(Z.dup(v_this), Z.dup(Z.index(v_args, 0)));
  }
  Z.setLine(208);
  return null;
  return null;
}
function f_Parser__forStmt__w(v_this, v_args) {
  Z.setLine(217);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(217);
    Z.raise(new Z.ZExc(1, "forStmt: brak argumentu $line"));
  }
  Z.setLine(217);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 1) >= 0))) {
    Z.setLine(217);
    return f_Parser__forStmt(Z.dup(v_this), Z.dup(Z.index(v_args, 0)));
  }
  Z.setLine(217);
  return null;
  return null;
}
function f_Parser__foreachStmt__w(v_this, v_args) {
  Z.setLine(229);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(229);
    Z.raise(new Z.ZExc(1, "foreachStmt: brak argumentu $line"));
  }
  Z.setLine(229);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 1) >= 0))) {
    Z.setLine(229);
    return f_Parser__foreachStmt(Z.dup(v_this), Z.dup(Z.index(v_args, 0)));
  }
  Z.setLine(229);
  return null;
  return null;
}
function f_Parser__switchStmt__w(v_this, v_args) {
  Z.setLine(242);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(242);
    Z.raise(new Z.ZExc(1, "switchStmt: brak argumentu $line"));
  }
  Z.setLine(242);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 1) >= 0))) {
    Z.setLine(242);
    return f_Parser__switchStmt(Z.dup(v_this), Z.dup(Z.index(v_args, 0)));
  }
  Z.setLine(242);
  return null;
  return null;
}
function f_Parser__tryStmt__w(v_this, v_args) {
  Z.setLine(264);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(264);
    Z.raise(new Z.ZExc(1, "tryStmt: brak argumentu $line"));
  }
  Z.setLine(264);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 1) >= 0))) {
    Z.setLine(264);
    return f_Parser__tryStmt(Z.dup(v_this), Z.dup(Z.index(v_args, 0)));
  }
  Z.setLine(264);
  return null;
  return null;
}
function f_Parser__externStmt__w(v_this, v_args) {
  Z.setLine(284);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(284);
    Z.raise(new Z.ZExc(1, "externStmt: brak argumentu $line"));
  }
  Z.setLine(284);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 1) >= 0))) {
    Z.setLine(284);
    return f_Parser__externStmt(Z.dup(v_this), Z.dup(Z.index(v_args, 0)));
  }
  Z.setLine(284);
  return null;
  return null;
}
function f_Parser__types__w(v_this, v_args) {
  Z.setLine(306);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 0) >= 0))) {
    Z.setLine(306);
    return f_Parser__types(Z.dup(v_this));
  }
  Z.setLine(306);
  return null;
  return null;
}
function f_Parser__params__w(v_this, v_args) {
  Z.setLine(321);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 0) >= 0))) {
    Z.setLine(321);
    return f_Parser__params(Z.dup(v_this));
  }
  Z.setLine(321);
  return null;
  return null;
}
function f_Parser__funcRest__w(v_this, v_args) {
  Z.setLine(336);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(336);
    Z.raise(new Z.ZExc(1, "funcRest: brak argumentu $named"));
  }
  Z.setLine(336);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 1) >= 0))) {
    Z.setLine(336);
    return f_Parser__funcRest(Z.dup(v_this), Z.dup(Z.index(v_args, 0)));
  }
  Z.setLine(336);
  return null;
  return null;
}
function f_Parser__classDecl__w(v_this, v_args) {
  Z.setLine(345);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(345);
    Z.raise(new Z.ZExc(1, "classDecl: brak argumentu $line"));
  }
  Z.setLine(345);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 1) >= 0))) {
    Z.setLine(345);
    return f_Parser__classDecl(Z.dup(v_this), Z.dup(Z.index(v_args, 0)));
  }
  Z.setLine(345);
  return null;
  return null;
}
function f_Parser__expr__w(v_this, v_args) {
  Z.setLine(404);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 0) >= 0))) {
    Z.setLine(404);
    return f_Parser__expr(Z.dup(v_this));
  }
  Z.setLine(404);
  return null;
  return null;
}
function f_Parser__checkLvalue__w(v_this, v_args) {
  Z.setLine(406);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(406);
    Z.raise(new Z.ZExc(1, "checkLvalue: brak argumentu $e"));
  }
  Z.setLine(406);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 1) >= 0))) {
    Z.setLine(406);
    return f_Parser__checkLvalue(Z.dup(v_this), Z.dup(Z.index(v_args, 0)));
  }
  Z.setLine(406);
  return null;
  return null;
}
function f_Parser__exprBp__w(v_this, v_args) {
  Z.setLine(412);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(412);
    Z.raise(new Z.ZExc(1, "exprBp: brak argumentu $min"));
  }
  Z.setLine(412);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 1) >= 0))) {
    Z.setLine(412);
    return f_Parser__exprBp(Z.dup(v_this), Z.dup(Z.index(v_args, 0)));
  }
  Z.setLine(412);
  return null;
  return null;
}
function f_Parser__unary__w(v_this, v_args) {
  Z.setLine(451);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 0) >= 0))) {
    Z.setLine(451);
    return f_Parser__unary(Z.dup(v_this));
  }
  Z.setLine(451);
  return null;
  return null;
}
function f_Parser__args__w(v_this, v_args) {
  Z.setLine(477);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 0) >= 0))) {
    Z.setLine(477);
    return f_Parser__args(Z.dup(v_this));
  }
  Z.setLine(477);
  return null;
  return null;
}
function f_Parser__postfix__w(v_this, v_args) {
  Z.setLine(494);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 0) >= 0))) {
    Z.setLine(494);
    return f_Parser__postfix(Z.dup(v_this));
  }
  Z.setLine(494);
  return null;
  return null;
}
function f_Parser__primary__w(v_this, v_args) {
  Z.setLine(526);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 0) >= 0))) {
    Z.setLine(526);
    return f_Parser__primary(Z.dup(v_this));
  }
  Z.setLine(526);
  return null;
  return null;
}
function f_Parser__matchExpr__w(v_this, v_args) {
  Z.setLine(587);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(587);
    Z.raise(new Z.ZExc(1, "matchExpr: brak argumentu $line"));
  }
  Z.setLine(587);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 1) >= 0))) {
    Z.setLine(587);
    return f_Parser__matchExpr(Z.dup(v_this), Z.dup(Z.index(v_args, 0)));
  }
  Z.setLine(587);
  return null;
  return null;
}
function f_Bundler__scan__w(v_this, v_args) {
  Z.setLine(18);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(18);
    Z.raise(new Z.ZExc(1, "scan: brak argumentu $stmts"));
  }
  Z.setLine(18);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 1))) {
    Z.setLine(18);
    Z.raise(new Z.ZExc(1, "scan: brak argumentu $dir"));
  }
  Z.setLine(18);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 2) >= 0))) {
    Z.setLine(18);
    return f_Bundler__scan(Z.dup(v_this), Z.dup(Z.index(v_args, 0)), Z.dup(Z.index(v_args, 1)));
  }
  Z.setLine(18);
  return null;
  return null;
}
function f_SemaScope__raise__w(v_this, v_args) {
  Z.setLine(42);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(42);
    Z.raise(new Z.ZExc(1, "raise: brak argumentu $v"));
  }
  Z.setLine(42);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 1))) {
    Z.setLine(42);
    Z.raise(new Z.ZExc(1, "raise: brak argumentu $lv"));
  }
  Z.setLine(42);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 2) >= 0))) {
    Z.setLine(42);
    return f_SemaScope__raise(Z.dup(v_this), Z.dup(Z.index(v_args, 0)), Z.dup(Z.index(v_args, 1)));
  }
  Z.setLine(42);
  return null;
  return null;
}
function f_Analyzer__baseVar__w(v_this, v_args) {
  Z.setLine(57);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(57);
    Z.raise(new Z.ZExc(1, "baseVar: brak argumentu $e"));
  }
  Z.setLine(57);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 1) >= 0))) {
    Z.setLine(57);
    return f_Analyzer__baseVar(Z.dup(v_this), Z.dup(Z.index(v_args, 0)));
  }
  Z.setLine(57);
  return null;
  return null;
}
function f_Analyzer__allocKind__w(v_this, v_args) {
  Z.setLine(62);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(62);
    Z.raise(new Z.ZExc(1, "allocKind: brak argumentu $e"));
  }
  Z.setLine(62);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 1) >= 0))) {
    Z.setLine(62);
    return f_Analyzer__allocKind(Z.dup(v_this), Z.dup(Z.index(v_args, 0)));
  }
  Z.setLine(62);
  return null;
  return null;
}
function f_Analyzer__valueVars__w(v_this, v_args) {
  Z.setLine(70);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(70);
    Z.raise(new Z.ZExc(1, "valueVars: brak argumentu $e"));
  }
  Z.setLine(70);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 1) >= 0))) {
    Z.setLine(70);
    return f_Analyzer__valueVars(Z.dup(v_this), Z.dup(Z.index(v_args, 0)));
  }
  Z.setLine(70);
  return null;
  return null;
}
function f_Analyzer__visitAny__w(v_this, v_args) {
  Z.setLine(87);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(87);
    Z.raise(new Z.ZExc(1, "visitAny: brak argumentu $x"));
  }
  Z.setLine(87);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 1))) {
    Z.setLine(87);
    Z.raise(new Z.ZExc(1, "visitAny: brak argumentu $sc"));
  }
  Z.setLine(87);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 2))) {
    Z.setLine(87);
    Z.raise(new Z.ZExc(1, "visitAny: brak argumentu $prefix"));
  }
  Z.setLine(87);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 3) >= 0))) {
    Z.setLine(87);
    return f_Analyzer__visitAny(Z.dup(v_this), Z.dup(Z.index(v_args, 0)), Z.dup(Z.index(v_args, 1)), Z.dup(Z.index(v_args, 2)));
  }
  Z.setLine(87);
  return null;
  return null;
}
function f_Analyzer__visitChildren__w(v_this, v_args) {
  Z.setLine(92);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(92);
    Z.raise(new Z.ZExc(1, "visitChildren: brak argumentu $n"));
  }
  Z.setLine(92);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 1))) {
    Z.setLine(92);
    Z.raise(new Z.ZExc(1, "visitChildren: brak argumentu $sc"));
  }
  Z.setLine(92);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 2))) {
    Z.setLine(92);
    Z.raise(new Z.ZExc(1, "visitChildren: brak argumentu $prefix"));
  }
  Z.setLine(92);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 3) >= 0))) {
    Z.setLine(92);
    return f_Analyzer__visitChildren(Z.dup(v_this), Z.dup(Z.index(v_args, 0)), Z.dup(Z.index(v_args, 1)), Z.dup(Z.index(v_args, 2)));
  }
  Z.setLine(92);
  return null;
  return null;
}
function f_Analyzer__visit__w(v_this, v_args) {
  Z.setLine(96);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(96);
    Z.raise(new Z.ZExc(1, "visit: brak argumentu $n"));
  }
  Z.setLine(96);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 1))) {
    Z.setLine(96);
    Z.raise(new Z.ZExc(1, "visit: brak argumentu $sc"));
  }
  Z.setLine(96);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 2))) {
    Z.setLine(96);
    Z.raise(new Z.ZExc(1, "visit: brak argumentu $prefix"));
  }
  Z.setLine(96);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 3) >= 0))) {
    Z.setLine(96);
    return f_Analyzer__visit(Z.dup(v_this), Z.dup(Z.index(v_args, 0)), Z.dup(Z.index(v_args, 1)), Z.dup(Z.index(v_args, 2)));
  }
  Z.setLine(96);
  return null;
  return null;
}
function f_Analyzer__fnScope__w(v_this, v_args) {
  Z.setLine(199);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(199);
    Z.raise(new Z.ZExc(1, "fnScope: brak argumentu $decl"));
  }
  Z.setLine(199);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 1))) {
    Z.setLine(199);
    Z.raise(new Z.ZExc(1, "fnScope: brak argumentu $prefix"));
  }
  Z.setLine(199);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 2))) {
    Z.setLine(199);
    Z.raise(new Z.ZExc(1, "fnScope: brak argumentu $isClosure"));
  }
  Z.setLine(199);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 3))) {
    Z.setLine(199);
    Z.raise(new Z.ZExc(1, "fnScope: brak argumentu $parent"));
  }
  Z.setLine(199);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 4) >= 0))) {
    Z.setLine(199);
    return f_Analyzer__fnScope(Z.dup(v_this), Z.dup(Z.index(v_args, 0)), Z.dup(Z.index(v_args, 1)), Z.dup(Z.index(v_args, 2)), Z.dup(Z.index(v_args, 3)));
  }
  Z.setLine(199);
  return null;
  return null;
}
function f_Analyzer__resolveChildren__w(v_this, v_args) {
  Z.setLine(216);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(216);
    Z.raise(new Z.ZExc(1, "resolveChildren: brak argumentu $sc"));
  }
  Z.setLine(216);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 1) >= 0))) {
    Z.setLine(216);
    return f_Analyzer__resolveChildren(Z.dup(v_this), Z.dup(Z.index(v_args, 0)));
  }
  Z.setLine(216);
  return null;
  return null;
}
function f_Analyzer__finish__w(v_this, v_args) {
  Z.setLine(227);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(227);
    Z.raise(new Z.ZExc(1, "finish: brak argumentu $sc"));
  }
  Z.setLine(227);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 1))) {
    Z.setLine(227);
    Z.raise(new Z.ZExc(1, "finish: brak argumentu $report"));
  }
  Z.setLine(227);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 2) >= 0))) {
    Z.setLine(227);
    return f_Analyzer__finish(Z.dup(v_this), Z.dup(Z.index(v_args, 0)), Z.dup(Z.index(v_args, 1)));
  }
  Z.setLine(227);
  return null;
  return null;
}
function f_Lowerer__err__w(v_this, v_args) {
  Z.setLine(55);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(55);
    Z.raise(new Z.ZExc(1, "err: brak argumentu $line"));
  }
  Z.setLine(55);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 1))) {
    Z.setLine(55);
    Z.raise(new Z.ZExc(1, "err: brak argumentu $code"));
  }
  Z.setLine(55);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 2))) {
    Z.setLine(55);
    Z.raise(new Z.ZExc(1, "err: brak argumentu $msg"));
  }
  Z.setLine(55);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 3) >= 0))) {
    Z.setLine(55);
    return f_Lowerer__err(Z.dup(v_this), Z.dup(Z.index(v_args, 0)), Z.dup(Z.index(v_args, 1)), Z.dup(Z.index(v_args, 2)));
  }
  Z.setLine(55);
  return null;
  return null;
}
function f_Lowerer__addLocal__w(v_this, v_args) {
  Z.setLine(58);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(58);
    Z.raise(new Z.ZExc(1, "addLocal: brak argumentu $locals"));
  }
  Z.setLine(58);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 1))) {
    Z.setLine(58);
    Z.raise(new Z.ZExc(1, "addLocal: brak argumentu $name"));
  }
  Z.setLine(58);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 2) >= 0))) {
    Z.setLine(58);
    return f_Lowerer__addLocal(Z.dup(v_this), Z.dup(Z.index(v_args, 0)), Z.dup(Z.index(v_args, 1)));
  }
  Z.setLine(58);
  return null;
  return null;
}
function f_Lowerer__collectExpr__w(v_this, v_args) {
  Z.setLine(63);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(63);
    Z.raise(new Z.ZExc(1, "collectExpr: brak argumentu $e"));
  }
  Z.setLine(63);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 1))) {
    Z.setLine(63);
    Z.raise(new Z.ZExc(1, "collectExpr: brak argumentu $locals"));
  }
  Z.setLine(63);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 2) >= 0))) {
    Z.setLine(63);
    return f_Lowerer__collectExpr(Z.dup(v_this), Z.dup(Z.index(v_args, 0)), Z.dup(Z.index(v_args, 1)));
  }
  Z.setLine(63);
  return null;
  return null;
}
function f_Lowerer__collectTarget__w(v_this, v_args) {
  Z.setLine(73);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(73);
    Z.raise(new Z.ZExc(1, "collectTarget: brak argumentu $t"));
  }
  Z.setLine(73);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 1))) {
    Z.setLine(73);
    Z.raise(new Z.ZExc(1, "collectTarget: brak argumentu $locals"));
  }
  Z.setLine(73);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 2) >= 0))) {
    Z.setLine(73);
    return f_Lowerer__collectTarget(Z.dup(v_this), Z.dup(Z.index(v_args, 0)), Z.dup(Z.index(v_args, 1)));
  }
  Z.setLine(73);
  return null;
  return null;
}
function f_Lowerer__collectAny__w(v_this, v_args) {
  Z.setLine(79);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(79);
    Z.raise(new Z.ZExc(1, "collectAny: brak argumentu $x"));
  }
  Z.setLine(79);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 1))) {
    Z.setLine(79);
    Z.raise(new Z.ZExc(1, "collectAny: brak argumentu $locals"));
  }
  Z.setLine(79);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 2) >= 0))) {
    Z.setLine(79);
    return f_Lowerer__collectAny(Z.dup(v_this), Z.dup(Z.index(v_args, 0)), Z.dup(Z.index(v_args, 1)));
  }
  Z.setLine(79);
  return null;
  return null;
}
function f_Lowerer__checkStmts__w(v_this, v_args) {
  Z.setLine(93);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(93);
    Z.raise(new Z.ZExc(1, "checkStmts: brak argumentu $list"));
  }
  Z.setLine(93);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 1))) {
    Z.setLine(93);
    Z.raise(new Z.ZExc(1, "checkStmts: brak argumentu $depth"));
  }
  Z.setLine(93);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 2) >= 0))) {
    Z.setLine(93);
    return f_Lowerer__checkStmts(Z.dup(v_this), Z.dup(Z.index(v_args, 0)), Z.dup(Z.index(v_args, 1)));
  }
  Z.setLine(93);
  return null;
  return null;
}
function f_Lowerer__checkStmt__w(v_this, v_args) {
  Z.setLine(95);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(95);
    Z.raise(new Z.ZExc(1, "checkStmt: brak argumentu $s"));
  }
  Z.setLine(95);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 1))) {
    Z.setLine(95);
    Z.raise(new Z.ZExc(1, "checkStmt: brak argumentu $depth"));
  }
  Z.setLine(95);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 2) >= 0))) {
    Z.setLine(95);
    return f_Lowerer__checkStmt(Z.dup(v_this), Z.dup(Z.index(v_args, 0)), Z.dup(Z.index(v_args, 1)));
  }
  Z.setLine(95);
  return null;
  return null;
}
function f_Lowerer__checkNew__w(v_this, v_args) {
  Z.setLine(144);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(144);
    Z.raise(new Z.ZExc(1, "checkNew: brak argumentu $x"));
  }
  Z.setLine(144);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 1) >= 0))) {
    Z.setLine(144);
    return f_Lowerer__checkNew(Z.dup(v_this), Z.dup(Z.index(v_args, 0)));
  }
  Z.setLine(144);
  return null;
  return null;
}
function f_Lowerer__containsTry__w(v_this, v_args) {
  Z.setLine(150);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(150);
    Z.raise(new Z.ZExc(1, "containsTry: brak argumentu $x"));
  }
  Z.setLine(150);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 1) >= 0))) {
    Z.setLine(150);
    return f_Lowerer__containsTry(Z.dup(v_this), Z.dup(Z.index(v_args, 0)));
  }
  Z.setLine(150);
  return null;
  return null;
}
function f_Lowerer__calleeName__w(v_this, v_args) {
  Z.setLine(161);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(161);
    Z.raise(new Z.ZExc(1, "calleeName: brak argumentu $c"));
  }
  Z.setLine(161);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 1) >= 0))) {
    Z.setLine(161);
    return f_Lowerer__calleeName(Z.dup(v_this), Z.dup(Z.index(v_args, 0)));
  }
  Z.setLine(161);
  return null;
  return null;
}
function f_Lowerer__checkExpr__w(v_this, v_args) {
  Z.setLine(166);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(166);
    Z.raise(new Z.ZExc(1, "checkExpr: brak argumentu $e"));
  }
  Z.setLine(166);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 1) >= 0))) {
    Z.setLine(166);
    return f_Lowerer__checkExpr(Z.dup(v_this), Z.dup(Z.index(v_args, 0)));
  }
  Z.setLine(166);
  return null;
  return null;
}
function f_Lowerer__checkLvalue__w(v_this, v_args) {
  Z.setLine(207);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(207);
    Z.raise(new Z.ZExc(1, "checkLvalue: brak argumentu $t"));
  }
  Z.setLine(207);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 1) >= 0))) {
    Z.setLine(207);
    return f_Lowerer__checkLvalue(Z.dup(v_this), Z.dup(Z.index(v_args, 0)));
  }
  Z.setLine(207);
  return null;
  return null;
}
function f_Lowerer__checkCall__w(v_this, v_args) {
  Z.setLine(213);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(213);
    Z.raise(new Z.ZExc(1, "checkCall: brak argumentu $e"));
  }
  Z.setLine(213);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 1) >= 0))) {
    Z.setLine(213);
    return f_Lowerer__checkCall(Z.dup(v_this), Z.dup(Z.index(v_args, 0)));
  }
  Z.setLine(213);
  return null;
  return null;
}
function f_Lowerer__topCallsMain__w(v_this, v_args) {
  Z.setLine(263);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(263);
    Z.raise(new Z.ZExc(1, "topCallsMain: brak argumentu $x"));
  }
  Z.setLine(263);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 1) >= 0))) {
    Z.setLine(263);
    return f_Lowerer__topCallsMain(Z.dup(v_this), Z.dup(Z.index(v_args, 0)));
  }
  Z.setLine(263);
  return null;
  return null;
}
function f_Lifter__err__w(v_this, v_args) {
  Z.setLine(62);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(62);
    Z.raise(new Z.ZExc(1, "err: brak argumentu $line"));
  }
  Z.setLine(62);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 1))) {
    Z.setLine(62);
    Z.raise(new Z.ZExc(1, "err: brak argumentu $m"));
  }
  Z.setLine(62);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 2) >= 0))) {
    Z.setLine(62);
    return f_Lifter__err(Z.dup(v_this), Z.dup(Z.index(v_args, 0)), Z.dup(Z.index(v_args, 1)));
  }
  Z.setLine(62);
  return null;
  return null;
}
function f_Lifter__scan__w(v_this, v_args) {
  Z.setLine(65);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(65);
    Z.raise(new Z.ZExc(1, "scan: brak argumentu $x"));
  }
  Z.setLine(65);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 1) >= 0))) {
    Z.setLine(65);
    return f_Lifter__scan(Z.dup(v_this), Z.dup(Z.index(v_args, 0)));
  }
  Z.setLine(65);
  return null;
  return null;
}
function f_Lifter__names__w(v_this, v_args) {
  Z.setLine(80);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(80);
    Z.raise(new Z.ZExc(1, "names: brak argumentu $x"));
  }
  Z.setLine(80);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 1) >= 0))) {
    Z.setLine(80);
    return f_Lifter__names(Z.dup(v_this), Z.dup(Z.index(v_args, 0)));
  }
  Z.setLine(80);
  return null;
  return null;
}
function f_Lifter__freeOf__w(v_this, v_args) {
  Z.setLine(90);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(90);
    Z.raise(new Z.ZExc(1, "freeOf: brak argumentu $f"));
  }
  Z.setLine(90);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 1) >= 0))) {
    Z.setLine(90);
    return f_Lifter__freeOf(Z.dup(v_this), Z.dup(Z.index(v_args, 0)));
  }
  Z.setLine(90);
  return null;
  return null;
}
function f_Lifter__lift__w(v_this, v_args) {
  Z.setLine(100);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(100);
    Z.raise(new Z.ZExc(1, "lift: brak argumentu $x"));
  }
  Z.setLine(100);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 1))) {
    Z.setLine(100);
    Z.raise(new Z.ZExc(1, "lift: brak argumentu $vis"));
  }
  Z.setLine(100);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 2) >= 0))) {
    Z.setLine(100);
    return f_Lifter__lift(Z.dup(v_this), Z.dup(Z.index(v_args, 0)), Z.dup(Z.index(v_args, 1)));
  }
  Z.setLine(100);
  return null;
  return null;
}
function f_Lifter__rw__w(v_this, v_args) {
  Z.setLine(129);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(129);
    Z.raise(new Z.ZExc(1, "rw: brak argumentu $x"));
  }
  Z.setLine(129);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 1))) {
    Z.setLine(129);
    Z.raise(new Z.ZExc(1, "rw: brak argumentu $vis"));
  }
  Z.setLine(129);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 2) >= 0))) {
    Z.setLine(129);
    return f_Lifter__rw(Z.dup(v_this), Z.dup(Z.index(v_args, 0)), Z.dup(Z.index(v_args, 1)));
  }
  Z.setLine(129);
  return null;
  return null;
}
function f_Lifter__argsArray__w(v_this, v_args) {
  Z.setLine(146);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(146);
    Z.raise(new Z.ZExc(1, "argsArray: brak argumentu $line"));
  }
  Z.setLine(146);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 1))) {
    Z.setLine(146);
    Z.raise(new Z.ZExc(1, "argsArray: brak argumentu $args"));
  }
  Z.setLine(146);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 2))) {
    Z.setLine(146);
    Z.raise(new Z.ZExc(1, "argsArray: brak argumentu $vis"));
  }
  Z.setLine(146);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 3) >= 0))) {
    Z.setLine(146);
    return f_Lifter__argsArray(Z.dup(v_this), Z.dup(Z.index(v_args, 0)), Z.dup(Z.index(v_args, 1)), Z.dup(Z.index(v_args, 2)));
  }
  Z.setLine(146);
  return null;
  return null;
}
function f_Lifter__rwCall__w(v_this, v_args) {
  Z.setLine(168);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(168);
    Z.raise(new Z.ZExc(1, "rwCall: brak argumentu $x"));
  }
  Z.setLine(168);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 1))) {
    Z.setLine(168);
    Z.raise(new Z.ZExc(1, "rwCall: brak argumentu $vis"));
  }
  Z.setLine(168);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 2) >= 0))) {
    Z.setLine(168);
    return f_Lifter__rwCall(Z.dup(v_this), Z.dup(Z.index(v_args, 0)), Z.dup(Z.index(v_args, 1)));
  }
  Z.setLine(168);
  return null;
  return null;
}
function f_Lifter__plain__w(v_this, v_args) {
  Z.setLine(201);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(201);
    Z.raise(new Z.ZExc(1, "plain: brak argumentu $x"));
  }
  Z.setLine(201);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 1))) {
    Z.setLine(201);
    Z.raise(new Z.ZExc(1, "plain: brak argumentu $vis"));
  }
  Z.setLine(201);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 2) >= 0))) {
    Z.setLine(201);
    return f_Lifter__plain(Z.dup(v_this), Z.dup(Z.index(v_args, 0)), Z.dup(Z.index(v_args, 1)));
  }
  Z.setLine(201);
  return null;
  return null;
}
function f_Lifter__reorder__w(v_this, v_args) {
  Z.setLine(208);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(208);
    Z.raise(new Z.ZExc(1, "reorder: brak argumentu $x"));
  }
  Z.setLine(208);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 1))) {
    Z.setLine(208);
    Z.raise(new Z.ZExc(1, "reorder: brak argumentu $vis"));
  }
  Z.setLine(208);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 2) >= 0))) {
    Z.setLine(208);
    return f_Lifter__reorder(Z.dup(v_this), Z.dup(Z.index(v_args, 0)), Z.dup(Z.index(v_args, 1)));
  }
  Z.setLine(208);
  return null;
  return null;
}
function f_Lifter__helpers__w(v_this, v_args) {
  Z.setLine(241);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 0) >= 0))) {
    Z.setLine(241);
    return f_Lifter__helpers(Z.dup(v_this));
  }
  Z.setLine(241);
  return null;
  return null;
}
function f_Lifter__dispatcher__w(v_this, v_args) {
  Z.setLine(252);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 0) >= 0))) {
    Z.setLine(252);
    return f_Lifter__dispatcher(Z.dup(v_this));
  }
  Z.setLine(252);
  return null;
  return null;
}
function f_Desugar__err__w(v_this, v_args) {
  Z.setLine(38);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(38);
    Z.raise(new Z.ZExc(1, "err: brak argumentu $line"));
  }
  Z.setLine(38);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 1))) {
    Z.setLine(38);
    Z.raise(new Z.ZExc(1, "err: brak argumentu $msg"));
  }
  Z.setLine(38);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 2) >= 0))) {
    Z.setLine(38);
    return f_Desugar__err(Z.dup(v_this), Z.dup(Z.index(v_args, 0)), Z.dup(Z.index(v_args, 1)));
  }
  Z.setLine(38);
  return null;
  return null;
}
function f_Desugar__node__w(v_this, v_args) {
  Z.setLine(40);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(40);
    Z.raise(new Z.ZExc(1, "node: brak argumentu $k"));
  }
  Z.setLine(40);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 1))) {
    Z.setLine(40);
    Z.raise(new Z.ZExc(1, "node: brak argumentu $line"));
  }
  Z.setLine(40);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 2))) {
    Z.setLine(40);
    return f_Desugar__node(Z.dup(v_this), Z.dup(Z.index(v_args, 0)), Z.dup(Z.index(v_args, 1)), null, null, null, null);
  }
  Z.setLine(40);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 3))) {
    Z.setLine(40);
    return f_Desugar__node(Z.dup(v_this), Z.dup(Z.index(v_args, 0)), Z.dup(Z.index(v_args, 1)), Z.dup(Z.index(v_args, 2)), null, null, null);
  }
  Z.setLine(40);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 4))) {
    Z.setLine(40);
    return f_Desugar__node(Z.dup(v_this), Z.dup(Z.index(v_args, 0)), Z.dup(Z.index(v_args, 1)), Z.dup(Z.index(v_args, 2)), Z.dup(Z.index(v_args, 3)), null, null);
  }
  Z.setLine(40);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 5))) {
    Z.setLine(40);
    return f_Desugar__node(Z.dup(v_this), Z.dup(Z.index(v_args, 0)), Z.dup(Z.index(v_args, 1)), Z.dup(Z.index(v_args, 2)), Z.dup(Z.index(v_args, 3)), Z.dup(Z.index(v_args, 4)), null);
  }
  Z.setLine(40);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 6) >= 0))) {
    Z.setLine(40);
    return f_Desugar__node(Z.dup(v_this), Z.dup(Z.index(v_args, 0)), Z.dup(Z.index(v_args, 1)), Z.dup(Z.index(v_args, 2)), Z.dup(Z.index(v_args, 3)), Z.dup(Z.index(v_args, 4)), Z.dup(Z.index(v_args, 5)));
  }
  Z.setLine(40);
  return null;
  return null;
}
function f_Desugar__nm__w(v_this, v_args) {
  Z.setLine(41);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(41);
    Z.raise(new Z.ZExc(1, "nm: brak argumentu $line"));
  }
  Z.setLine(41);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 1))) {
    Z.setLine(41);
    Z.raise(new Z.ZExc(1, "nm: brak argumentu $n"));
  }
  Z.setLine(41);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 2) >= 0))) {
    Z.setLine(41);
    return f_Desugar__nm(Z.dup(v_this), Z.dup(Z.index(v_args, 0)), Z.dup(Z.index(v_args, 1)));
  }
  Z.setLine(41);
  return null;
  return null;
}
function f_Desugar__mkstr__w(v_this, v_args) {
  Z.setLine(42);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(42);
    Z.raise(new Z.ZExc(1, "mkstr: brak argumentu $line"));
  }
  Z.setLine(42);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 1))) {
    Z.setLine(42);
    Z.raise(new Z.ZExc(1, "mkstr: brak argumentu $s"));
  }
  Z.setLine(42);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 2) >= 0))) {
    Z.setLine(42);
    return f_Desugar__mkstr(Z.dup(v_this), Z.dup(Z.index(v_args, 0)), Z.dup(Z.index(v_args, 1)));
  }
  Z.setLine(42);
  return null;
  return null;
}
function f_Desugar__mkvar__w(v_this, v_args) {
  Z.setLine(43);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(43);
    Z.raise(new Z.ZExc(1, "mkvar: brak argumentu $line"));
  }
  Z.setLine(43);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 1))) {
    Z.setLine(43);
    Z.raise(new Z.ZExc(1, "mkvar: brak argumentu $n"));
  }
  Z.setLine(43);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 2) >= 0))) {
    Z.setLine(43);
    return f_Desugar__mkvar(Z.dup(v_this), Z.dup(Z.index(v_args, 0)), Z.dup(Z.index(v_args, 1)));
  }
  Z.setLine(43);
  return null;
  return null;
}
function f_Desugar__call__w(v_this, v_args) {
  Z.setLine(44);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(44);
    Z.raise(new Z.ZExc(1, "call: brak argumentu $line"));
  }
  Z.setLine(44);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 1))) {
    Z.setLine(44);
    Z.raise(new Z.ZExc(1, "call: brak argumentu $fn"));
  }
  Z.setLine(44);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 2))) {
    Z.setLine(44);
    Z.raise(new Z.ZExc(1, "call: brak argumentu $args"));
  }
  Z.setLine(44);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 3) >= 0))) {
    Z.setLine(44);
    return f_Desugar__call(Z.dup(v_this), Z.dup(Z.index(v_args, 0)), Z.dup(Z.index(v_args, 1)), Z.dup(Z.index(v_args, 2)));
  }
  Z.setLine(44);
  return null;
  return null;
}
function f_Desugar__fresh__w(v_this, v_args) {
  Z.setLine(49);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(49);
    Z.raise(new Z.ZExc(1, "fresh: brak argumentu $p"));
  }
  Z.setLine(49);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 1) >= 0))) {
    Z.setLine(49);
    return f_Desugar__fresh(Z.dup(v_this), Z.dup(Z.index(v_args, 0)));
  }
  Z.setLine(49);
  return null;
  return null;
}
function f_Desugar__collect__w(v_this, v_args) {
  Z.setLine(52);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(52);
    Z.raise(new Z.ZExc(1, "collect: brak argumentu $ast"));
  }
  Z.setLine(52);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 1) >= 0))) {
    Z.setLine(52);
    return f_Desugar__collect(Z.dup(v_this), Z.dup(Z.index(v_args, 0)));
  }
  Z.setLine(52);
  return null;
  return null;
}
function f_Desugar__chain__w(v_this, v_args) {
  Z.setLine(66);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(66);
    Z.raise(new Z.ZExc(1, "chain: brak argumentu $name"));
  }
  Z.setLine(66);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 1) >= 0))) {
    Z.setLine(66);
    return f_Desugar__chain(Z.dup(v_this), Z.dup(Z.index(v_args, 0)));
  }
  Z.setLine(66);
  return null;
  return null;
}
function f_Desugar__owner__w(v_this, v_args) {
  Z.setLine(74);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(74);
    Z.raise(new Z.ZExc(1, "owner: brak argumentu $cls"));
  }
  Z.setLine(74);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 1))) {
    Z.setLine(74);
    Z.raise(new Z.ZExc(1, "owner: brak argumentu $m"));
  }
  Z.setLine(74);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 2) >= 0))) {
    Z.setLine(74);
    return f_Desugar__owner(Z.dup(v_this), Z.dup(Z.index(v_args, 0)), Z.dup(Z.index(v_args, 1)));
  }
  Z.setLine(74);
  return null;
  return null;
}
function f_Desugar__allProps__w(v_this, v_args) {
  Z.setLine(81);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(81);
    Z.raise(new Z.ZExc(1, "allProps: brak argumentu $cls"));
  }
  Z.setLine(81);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 1) >= 0))) {
    Z.setLine(81);
    return f_Desugar__allProps(Z.dup(v_this), Z.dup(Z.index(v_args, 0)));
  }
  Z.setLine(81);
  return null;
  return null;
}
function f_Desugar__isaNames__w(v_this, v_args) {
  Z.setLine(94);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(94);
    Z.raise(new Z.ZExc(1, "isaNames: brak argumentu $cls"));
  }
  Z.setLine(94);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 1) >= 0))) {
    Z.setLine(94);
    return f_Desugar__isaNames(Z.dup(v_this), Z.dup(Z.index(v_args, 0)));
  }
  Z.setLine(94);
  return null;
  return null;
}
function f_Desugar__rwList__w(v_this, v_args) {
  Z.setLine(113);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(113);
    Z.raise(new Z.ZExc(1, "rwList: brak argumentu $xs"));
  }
  Z.setLine(113);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 1) >= 0))) {
    Z.setLine(113);
    return f_Desugar__rwList(Z.dup(v_this), Z.dup(Z.index(v_args, 0)));
  }
  Z.setLine(113);
  return null;
  return null;
}
function f_Desugar__rw__w(v_this, v_args) {
  Z.setLine(125);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(125);
    Z.raise(new Z.ZExc(1, "rw: brak argumentu $x"));
  }
  Z.setLine(125);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 1) >= 0))) {
    Z.setLine(125);
    return f_Desugar__rw(Z.dup(v_this), Z.dup(Z.index(v_args, 0)));
  }
  Z.setLine(125);
  return null;
  return null;
}
function f_Desugar__baseOk__w(v_this, v_args) {
  Z.setLine(190);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(190);
    Z.raise(new Z.ZExc(1, "baseOk: brak argumentu $b"));
  }
  Z.setLine(190);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 1) >= 0))) {
    Z.setLine(190);
    return f_Desugar__baseOk(Z.dup(v_this), Z.dup(Z.index(v_args, 0)));
  }
  Z.setLine(190);
  return null;
  return null;
}
function f_Desugar__propModify__w(v_this, v_args) {
  Z.setLine(192);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(192);
    Z.raise(new Z.ZExc(1, "propModify: brak argumentu $line"));
  }
  Z.setLine(192);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 1))) {
    Z.setLine(192);
    Z.raise(new Z.ZExc(1, "propModify: brak argumentu $t"));
  }
  Z.setLine(192);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 2))) {
    Z.setLine(192);
    Z.raise(new Z.ZExc(1, "propModify: brak argumentu $op"));
  }
  Z.setLine(192);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 3))) {
    Z.setLine(192);
    Z.raise(new Z.ZExc(1, "propModify: brak argumentu $rhs"));
  }
  Z.setLine(192);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 4) >= 0))) {
    Z.setLine(192);
    return f_Desugar__propModify(Z.dup(v_this), Z.dup(Z.index(v_args, 0)), Z.dup(Z.index(v_args, 1)), Z.dup(Z.index(v_args, 2)), Z.dup(Z.index(v_args, 3)));
  }
  Z.setLine(192);
  return null;
  return null;
}
function f_Desugar__staticName__w(v_this, v_args) {
  Z.setLine(200);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(200);
    Z.raise(new Z.ZExc(1, "staticName: brak argumentu $cn"));
  }
  Z.setLine(200);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 1))) {
    Z.setLine(200);
    Z.raise(new Z.ZExc(1, "staticName: brak argumentu $p"));
  }
  Z.setLine(200);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 2) >= 0))) {
    Z.setLine(200);
    return f_Desugar__staticName(Z.dup(v_this), Z.dup(Z.index(v_args, 0)), Z.dup(Z.index(v_args, 1)));
  }
  Z.setLine(200);
  return null;
  return null;
}
function f_Desugar__staticTarget__w(v_this, v_args) {
  Z.setLine(208);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(208);
    Z.raise(new Z.ZExc(1, "staticTarget: brak argumentu $t"));
  }
  Z.setLine(208);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 1) >= 0))) {
    Z.setLine(208);
    return f_Desugar__staticTarget(Z.dup(v_this), Z.dup(Z.index(v_args, 0)));
  }
  Z.setLine(208);
  return null;
  return null;
}
function f_Desugar__clsName__w(v_this, v_args) {
  Z.setLine(215);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(215);
    Z.raise(new Z.ZExc(1, "clsName: brak argumentu $n"));
  }
  Z.setLine(215);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 1) >= 0))) {
    Z.setLine(215);
    return f_Desugar__clsName(Z.dup(v_this), Z.dup(Z.index(v_args, 0)));
  }
  Z.setLine(215);
  return null;
  return null;
}
function f_Desugar__constOf__w(v_this, v_args) {
  Z.setLine(220);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(220);
    Z.raise(new Z.ZExc(1, "constOf: brak argumentu $cn"));
  }
  Z.setLine(220);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 1))) {
    Z.setLine(220);
    Z.raise(new Z.ZExc(1, "constOf: brak argumentu $k"));
  }
  Z.setLine(220);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 2) >= 0))) {
    Z.setLine(220);
    return f_Desugar__constOf(Z.dup(v_this), Z.dup(Z.index(v_args, 0)), Z.dup(Z.index(v_args, 1)));
  }
  Z.setLine(220);
  return null;
  return null;
}
function f_Desugar__rwNew__w(v_this, v_args) {
  Z.setLine(227);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(227);
    Z.raise(new Z.ZExc(1, "rwNew: brak argumentu $x"));
  }
  Z.setLine(227);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 1) >= 0))) {
    Z.setLine(227);
    return f_Desugar__rwNew(Z.dup(v_this), Z.dup(Z.index(v_args, 0)));
  }
  Z.setLine(227);
  return null;
  return null;
}
function f_Desugar__rwCall__w(v_this, v_args) {
  Z.setLine(238);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(238);
    Z.raise(new Z.ZExc(1, "rwCall: brak argumentu $x"));
  }
  Z.setLine(238);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 1) >= 0))) {
    Z.setLine(238);
    return f_Desugar__rwCall(Z.dup(v_this), Z.dup(Z.index(v_args, 0)));
  }
  Z.setLine(238);
  return null;
  return null;
}
function f_Desugar__rwTry__w(v_this, v_args) {
  Z.setLine(294);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(294);
    Z.raise(new Z.ZExc(1, "rwTry: brak argumentu $x"));
  }
  Z.setLine(294);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 1) >= 0))) {
    Z.setLine(294);
    return f_Desugar__rwTry(Z.dup(v_this), Z.dup(Z.index(v_args, 0)));
  }
  Z.setLine(294);
  return null;
  return null;
}
function f_Desugar__anyMethod__w(v_this, v_args) {
  Z.setLine(314);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(314);
    Z.raise(new Z.ZExc(1, "anyMethod: brak argumentu $m"));
  }
  Z.setLine(314);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 1) >= 0))) {
    Z.setLine(314);
    return f_Desugar__anyMethod(Z.dup(v_this), Z.dup(Z.index(v_args, 0)));
  }
  Z.setLine(314);
  return null;
  return null;
}
function f_Desugar__stmtExpr__w(v_this, v_args) {
  Z.setLine(320);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(320);
    Z.raise(new Z.ZExc(1, "stmtExpr: brak argumentu $s"));
  }
  Z.setLine(320);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 1) >= 0))) {
    Z.setLine(320);
    return f_Desugar__stmtExpr(Z.dup(v_this), Z.dup(Z.index(v_args, 0)));
  }
  Z.setLine(320);
  return null;
  return null;
}
function f_Desugar__funcStmt__w(v_this, v_args) {
  Z.setLine(369);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(369);
    Z.raise(new Z.ZExc(1, "funcStmt: brak argumentu $line"));
  }
  Z.setLine(369);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 1))) {
    Z.setLine(369);
    Z.raise(new Z.ZExc(1, "funcStmt: brak argumentu $name"));
  }
  Z.setLine(369);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 2))) {
    Z.setLine(369);
    Z.raise(new Z.ZExc(1, "funcStmt: brak argumentu $params"));
  }
  Z.setLine(369);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 3))) {
    Z.setLine(369);
    Z.raise(new Z.ZExc(1, "funcStmt: brak argumentu $body"));
  }
  Z.setLine(369);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 4) >= 0))) {
    Z.setLine(369);
    return f_Desugar__funcStmt(Z.dup(v_this), Z.dup(Z.index(v_args, 0)), Z.dup(Z.index(v_args, 1)), Z.dup(Z.index(v_args, 2)), Z.dup(Z.index(v_args, 3)));
  }
  Z.setLine(369);
  return null;
  return null;
}
function f_Desugar__param__w(v_this, v_args) {
  Z.setLine(373);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(373);
    Z.raise(new Z.ZExc(1, "param: brak argumentu $name"));
  }
  Z.setLine(373);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 1))) {
    Z.setLine(373);
    return f_Desugar__param(Z.dup(v_this), Z.dup(Z.index(v_args, 0)), null);
  }
  Z.setLine(373);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 2) >= 0))) {
    Z.setLine(373);
    return f_Desugar__param(Z.dup(v_this), Z.dup(Z.index(v_args, 0)), Z.dup(Z.index(v_args, 1)));
  }
  Z.setLine(373);
  return null;
  return null;
}
function f_Desugar__genClass__w(v_this, v_args) {
  Z.setLine(375);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(375);
    Z.raise(new Z.ZExc(1, "genClass: brak argumentu $k"));
  }
  Z.setLine(375);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 1) >= 0))) {
    Z.setLine(375);
    return f_Desugar__genClass(Z.dup(v_this), Z.dup(Z.index(v_args, 0)));
  }
  Z.setLine(375);
  return null;
  return null;
}
function f_Desugar__wrapper__w(v_this, v_args) {
  Z.setLine(410);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(410);
    Z.raise(new Z.ZExc(1, "wrapper: brak argumentu $owner"));
  }
  Z.setLine(410);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 1))) {
    Z.setLine(410);
    Z.raise(new Z.ZExc(1, "wrapper: brak argumentu $m"));
  }
  Z.setLine(410);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 2) >= 0))) {
    Z.setLine(410);
    return f_Desugar__wrapper(Z.dup(v_this), Z.dup(Z.index(v_args, 0)), Z.dup(Z.index(v_args, 1)));
  }
  Z.setLine(410);
  return null;
  return null;
}
function f_Desugar__wrapperN__w(v_this, v_args) {
  Z.setLine(443);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(443);
    Z.raise(new Z.ZExc(1, "wrapperN: brak argumentu $owner"));
  }
  Z.setLine(443);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 1))) {
    Z.setLine(443);
    Z.raise(new Z.ZExc(1, "wrapperN: brak argumentu $m"));
  }
  Z.setLine(443);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 2) >= 0))) {
    Z.setLine(443);
    return f_Desugar__wrapperN(Z.dup(v_this), Z.dup(Z.index(v_args, 0)), Z.dup(Z.index(v_args, 1)));
  }
  Z.setLine(443);
  return null;
  return null;
}
function f_Desugar__genDispatchN__w(v_this, v_args) {
  Z.setLine(451);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 0) >= 0))) {
    Z.setLine(451);
    return f_Desugar__genDispatchN(Z.dup(v_this));
  }
  Z.setLine(451);
  return null;
  return null;
}
function f_Desugar__genDispatch__w(v_this, v_args) {
  Z.setLine(477);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 0) >= 0))) {
    Z.setLine(477);
    return f_Desugar__genDispatch(Z.dup(v_this));
  }
  Z.setLine(477);
  return null;
  return null;
}
function f_Linker__err__w(v_this, v_args) {
  Z.setLine(25);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(25);
    Z.raise(new Z.ZExc(1, "err: brak argumentu $file"));
  }
  Z.setLine(25);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 1))) {
    Z.setLine(25);
    Z.raise(new Z.ZExc(1, "err: brak argumentu $line"));
  }
  Z.setLine(25);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 2))) {
    Z.setLine(25);
    Z.raise(new Z.ZExc(1, "err: brak argumentu $code"));
  }
  Z.setLine(25);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 3))) {
    Z.setLine(25);
    Z.raise(new Z.ZExc(1, "err: brak argumentu $msg"));
  }
  Z.setLine(25);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 4) >= 0))) {
    Z.setLine(25);
    return f_Linker__err(Z.dup(v_this), Z.dup(Z.index(v_args, 0)), Z.dup(Z.index(v_args, 1)), Z.dup(Z.index(v_args, 2)), Z.dup(Z.index(v_args, 3)));
  }
  Z.setLine(25);
  return null;
  return null;
}
function f_Linker__prefixOf__w(v_this, v_args) {
  Z.setLine(27);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(27);
    Z.raise(new Z.ZExc(1, "prefixOf: brak argumentu $path"));
  }
  Z.setLine(27);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 1) >= 0))) {
    Z.setLine(27);
    return f_Linker__prefixOf(Z.dup(v_this), Z.dup(Z.index(v_args, 0)));
  }
  Z.setLine(27);
  return null;
  return null;
}
function f_Linker__dirOf__w(v_this, v_args) {
  Z.setLine(29);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(29);
    Z.raise(new Z.ZExc(1, "dirOf: brak argumentu $file"));
  }
  Z.setLine(29);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 1) >= 0))) {
    Z.setLine(29);
    return f_Linker__dirOf(Z.dup(v_this), Z.dup(Z.index(v_args, 0)));
  }
  Z.setLine(29);
  return null;
  return null;
}
function f_Linker__rw__w(v_this, v_args) {
  Z.setLine(35);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(35);
    Z.raise(new Z.ZExc(1, "rw: brak argumentu $x"));
  }
  Z.setLine(35);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 1))) {
    Z.setLine(35);
    Z.raise(new Z.ZExc(1, "rw: brak argumentu $self"));
  }
  Z.setLine(35);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 2))) {
    Z.setLine(35);
    Z.raise(new Z.ZExc(1, "rw: brak argumentu $funcs"));
  }
  Z.setLine(35);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 3))) {
    Z.setLine(35);
    Z.raise(new Z.ZExc(1, "rw: brak argumentu $aliases"));
  }
  Z.setLine(35);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 4) >= 0))) {
    Z.setLine(35);
    return f_Linker__rw(Z.dup(v_this), Z.dup(Z.index(v_args, 0)), Z.dup(Z.index(v_args, 1)), Z.dup(Z.index(v_args, 2)), Z.dup(Z.index(v_args, 3)));
  }
  Z.setLine(35);
  return null;
  return null;
}
function f_Linker__loadModule__w(v_this, v_args) {
  Z.setLine(61);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(61);
    Z.raise(new Z.ZExc(1, "loadModule: brak argumentu $file"));
  }
  Z.setLine(61);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 1))) {
    Z.setLine(61);
    Z.raise(new Z.ZExc(1, "loadModule: brak argumentu $path"));
  }
  Z.setLine(61);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 2))) {
    Z.setLine(61);
    Z.raise(new Z.ZExc(1, "loadModule: brak argumentu $fromFile"));
  }
  Z.setLine(61);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 3))) {
    Z.setLine(61);
    Z.raise(new Z.ZExc(1, "loadModule: brak argumentu $line"));
  }
  Z.setLine(61);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 4) >= 0))) {
    Z.setLine(61);
    return f_Linker__loadModule(Z.dup(v_this), Z.dup(Z.index(v_args, 0)), Z.dup(Z.index(v_args, 1)), Z.dup(Z.index(v_args, 2)), Z.dup(Z.index(v_args, 3)));
  }
  Z.setLine(61);
  return null;
  return null;
}
function f_Linker__collectImports__w(v_this, v_args) {
  Z.setLine(94);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(94);
    Z.raise(new Z.ZExc(1, "collectImports: brak argumentu $ast"));
  }
  Z.setLine(94);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 1))) {
    Z.setLine(94);
    Z.raise(new Z.ZExc(1, "collectImports: brak argumentu $file"));
  }
  Z.setLine(94);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 2) >= 0))) {
    Z.setLine(94);
    return f_Linker__collectImports(Z.dup(v_this), Z.dup(Z.index(v_args, 0)), Z.dup(Z.index(v_args, 1)));
  }
  Z.setLine(94);
  return null;
  return null;
}
function f_VarPass__rw__w(v_this, v_args) {
  Z.setLine(151);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(151);
    Z.raise(new Z.ZExc(1, "rw: brak argumentu $x"));
  }
  Z.setLine(151);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 1) >= 0))) {
    Z.setLine(151);
    return f_VarPass__rw(Z.dup(v_this), Z.dup(Z.index(v_args, 0)));
  }
  Z.setLine(151);
  return null;
  return null;
}
function f_LlEmitter__r__w(v_this, v_args) {
  Z.setLine(62);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 0) >= 0))) {
    Z.setLine(62);
    return f_LlEmitter__r(Z.dup(v_this));
  }
  Z.setLine(62);
  return null;
  return null;
}
function f_LlEmitter__newLabel__w(v_this, v_args) {
  Z.setLine(63);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(63);
    Z.raise(new Z.ZExc(1, "newLabel: brak argumentu $p"));
  }
  Z.setLine(63);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 1) >= 0))) {
    Z.setLine(63);
    return f_LlEmitter__newLabel(Z.dup(v_this), Z.dup(Z.index(v_args, 0)));
  }
  Z.setLine(63);
  return null;
  return null;
}
function f_LlEmitter__line__w(v_this, v_args) {
  Z.setLine(65);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(65);
    Z.raise(new Z.ZExc(1, "line: brak argumentu $s"));
  }
  Z.setLine(65);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 1) >= 0))) {
    Z.setLine(65);
    return f_LlEmitter__line(Z.dup(v_this), Z.dup(Z.index(v_args, 0)));
  }
  Z.setLine(65);
  return null;
  return null;
}
function f_LlEmitter__label__w(v_this, v_args) {
  Z.setLine(70);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(70);
    Z.raise(new Z.ZExc(1, "label: brak argumentu $l"));
  }
  Z.setLine(70);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 1) >= 0))) {
    Z.setLine(70);
    return f_LlEmitter__label(Z.dup(v_this), Z.dup(Z.index(v_args, 0)));
  }
  Z.setLine(70);
  return null;
  return null;
}
function f_LlEmitter__terminate__w(v_this, v_args) {
  Z.setLine(76);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(76);
    Z.raise(new Z.ZExc(1, "terminate: brak argumentu $s"));
  }
  Z.setLine(76);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 1) >= 0))) {
    Z.setLine(76);
    return f_LlEmitter__terminate(Z.dup(v_this), Z.dup(Z.index(v_args, 0)));
  }
  Z.setLine(76);
  return null;
  return null;
}
function f_LlEmitter__esc__w(v_this, v_args) {
  Z.setLine(82);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(82);
    Z.raise(new Z.ZExc(1, "esc: brak argumentu $s"));
  }
  Z.setLine(82);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 1) >= 0))) {
    Z.setLine(82);
    return f_LlEmitter__esc(Z.dup(v_this), Z.dup(Z.index(v_args, 0)));
  }
  Z.setLine(82);
  return null;
  return null;
}
function f_LlEmitter__cstr__w(v_this, v_args) {
  Z.setLine(94);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(94);
    Z.raise(new Z.ZExc(1, "cstr: brak argumentu $s"));
  }
  Z.setLine(94);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 1) >= 0))) {
    Z.setLine(94);
    return f_LlEmitter__cstr(Z.dup(v_this), Z.dup(Z.index(v_args, 0)));
  }
  Z.setLine(94);
  return null;
  return null;
}
function f_LlEmitter__strSlot__w(v_this, v_args) {
  Z.setLine(103);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(103);
    Z.raise(new Z.ZExc(1, "strSlot: brak argumentu $s"));
  }
  Z.setLine(103);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 1) >= 0))) {
    Z.setLine(103);
    return f_LlEmitter__strSlot(Z.dup(v_this), Z.dup(Z.index(v_args, 0)));
  }
  Z.setLine(103);
  return null;
  return null;
}
function f_LlEmitter__slot__w(v_this, v_args) {
  Z.setLine(111);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 0) >= 0))) {
    Z.setLine(111);
    return f_LlEmitter__slot(Z.dup(v_this));
  }
  Z.setLine(111);
  return null;
  return null;
}
function f_LlEmitter__ty__w(v_this, v_args) {
  Z.setLine(119);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(119);
    Z.raise(new Z.ZExc(1, "ty: brak argumentu $t"));
  }
  Z.setLine(119);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 1) >= 0))) {
    Z.setLine(119);
    return f_LlEmitter__ty(Z.dup(v_this), Z.dup(Z.index(v_args, 0)));
  }
  Z.setLine(119);
  return null;
  return null;
}
function f_LlEmitter__rt__w(v_this, v_args) {
  Z.setLine(122);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(122);
    Z.raise(new Z.ZExc(1, "rt: brak argumentu $fn"));
  }
  Z.setLine(122);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 1))) {
    Z.setLine(122);
    Z.raise(new Z.ZExc(1, "rt: brak argumentu $ret"));
  }
  Z.setLine(122);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 2))) {
    Z.setLine(122);
    Z.raise(new Z.ZExc(1, "rt: brak argumentu $args"));
  }
  Z.setLine(122);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 3) >= 0))) {
    Z.setLine(122);
    return f_LlEmitter__rt(Z.dup(v_this), Z.dup(Z.index(v_args, 0)), Z.dup(Z.index(v_args, 1)), Z.dup(Z.index(v_args, 2)));
  }
  Z.setLine(122);
  return null;
  return null;
}
function f_LlEmitter__vcall__w(v_this, v_args) {
  Z.setLine(140);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(140);
    Z.raise(new Z.ZExc(1, "vcall: brak argumentu $fn"));
  }
  Z.setLine(140);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 1))) {
    Z.setLine(140);
    Z.raise(new Z.ZExc(1, "vcall: brak argumentu $regs"));
  }
  Z.setLine(140);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 2) >= 0))) {
    Z.setLine(140);
    return f_LlEmitter__vcall(Z.dup(v_this), Z.dup(Z.index(v_args, 0)), Z.dup(Z.index(v_args, 1)));
  }
  Z.setLine(140);
  return null;
  return null;
}
function f_LlEmitter__mkv__w(v_this, v_args) {
  Z.setLine(146);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(146);
    Z.raise(new Z.ZExc(1, "mkv: brak argumentu $tag"));
  }
  Z.setLine(146);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 1))) {
    Z.setLine(146);
    Z.raise(new Z.ZExc(1, "mkv: brak argumentu $bits"));
  }
  Z.setLine(146);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 2) >= 0))) {
    Z.setLine(146);
    return f_LlEmitter__mkv(Z.dup(v_this), Z.dup(Z.index(v_args, 0)), Z.dup(Z.index(v_args, 1)));
  }
  Z.setLine(146);
  return null;
  return null;
}
function f_LlEmitter__nullv__w(v_this, v_args) {
  Z.setLine(152);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 0) >= 0))) {
    Z.setLine(152);
    return f_LlEmitter__nullv(Z.dup(v_this));
  }
  Z.setLine(152);
  return null;
  return null;
}
function f_LlEmitter__truthy__w(v_this, v_args) {
  Z.setLine(154);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(154);
    Z.raise(new Z.ZExc(1, "truthy: brak argumentu $v"));
  }
  Z.setLine(154);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 1) >= 0))) {
    Z.setLine(154);
    return f_LlEmitter__truthy(Z.dup(v_this), Z.dup(Z.index(v_args, 0)));
  }
  Z.setLine(154);
  return null;
  return null;
}
function f_LlEmitter__boolOf__w(v_this, v_args) {
  Z.setLine(161);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(161);
    Z.raise(new Z.ZExc(1, "boolOf: brak argumentu $i1"));
  }
  Z.setLine(161);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 1) >= 0))) {
    Z.setLine(161);
    return f_LlEmitter__boolOf(Z.dup(v_this), Z.dup(Z.index(v_args, 0)));
  }
  Z.setLine(161);
  return null;
  return null;
}
function f_LlEmitter__ident__w(v_this, v_args) {
  Z.setLine(169);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(169);
    Z.raise(new Z.ZExc(1, "ident: brak argumentu $n"));
  }
  Z.setLine(169);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 1) >= 0))) {
    Z.setLine(169);
    return f_LlEmitter__ident(Z.dup(v_this), Z.dup(Z.index(v_args, 0)));
  }
  Z.setLine(169);
  return null;
  return null;
}
function f_LlEmitter__load__w(v_this, v_args) {
  Z.setLine(171);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(171);
    Z.raise(new Z.ZExc(1, "load: brak argumentu $n"));
  }
  Z.setLine(171);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 1) >= 0))) {
    Z.setLine(171);
    return f_LlEmitter__load(Z.dup(v_this), Z.dup(Z.index(v_args, 0)));
  }
  Z.setLine(171);
  return null;
  return null;
}
function f_LlEmitter__store__w(v_this, v_args) {
  Z.setLine(177);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(177);
    Z.raise(new Z.ZExc(1, "store: brak argumentu $n"));
  }
  Z.setLine(177);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 1))) {
    Z.setLine(177);
    Z.raise(new Z.ZExc(1, "store: brak argumentu $v"));
  }
  Z.setLine(177);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 2) >= 0))) {
    Z.setLine(177);
    return f_LlEmitter__store(Z.dup(v_this), Z.dup(Z.index(v_args, 0)), Z.dup(Z.index(v_args, 1)));
  }
  Z.setLine(177);
  return null;
  return null;
}
function f_LlEmitter__storeTo__w(v_this, v_args) {
  Z.setLine(179);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(179);
    Z.raise(new Z.ZExc(1, "storeTo: brak argumentu $ptr"));
  }
  Z.setLine(179);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 1))) {
    Z.setLine(179);
    Z.raise(new Z.ZExc(1, "storeTo: brak argumentu $v"));
  }
  Z.setLine(179);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 2) >= 0))) {
    Z.setLine(179);
    return f_LlEmitter__storeTo(Z.dup(v_this), Z.dup(Z.index(v_args, 0)), Z.dup(Z.index(v_args, 1)));
  }
  Z.setLine(179);
  return null;
  return null;
}
function f_LlEmitter__loadFrom__w(v_this, v_args) {
  Z.setLine(181);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(181);
    Z.raise(new Z.ZExc(1, "loadFrom: brak argumentu $ptr"));
  }
  Z.setLine(181);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 1) >= 0))) {
    Z.setLine(181);
    return f_LlEmitter__loadFrom(Z.dup(v_this), Z.dup(Z.index(v_args, 0)));
  }
  Z.setLine(181);
  return null;
  return null;
}
function f_LlEmitter__isLval__w(v_this, v_args) {
  Z.setLine(188);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(188);
    Z.raise(new Z.ZExc(1, "isLval: brak argumentu $e"));
  }
  Z.setLine(188);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 1) >= 0))) {
    Z.setLine(188);
    return f_LlEmitter__isLval(Z.dup(v_this), Z.dup(Z.index(v_args, 0)));
  }
  Z.setLine(188);
  return null;
  return null;
}
function f_LlEmitter__val__w(v_this, v_args) {
  Z.setLine(190);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(190);
    Z.raise(new Z.ZExc(1, "val: brak argumentu $e"));
  }
  Z.setLine(190);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 1) >= 0))) {
    Z.setLine(190);
    return f_LlEmitter__val(Z.dup(v_this), Z.dup(Z.index(v_args, 0)));
  }
  Z.setLine(190);
  return null;
  return null;
}
function f_LlEmitter__binop__w(v_this, v_args) {
  Z.setLine(195);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(195);
    Z.raise(new Z.ZExc(1, "binop: brak argumentu $op"));
  }
  Z.setLine(195);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 1))) {
    Z.setLine(195);
    Z.raise(new Z.ZExc(1, "binop: brak argumentu $a"));
  }
  Z.setLine(195);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 2))) {
    Z.setLine(195);
    Z.raise(new Z.ZExc(1, "binop: brak argumentu $b"));
  }
  Z.setLine(195);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 3) >= 0))) {
    Z.setLine(195);
    return f_LlEmitter__binop(Z.dup(v_this), Z.dup(Z.index(v_args, 0)), Z.dup(Z.index(v_args, 1)), Z.dup(Z.index(v_args, 2)));
  }
  Z.setLine(195);
  return null;
  return null;
}
function f_LlEmitter__quiet__w(v_this, v_args) {
  Z.setLine(223);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(223);
    Z.raise(new Z.ZExc(1, "quiet: brak argumentu $e"));
  }
  Z.setLine(223);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 1) >= 0))) {
    Z.setLine(223);
    return f_LlEmitter__quiet(Z.dup(v_this), Z.dup(Z.index(v_args, 0)));
  }
  Z.setLine(223);
  return null;
  return null;
}
function f_LlEmitter__keyOf__w(v_this, v_args) {
  Z.setLine(232);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(232);
    Z.raise(new Z.ZExc(1, "keyOf: brak argumentu $t"));
  }
  Z.setLine(232);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 1))) {
    Z.setLine(232);
    Z.raise(new Z.ZExc(1, "keyOf: brak argumentu $arr"));
  }
  Z.setLine(232);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 2) >= 0))) {
    Z.setLine(232);
    return f_LlEmitter__keyOf(Z.dup(v_this), Z.dup(Z.index(v_args, 0)), Z.dup(Z.index(v_args, 1)));
  }
  Z.setLine(232);
  return null;
  return null;
}
function f_LlEmitter__lv__w(v_this, v_args) {
  Z.setLine(243);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(243);
    Z.raise(new Z.ZExc(1, "lv: brak argumentu $base"));
  }
  Z.setLine(243);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 1) >= 0))) {
    Z.setLine(243);
    return f_LlEmitter__lv(Z.dup(v_this), Z.dup(Z.index(v_args, 0)));
  }
  Z.setLine(243);
  return null;
  return null;
}
function f_LlEmitter__newArr__w(v_this, v_args) {
  Z.setLine(271);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 0) >= 0))) {
    Z.setLine(271);
    return f_LlEmitter__newArr(Z.dup(v_this));
  }
  Z.setLine(271);
  return null;
  return null;
}
function f_LlEmitter__vcallVoid__w(v_this, v_args) {
  Z.setLine(273);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(273);
    Z.raise(new Z.ZExc(1, "vcallVoid: brak argumentu $fn"));
  }
  Z.setLine(273);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 1))) {
    Z.setLine(273);
    Z.raise(new Z.ZExc(1, "vcallVoid: brak argumentu $regs"));
  }
  Z.setLine(273);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 2) >= 0))) {
    Z.setLine(273);
    return f_LlEmitter__vcallVoid(Z.dup(v_this), Z.dup(Z.index(v_args, 0)), Z.dup(Z.index(v_args, 1)));
  }
  Z.setLine(273);
  return null;
  return null;
}
function f_LlEmitter__incdec__w(v_this, v_args) {
  Z.setLine(279);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(279);
    Z.raise(new Z.ZExc(1, "incdec: brak argumentu $e"));
  }
  Z.setLine(279);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 1) >= 0))) {
    Z.setLine(279);
    return f_LlEmitter__incdec(Z.dup(v_this), Z.dup(Z.index(v_args, 0)));
  }
  Z.setLine(279);
  return null;
  return null;
}
function f_LlEmitter__assignop__w(v_this, v_args) {
  Z.setLine(299);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(299);
    Z.raise(new Z.ZExc(1, "assignop: brak argumentu $e"));
  }
  Z.setLine(299);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 1) >= 0))) {
    Z.setLine(299);
    return f_LlEmitter__assignop(Z.dup(v_this), Z.dup(Z.index(v_args, 0)));
  }
  Z.setLine(299);
  return null;
  return null;
}
function f_LlEmitter__coalesceWith__w(v_this, v_args) {
  Z.setLine(329);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(329);
    Z.raise(new Z.ZExc(1, "coalesceWith: brak argumentu $x"));
  }
  Z.setLine(329);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 1))) {
    Z.setLine(329);
    Z.raise(new Z.ZExc(1, "coalesceWith: brak argumentu $rhsExpr"));
  }
  Z.setLine(329);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 2) >= 0))) {
    Z.setLine(329);
    return f_LlEmitter__coalesceWith(Z.dup(v_this), Z.dup(Z.index(v_args, 0)), Z.dup(Z.index(v_args, 1)));
  }
  Z.setLine(329);
  return null;
  return null;
}
function f_LlEmitter__assign__w(v_this, v_args) {
  Z.setLine(346);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(346);
    Z.raise(new Z.ZExc(1, "assign: brak argumentu $e"));
  }
  Z.setLine(346);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 1) >= 0))) {
    Z.setLine(346);
    return f_LlEmitter__assign(Z.dup(v_this), Z.dup(Z.index(v_args, 0)));
  }
  Z.setLine(346);
  return null;
  return null;
}
function f_LlEmitter__argRegs__w(v_this, v_args) {
  Z.setLine(363);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(363);
    Z.raise(new Z.ZExc(1, "argRegs: brak argumentu $list"));
  }
  Z.setLine(363);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 1))) {
    Z.setLine(363);
    Z.raise(new Z.ZExc(1, "argRegs: brak argumentu $dup"));
  }
  Z.setLine(363);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 2) >= 0))) {
    Z.setLine(363);
    return f_LlEmitter__argRegs(Z.dup(v_this), Z.dup(Z.index(v_args, 0)), Z.dup(Z.index(v_args, 1)));
  }
  Z.setLine(363);
  return null;
  return null;
}
function f_LlEmitter__call__w(v_this, v_args) {
  Z.setLine(369);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(369);
    Z.raise(new Z.ZExc(1, "call: brak argumentu $e"));
  }
  Z.setLine(369);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 1) >= 0))) {
    Z.setLine(369);
    return f_LlEmitter__call(Z.dup(v_this), Z.dup(Z.index(v_args, 0)));
  }
  Z.setLine(369);
  return null;
  return null;
}
function f_LlEmitter__doExit__w(v_this, v_args) {
  Z.setLine(392);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(392);
    Z.raise(new Z.ZExc(1, "doExit: brak argumentu $a"));
  }
  Z.setLine(392);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 1) >= 0))) {
    Z.setLine(392);
    return f_LlEmitter__doExit(Z.dup(v_this), Z.dup(Z.index(v_args, 0)));
  }
  Z.setLine(392);
  return null;
  return null;
}
function f_LlEmitter__builtin__w(v_this, v_args) {
  Z.setLine(399);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(399);
    Z.raise(new Z.ZExc(1, "builtin: brak argumentu $name"));
  }
  Z.setLine(399);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 1))) {
    Z.setLine(399);
    Z.raise(new Z.ZExc(1, "builtin: brak argumentu $list"));
  }
  Z.setLine(399);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 2) >= 0))) {
    Z.setLine(399);
    return f_LlEmitter__builtin(Z.dup(v_this), Z.dup(Z.index(v_args, 0)), Z.dup(Z.index(v_args, 1)));
  }
  Z.setLine(399);
  return null;
  return null;
}
function f_LlEmitter__expr__w(v_this, v_args) {
  Z.setLine(431);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(431);
    Z.raise(new Z.ZExc(1, "expr: brak argumentu $e"));
  }
  Z.setLine(431);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 1) >= 0))) {
    Z.setLine(431);
    return f_LlEmitter__expr(Z.dup(v_this), Z.dup(Z.index(v_args, 0)));
  }
  Z.setLine(431);
  return null;
  return null;
}
function f_LlEmitter__shortCircuit__w(v_this, v_args) {
  Z.setLine(502);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(502);
    Z.raise(new Z.ZExc(1, "shortCircuit: brak argumentu $isAnd"));
  }
  Z.setLine(502);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 1))) {
    Z.setLine(502);
    Z.raise(new Z.ZExc(1, "shortCircuit: brak argumentu $l"));
  }
  Z.setLine(502);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 2))) {
    Z.setLine(502);
    Z.raise(new Z.ZExc(1, "shortCircuit: brak argumentu $r"));
  }
  Z.setLine(502);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 3) >= 0))) {
    Z.setLine(502);
    return f_LlEmitter__shortCircuit(Z.dup(v_this), Z.dup(Z.index(v_args, 0)), Z.dup(Z.index(v_args, 1)), Z.dup(Z.index(v_args, 2)));
  }
  Z.setLine(502);
  return null;
  return null;
}
function f_LlEmitter__ternary__w(v_this, v_args) {
  Z.setLine(519);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(519);
    Z.raise(new Z.ZExc(1, "ternary: brak argumentu $e"));
  }
  Z.setLine(519);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 1) >= 0))) {
    Z.setLine(519);
    return f_LlEmitter__ternary(Z.dup(v_this), Z.dup(Z.index(v_args, 0)));
  }
  Z.setLine(519);
  return null;
  return null;
}
function f_LlEmitter__setLine__w(v_this, v_args) {
  Z.setLine(546);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(546);
    Z.raise(new Z.ZExc(1, "setLine: brak argumentu $n"));
  }
  Z.setLine(546);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 1) >= 0))) {
    Z.setLine(546);
    return f_LlEmitter__setLine(Z.dup(v_this), Z.dup(Z.index(v_args, 0)));
  }
  Z.setLine(546);
  return null;
  return null;
}
function f_LlEmitter__block__w(v_this, v_args) {
  Z.setLine(548);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(548);
    Z.raise(new Z.ZExc(1, "block: brak argumentu $list"));
  }
  Z.setLine(548);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 1) >= 0))) {
    Z.setLine(548);
    return f_LlEmitter__block(Z.dup(v_this), Z.dup(Z.index(v_args, 0)));
  }
  Z.setLine(548);
  return null;
  return null;
}
function f_LlEmitter__regionBegin__w(v_this, v_args) {
  Z.setLine(551);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(551);
    Z.raise(new Z.ZExc(1, "regionBegin: brak argumentu $loop"));
  }
  Z.setLine(551);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 1))) {
    Z.setLine(551);
    Z.raise(new Z.ZExc(1, "regionBegin: brak argumentu $body"));
  }
  Z.setLine(551);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 2))) {
    Z.setLine(551);
    Z.raise(new Z.ZExc(1, "regionBegin: brak argumentu $hdr"));
  }
  Z.setLine(551);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 3))) {
    Z.setLine(551);
    Z.raise(new Z.ZExc(1, "regionBegin: brak argumentu $pre"));
  }
  Z.setLine(551);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 4))) {
    Z.setLine(551);
    Z.raise(new Z.ZExc(1, "regionBegin: brak argumentu $id"));
  }
  Z.setLine(551);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 5) >= 0))) {
    Z.setLine(551);
    return f_LlEmitter__regionBegin(Z.dup(v_this), Z.dup(Z.index(v_args, 0)), Z.dup(Z.index(v_args, 1)), Z.dup(Z.index(v_args, 2)), Z.dup(Z.index(v_args, 3)), Z.dup(Z.index(v_args, 4)));
  }
  Z.setLine(551);
  return null;
  return null;
}
function f_LlEmitter__regionEnter__w(v_this, v_args) {
  Z.setLine(560);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 0) >= 0))) {
    Z.setLine(560);
    return f_LlEmitter__regionEnter(Z.dup(v_this));
  }
  Z.setLine(560);
  return null;
  return null;
}
function f_LlEmitter__regionExit__w(v_this, v_args) {
  Z.setLine(565);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 0) >= 0))) {
    Z.setLine(565);
    return f_LlEmitter__regionExit(Z.dup(v_this));
  }
  Z.setLine(565);
  return null;
  return null;
}
function f_LlEmitter__regionEnd__w(v_this, v_args) {
  Z.setLine(578);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 0) >= 0))) {
    Z.setLine(578);
    return f_LlEmitter__regionEnd(Z.dup(v_this));
  }
  Z.setLine(578);
  return null;
  return null;
}
function f_LlEmitter__pushLoop__w(v_this, v_args) {
  Z.setLine(580);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 0) >= 0))) {
    Z.setLine(580);
    return f_LlEmitter__pushLoop(Z.dup(v_this));
  }
  Z.setLine(580);
  return null;
  return null;
}
function f_LlEmitter__popLoop__w(v_this, v_args) {
  Z.setLine(581);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 0) >= 0))) {
    Z.setLine(581);
    return f_LlEmitter__popLoop(Z.dup(v_this));
  }
  Z.setLine(581);
  return null;
  return null;
}
function f_LlEmitter__jumpOut__w(v_this, v_args) {
  Z.setLine(583);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(583);
    Z.raise(new Z.ZExc(1, "jumpOut: brak argumentu $depth"));
  }
  Z.setLine(583);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 1) >= 0))) {
    Z.setLine(583);
    return f_LlEmitter__jumpOut(Z.dup(v_this), Z.dup(Z.index(v_args, 0)));
  }
  Z.setLine(583);
  return null;
  return null;
}
function f_LlEmitter__catchCond__w(v_this, v_args) {
  Z.setLine(596);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(596);
    Z.raise(new Z.ZExc(1, "catchCond: brak argumentu $types"));
  }
  Z.setLine(596);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 1))) {
    Z.setLine(596);
    Z.raise(new Z.ZExc(1, "catchCond: brak argumentu $x"));
  }
  Z.setLine(596);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 2) >= 0))) {
    Z.setLine(596);
    return f_LlEmitter__catchCond(Z.dup(v_this), Z.dup(Z.index(v_args, 0)), Z.dup(Z.index(v_args, 1)));
  }
  Z.setLine(596);
  return null;
  return null;
}
function f_LlEmitter__handler__w(v_this, v_args) {
  Z.setLine(617);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 0) >= 0))) {
    Z.setLine(617);
    return f_LlEmitter__handler(Z.dup(v_this));
  }
  Z.setLine(617);
  return null;
  return null;
}
function f_LlEmitter__jb__w(v_this, v_args) {
  Z.setLine(624);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(624);
    Z.raise(new Z.ZExc(1, "jb: brak argumentu $h"));
  }
  Z.setLine(624);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 1) >= 0))) {
    Z.setLine(624);
    return f_LlEmitter__jb(Z.dup(v_this), Z.dup(Z.index(v_args, 0)));
  }
  Z.setLine(624);
  return null;
  return null;
}
function f_LlEmitter__tryCatch__w(v_this, v_args) {
  Z.setLine(630);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(630);
    Z.raise(new Z.ZExc(1, "tryCatch: brak argumentu $body"));
  }
  Z.setLine(630);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 1))) {
    Z.setLine(630);
    Z.raise(new Z.ZExc(1, "tryCatch: brak argumentu $catches"));
  }
  Z.setLine(630);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 2) >= 0))) {
    Z.setLine(630);
    return f_LlEmitter__tryCatch(Z.dup(v_this), Z.dup(Z.index(v_args, 0)), Z.dup(Z.index(v_args, 1)));
  }
  Z.setLine(630);
  return null;
  return null;
}
function f_LlEmitter__tryStmt__w(v_this, v_args) {
  Z.setLine(669);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(669);
    Z.raise(new Z.ZExc(1, "tryStmt: brak argumentu $s"));
  }
  Z.setLine(669);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 1) >= 0))) {
    Z.setLine(669);
    return f_LlEmitter__tryStmt(Z.dup(v_this), Z.dup(Z.index(v_args, 0)));
  }
  Z.setLine(669);
  return null;
  return null;
}
function f_LlEmitter__chkType__w(v_this, v_args) {
  Z.setLine(714);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(714);
    Z.raise(new Z.ZExc(1, "chkType: brak argumentu $types"));
  }
  Z.setLine(714);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 1))) {
    Z.setLine(714);
    Z.raise(new Z.ZExc(1, "chkType: brak argumentu $v"));
  }
  Z.setLine(714);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 2))) {
    Z.setLine(714);
    Z.raise(new Z.ZExc(1, "chkType: brak argumentu $what"));
  }
  Z.setLine(714);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 3) >= 0))) {
    Z.setLine(714);
    return f_LlEmitter__chkType(Z.dup(v_this), Z.dup(Z.index(v_args, 0)), Z.dup(Z.index(v_args, 1)), Z.dup(Z.index(v_args, 2)));
  }
  Z.setLine(714);
  return null;
  return null;
}
function f_LlEmitter__stmt__w(v_this, v_args) {
  Z.setLine(721);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(721);
    Z.raise(new Z.ZExc(1, "stmt: brak argumentu $s"));
  }
  Z.setLine(721);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 1) >= 0))) {
    Z.setLine(721);
    return f_LlEmitter__stmt(Z.dup(v_this), Z.dup(Z.index(v_args, 0)));
  }
  Z.setLine(721);
  return null;
  return null;
}
function f_LlEmitter__emptyStr__w(v_this, v_args) {
  Z.setLine(954);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 0) >= 0))) {
    Z.setLine(954);
    return f_LlEmitter__emptyStr(Z.dup(v_this));
  }
  Z.setLine(954);
  return null;
  return null;
}
function f_LlEmitter__beginFunc__w(v_this, v_args) {
  Z.setLine(962);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(962);
    Z.raise(new Z.ZExc(1, "beginFunc: brak argumentu $vol"));
  }
  Z.setLine(962);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 1) >= 0))) {
    Z.setLine(962);
    return f_LlEmitter__beginFunc(Z.dup(v_this), Z.dup(Z.index(v_args, 0)));
  }
  Z.setLine(962);
  return null;
  return null;
}
function f_LlEmitter__initLocals__w(v_this, v_args) {
  Z.setLine(971);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(971);
    Z.raise(new Z.ZExc(1, "initLocals: brak argumentu $locals"));
  }
  Z.setLine(971);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 1))) {
    Z.setLine(971);
    Z.raise(new Z.ZExc(1, "initLocals: brak argumentu $params"));
  }
  Z.setLine(971);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 2) >= 0))) {
    Z.setLine(971);
    return f_LlEmitter__initLocals(Z.dup(v_this), Z.dup(Z.index(v_args, 0)), Z.dup(Z.index(v_args, 1)));
  }
  Z.setLine(971);
  return null;
  return null;
}
function f_LlEmitter__finishFunc__w(v_this, v_args) {
  Z.setLine(981);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(981);
    Z.raise(new Z.ZExc(1, "finishFunc: brak argumentu $header"));
  }
  Z.setLine(981);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 1))) {
    Z.setLine(981);
    Z.raise(new Z.ZExc(1, "finishFunc: brak argumentu $kind"));
  }
  Z.setLine(981);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 2) >= 0))) {
    Z.setLine(981);
    return f_LlEmitter__finishFunc(Z.dup(v_this), Z.dup(Z.index(v_args, 0)), Z.dup(Z.index(v_args, 1)));
  }
  Z.setLine(981);
  return null;
  return null;
}
function f_LlEmitter__funcDef__w(v_this, v_args) {
  Z.setLine(996);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(996);
    Z.raise(new Z.ZExc(1, "funcDef: brak argumentu $name"));
  }
  Z.setLine(996);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 1) >= 0))) {
    Z.setLine(996);
    return f_LlEmitter__funcDef(Z.dup(v_this), Z.dup(Z.index(v_args, 0)));
  }
  Z.setLine(996);
  return null;
  return null;
}
function f_LlEmitter__generate__w(v_this, v_args) {
  Z.setLine(1041);
  if (Z.truthy(Z.ident(Z.B.count(v_args), 0))) {
    Z.setLine(1041);
    Z.raise(new Z.ZExc(1, "generate: brak argumentu $triple"));
  }
  Z.setLine(1041);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 1) >= 0))) {
    Z.setLine(1041);
    return f_LlEmitter__generate(Z.dup(v_this), Z.dup(Z.index(v_args, 0)));
  }
  Z.setLine(1041);
  return null;
  return null;
}
function f_LlEmitter__decls__w(v_this, v_args) {
  Z.setLine(1109);
  if (Z.truthy((Z.cmp(Z.B.count(v_args), 0) >= 0))) {
    Z.setLine(1109);
    return f_LlEmitter__decls(Z.dup(v_this));
  }
  Z.setLine(1109);
  return null;
  return null;
}
function f_zs_invoke(v_o, v_name, v_args) {
  let v_c = null;
  Z.setLine(0);
  (v_c = Z.B.zs_obj_class(v_o));
  Z.setLine(0);
  if (Z.truthy(Z.ident(v_c, null))) {
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "getMessage"))) {
      Z.setLine(0);
      return Z.getMessage(v_o);
    }
  }
  Z.setLine(0);
  if (Z.truthy(Z.ident(v_c, "LexError"))) {
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "getMessage"))) {
      Z.setLine(0);
      return f_Exception__getMessage__w(Z.dup(v_o), Z.dup(v_args));
    }
  }
  Z.setLine(0);
  if (Z.truthy(Z.ident(v_c, "Lexer"))) {
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "peek"))) {
      Z.setLine(0);
      return f_Lexer__peek__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "bump"))) {
      Z.setLine(0);
      return f_Lexer__bump__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "fail"))) {
      Z.setLine(0);
      return f_Lexer__fail__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "emit"))) {
      Z.setLine(0);
      return f_Lexer__emit__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "run"))) {
      Z.setLine(0);
      return f_Lexer__run__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "skipTrivia"))) {
      Z.setLine(0);
      return f_Lexer__skipTrivia__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "variable"))) {
      Z.setLine(0);
      return f_Lexer__variable__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "ident"))) {
      Z.setLine(0);
      return f_Lexer__ident__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "digitValue"))) {
      Z.setLine(0);
      return f_Lexer__digitValue__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "digits"))) {
      Z.setLine(0);
      return f_Lexer__digits__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "number"))) {
      Z.setLine(0);
      return f_Lexer__number__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "string"))) {
      Z.setLine(0);
      return f_Lexer__string__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "op"))) {
      Z.setLine(0);
      return f_Lexer__op__w(Z.dup(v_o), Z.dup(v_args));
    }
  }
  Z.setLine(0);
  if (Z.truthy(Z.ident(v_c, "ParseError"))) {
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "getMessage"))) {
      Z.setLine(0);
      return f_Exception__getMessage__w(Z.dup(v_o), Z.dup(v_args));
    }
  }
  Z.setLine(0);
  if (Z.truthy(Z.ident(v_c, "Parser"))) {
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "cur"))) {
      Z.setLine(0);
      return f_Parser__cur__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "at"))) {
      Z.setLine(0);
      return f_Parser__at__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "line"))) {
      Z.setLine(0);
      return f_Parser__line__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "atEof"))) {
      Z.setLine(0);
      return f_Parser__atEof__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "bump"))) {
      Z.setLine(0);
      return f_Parser__bump__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "back"))) {
      Z.setLine(0);
      return f_Parser__back__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "fail"))) {
      Z.setLine(0);
      return f_Parser__fail__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "isOp"))) {
      Z.setLine(0);
      return f_Parser__isOp__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "isKw"))) {
      Z.setLine(0);
      return f_Parser__isKw__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "isWord"))) {
      Z.setLine(0);
      return f_Parser__isWord__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "isVar"))) {
      Z.setLine(0);
      return f_Parser__isVar__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "eatOp"))) {
      Z.setLine(0);
      return f_Parser__eatOp__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "eatKw"))) {
      Z.setLine(0);
      return f_Parser__eatKw__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "eatWord"))) {
      Z.setLine(0);
      return f_Parser__eatWord__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "expectOp"))) {
      Z.setLine(0);
      return f_Parser__expectOp__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "ident"))) {
      Z.setLine(0);
      return f_Parser__ident__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "varName"))) {
      Z.setLine(0);
      return f_Parser__varName__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "isFuncKw"))) {
      Z.setLine(0);
      return f_Parser__isFuncKw__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "block"))) {
      Z.setLine(0);
      return f_Parser__block__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "body"))) {
      Z.setLine(0);
      return f_Parser__body__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "parenExpr"))) {
      Z.setLine(0);
      return f_Parser__parenExpr__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "path"))) {
      Z.setLine(0);
      return f_Parser__path__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "stmt"))) {
      Z.setLine(0);
      return f_Parser__stmt__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "ifRest"))) {
      Z.setLine(0);
      return f_Parser__ifRest__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "exprList"))) {
      Z.setLine(0);
      return f_Parser__exprList__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "forStmt"))) {
      Z.setLine(0);
      return f_Parser__forStmt__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "foreachStmt"))) {
      Z.setLine(0);
      return f_Parser__foreachStmt__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "switchStmt"))) {
      Z.setLine(0);
      return f_Parser__switchStmt__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "tryStmt"))) {
      Z.setLine(0);
      return f_Parser__tryStmt__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "externStmt"))) {
      Z.setLine(0);
      return f_Parser__externStmt__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "types"))) {
      Z.setLine(0);
      return f_Parser__types__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "params"))) {
      Z.setLine(0);
      return f_Parser__params__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "funcRest"))) {
      Z.setLine(0);
      return f_Parser__funcRest__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "classDecl"))) {
      Z.setLine(0);
      return f_Parser__classDecl__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "expr"))) {
      Z.setLine(0);
      return f_Parser__expr__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "checkLvalue"))) {
      Z.setLine(0);
      return f_Parser__checkLvalue__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "exprBp"))) {
      Z.setLine(0);
      return f_Parser__exprBp__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "unary"))) {
      Z.setLine(0);
      return f_Parser__unary__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "args"))) {
      Z.setLine(0);
      return f_Parser__args__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "postfix"))) {
      Z.setLine(0);
      return f_Parser__postfix__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "primary"))) {
      Z.setLine(0);
      return f_Parser__primary__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "matchExpr"))) {
      Z.setLine(0);
      return f_Parser__matchExpr__w(Z.dup(v_o), Z.dup(v_args));
    }
  }
  Z.setLine(0);
  if (Z.truthy(Z.ident(v_c, "Bundler"))) {
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "scan"))) {
      Z.setLine(0);
      return f_Bundler__scan__w(Z.dup(v_o), Z.dup(v_args));
    }
  }
  Z.setLine(0);
  if (Z.truthy(Z.ident(v_c, "SemaScope"))) {
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "raise"))) {
      Z.setLine(0);
      return f_SemaScope__raise__w(Z.dup(v_o), Z.dup(v_args));
    }
  }
  Z.setLine(0);
  if (Z.truthy(Z.ident(v_c, "Analyzer"))) {
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "baseVar"))) {
      Z.setLine(0);
      return f_Analyzer__baseVar__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "allocKind"))) {
      Z.setLine(0);
      return f_Analyzer__allocKind__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "valueVars"))) {
      Z.setLine(0);
      return f_Analyzer__valueVars__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "visitAny"))) {
      Z.setLine(0);
      return f_Analyzer__visitAny__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "visitChildren"))) {
      Z.setLine(0);
      return f_Analyzer__visitChildren__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "visit"))) {
      Z.setLine(0);
      return f_Analyzer__visit__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "fnScope"))) {
      Z.setLine(0);
      return f_Analyzer__fnScope__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "resolveChildren"))) {
      Z.setLine(0);
      return f_Analyzer__resolveChildren__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "finish"))) {
      Z.setLine(0);
      return f_Analyzer__finish__w(Z.dup(v_o), Z.dup(v_args));
    }
  }
  Z.setLine(0);
  if (Z.truthy(Z.ident(v_c, "Lowerer"))) {
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "err"))) {
      Z.setLine(0);
      return f_Lowerer__err__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "addLocal"))) {
      Z.setLine(0);
      return f_Lowerer__addLocal__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "collectExpr"))) {
      Z.setLine(0);
      return f_Lowerer__collectExpr__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "collectTarget"))) {
      Z.setLine(0);
      return f_Lowerer__collectTarget__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "collectAny"))) {
      Z.setLine(0);
      return f_Lowerer__collectAny__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "checkStmts"))) {
      Z.setLine(0);
      return f_Lowerer__checkStmts__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "checkStmt"))) {
      Z.setLine(0);
      return f_Lowerer__checkStmt__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "checkNew"))) {
      Z.setLine(0);
      return f_Lowerer__checkNew__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "containsTry"))) {
      Z.setLine(0);
      return f_Lowerer__containsTry__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "calleeName"))) {
      Z.setLine(0);
      return f_Lowerer__calleeName__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "checkExpr"))) {
      Z.setLine(0);
      return f_Lowerer__checkExpr__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "checkLvalue"))) {
      Z.setLine(0);
      return f_Lowerer__checkLvalue__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "checkCall"))) {
      Z.setLine(0);
      return f_Lowerer__checkCall__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "topCallsMain"))) {
      Z.setLine(0);
      return f_Lowerer__topCallsMain__w(Z.dup(v_o), Z.dup(v_args));
    }
  }
  Z.setLine(0);
  if (Z.truthy(Z.ident(v_c, "Lifter"))) {
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "err"))) {
      Z.setLine(0);
      return f_Lifter__err__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "scan"))) {
      Z.setLine(0);
      return f_Lifter__scan__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "names"))) {
      Z.setLine(0);
      return f_Lifter__names__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "freeOf"))) {
      Z.setLine(0);
      return f_Lifter__freeOf__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "lift"))) {
      Z.setLine(0);
      return f_Lifter__lift__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "rw"))) {
      Z.setLine(0);
      return f_Lifter__rw__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "argsArray"))) {
      Z.setLine(0);
      return f_Lifter__argsArray__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "rwCall"))) {
      Z.setLine(0);
      return f_Lifter__rwCall__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "plain"))) {
      Z.setLine(0);
      return f_Lifter__plain__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "reorder"))) {
      Z.setLine(0);
      return f_Lifter__reorder__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "helpers"))) {
      Z.setLine(0);
      return f_Lifter__helpers__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "dispatcher"))) {
      Z.setLine(0);
      return f_Lifter__dispatcher__w(Z.dup(v_o), Z.dup(v_args));
    }
  }
  Z.setLine(0);
  if (Z.truthy(Z.ident(v_c, "Desugar"))) {
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "err"))) {
      Z.setLine(0);
      return f_Desugar__err__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "node"))) {
      Z.setLine(0);
      return f_Desugar__node__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "nm"))) {
      Z.setLine(0);
      return f_Desugar__nm__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "mkstr"))) {
      Z.setLine(0);
      return f_Desugar__mkstr__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "mkvar"))) {
      Z.setLine(0);
      return f_Desugar__mkvar__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "call"))) {
      Z.setLine(0);
      return f_Desugar__call__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "fresh"))) {
      Z.setLine(0);
      return f_Desugar__fresh__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "collect"))) {
      Z.setLine(0);
      return f_Desugar__collect__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "chain"))) {
      Z.setLine(0);
      return f_Desugar__chain__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "owner"))) {
      Z.setLine(0);
      return f_Desugar__owner__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "allProps"))) {
      Z.setLine(0);
      return f_Desugar__allProps__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "isaNames"))) {
      Z.setLine(0);
      return f_Desugar__isaNames__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "rwList"))) {
      Z.setLine(0);
      return f_Desugar__rwList__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "rw"))) {
      Z.setLine(0);
      return f_Desugar__rw__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "baseOk"))) {
      Z.setLine(0);
      return f_Desugar__baseOk__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "propModify"))) {
      Z.setLine(0);
      return f_Desugar__propModify__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "staticName"))) {
      Z.setLine(0);
      return f_Desugar__staticName__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "staticTarget"))) {
      Z.setLine(0);
      return f_Desugar__staticTarget__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "clsName"))) {
      Z.setLine(0);
      return f_Desugar__clsName__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "constOf"))) {
      Z.setLine(0);
      return f_Desugar__constOf__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "rwNew"))) {
      Z.setLine(0);
      return f_Desugar__rwNew__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "rwCall"))) {
      Z.setLine(0);
      return f_Desugar__rwCall__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "rwTry"))) {
      Z.setLine(0);
      return f_Desugar__rwTry__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "anyMethod"))) {
      Z.setLine(0);
      return f_Desugar__anyMethod__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "stmtExpr"))) {
      Z.setLine(0);
      return f_Desugar__stmtExpr__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "funcStmt"))) {
      Z.setLine(0);
      return f_Desugar__funcStmt__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "param"))) {
      Z.setLine(0);
      return f_Desugar__param__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "genClass"))) {
      Z.setLine(0);
      return f_Desugar__genClass__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "wrapper"))) {
      Z.setLine(0);
      return f_Desugar__wrapper__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "wrapperN"))) {
      Z.setLine(0);
      return f_Desugar__wrapperN__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "genDispatchN"))) {
      Z.setLine(0);
      return f_Desugar__genDispatchN__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "genDispatch"))) {
      Z.setLine(0);
      return f_Desugar__genDispatch__w(Z.dup(v_o), Z.dup(v_args));
    }
  }
  Z.setLine(0);
  if (Z.truthy(Z.ident(v_c, "Linker"))) {
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "err"))) {
      Z.setLine(0);
      return f_Linker__err__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "prefixOf"))) {
      Z.setLine(0);
      return f_Linker__prefixOf__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "dirOf"))) {
      Z.setLine(0);
      return f_Linker__dirOf__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "rw"))) {
      Z.setLine(0);
      return f_Linker__rw__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "loadModule"))) {
      Z.setLine(0);
      return f_Linker__loadModule__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "collectImports"))) {
      Z.setLine(0);
      return f_Linker__collectImports__w(Z.dup(v_o), Z.dup(v_args));
    }
  }
  Z.setLine(0);
  if (Z.truthy(Z.ident(v_c, "VarPass"))) {
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "rw"))) {
      Z.setLine(0);
      return f_VarPass__rw__w(Z.dup(v_o), Z.dup(v_args));
    }
  }
  Z.setLine(0);
  if (Z.truthy(Z.ident(v_c, "LlEmitter"))) {
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "r"))) {
      Z.setLine(0);
      return f_LlEmitter__r__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "newLabel"))) {
      Z.setLine(0);
      return f_LlEmitter__newLabel__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "line"))) {
      Z.setLine(0);
      return f_LlEmitter__line__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "label"))) {
      Z.setLine(0);
      return f_LlEmitter__label__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "terminate"))) {
      Z.setLine(0);
      return f_LlEmitter__terminate__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "esc"))) {
      Z.setLine(0);
      return f_LlEmitter__esc__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "cstr"))) {
      Z.setLine(0);
      return f_LlEmitter__cstr__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "strSlot"))) {
      Z.setLine(0);
      return f_LlEmitter__strSlot__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "slot"))) {
      Z.setLine(0);
      return f_LlEmitter__slot__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "ty"))) {
      Z.setLine(0);
      return f_LlEmitter__ty__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "rt"))) {
      Z.setLine(0);
      return f_LlEmitter__rt__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "vcall"))) {
      Z.setLine(0);
      return f_LlEmitter__vcall__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "mkv"))) {
      Z.setLine(0);
      return f_LlEmitter__mkv__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "nullv"))) {
      Z.setLine(0);
      return f_LlEmitter__nullv__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "truthy"))) {
      Z.setLine(0);
      return f_LlEmitter__truthy__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "boolOf"))) {
      Z.setLine(0);
      return f_LlEmitter__boolOf__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "ident"))) {
      Z.setLine(0);
      return f_LlEmitter__ident__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "load"))) {
      Z.setLine(0);
      return f_LlEmitter__load__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "store"))) {
      Z.setLine(0);
      return f_LlEmitter__store__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "storeTo"))) {
      Z.setLine(0);
      return f_LlEmitter__storeTo__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "loadFrom"))) {
      Z.setLine(0);
      return f_LlEmitter__loadFrom__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "isLval"))) {
      Z.setLine(0);
      return f_LlEmitter__isLval__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "val"))) {
      Z.setLine(0);
      return f_LlEmitter__val__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "binop"))) {
      Z.setLine(0);
      return f_LlEmitter__binop__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "quiet"))) {
      Z.setLine(0);
      return f_LlEmitter__quiet__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "keyOf"))) {
      Z.setLine(0);
      return f_LlEmitter__keyOf__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "lv"))) {
      Z.setLine(0);
      return f_LlEmitter__lv__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "newArr"))) {
      Z.setLine(0);
      return f_LlEmitter__newArr__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "vcallVoid"))) {
      Z.setLine(0);
      return f_LlEmitter__vcallVoid__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "incdec"))) {
      Z.setLine(0);
      return f_LlEmitter__incdec__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "assignop"))) {
      Z.setLine(0);
      return f_LlEmitter__assignop__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "coalesceWith"))) {
      Z.setLine(0);
      return f_LlEmitter__coalesceWith__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "assign"))) {
      Z.setLine(0);
      return f_LlEmitter__assign__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "argRegs"))) {
      Z.setLine(0);
      return f_LlEmitter__argRegs__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "call"))) {
      Z.setLine(0);
      return f_LlEmitter__call__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "doExit"))) {
      Z.setLine(0);
      return f_LlEmitter__doExit__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "builtin"))) {
      Z.setLine(0);
      return f_LlEmitter__builtin__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "expr"))) {
      Z.setLine(0);
      return f_LlEmitter__expr__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "shortCircuit"))) {
      Z.setLine(0);
      return f_LlEmitter__shortCircuit__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "ternary"))) {
      Z.setLine(0);
      return f_LlEmitter__ternary__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "setLine"))) {
      Z.setLine(0);
      return f_LlEmitter__setLine__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "block"))) {
      Z.setLine(0);
      return f_LlEmitter__block__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "regionBegin"))) {
      Z.setLine(0);
      return f_LlEmitter__regionBegin__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "regionEnter"))) {
      Z.setLine(0);
      return f_LlEmitter__regionEnter__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "regionExit"))) {
      Z.setLine(0);
      return f_LlEmitter__regionExit__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "regionEnd"))) {
      Z.setLine(0);
      return f_LlEmitter__regionEnd__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "pushLoop"))) {
      Z.setLine(0);
      return f_LlEmitter__pushLoop__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "popLoop"))) {
      Z.setLine(0);
      return f_LlEmitter__popLoop__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "jumpOut"))) {
      Z.setLine(0);
      return f_LlEmitter__jumpOut__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "catchCond"))) {
      Z.setLine(0);
      return f_LlEmitter__catchCond__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "handler"))) {
      Z.setLine(0);
      return f_LlEmitter__handler__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "jb"))) {
      Z.setLine(0);
      return f_LlEmitter__jb__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "tryCatch"))) {
      Z.setLine(0);
      return f_LlEmitter__tryCatch__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "tryStmt"))) {
      Z.setLine(0);
      return f_LlEmitter__tryStmt__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "chkType"))) {
      Z.setLine(0);
      return f_LlEmitter__chkType__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "stmt"))) {
      Z.setLine(0);
      return f_LlEmitter__stmt__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "emptyStr"))) {
      Z.setLine(0);
      return f_LlEmitter__emptyStr__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "beginFunc"))) {
      Z.setLine(0);
      return f_LlEmitter__beginFunc__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "initLocals"))) {
      Z.setLine(0);
      return f_LlEmitter__initLocals__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "finishFunc"))) {
      Z.setLine(0);
      return f_LlEmitter__finishFunc__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "funcDef"))) {
      Z.setLine(0);
      return f_LlEmitter__funcDef__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "generate"))) {
      Z.setLine(0);
      return f_LlEmitter__generate__w(Z.dup(v_o), Z.dup(v_args));
    }
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "decls"))) {
      Z.setLine(0);
      return f_LlEmitter__decls__w(Z.dup(v_o), Z.dup(v_args));
    }
  }
  Z.setLine(0);
  if (Z.truthy(Z.ident(v_c, "Exception"))) {
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "getMessage"))) {
      Z.setLine(0);
      return f_Exception__getMessage__w(Z.dup(v_o), Z.dup(v_args));
    }
  }
  Z.setLine(0);
  if (Z.truthy(Z.ident(v_c, "Error"))) {
    Z.setLine(0);
    if (Z.truthy(Z.ident(v_name, "getMessage"))) {
      Z.setLine(0);
      return f_Exception__getMessage__w(Z.dup(v_o), Z.dup(v_args));
    }
  }
  Z.setLine(0);
  return Z.B.zs_no_method(v_o, v_name);
  return null;
}
function f_zs_isa(v_o, v_k) {
  let v_c = null, v_t = null;
  Z.setLine(0);
  (v_c = Z.B.zs_obj_class(v_o));
  Z.setLine(0);
  if (Z.truthy(Z.ident(v_c, null))) {
    Z.setLine(0);
    (v_t = Z.B.typeof(v_o));
    Z.setLine(0);
    return (Z.truthy(Z.ident(v_t, v_k)) || Z.truthy((Z.truthy((Z.truthy(Z.ident(v_k, "Exception")) && Z.truthy(Z.ident(v_t, "Error")))) || Z.truthy((Z.truthy(Z.ident(v_k, "Throwable")) && Z.truthy((Z.truthy(Z.ident(v_t, "Exception")) || Z.truthy(Z.ident(v_t, "Error")))))))));
  }
  Z.setLine(0);
  if (Z.truthy(Z.ident(v_c, "LexError"))) {
    Z.setLine(0);
    return (Z.truthy((Z.truthy(Z.ident(v_k, "LexError")) || Z.truthy(Z.ident(v_k, "Exception")))) || Z.truthy(Z.ident(v_k, "Throwable")));
  }
  Z.setLine(0);
  if (Z.truthy(Z.ident(v_c, "LexTables"))) {
    Z.setLine(0);
    return Z.ident(v_k, "LexTables");
  }
  Z.setLine(0);
  if (Z.truthy(Z.ident(v_c, "Lexer"))) {
    Z.setLine(0);
    return Z.ident(v_k, "Lexer");
  }
  Z.setLine(0);
  if (Z.truthy(Z.ident(v_c, "ParseError"))) {
    Z.setLine(0);
    return (Z.truthy((Z.truthy(Z.ident(v_k, "ParseError")) || Z.truthy(Z.ident(v_k, "Exception")))) || Z.truthy(Z.ident(v_k, "Throwable")));
  }
  Z.setLine(0);
  if (Z.truthy(Z.ident(v_c, "Tables"))) {
    Z.setLine(0);
    return Z.ident(v_k, "Tables");
  }
  Z.setLine(0);
  if (Z.truthy(Z.ident(v_c, "Parser"))) {
    Z.setLine(0);
    return Z.ident(v_k, "Parser");
  }
  Z.setLine(0);
  if (Z.truthy(Z.ident(v_c, "ZbcTables"))) {
    Z.setLine(0);
    return Z.ident(v_k, "ZbcTables");
  }
  Z.setLine(0);
  if (Z.truthy(Z.ident(v_c, "Bundler"))) {
    Z.setLine(0);
    return Z.ident(v_k, "Bundler");
  }
  Z.setLine(0);
  if (Z.truthy(Z.ident(v_c, "SemaTables"))) {
    Z.setLine(0);
    return Z.ident(v_k, "SemaTables");
  }
  Z.setLine(0);
  if (Z.truthy(Z.ident(v_c, "SemaScope"))) {
    Z.setLine(0);
    return Z.ident(v_k, "SemaScope");
  }
  Z.setLine(0);
  if (Z.truthy(Z.ident(v_c, "Analyzer"))) {
    Z.setLine(0);
    return Z.ident(v_k, "Analyzer");
  }
  Z.setLine(0);
  if (Z.truthy(Z.ident(v_c, "IrTables"))) {
    Z.setLine(0);
    return Z.ident(v_k, "IrTables");
  }
  Z.setLine(0);
  if (Z.truthy(Z.ident(v_c, "Lowerer"))) {
    Z.setLine(0);
    return Z.ident(v_k, "Lowerer");
  }
  Z.setLine(0);
  if (Z.truthy(Z.ident(v_c, "Lifter"))) {
    Z.setLine(0);
    return Z.ident(v_k, "Lifter");
  }
  Z.setLine(0);
  if (Z.truthy(Z.ident(v_c, "Cls"))) {
    Z.setLine(0);
    return Z.ident(v_k, "Cls");
  }
  Z.setLine(0);
  if (Z.truthy(Z.ident(v_c, "Desugar"))) {
    Z.setLine(0);
    return Z.ident(v_k, "Desugar");
  }
  Z.setLine(0);
  if (Z.truthy(Z.ident(v_c, "Linker"))) {
    Z.setLine(0);
    return Z.ident(v_k, "Linker");
  }
  Z.setLine(0);
  if (Z.truthy(Z.ident(v_c, "VarPass"))) {
    Z.setLine(0);
    return Z.ident(v_k, "VarPass");
  }
  Z.setLine(0);
  if (Z.truthy(Z.ident(v_c, "LlEmitter"))) {
    Z.setLine(0);
    return Z.ident(v_k, "LlEmitter");
  }
  Z.setLine(0);
  if (Z.truthy(Z.ident(v_c, "Exception"))) {
    Z.setLine(0);
    return (Z.truthy(Z.ident(v_k, "Exception")) || Z.truthy(Z.ident(v_k, "Throwable")));
  }
  Z.setLine(0);
  if (Z.truthy(Z.ident(v_c, "Error"))) {
    Z.setLine(0);
    return (Z.truthy((Z.truthy(Z.ident(v_k, "Error")) || Z.truthy(Z.ident(v_k, "Exception")))) || Z.truthy(Z.ident(v_k, "Throwable")));
  }
  Z.setLine(0);
  return false;
  return null;
}
function f_Workspace_lexer__tokenize(v_src, v_keep) {
  let v_lx = null;
  let _t2250 = null;
  Z.setLine(252);
  (v_lx = f_Lexer__new(Z.dup(v_src), Z.dup(v_keep)));
  Z.setLine(253);
  return f_zs_invoke(Z.dup(v_lx), "run", ((_t2250 = Z.arrNew()), _t2250));
  return null;
}
function f_Workspace_parser__node(v_kind, v_line, v_rest) {
  let v_a = null, v_x = null;
  let _t2251 = null;
  Z.setLine(41);
  (v_a = ((_t2251 = Z.arrNew()), Z.apush(_t2251, Z.concat(":", v_kind)), Z.apush(_t2251, Z.dup(v_line)), _t2251));
  Z.setLine(42);
  {
    const _it211 = Z.foreachArr(Z.dup(v_rest));
    L211: for (let _i211 = 0; _i211 < _it211.keys.length; _i211++) {
      v_x = _it211.vals[_i211];
      Z.setLine(42);
      Z.apush((v_a = Z.wr(v_a)), Z.dup(v_x));
    }
  }
  Z.setLine(43);
  return Z.dup(v_a);
  return null;
}
function f_Workspace_parser__isNode(v_v) {
  Z.setLine(47);
  return (Z.truthy((Z.truthy((Z.truthy(Z.B.is_array(v_v)) && Z.truthy((Z.cmp(Z.B.count(v_v), 1) > 0)))) && Z.truthy(Z.B.is_string(Z.index(v_v, 0))))) && Z.truthy(Z.B.starts_with(Z.index(v_v, 0), ":")));
  return null;
}
function f_Workspace_parser__isNamePath(v_e) {
  Z.setLine(51);
  if (Z.truthy(Z.ident(Z.index(v_e, 0), ":Name"))) {
    Z.setLine(51);
    return true;
  }
  Z.setLine(52);
  if (Z.truthy(Z.ident(Z.index(v_e, 0), ":Dot"))) {
    Z.setLine(52);
    return f_Workspace_parser__isNamePath(Z.dup(Z.index(v_e, 2)));
  }
  Z.setLine(53);
  return false;
  return null;
}
function f_Workspace_parser__parse(v_src) {
  let v_all = null, v_toks = null, v_t = null, v_p = null, v_out = null;
  let _t2252 = null, _t2253 = null, _t2254 = null, _t2255 = null;
  Z.setLine(614);
  (v_all = f_Workspace_lexer__tokenize(Z.dup(v_src), false));
  Z.setLine(615);
  (v_toks = ((_t2252 = Z.arrNew()), _t2252));
  Z.setLine(616);
  {
    const _it212 = Z.foreachArr(Z.dup(v_all));
    L212: for (let _i212 = 0; _i212 < _it212.keys.length; _i212++) {
      v_t = _it212.vals[_i212];
      Z.setLine(617);
      if (Z.truthy((Z.truthy(!Z.ident(Z.index(v_t, "kind"), "shebang")) && Z.truthy(!Z.ident(Z.index(v_t, "kind"), "doc"))))) {
        Z.setLine(617);
        Z.apush((v_toks = Z.wr(v_toks)), Z.dup(v_t));
      }
    }
  }
  Z.setLine(619);
  (v_p = f_Parser__new(Z.dup(v_toks)));
  Z.setLine(620);
  (v_out = ((_t2253 = Z.arrNew()), _t2253));
  L213: while (true) {
    Z.setLine(621);
    if (!Z.truthy(!Z.truthy(f_zs_invoke(Z.dup(v_p), "atEof", ((_t2254 = Z.arrNew()), _t2254))))) break;
    Z.setLine(621);
    Z.apush((v_out = Z.wr(v_out)), f_zs_invoke(Z.dup(v_p), "stmt", ((_t2255 = Z.arrNew()), _t2255)));
  }
  Z.setLine(622);
  return Z.dup(v_out);
  return null;
}
function f_Workspace_parser__escapeStr(v_s) {
  Z.setLine(626);
  (v_s = Z.B.replace(v_s, "\\", "\\\\"));
  Z.setLine(627);
  (v_s = Z.B.replace(v_s, "\"", "\\\""));
  Z.setLine(628);
  (v_s = Z.B.replace(v_s, "\n", "\\n"));
  Z.setLine(629);
  (v_s = Z.B.replace(v_s, "\t", "\\t"));
  Z.setLine(630);
  (v_s = Z.B.replace(v_s, "\r", "\\r"));
  Z.setLine(631);
  return Z.concat(Z.concat("\"", v_s), "\"");
  return null;
}
function f_Workspace_parser__dump(v_v) {
  let v_s = null, v_i = null, v_parts = null, v_x = null;
  let _t2256 = null, _t2257 = null;
  Z.setLine(638);
  if (Z.truthy(Z.ident(v_v, null))) {
    Z.setLine(638);
    return "_";
  }
  Z.setLine(639);
  if (Z.truthy(Z.B.is_bool(v_v))) {
    Z.setLine(639);
    return (Z.truthy(v_v) ? "true" : "false");
  }
  Z.setLine(640);
  if (Z.truthy(Z.B.is_int(v_v))) {
    Z.setLine(640);
    return Z.concat("", v_v);
  }
  Z.setLine(641);
  if (Z.truthy(Z.B.is_float(v_v))) {
    Z.setLine(641);
    return Z.concat("", v_v);
  }
  Z.setLine(642);
  if (Z.truthy(Z.B.is_string(v_v))) {
    Z.setLine(642);
    return f_Workspace_parser__escapeStr(Z.dup(v_v));
  }
  Z.setLine(643);
  if (Z.truthy(f_Workspace_parser__isNode(Z.dup(v_v)))) {
    Z.setLine(644);
    (v_s = Z.concat(Z.concat(Z.concat("(", Z.B.substr(Z.index(v_v, 0), 1)), "@"), Z.index(v_v, 1)));
    Z.setLine(645);
    (v_i = 2);
    L214: for (; Z.truthy((Z.cmp(v_i, Z.B.count(v_v)) < 0)); ((_t2256 = v_i), (v_i = Z.add(_t2256, 1)), _t2256)) {
      Z.setLine(645);
      (v_s = Z.concat(Z.concat(v_s, " "), f_Workspace_parser__dump(Z.dup(Z.index(v_v, v_i)))));
    }
    Z.setLine(646);
    return Z.concat(v_s, ")");
  }
  Z.setLine(648);
  (v_parts = ((_t2257 = Z.arrNew()), _t2257));
  Z.setLine(649);
  {
    const _it215 = Z.foreachArr(Z.dup(v_v));
    L215: for (let _i215 = 0; _i215 < _it215.keys.length; _i215++) {
      v_x = _it215.vals[_i215];
      Z.setLine(649);
      Z.apush((v_parts = Z.wr(v_parts)), f_Workspace_parser__dump(Z.dup(v_x)));
    }
  }
  Z.setLine(650);
  return Z.concat(Z.concat("[", Z.B.join(v_parts, " ")), "]");
  return null;
}
function f_Workspace_zbc__bundle(v_entryFile) {
  let v_b = null, v_ast = null, v_lines = null, v_key = null, v_stmts = null, v_s = null;
  let _t2258 = null, _t2259 = null;
  Z.setLine(45);
  (v_b = f_Bundler__new());
  Z.setLine(46);
  (v_ast = f_Workspace_parser__parse(Z.M.File.read(v_entryFile)));
  Z.setLine(47);
  f_zs_invoke(Z.dup(v_b), "scan", ((_t2258 = Z.arrNew()), Z.apush(_t2258, Z.dup(v_ast)), Z.apush(_t2258, Z.M.System.dirname(v_entryFile)), _t2258));
  Z.setLine(48);
  (v_lines = ((_t2259 = Z.arrNew()), Z.apush(_t2259, "ZBC 1"), _t2259));
  Z.setLine(49);
  {
    const _it216 = Z.foreachArr(Z.B.zs_obj_get(v_b, "mods"));
    L216: for (let _i216 = 0; _i216 < _it216.keys.length; _i216++) {
      v_stmts = _it216.vals[_i216];
      v_key = _it216.keys[_i216];
      Z.setLine(50);
      Z.apush((v_lines = Z.wr(v_lines)), Z.concat("@@module ", v_key));
      Z.setLine(51);
      {
        const _it217 = Z.foreachArr(Z.dup(v_stmts));
        L217: for (let _i217 = 0; _i217 < _it217.keys.length; _i217++) {
          v_s = _it217.vals[_i217];
          Z.setLine(51);
          Z.apush((v_lines = Z.wr(v_lines)), f_Workspace_parser__dump(Z.dup(v_s)));
        }
      }
    }
  }
  Z.setLine(53);
  Z.apush((v_lines = Z.wr(v_lines)), "@@entry");
  Z.setLine(54);
  {
    const _it218 = Z.foreachArr(Z.dup(v_ast));
    L218: for (let _i218 = 0; _i218 < _it218.keys.length; _i218++) {
      v_s = _it218.vals[_i218];
      Z.setLine(54);
      Z.apush((v_lines = Z.wr(v_lines)), f_Workspace_parser__dump(Z.dup(v_s)));
    }
  }
  Z.setLine(55);
  Z.apush((v_lines = Z.wr(v_lines)), "");
  Z.setLine(56);
  return Z.B.join(v_lines, "\n");
  return null;
}
function f_Workspace_sema__analyze(v_stmts) {
  let v_an = null, v_sc = null;
  let _t2260 = null, _t2261 = null, _t2262 = null;
  Z.setLine(264);
  (v_an = f_Analyzer__new());
  Z.setLine(265);
  (v_sc = f_SemaScope__new("{main}", 1, false));
  Z.setLine(266);
  f_zs_invoke(Z.dup(v_an), "visitAny", ((_t2260 = Z.arrNew()), Z.apush(_t2260, Z.dup(v_stmts)), Z.apush(_t2260, Z.dup(v_sc)), Z.apush(_t2260, ""), _t2260));
  Z.setLine(267);
  f_zs_invoke(Z.dup(v_an), "finish", ((_t2261 = Z.arrNew()), Z.apush(_t2261, Z.dup(v_sc)), Z.apush(_t2261, false), _t2261));
  Z.setLine(268);
  return ((_t2262 = Z.arrNew()), Z.aset(_t2262, "warnings", Z.B.zs_obj_get(v_an, "warnings")), Z.aset(_t2262, "functions", Z.B.zs_obj_get(v_an, "functions")), _t2262);
  return null;
}
function f_Workspace_sema__report(v_r) {
  let v_out = null, v_w = null, v_f = null, v_s = null;
  let _t2263 = null;
  Z.setLine(275);
  (v_out = ((_t2263 = Z.arrNew()), _t2263));
  Z.setLine(276);
  {
    const _it219 = Z.foreachArr(Z.dup(Z.index(v_r, "warnings")));
    L219: for (let _i219 = 0; _i219 < _it219.keys.length; _i219++) {
      v_w = _it219.vals[_i219];
      Z.setLine(276);
      Z.apush((v_out = Z.wr(v_out)), Z.concat(Z.concat(Z.concat("warn ", Z.index(v_w, 0)), ": "), Z.index(v_w, 1)));
    }
  }
  Z.setLine(277);
  {
    const _it220 = Z.foreachArr(Z.dup(Z.index(v_r, "functions")));
    L220: for (let _i220 = 0; _i220 < _it220.keys.length; _i220++) {
      v_f = _it220.vals[_i220];
      Z.setLine(278);
      if (Z.truthy(Z.ident(Z.B.count(Z.index(v_f, "sites")), 0))) {
        continue L220;
      }
      Z.setLine(279);
      Z.apush((v_out = Z.wr(v_out)), Z.concat(Z.concat(Z.concat("fn ", Z.index(v_f, "name")), " @"), Z.index(v_f, "line")));
      Z.setLine(280);
      {
        const _it221 = Z.foreachArr(Z.dup(Z.index(v_f, "sites")));
        L221: for (let _i221 = 0; _i221 < _it221.keys.length; _i221++) {
          v_s = _it221.vals[_i221];
          Z.setLine(281);
          Z.apush((v_out = Z.wr(v_out)), Z.concat(Z.concat(Z.concat(Z.concat(Z.concat(Z.concat(Z.concat(Z.concat(Z.concat("  ", Z.index(v_s, "line")), ": $"), Z.index(v_s, "var")), " = "), Z.index(v_s, "kind")), " -> Escape::"), Z.index(v_s, "escape")), " => "), Z.index(v_s, "zamm")));
        }
      }
    }
  }
  Z.setLine(284);
  return Z.B.join(v_out, "\n");
  return null;
}
function f_Workspace_ir__lower(v_ast) {
  let v_lw = null, v_top = null, v_s = null, v_f = null, v_name = null, v___r198 = null, v___w199 = null, v_p = null, v___r200 = null, v___w201 = null, v___k202 = null, v___r203 = null, v___w204 = null, v___r205 = null, v___w206 = null, v_k = null, v_path = null, v___r207 = null, v___w208 = null, v_loc = null, v___k209 = null, v___r210 = null, v___w211 = null, v_toploc = null, v_callsMain = null;
  let _t2264 = null, _t2265 = null, _t2266 = null, _t2267 = null, _t2268 = null, _t2269 = null, _t2270 = null, _t2271 = null, _t2272 = null, _t2273 = null, _t2274 = null, _t2275 = null, _t2276 = null, _t2277 = null, _t2278 = null, _t2279 = null, _t2280 = null, _t2281 = null;
  Z.setLine(279);
  (v_lw = f_Lowerer__new());
  Z.setLine(280);
  (v_top = ((_t2264 = Z.arrNew()), _t2264));
  Z.setLine(282);
  {
    const _it222 = Z.foreachArr(Z.dup(v_ast));
    L222: for (let _i222 = 0; _i222 < _it222.keys.length; _i222++) {
      v_s = _it222.vals[_i222];
      Z.setLine(283);
      if (Z.truthy(Z.ident(Z.index(v_s, 0), ":FuncStmt"))) {
        Z.setLine(284);
        (v_f = Z.dup(Z.index(v_s, 2)));
        Z.setLine(285);
        (v_name = Z.dup(Z.index(v_f, 2)));
        Z.setLine(286);
        if (Z.truthy(Z.B.has_key(Z.B.zs_obj_get(v_lw, "funcs"), v_name))) {
          Z.setLine(286);
          (v___r198 = ((_t2265 = Z.arrNew()), Z.apush(_t2265, Z.dup(Z.index(v_s, 1))), Z.apush(_t2265, "E0101"), Z.apush(_t2265, Z.concat(Z.concat("funkcja ", v_name), " zdefiniowana wielokrotnie")), _t2265));
          Z.setLine(286);
          (v___w199 = Z.B.zs_obj_take(v_lw, "errors"));
          Z.setLine(286);
          Z.apush((v___w199 = Z.wr(v___w199)), Z.dup(v___r198));
          Z.setLine(286);
          Z.B.zs_obj_put(v_lw, "errors", v___w199);
          continue L222;
        }
        Z.setLine(287);
        {
          const _it223 = Z.foreachArr(Z.dup(Z.index(v_f, 3)));
          L223: for (let _i223 = 0; _i223 < _it223.keys.length; _i223++) {
            v_p = _it223.vals[_i223];
            Z.setLine(288);
            if (Z.truthy(Z.index(v_p, 5))) {
              Z.setLine(288);
              (v___r200 = ((_t2266 = Z.arrNew()), Z.apush(_t2266, Z.dup(Z.index(v_s, 1))), Z.apush(_t2266, "E0104"), Z.apush(_t2266, "parametry variadic (...) niedostępne w backendzie natywnym 0.0.1"), _t2266));
              Z.setLine(288);
              (v___w201 = Z.B.zs_obj_take(v_lw, "errors"));
              Z.setLine(288);
              Z.apush((v___w201 = Z.wr(v___w201)), Z.dup(v___r200));
              Z.setLine(288);
              Z.B.zs_obj_put(v_lw, "errors", v___w201);
            }
          }
        }
        Z.setLine(290);
        (v___k202 = Z.dup(v_name));
        Z.setLine(290);
        (v___r203 = ((_t2267 = Z.arrNew()), Z.aset(_t2267, "name", Z.dup(v_name)), Z.aset(_t2267, "line", Z.dup(Z.index(v_s, 1))), Z.aset(_t2267, "params", Z.dup(Z.index(v_f, 3))), Z.aset(_t2267, "ret", Z.dup(Z.index(v_f, 4))), Z.aset(_t2267, "body", Z.dup(Z.index(v_f, 5))), Z.aset(_t2267, "locals", ((_t2268 = Z.arrNew()), _t2268)), Z.aset(_t2267, "has_try", false), _t2267));
        Z.setLine(290);
        (v___w204 = Z.B.zs_obj_take(v_lw, "funcs"));
        Z.setLine(290);
        Z.aset((v___w204 = Z.wr(v___w204)), v___k202, Z.dup(v___r203));
        Z.setLine(290);
        Z.B.zs_obj_put(v_lw, "funcs", v___w204);
        Z.setLine(291);
        (v___r205 = Z.dup(v_name));
        Z.setLine(291);
        (v___w206 = Z.B.zs_obj_take(v_lw, "order"));
        Z.setLine(291);
        Z.apush((v___w206 = Z.wr(v___w206)), Z.dup(v___r205));
        Z.setLine(291);
        Z.B.zs_obj_put(v_lw, "order", v___w206);
      }
    }
  }
  Z.setLine(295);
  {
    const _it224 = Z.foreachArr(Z.dup(v_ast));
    L224: for (let _i224 = 0; _i224 < _it224.keys.length; _i224++) {
      v_s = _it224.vals[_i224];
      Z.setLine(296);
      (v_k = Z.dup(Z.index(v_s, 0)));
      Z.setLine(297);
      if (Z.truthy((Z.truthy(Z.ident(v_k, ":FuncStmt")) || Z.truthy(Z.ident(v_k, ":Namespace"))))) {
        continue L224;
      }
      Z.setLine(298);
      if (Z.truthy(Z.ident(v_k, ":Import"))) {
        Z.setLine(299);
        (v_path = Z.dup(Z.index(v_s, 2)));
        Z.setLine(300);
        if (Z.truthy(!Z.truthy(Z.B.in_array(Z.index(v_path, 0), ((_t2269 = Z.arrNew()), Z.apush(_t2269, "System"), Z.apush(_t2269, "Math"), Z.apush(_t2269, "File"), Z.apush(_t2269, "Directory"), Z.apush(_t2269, "Process"), _t2269))))) {
          Z.setLine(301);
          (v___r207 = ((_t2270 = Z.arrNew()), Z.apush(_t2270, Z.dup(Z.index(v_s, 1))), Z.apush(_t2270, "E0106"), Z.apush(_t2270, Z.concat(Z.concat("import ", Z.B.join(v_path, ".")), ": moduły Z# nie są jeszcze obsługiwane w backendzie natywnym 0.0.1 (użyj `zsc build --emit zbc`)")), _t2270));
          Z.setLine(301);
          (v___w208 = Z.B.zs_obj_take(v_lw, "errors"));
          Z.setLine(301);
          Z.apush((v___w208 = Z.wr(v___w208)), Z.dup(v___r207));
          Z.setLine(301);
          Z.B.zs_obj_put(v_lw, "errors", v___w208);
        }
        continue L224;
      }
      Z.setLine(305);
      Z.apush((v_top = Z.wr(v_top)), Z.dup(v_s));
    }
  }
  Z.setLine(307);
  {
    const _it225 = Z.foreachArr(Z.B.zs_obj_get(v_lw, "order"));
    L225: for (let _i225 = 0; _i225 < _it225.keys.length; _i225++) {
      v_name = _it225.vals[_i225];
      Z.setLine(308);
      (v_f = Z.dup(Z.index(Z.B.zs_obj_get(v_lw, "funcs"), v_name)));
      Z.setLine(309);
      f_zs_invoke(Z.dup(v_lw), "checkStmts", ((_t2271 = Z.arrNew()), Z.apush(_t2271, Z.dup(Z.index(v_f, "body"))), Z.apush(_t2271, 0), _t2271));
      Z.setLine(310);
      (v_loc = ((_t2272 = Z.arrNew()), _t2272));
      Z.setLine(311);
      {
        const _it226 = Z.foreachArr(Z.dup(Z.index(v_f, "params")));
        L226: for (let _i226 = 0; _i226 < _it226.keys.length; _i226++) {
          v_p = _it226.vals[_i226];
          Z.setLine(311);
          (v_loc = f_zs_invoke(Z.dup(v_lw), "addLocal", ((_t2273 = Z.arrNew()), Z.apush(_t2273, Z.dup(v_loc)), Z.apush(_t2273, Z.dup(Z.index(v_p, 2))), _t2273)));
        }
      }
      Z.setLine(312);
      (v_loc = f_zs_invoke(Z.dup(v_lw), "collectAny", ((_t2274 = Z.arrNew()), Z.apush(_t2274, Z.dup(Z.index(v_f, "body"))), Z.apush(_t2274, Z.dup(v_loc)), _t2274)));
      Z.setLine(313);
      Z.aset((v_f = Z.wr(v_f)), "locals", Z.dup(v_loc));
      Z.setLine(314);
      Z.aset((v_f = Z.wr(v_f)), "has_try", f_zs_invoke(Z.dup(v_lw), "containsTry", ((_t2275 = Z.arrNew()), Z.apush(_t2275, Z.dup(Z.index(v_f, "body"))), _t2275)));
      Z.setLine(315);
      (v___k209 = Z.dup(v_name));
      Z.setLine(315);
      (v___r210 = Z.dup(v_f));
      Z.setLine(315);
      (v___w211 = Z.B.zs_obj_take(v_lw, "funcs"));
      Z.setLine(315);
      Z.aset((v___w211 = Z.wr(v___w211)), v___k209, Z.dup(v___r210));
      Z.setLine(315);
      Z.B.zs_obj_put(v_lw, "funcs", v___w211);
    }
  }
  Z.setLine(317);
  f_zs_invoke(Z.dup(v_lw), "checkStmts", ((_t2276 = Z.arrNew()), Z.apush(_t2276, Z.dup(v_top)), Z.apush(_t2276, 0), _t2276));
  Z.setLine(318);
  (v_toploc = f_zs_invoke(Z.dup(v_lw), "collectAny", ((_t2277 = Z.arrNew()), Z.apush(_t2277, Z.dup(v_top)), Z.apush(_t2277, ((_t2278 = Z.arrNew()), _t2278)), _t2277)));
  Z.setLine(319);
  (v_callsMain = false);
  Z.setLine(320);
  {
    const _it227 = Z.foreachArr(Z.dup(v_top));
    L227: for (let _i227 = 0; _i227 < _it227.keys.length; _i227++) {
      v_s = _it227.vals[_i227];
      Z.setLine(320);
      if (Z.truthy(f_zs_invoke(Z.dup(v_lw), "topCallsMain", ((_t2279 = Z.arrNew()), Z.apush(_t2279, Z.dup(v_s)), _t2279)))) {
        Z.setLine(320);
        (v_callsMain = true);
      }
    }
  }
  Z.setLine(321);
  return ((_t2280 = Z.arrNew()), Z.aset(_t2280, "funcs", Z.B.zs_obj_get(v_lw, "funcs")), Z.aset(_t2280, "order", Z.B.zs_obj_get(v_lw, "order")), Z.aset(_t2280, "top", Z.dup(v_top)), Z.aset(_t2280, "top_has_try", f_zs_invoke(Z.dup(v_lw), "containsTry", ((_t2281 = Z.arrNew()), Z.apush(_t2281, Z.dup(v_top)), _t2281))), Z.aset(_t2280, "toplocals", Z.dup(v_toploc)), Z.aset(_t2280, "calls_main", Z.dup(v_callsMain)), Z.aset(_t2280, "errors", Z.B.zs_obj_get(v_lw, "errors")), _t2280);
  return null;
}
function f_Workspace_ir__report(v_ir) {
  let v_out = null, v_name = null, v_f = null, v_ps = null, v_p = null;
  let _t2282 = null, _t2283 = null;
  Z.setLine(328);
  (v_out = ((_t2282 = Z.arrNew()), _t2282));
  Z.setLine(329);
  {
    const _it228 = Z.foreachArr(Z.dup(Z.index(v_ir, "order")));
    L228: for (let _i228 = 0; _i228 < _it228.keys.length; _i228++) {
      v_name = _it228.vals[_i228];
      Z.setLine(330);
      (v_f = Z.dup(Z.index(Z.index(v_ir, "funcs"), v_name)));
      Z.setLine(331);
      (v_ps = ((_t2283 = Z.arrNew()), _t2283));
      Z.setLine(332);
      {
        const _it229 = Z.foreachArr(Z.dup(Z.index(v_f, "params")));
        L229: for (let _i229 = 0; _i229 < _it229.keys.length; _i229++) {
          v_p = _it229.vals[_i229];
          Z.setLine(332);
          Z.apush((v_ps = Z.wr(v_ps)), Z.concat(Z.concat(Z.concat("$", Z.index(v_p, 2)), (Z.truthy((Z.cmp(Z.B.count(Z.index(v_p, 3)), 0) > 0)) ? Z.concat(":", Z.B.join(Z.index(v_p, 3), "|")) : "")), (Z.truthy(!Z.ident(Z.index(v_p, 4), null)) ? "=…" : "")));
        }
      }
      Z.setLine(333);
      Z.apush((v_out = Z.wr(v_out)), Z.concat(Z.concat(Z.concat(Z.concat(Z.concat(Z.concat(Z.concat("fn ", v_name), "("), Z.B.join(v_ps, ", ")), ")"), (Z.truthy((Z.cmp(Z.B.count(Z.index(v_f, "ret")), 0) > 0)) ? Z.concat(": ", Z.B.join(Z.index(v_f, "ret"), "|")) : "")), " @"), Z.index(v_f, "line")));
      Z.setLine(334);
      Z.apush((v_out = Z.wr(v_out)), Z.concat("  locals: ", Z.B.join(Z.index(v_f, "locals"), ", ")));
      Z.setLine(335);
      Z.apush((v_out = Z.wr(v_out)), Z.concat("  stmts: ", Z.B.count(Z.index(v_f, "body"))));
    }
  }
  Z.setLine(337);
  Z.apush((v_out = Z.wr(v_out)), Z.concat(Z.concat(Z.concat("top: ", Z.B.count(Z.index(v_ir, "top"))), " instrukcji, locals: "), Z.B.join(Z.index(v_ir, "toplocals"), ", ")));
  Z.setLine(338);
  Z.apush((v_out = Z.wr(v_out)), Z.concat("main: ", (Z.truthy(Z.B.has_key(Z.index(v_ir, "funcs"), "main")) ? (Z.truthy(Z.index(v_ir, "calls_main")) ? "wywołane jawnie" : "wywoływane automatycznie") : "brak")));
  Z.setLine(339);
  return Z.B.join(v_out, "\n");
  return null;
}
function f_Workspace_cli__parse(v_args, v_valueOpts) {
  let v_positional = null, v_flags = null, v_options = null, v_i = null, v_n = null, v_rest = null, v_a = null, v_body = null, v_eq = null, v_name = null;
  let _t2284 = null, _t2285 = null, _t2286 = null, _t2287 = null, _t2288 = null, _t2289 = null, _t2290 = null;
  Z.setLine(8);
  (v_positional = ((_t2284 = Z.arrNew()), _t2284));
  Z.setLine(9);
  (v_flags = ((_t2285 = Z.arrNew()), _t2285));
  Z.setLine(10);
  (v_options = ((_t2286 = Z.arrNew()), _t2286));
  Z.setLine(11);
  (v_i = 1);
  Z.setLine(12);
  (v_n = Z.B.count(v_args));
  Z.setLine(13);
  (v_rest = false);
  L230: while (true) {
    Z.setLine(14);
    if (!Z.truthy((Z.cmp(v_i, v_n) < 0))) break;
    Z.setLine(15);
    (v_a = Z.dup(Z.index(v_args, v_i)));
    Z.setLine(16);
    if (Z.truthy((Z.truthy((Z.truthy(v_rest) || Z.truthy(!Z.truthy(Z.B.starts_with(v_a, "-"))))) || Z.truthy(Z.ident(v_a, "-"))))) {
      Z.setLine(17);
      Z.apush((v_positional = Z.wr(v_positional)), Z.dup(v_a));
    } else {
      Z.setLine(18);
      if (Z.truthy(Z.ident(v_a, "--"))) {
        Z.setLine(19);
        (v_rest = true);
      } else {
        Z.setLine(20);
        if (Z.truthy(Z.B.starts_with(v_a, "--"))) {
          Z.setLine(21);
          (v_body = Z.B.substr(v_a, 2));
          Z.setLine(22);
          (v_eq = Z.B.index_of(v_body, "="));
          Z.setLine(23);
          if (Z.truthy((Z.cmp(v_eq, 0) >= 0))) {
            Z.setLine(23);
            Z.aset((v_options = Z.wr(v_options)), Z.B.substr(v_body, 0, v_eq), Z.B.substr(v_body, Z.add(v_eq, 1)));
          } else {
            Z.setLine(24);
            if (Z.truthy((Z.truthy(Z.B.in_array(v_body, v_valueOpts)) && Z.truthy((Z.cmp(Z.add(v_i, 1), v_n) < 0))))) {
              Z.setLine(24);
              ((_t2287 = v_i), (v_i = Z.add(_t2287, 1)), _t2287);
              Z.setLine(24);
              Z.aset((v_options = Z.wr(v_options)), v_body, Z.dup(Z.index(v_args, v_i)));
            } else {
              Z.setLine(25);
              Z.aset((v_flags = Z.wr(v_flags)), v_a, true);
            }
          }
        } else {
          Z.setLine(27);
          (v_name = Z.B.substr(v_a, 1));
          Z.setLine(28);
          if (Z.truthy((Z.truthy(Z.B.in_array(v_name, v_valueOpts)) && Z.truthy((Z.cmp(Z.add(v_i, 1), v_n) < 0))))) {
            Z.setLine(28);
            ((_t2288 = v_i), (v_i = Z.add(_t2288, 1)), _t2288);
            Z.setLine(28);
            Z.aset((v_options = Z.wr(v_options)), v_name, Z.dup(Z.index(v_args, v_i)));
          } else {
            Z.setLine(29);
            Z.aset((v_flags = Z.wr(v_flags)), v_a, true);
          }
        }
      }
    }
    Z.setLine(31);
    ((_t2289 = v_i), (v_i = Z.add(_t2289, 1)), _t2289);
  }
  Z.setLine(33);
  return ((_t2290 = Z.arrNew()), Z.aset(_t2290, "positional", Z.dup(v_positional)), Z.aset(_t2290, "flags", Z.dup(v_flags)), Z.aset(_t2290, "options", Z.dup(v_options)), _t2290);
  return null;
}
function f_pipeline__stages() {
  let _t2291 = null, _t2292 = null, _t2293 = null, _t2294 = null, _t2295 = null, _t2296 = null, _t2297 = null, _t2298 = null, _t2299 = null, _t2300 = null, _t2301 = null, _t2302 = null, _t2303 = null;
  Z.setLine(4);
  return ((_t2291 = Z.arrNew()), Z.apush(_t2291, ((_t2292 = Z.arrNew()), Z.aset(_t2292, "name", "lexer"), Z.aset(_t2292, "status", "done"), Z.aset(_t2292, "impl", "Workspace.lexer (Z#, parytet z Rust)"), _t2292)), Z.apush(_t2291, ((_t2293 = Z.arrNew()), Z.aset(_t2293, "name", "parser + AST"), Z.aset(_t2293, "status", "done"), Z.aset(_t2293, "impl", "Workspace.parser (Z#, parytet z Rust: scripts/tests/parser_parity.zsharp)"), _t2293)), Z.apush(_t2291, ((_t2294 = Z.arrNew()), Z.aset(_t2294, "name", "semantic analysis"), Z.aset(_t2294, "status", "done"), Z.aset(_t2294, "impl", "Workspace.sema (zmienne + analiza ucieczki -> klasy ZAMM)"), _t2294)), Z.apush(_t2291, ((_t2295 = Z.arrNew()), Z.aset(_t2295, "name", "zbc packer"), Z.aset(_t2295, "status", "done"), Z.aset(_t2295, "impl", "Workspace.zbc (.zbc = AST bez źródeł; zsc0 exec / zsi)"), _t2295)), Z.apush(_t2291, ((_t2296 = Z.arrNew()), Z.aset(_t2296, "name", "Z# IR"), Z.aset(_t2296, "status", "done"), Z.aset(_t2296, "impl", "Workspace.ir (strukturalne IR, walidacja, lokalne; SSA: todo)"), _t2296)), Z.apush(_t2291, ((_t2297 = Z.arrNew()), Z.aset(_t2297, "name", "ZAMM runtime"), Z.aset(_t2297, "status", "done"), Z.aset(_t2297, "impl", "Z-Sharp/zamm + runtime (Z# = definicja); natywnie: runtime/native/zs_rt.c (C, bez Rusta)"), _t2297)), Z.apush(_t2291, ((_t2298 = Z.arrNew()), Z.aset(_t2298, "name", "ZAMM lowering"), Z.aset(_t2298, "status", "todo"), Z.aset(_t2298, "impl", "- (wyniki analizy ucieczki -> ramki; natywnie: czas życia Persistent)"), _t2298)), Z.apush(_t2291, ((_t2299 = Z.arrNew()), Z.aset(_t2299, "name", "C backend"), Z.aset(_t2299, "status", "done"), Z.aset(_t2299, "impl", "Workspace.emit_c (podzbiór: funkcje, tablice indeksowane, napisy, pętle, switch)"), _t2299)), Z.apush(_t2291, ((_t2300 = Z.arrNew()), Z.aset(_t2300, "name", "linker + runtime"), Z.aset(_t2300, "status", "done"), Z.aset(_t2300, "impl", "cc/clang + runtime/native/zs_rt.c"), _t2300)), Z.apush(_t2291, ((_t2301 = Z.arrNew()), Z.aset(_t2301, "name", "LLVM backend"), Z.aset(_t2301, "status", "done"), Z.aset(_t2301, "impl", "Workspace.emit_llvm (podzbiór natywny; .ll + clang; --target <triple>)"), _t2301)), Z.apush(_t2291, ((_t2302 = Z.arrNew()), Z.aset(_t2302, "name", "native classes"), Z.aset(_t2302, "status", "todo"), Z.aset(_t2302, "impl", "klasy, domknięcia, importy w backendach natywnych (warunek samokompilacji natywnej)"), _t2302)), Z.apush(_t2291, ((_t2303 = Z.arrNew()), Z.aset(_t2303, "name", "extern linking"), Z.aset(_t2303, "status", "todo"), Z.aset(_t2303, "impl", "składnia sparsowana w stage0; linkowanie w zsc"), _t2303)), _t2291);
  return null;
}
function f_llvmtool__MIN_MAJOR() {
  Z.setLine(12);
  return 21;
  return null;
}
function f_llvmtool__MIN_MAJOR_LEGACY() {
  Z.setLine(13);
  return 17;
  return null;
}
function f_llvmtool__parse_major(v_text) {
  let v_i = null, v_j = null, v_n = null;
  let _t2304 = null;
  Z.setLine(16);
  (v_i = Z.B.index_of(v_text, "version "));
  Z.setLine(17);
  if (Z.truthy((Z.cmp(v_i, 0) < 0))) {
    Z.setLine(17);
    return 0;
  }
  Z.setLine(18);
  (v_j = Z.add(v_i, 8));
  Z.setLine(19);
  (v_n = "");
  L231: while (true) {
    Z.setLine(20);
    if (!Z.truthy((Z.truthy((Z.cmp(v_j, Z.B.strlen(v_text)) < 0)) && Z.truthy(Z.B.is_digit(Z.B.substr(v_text, v_j, 1)))))) break;
    Z.setLine(20);
    (v_n = Z.concat(v_n, Z.B.substr(v_text, v_j, 1)));
    Z.setLine(20);
    ((_t2304 = v_j), (v_j = Z.add(_t2304, 1)), _t2304);
  }
  Z.setLine(21);
  return (Z.truthy(Z.ident(v_n, "")) ? 0 : Z.B.intval(v_n));
  return null;
}
function f_llvmtool__first_line(v_text) {
  let v_p = null, v_l = null;
  Z.setLine(25);
  (v_p = Z.B.split(v_text, "\n"));
  Z.setLine(26);
  {
    const _it232 = Z.foreachArr(Z.dup(v_p));
    L232: for (let _i232 = 0; _i232 < _it232.keys.length; _i232++) {
      v_l = _it232.vals[_i232];
      Z.setLine(26);
      if (Z.truthy(Z.B.contains(v_l, "version "))) {
        Z.setLine(26);
        return Z.B.trim(v_l);
      }
    }
  }
  Z.setLine(27);
  return (Z.truthy((Z.cmp(Z.B.count(v_p), 0) > 0)) ? Z.B.trim(Z.index(v_p, 0)) : "");
  return null;
}
function f_llvmtool__probe(v_cmd) {
  let v_r = null, v_t = null, v___ex212 = null, v_e = null;
  let _t2305 = null, _t2306 = null;
  try {
    Z.setLine(32);
    (v_r = Z.M.Process.run(v_cmd, ((_t2305 = Z.arrNew()), Z.apush(_t2305, "--version"), _t2305)));
    Z.setLine(33);
    if (Z.truthy(!Z.ident(Z.index(v_r, "status"), 0))) {
      Z.setLine(33);
      return null;
    }
    Z.setLine(34);
    (v_t = Z.concat(Z.index(v_r, "stdout"), Z.index(v_r, "stderr")));
    Z.setLine(35);
    return ((_t2306 = Z.arrNew()), Z.aset(_t2306, "cmd", Z.dup(v_cmd)), Z.aset(_t2306, "major", f_llvmtool__parse_major(Z.dup(v_t))), Z.aset(_t2306, "line", f_llvmtool__first_line(Z.dup(v_t))), _t2306);
  } catch (_e) {
    _e = Z.toExc(_e);
    if (true) {
      v___ex212 = _e;
      Z.setLine(31);
      if (Z.truthy(f_zs_isa(Z.dup(v___ex212), "Exception"))) {
        Z.setLine(31);
        (v_e = Z.dup(v___ex212));
        Z.setLine(37);
        return null;
      } else {
        Z.setLine(31);
        Z.throwV(v___ex212);
      }
    }
    else throw _e;
  }
  return null;
}
function f_llvmtool__candidates(v_name, v_binDir) {
  let v_c = null, v_d = null;
  let _t2307 = null, _t2308 = null;
  Z.setLine(42);
  (v_c = ((_t2307 = Z.arrNew()), _t2307));
  Z.setLine(43);
  if (Z.truthy((Z.truthy(!Z.ident(v_binDir, null)) && Z.truthy(!Z.ident(v_binDir, ""))))) {
    Z.setLine(44);
    Z.apush((v_c = Z.wr(v_c)), Z.concat(Z.concat(Z.concat(Z.concat(v_binDir, "/"), v_name), "-"), f_llvmtool__MIN_MAJOR()));
    Z.setLine(45);
    Z.apush((v_c = Z.wr(v_c)), Z.concat(Z.concat(v_binDir, "/"), v_name));
  }
  Z.setLine(47);
  Z.apush((v_c = Z.wr(v_c)), Z.concat(Z.concat(v_name, "-"), f_llvmtool__MIN_MAJOR()));
  Z.setLine(48);
  Z.apush((v_c = Z.wr(v_c)), Z.dup(v_name));
  Z.setLine(49);
  {
    const _it233 = Z.foreachArr(((_t2308 = Z.arrNew()), Z.apush(_t2308, Z.concat(Z.concat("/usr/lib/llvm-", f_llvmtool__MIN_MAJOR()), "/bin/")), Z.apush(_t2308, "/usr/local/llvm/bin/"), Z.apush(_t2308, "/opt/llvm/bin/"), Z.apush(_t2308, "/opt/homebrew/opt/llvm/bin/"), Z.apush(_t2308, "/usr/local/opt/llvm/bin/"), _t2308));
    L233: for (let _i233 = 0; _i233 < _it233.keys.length; _i233++) {
      v_d = _it233.vals[_i233];
      Z.setLine(50);
      Z.apush((v_c = Z.wr(v_c)), Z.concat(v_d, v_name));
    }
  }
  Z.setLine(52);
  return Z.dup(v_c);
  return null;
}
function f_llvmtool__find_tool(v_name, v_binDir, v_min) {
  let v_seen = null, v_best = null, v_c = null, v_p = null;
  let _t2309 = null, _t2310 = null, _t2311 = null, _t2312 = null;
  Z.setLine(60);
  (v_seen = ((_t2309 = Z.arrNew()), _t2309));
  Z.setLine(61);
  (v_best = null);
  Z.setLine(62);
  {
    const _it234 = Z.foreachArr(f_llvmtool__candidates(Z.dup(v_name), Z.dup(v_binDir)));
    L234: for (let _i234 = 0; _i234 < _it234.keys.length; _i234++) {
      v_c = _it234.vals[_i234];
      Z.setLine(63);
      (v_p = f_llvmtool__probe(Z.dup(v_c)));
      Z.setLine(64);
      if (Z.truthy(Z.ident(v_p, null))) {
        continue L234;
      }
      Z.setLine(65);
      Z.apush((v_seen = Z.wr(v_seen)), Z.concat(Z.concat(Z.concat(Z.index(v_p, "cmd"), " ("), Z.index(v_p, "major")), ")"));
      Z.setLine(66);
      if (Z.truthy((Z.cmp(Z.index(v_p, "major"), v_min) >= 0))) {
        Z.setLine(66);
        return ((_t2310 = Z.arrNew()), Z.aset(_t2310, "ok", true), Z.aset(_t2310, "cmd", Z.dup(Z.index(v_p, "cmd"))), Z.aset(_t2310, "major", Z.dup(Z.index(v_p, "major"))), Z.aset(_t2310, "line", Z.dup(Z.index(v_p, "line"))), _t2310);
      }
    }
  }
  Z.setLine(68);
  if (Z.truthy(Z.ident(Z.B.count(v_seen), 0))) {
    Z.setLine(69);
    return ((_t2311 = Z.arrNew()), Z.aset(_t2311, "ok", false), Z.aset(_t2311, "err", Z.concat(Z.concat(Z.concat(Z.concat("zsc: nie znaleziono narzędzia LLVM '", v_name), "' (wymagany LLVM >= "), v_min), "; ustaw --llvm-bin <katalog> lub ZS_LLVM_BIN)")), _t2311);
  }
  Z.setLine(71);
  return ((_t2312 = Z.arrNew()), Z.aset(_t2312, "ok", false), Z.aset(_t2312, "err", Z.concat(Z.concat(Z.concat(Z.concat(Z.concat(Z.concat(Z.concat(Z.concat("zsc: '", v_name), "' ma za starą wersję: "), Z.B.join(v_seen, ", ")), " — wymagany LLVM >= "), v_min), " (--allow-older-llvm / ZS_ALLOW_OLD_LLVM=1 obniża próg do "), f_llvmtool__MIN_MAJOR_LEGACY()), " bez gwarancji)")), _t2312);
  return null;
}
function f_llvmtool__allow_old(v_opts) {
  let v_e = null;
  Z.setLine(76);
  if (Z.truthy(Z.B.has_key(Z.index(v_opts, "flags"), "--allow-older-llvm"))) {
    Z.setLine(76);
    return true;
  }
  Z.setLine(77);
  (v_e = Z.M.System.env("ZS_ALLOW_OLD_LLVM"));
  Z.setLine(78);
  return (Z.truthy((Z.truthy(!Z.ident(v_e, null)) && Z.truthy(!Z.ident(v_e, "")))) && Z.truthy(!Z.ident(v_e, "0")));
  return null;
}
function f_llvmtool__llvm_bin(v_opts) {
  let v_b = null, v_e = null;
  let _t2313 = null;
  Z.setLine(82);
  (v_b = (((_t2313 = Z.indexOpt(Z.indexOpt(v_opts, "options"), "llvm-bin")) !== null) ? _t2313 : null));
  Z.setLine(83);
  if (Z.truthy((Z.truthy(!Z.ident(v_b, null)) && Z.truthy(!Z.ident(v_b, ""))))) {
    Z.setLine(83);
    return Z.dup(v_b);
  }
  Z.setLine(84);
  (v_e = Z.M.System.env("ZS_LLVM_BIN"));
  Z.setLine(85);
  if (Z.truthy((Z.truthy(!Z.ident(v_e, null)) && Z.truthy(!Z.ident(v_e, ""))))) {
    Z.setLine(85);
    return Z.dup(v_e);
  }
  Z.setLine(86);
  return null;
  return null;
}
function f_llvmtool__detect(v_opts) {
  let v_min = null, v_bin = null, v_tc = null, v_opt = null, v_llc = null, v_clang = null;
  let _t2314 = null, _t2315 = null, _t2316 = null;
  Z.setLine(94);
  (v_min = (Z.truthy(f_llvmtool__allow_old(Z.dup(v_opts))) ? f_llvmtool__MIN_MAJOR_LEGACY() : f_llvmtool__MIN_MAJOR()));
  Z.setLine(95);
  (v_bin = f_llvmtool__llvm_bin(Z.dup(v_opts)));
  Z.setLine(96);
  (v_tc = ((_t2314 = Z.arrNew()), Z.aset(_t2314, "ok", false), Z.aset(_t2314, "lines", ((_t2315 = Z.arrNew()), _t2315)), Z.aset(_t2314, "min", Z.dup(v_min)), _t2314));
  Z.setLine(97);
  (v_opt = f_llvmtool__find_tool("opt", Z.dup(v_bin), Z.dup(v_min)));
  Z.setLine(98);
  if (Z.truthy(!Z.truthy(Z.index(v_opt, "ok")))) {
    Z.setLine(98);
    Z.aset((v_tc = Z.wr(v_tc)), "err", Z.dup(Z.index(v_opt, "err")));
    Z.setLine(98);
    return Z.dup(v_tc);
  }
  Z.setLine(99);
  (v_llc = f_llvmtool__find_tool("llc", Z.dup(v_bin), Z.dup(v_min)));
  Z.setLine(100);
  if (Z.truthy(!Z.truthy(Z.index(v_llc, "ok")))) {
    Z.setLine(100);
    Z.aset((v_tc = Z.wr(v_tc)), "err", Z.dup(Z.index(v_llc, "err")));
    Z.setLine(100);
    return Z.dup(v_tc);
  }
  Z.setLine(101);
  (v_clang = f_llvmtool__find_tool("clang", Z.dup(v_bin), Z.dup(v_min)));
  Z.setLine(102);
  Z.aset((v_tc = Z.wr(v_tc)), "opt", Z.dup(Z.index(v_opt, "cmd")));
  Z.setLine(103);
  Z.aset((v_tc = Z.wr(v_tc)), "llc", Z.dup(Z.index(v_llc, "cmd")));
  Z.setLine(104);
  Z.aset((v_tc = Z.wr(v_tc)), "clang", (Z.truthy(Z.index(v_clang, "ok")) ? Z.index(v_clang, "cmd") : null));
  Z.setLine(105);
  Z.aset((v_tc = Z.wr(v_tc)), "major", Z.dup(Z.index(v_llc, "major")));
  Z.setLine(106);
  Z.aset((v_tc = Z.wr(v_tc)), "lines", ((_t2316 = Z.arrNew()), Z.apush(_t2316, Z.concat(Z.concat(Z.index(v_opt, "cmd"), ": "), Z.index(v_opt, "line"))), Z.apush(_t2316, Z.concat(Z.concat(Z.index(v_llc, "cmd"), ": "), Z.index(v_llc, "line"))), Z.apush(_t2316, Z.concat("clang: ", (Z.truthy(Z.index(v_clang, "ok")) ? Z.concat(Z.concat(Z.index(v_clang, "cmd"), ": "), Z.index(v_clang, "line")) : "brak"))), _t2316));
  Z.setLine(107);
  Z.aset((v_tc = Z.wr(v_tc)), "ok", true);
  Z.setLine(108);
  return Z.dup(v_tc);
  return null;
}
function f_llvmtool__host_triple(v_tc) {
  let v_cands = null, v_c = null, v_r = null, v___ex213 = null, v_e = null, v_l = null, v_t = null, v___ex214 = null;
  let _t2317 = null, _t2318 = null, _t2319 = null;
  Z.setLine(112);
  (v_cands = ((_t2317 = Z.arrNew()), _t2317));
  Z.setLine(113);
  if (Z.truthy(!Z.ident(Z.index(v_tc, "clang"), null))) {
    Z.setLine(113);
    Z.apush((v_cands = Z.wr(v_cands)), Z.dup(Z.index(v_tc, "clang")));
  }
  Z.setLine(114);
  {
    const _it235 = Z.foreachArr(Z.dup(v_cands));
    L235: for (let _i235 = 0; _i235 < _it235.keys.length; _i235++) {
      v_c = _it235.vals[_i235];
      try {
        Z.setLine(116);
        (v_r = Z.M.Process.run(v_c, ((_t2318 = Z.arrNew()), Z.apush(_t2318, "-dumpmachine"), _t2318)));
        Z.setLine(117);
        if (Z.truthy((Z.truthy(Z.ident(Z.index(v_r, "status"), 0)) && Z.truthy(!Z.ident(Z.B.trim(Z.index(v_r, "stdout")), ""))))) {
          Z.setLine(117);
          return Z.B.trim(Z.index(v_r, "stdout"));
        }
      } catch (_e) {
        _e = Z.toExc(_e);
        if (true) {
          v___ex213 = _e;
          Z.setLine(115);
          if (Z.truthy(f_zs_isa(Z.dup(v___ex213), "Exception"))) {
            Z.setLine(115);
            (v_e = Z.dup(v___ex213));
          } else {
            Z.setLine(115);
            Z.throwV(v___ex213);
          }
        }
        else throw _e;
      }
    }
  }
  try {
    Z.setLine(121);
    (v_r = Z.M.Process.run(Z.index(v_tc, "llc"), ((_t2319 = Z.arrNew()), Z.apush(_t2319, "--version"), _t2319)));
    Z.setLine(122);
    {
      const _it236 = Z.foreachArr(Z.B.split(Z.index(v_r, "stdout"), "\n"));
      L236: for (let _i236 = 0; _i236 < _it236.keys.length; _i236++) {
        v_l = _it236.vals[_i236];
        Z.setLine(123);
        (v_t = Z.B.trim(v_l));
        Z.setLine(124);
        if (Z.truthy(Z.B.starts_with(v_t, "Default target:"))) {
          Z.setLine(124);
          return Z.B.trim(Z.B.substr(v_t, 15));
        }
      }
    }
  } catch (_e) {
    _e = Z.toExc(_e);
    if (true) {
      v___ex214 = _e;
      Z.setLine(120);
      if (Z.truthy(f_zs_isa(Z.dup(v___ex214), "Exception"))) {
        Z.setLine(120);
        (v_e = Z.dup(v___ex214));
      } else {
        Z.setLine(120);
        Z.throwV(v___ex214);
      }
    }
    else throw _e;
  }
  Z.setLine(127);
  return "x86_64-pc-linux-gnu";
  return null;
}
function f_llvmtool__mkdirs(v_path) {
  let v_parts = null, v_cur = null, v_p = null;
  Z.setLine(133);
  if (Z.truthy(Z.M.Directory.exists(v_path))) {
    Z.setLine(133);
    return null;
  }
  Z.setLine(134);
  (v_parts = Z.B.split(v_path, "/"));
  Z.setLine(135);
  (v_cur = (Z.truthy(Z.B.starts_with(v_path, "/")) ? "" : "."));
  Z.setLine(136);
  {
    const _it237 = Z.foreachArr(Z.dup(v_parts));
    L237: for (let _i237 = 0; _i237 < _it237.keys.length; _i237++) {
      v_p = _it237.vals[_i237];
      Z.setLine(137);
      if (Z.truthy(Z.ident(v_p, ""))) {
        continue L237;
      }
      Z.setLine(138);
      (v_cur = Z.concat(Z.concat(v_cur, "/"), v_p));
      Z.setLine(139);
      if (Z.truthy(!Z.truthy(Z.M.Directory.exists(v_cur)))) {
        Z.setLine(139);
        Z.M.Directory.create(v_cur);
      }
    }
  }
  return null;
}
function f_llvmtool__cache_dir() {
  let v_e = null, v_x = null, v_h = null;
  let _t2320 = null;
  Z.setLine(144);
  (v_e = Z.M.System.env("ZS_CACHE"));
  Z.setLine(145);
  if (Z.truthy((Z.truthy(!Z.ident(v_e, null)) && Z.truthy(!Z.ident(v_e, ""))))) {
    Z.setLine(145);
    return Z.dup(v_e);
  }
  Z.setLine(146);
  (v_x = Z.M.System.env("XDG_CACHE_HOME"));
  Z.setLine(147);
  if (Z.truthy((Z.truthy(!Z.ident(v_x, null)) && Z.truthy(!Z.ident(v_x, ""))))) {
    Z.setLine(147);
    return Z.concat(v_x, "/zsc");
  }
  Z.setLine(148);
  (v_h = Z.M.System.env("HOME"));
  Z.setLine(149);
  if (Z.truthy((Z.truthy(!Z.ident(v_h, null)) && Z.truthy(!Z.ident(v_h, ""))))) {
    Z.setLine(149);
    return Z.concat(v_h, "/.cache/zsc");
  }
  Z.setLine(150);
  return Z.concat((((_t2320 = Z.M.System.env("TMPDIR")) !== null) ? _t2320 : "/tmp"), "/zsc-cache");
  return null;
}
function f_llvmtool__tmp_dir() {
  let v_base = null, v_d = null;
  let _t2321 = null;
  Z.setLine(154);
  (v_base = (((_t2321 = Z.M.System.env("TMPDIR")) !== null) ? _t2321 : "/tmp"));
  Z.setLine(155);
  (v_d = Z.concat(Z.concat(Z.concat(Z.concat(v_base, "/zsc-"), Z.M.System.pid()), "-"), Z.M.System.nowNanos()));
  Z.setLine(156);
  f_llvmtool__mkdirs(Z.dup(v_d));
  Z.setLine(157);
  return Z.dup(v_d);
  return null;
}
function f_llvmtool__sanitize(v_s) {
  let v_o = null, v_c = null;
  Z.setLine(161);
  (v_o = "");
  Z.setLine(162);
  {
    const _it238 = Z.foreachArr(Z.B.chars(v_s));
    L238: for (let _i238 = 0; _i238 < _it238.keys.length; _i238++) {
      v_c = _it238.vals[_i238];
      Z.setLine(162);
      (v_o = Z.concat(v_o, (Z.truthy((Z.truthy((Z.truthy(Z.B.is_alnum(v_c)) || Z.truthy(Z.ident(v_c, ".")))) || Z.truthy(Z.ident(v_c, "-")))) ? v_c : "_")));
    }
  }
  Z.setLine(163);
  return Z.dup(v_o);
  return null;
}
function f_llvmtool__opt_pass(v_level) {
  Z.setLine(167);
  if (Z.truthy(Z.ident(v_level, "-O0"))) {
    Z.setLine(167);
    return "default<O0>";
  }
  Z.setLine(168);
  if (Z.truthy(Z.ident(v_level, "-O1"))) {
    Z.setLine(168);
    return "default<O1>";
  }
  Z.setLine(169);
  if (Z.truthy(Z.ident(v_level, "-O3"))) {
    Z.setLine(169);
    return "default<O3>";
  }
  Z.setLine(170);
  if (Z.truthy(Z.ident(v_level, "-Os"))) {
    Z.setLine(170);
    return "default<Os>";
  }
  Z.setLine(171);
  if (Z.truthy(Z.ident(v_level, "-Oz"))) {
    Z.setLine(171);
    return "default<Oz>";
  }
  Z.setLine(172);
  return "default<O2>";
  return null;
}
function f_llvmtool__llc_level(v_level) {
  Z.setLine(176);
  if (Z.truthy(Z.ident(v_level, "-O0"))) {
    Z.setLine(176);
    return "-O0";
  }
  Z.setLine(177);
  if (Z.truthy(Z.ident(v_level, "-O1"))) {
    Z.setLine(177);
    return "-O1";
  }
  Z.setLine(178);
  if (Z.truthy(Z.ident(v_level, "-O3"))) {
    Z.setLine(178);
    return "-O3";
  }
  Z.setLine(179);
  return "-O2";
  return null;
}
function f_llvmtool__run_tool(v_cmd, v_args, v_what) {
  let v_r = null, v___ex215 = null, v_e = null;
  let _t2322 = null, _t2323 = null, _t2324 = null, _t2325 = null;
  try {
    Z.setLine(183);
    (v_r = Z.M.Process.run(v_cmd, v_args));
  } catch (_e) {
    _e = Z.toExc(_e);
    if (true) {
      v___ex215 = _e;
      Z.setLine(183);
      if (Z.truthy(f_zs_isa(Z.dup(v___ex215), "Exception"))) {
        Z.setLine(183);
        (v_e = Z.dup(v___ex215));
        Z.setLine(184);
        return ((_t2322 = Z.arrNew()), Z.aset(_t2322, "ok", false), Z.aset(_t2322, "err", Z.concat(Z.concat(Z.concat(Z.concat(Z.concat("zsc: nie można uruchomić ", v_what), " ("), v_cmd), "): "), f_zs_invoke(Z.dup(v_e), "getMessage", ((_t2323 = Z.arrNew()), _t2323)))), _t2322);
      } else {
        Z.setLine(183);
        Z.throwV(v___ex215);
      }
    }
    else throw _e;
  }
  Z.setLine(185);
  if (Z.truthy(!Z.ident(Z.index(v_r, "status"), 0))) {
    Z.setLine(186);
    return ((_t2324 = Z.arrNew()), Z.aset(_t2324, "ok", false), Z.aset(_t2324, "err", Z.concat(Z.concat(Z.concat(Z.concat(Z.B.trim(Z.concat(Z.index(v_r, "stderr"), Z.index(v_r, "stdout"))), "\nzsc: "), v_what), " zakończył się kodem "), Z.index(v_r, "status"))), _t2324);
  }
  Z.setLine(188);
  return ((_t2325 = Z.arrNew()), Z.aset(_t2325, "ok", true), Z.aset(_t2325, "stdout", Z.dup(Z.index(v_r, "stdout"))), Z.aset(_t2325, "stderr", Z.dup(Z.index(v_r, "stderr"))), _t2325);
  return null;
}
function f_llvmtool__optimize(v_tc, v_ll, v_bc, v_level, v_triple) {
  let v_a = null;
  let _t2326 = null;
  Z.setLine(195);
  (v_a = ((_t2326 = Z.arrNew()), Z.apush(_t2326, Z.concat("-passes=", f_llvmtool__opt_pass(Z.dup(v_level)))), Z.apush(_t2326, Z.dup(v_ll)), Z.apush(_t2326, "-o"), Z.apush(_t2326, Z.dup(v_bc)), _t2326));
  Z.setLine(196);
  return f_llvmtool__run_tool(Z.dup(Z.index(v_tc, "opt")), Z.dup(v_a), "opt");
  return null;
}
function f_llvmtool__codegen(v_tc, v_in, v_out, v_level, v_triple, v_kind, v_triple_explicit) {
  let v_a = null;
  let _t2327 = null;
  Z.setLine(203);
  (v_a = ((_t2327 = Z.arrNew()), Z.apush(_t2327, f_llvmtool__llc_level(Z.dup(v_level))), Z.apush(_t2327, Z.concat("-filetype=", v_kind)), Z.apush(_t2327, "-relocation-model=pic"), _t2327));
  Z.setLine(204);
  if (Z.truthy(v_triple_explicit)) {
    Z.setLine(204);
    Z.apush((v_a = Z.wr(v_a)), Z.concat("-mtriple=", v_triple));
  }
  Z.setLine(205);
  Z.apush((v_a = Z.wr(v_a)), Z.dup(v_in));
  Z.setLine(206);
  Z.apush((v_a = Z.wr(v_a)), "-o");
  Z.setLine(207);
  Z.apush((v_a = Z.wr(v_a)), Z.dup(v_out));
  Z.setLine(208);
  return f_llvmtool__run_tool(Z.dup(Z.index(v_tc, "llc")), Z.dup(v_a), "llc");
  return null;
}
function f_llvmtool__runtime_obj(v_tc, v_root, v_triple, v_opts, v_level) {
  let v_given = null, v_src = null, v_hdr = null, v_ss = null, v_hs = null, v_cc = null, v_lv = null, v_key = null, v_dir = null, v_obj = null, v___ex216 = null, v_e = null, v_tmp = null, v_dest = null, v_args = null, v_r = null;
  let _t2328 = null, _t2329 = null, _t2330 = null, _t2331 = null, _t2332 = null, _t2333 = null, _t2334 = null, _t2335 = null, _t2336 = null;
  Z.setLine(215);
  (v_given = (((_t2328 = Z.indexOpt(Z.indexOpt(v_opts, "options"), "runtime-obj")) !== null) ? _t2328 : Z.M.System.env("ZS_RUNTIME_OBJ")));
  Z.setLine(216);
  if (Z.truthy((Z.truthy(!Z.ident(v_given, null)) && Z.truthy(!Z.ident(v_given, ""))))) {
    Z.setLine(217);
    if (Z.truthy(!Z.truthy(Z.M.File.exists(v_given)))) {
      Z.setLine(217);
      return ((_t2329 = Z.arrNew()), Z.aset(_t2329, "ok", false), Z.aset(_t2329, "err", Z.concat("zsc: brak obiektu runtime ", v_given)), _t2329);
    }
    Z.setLine(218);
    return ((_t2330 = Z.arrNew()), Z.aset(_t2330, "ok", true), Z.aset(_t2330, "path", Z.dup(v_given)), _t2330);
  }
  Z.setLine(220);
  (v_src = Z.concat(v_root, "/runtime/native/zs_rt.c"));
  Z.setLine(221);
  (v_hdr = Z.concat(v_root, "/runtime/include/zs_native.h"));
  Z.setLine(222);
  if (Z.truthy((Z.truthy(!Z.truthy(Z.M.File.exists(v_src))) || Z.truthy(!Z.truthy(Z.M.File.exists(v_hdr)))))) {
    Z.setLine(223);
    return ((_t2331 = Z.arrNew()), Z.aset(_t2331, "ok", false), Z.aset(_t2331, "err", Z.concat(Z.concat("zsc: nie znaleziono runtime (", v_src), ") — ustaw ZS_HOME albo --runtime-obj")), _t2331);
  }
  Z.setLine(225);
  (v_ss = Z.M.File.stat(v_src));
  Z.setLine(226);
  (v_hs = Z.M.File.stat(v_hdr));
  Z.setLine(227);
  (v_cc = Z.dup(Z.index(v_tc, "clang")));
  Z.setLine(228);
  if (Z.truthy(Z.ident(v_cc, null))) {
    Z.setLine(229);
    return ((_t2332 = Z.arrNew()), Z.aset(_t2332, "ok", false), Z.aset(_t2332, "err", Z.concat(Z.concat("zsc: do zbudowania runtime potrzebny jest clang >= ", Z.index(v_tc, "min")), " (albo gotowy obiekt: --runtime-obj)")), _t2332);
  }
  Z.setLine(231);
  (v_lv = (Z.truthy(Z.ident(v_level, "-O0")) ? "-O0" : "-O2"));
  Z.setLine(232);
  (v_key = Z.concat(Z.concat(Z.concat(Z.concat(Z.concat(Z.concat(Z.concat(Z.concat(Z.concat(Z.concat(Z.concat(Z.concat(Z.concat(Z.concat("rt-", Z.index(v_ss, "size")), "-"), Z.index(v_ss, "mtime")), "-"), Z.index(v_hs, "size")), "-"), Z.index(v_hs, "mtime")), "-"), f_llvmtool__sanitize(Z.dup(v_triple))), "-"), v_lv), "-llvm"), Z.index(v_tc, "major")), ".o"));
  Z.setLine(233);
  (v_dir = f_llvmtool__cache_dir());
  Z.setLine(234);
  (v_obj = Z.concat(Z.concat(v_dir, "/"), v_key));
  Z.setLine(235);
  if (Z.truthy(Z.M.File.exists(v_obj))) {
    Z.setLine(235);
    return ((_t2333 = Z.arrNew()), Z.aset(_t2333, "ok", true), Z.aset(_t2333, "path", Z.dup(v_obj)), _t2333);
  }
  try {
    Z.setLine(236);
    f_llvmtool__mkdirs(Z.dup(v_dir));
  } catch (_e) {
    _e = Z.toExc(_e);
    if (true) {
      v___ex216 = _e;
      Z.setLine(236);
      if (Z.truthy(f_zs_isa(Z.dup(v___ex216), "Exception"))) {
        Z.setLine(236);
        (v_e = Z.dup(v___ex216));
      } else {
        Z.setLine(236);
        Z.throwV(v___ex216);
      }
    }
    else throw _e;
  }
  Z.setLine(237);
  (v_tmp = Z.concat(Z.concat(Z.concat(v_obj, "."), Z.M.System.pid()), ".tmp"));
  Z.setLine(238);
  (v_dest = (Z.truthy(Z.M.Directory.exists(v_dir)) ? v_tmp : Z.concat(f_llvmtool__tmp_dir(), "/zs_rt.o")));
  Z.setLine(239);
  (v_args = ((_t2334 = Z.arrNew()), Z.apush(_t2334, "-c"), Z.apush(_t2334, Z.dup(v_src)), Z.apush(_t2334, "-o"), Z.apush(_t2334, Z.dup(v_dest)), Z.apush(_t2334, Z.dup(v_lv)), Z.apush(_t2334, "-std=gnu11"), Z.apush(_t2334, "-w"), Z.apush(_t2334, "-fPIC"), Z.apush(_t2334, "-I"), Z.apush(_t2334, Z.concat(v_root, "/runtime/include")), Z.apush(_t2334, Z.concat("--target=", v_triple)), _t2334));
  Z.setLine(240);
  (v_r = f_llvmtool__run_tool(Z.dup(v_cc), Z.dup(v_args), "clang (runtime)"));
  Z.setLine(241);
  if (Z.truthy(!Z.truthy(Z.index(v_r, "ok")))) {
    Z.setLine(241);
    return Z.dup(v_r);
  }
  Z.setLine(242);
  if (Z.truthy(Z.ident(v_dest, v_tmp))) {
    Z.setLine(242);
    Z.M.File.rename(v_tmp, v_obj);
    Z.setLine(242);
    return ((_t2335 = Z.arrNew()), Z.aset(_t2335, "ok", true), Z.aset(_t2335, "path", Z.dup(v_obj)), _t2335);
  }
  Z.setLine(243);
  return ((_t2336 = Z.arrNew()), Z.aset(_t2336, "ok", true), Z.aset(_t2336, "path", Z.dup(v_dest)), _t2336);
  return null;
}
function f_llvmtool__link(v_tc, v_objs, v_out, v_triple, v_triple_explicit, v_opts) {
  let v_drivers = null, v_l = null, v_c = null, v_last = null, v_d = null, v_a = null, v_o = null, v_extra = null, v_x = null, v_r = null, v___ex217 = null, v_e = null;
  let _t2337 = null, _t2338 = null, _t2339 = null, _t2340 = null, _t2341 = null, _t2342 = null, _t2343 = null, _t2344 = null;
  Z.setLine(251);
  (v_drivers = ((_t2337 = Z.arrNew()), _t2337));
  Z.setLine(252);
  (v_l = (((_t2338 = Z.indexOpt(Z.indexOpt(v_opts, "options"), "linker")) !== null) ? _t2338 : Z.M.System.env("ZS_LINKER")));
  Z.setLine(253);
  if (Z.truthy((Z.truthy(!Z.ident(v_l, null)) && Z.truthy(!Z.ident(v_l, ""))))) {
    Z.setLine(253);
    Z.apush((v_drivers = Z.wr(v_drivers)), Z.dup(v_l));
  }
  Z.setLine(254);
  if (Z.truthy(!Z.ident(Z.index(v_tc, "clang"), null))) {
    Z.setLine(254);
    Z.apush((v_drivers = Z.wr(v_drivers)), Z.dup(Z.index(v_tc, "clang")));
  }
  Z.setLine(255);
  {
    const _it239 = Z.foreachArr(((_t2339 = Z.arrNew()), Z.apush(_t2339, "cc"), Z.apush(_t2339, "gcc"), _t2339));
    L239: for (let _i239 = 0; _i239 < _it239.keys.length; _i239++) {
      v_c = _it239.vals[_i239];
      Z.setLine(255);
      Z.apush((v_drivers = Z.wr(v_drivers)), Z.dup(v_c));
    }
  }
  Z.setLine(256);
  (v_last = "");
  Z.setLine(257);
  {
    const _it240 = Z.foreachArr(Z.dup(v_drivers));
    L240: for (let _i240 = 0; _i240 < _it240.keys.length; _i240++) {
      v_d = _it240.vals[_i240];
      Z.setLine(258);
      (v_a = ((_t2340 = Z.arrNew()), _t2340));
      Z.setLine(259);
      {
        const _it241 = Z.foreachArr(Z.dup(v_objs));
        L241: for (let _i241 = 0; _i241 < _it241.keys.length; _i241++) {
          v_o = _it241.vals[_i241];
          Z.setLine(259);
          Z.apush((v_a = Z.wr(v_a)), Z.dup(v_o));
        }
      }
      Z.setLine(260);
      Z.apush((v_a = Z.wr(v_a)), "-o");
      Z.setLine(261);
      Z.apush((v_a = Z.wr(v_a)), Z.dup(v_out));
      Z.setLine(262);
      Z.apush((v_a = Z.wr(v_a)), "-lm");
      Z.setLine(263);
      if (Z.truthy((Z.truthy(v_triple_explicit) && Z.truthy(Z.ident(v_d, Z.index(v_tc, "clang")))))) {
        Z.setLine(263);
        Z.apush((v_a = Z.wr(v_a)), Z.concat("--target=", v_triple));
      }
      Z.setLine(264);
      (v_extra = (((_t2341 = Z.indexOpt(Z.indexOpt(v_opts, "options"), "ldflags")) !== null) ? _t2341 : null));
      Z.setLine(265);
      if (Z.truthy((Z.truthy(!Z.ident(v_extra, null)) && Z.truthy(!Z.ident(v_extra, ""))))) {
        Z.setLine(265);
        {
          const _it242 = Z.foreachArr(Z.B.split(v_extra, " "));
          L242: for (let _i242 = 0; _i242 < _it242.keys.length; _i242++) {
            v_x = _it242.vals[_i242];
            Z.setLine(265);
            if (Z.truthy(!Z.ident(v_x, ""))) {
              Z.setLine(265);
              Z.apush((v_a = Z.wr(v_a)), Z.dup(v_x));
            }
          }
        }
      }
      try {
        Z.setLine(266);
        (v_r = Z.M.Process.run(v_d, v_a));
      } catch (_e) {
        _e = Z.toExc(_e);
        if (true) {
          v___ex217 = _e;
          Z.setLine(266);
          if (Z.truthy(f_zs_isa(Z.dup(v___ex217), "Exception"))) {
            Z.setLine(266);
            (v_e = Z.dup(v___ex217));
            Z.setLine(267);
            (v_last = f_zs_invoke(Z.dup(v_e), "getMessage", ((_t2342 = Z.arrNew()), _t2342)));
            continue L240;
          } else {
            Z.setLine(266);
            Z.throwV(v___ex217);
          }
        }
        else throw _e;
      }
      Z.setLine(268);
      if (Z.truthy(Z.ident(Z.index(v_r, "status"), 0))) {
        Z.setLine(268);
        return ((_t2343 = Z.arrNew()), Z.aset(_t2343, "ok", true), Z.aset(_t2343, "driver", Z.dup(v_d)), _t2343);
      }
      Z.setLine(269);
      (v_last = Z.B.trim(Z.index(v_r, "stderr")));
    }
  }
  Z.setLine(271);
  return ((_t2344 = Z.arrNew()), Z.aset(_t2344, "ok", false), Z.aset(_t2344, "err", Z.concat(v_last, "\nzsc: linkowanie nie powiodło się (sterownik: --linker / ZS_LINKER)")), _t2344);
  return null;
}
function f_llvmtool__cleanup(v_dir) {
  let v_f = null, v___ex218 = null, v_e = null;
  try {
    Z.setLine(276);
    {
      const _it243 = Z.foreachArr(Z.M.Directory.list(v_dir));
      L243: for (let _i243 = 0; _i243 < _it243.keys.length; _i243++) {
        v_f = _it243.vals[_i243];
        Z.setLine(276);
        Z.M.File.delete(Z.concat(Z.concat(v_dir, "/"), v_f));
      }
    }
    Z.setLine(277);
    Z.M.Directory.remove(v_dir);
  } catch (_e) {
    _e = Z.toExc(_e);
    if (true) {
      v___ex218 = _e;
      Z.setLine(275);
      if (Z.truthy(f_zs_isa(Z.dup(v___ex218), "Exception"))) {
        Z.setLine(275);
        (v_e = Z.dup(v___ex218));
      } else {
        Z.setLine(275);
        Z.throwV(v___ex218);
      }
    }
    else throw _e;
  }
  return null;
}
function f_Workspace_closures__nm(v_line, v_n) {
  let _t2345 = null;
  Z.setLine(18);
  return ((_t2345 = Z.arrNew()), Z.apush(_t2345, ":Name"), Z.apush(_t2345, Z.dup(v_line)), Z.apush(_t2345, Z.dup(v_n)), _t2345);
  return null;
}
function f_Workspace_closures__str(v_line, v_s) {
  let _t2346 = null;
  Z.setLine(19);
  return ((_t2346 = Z.arrNew()), Z.apush(_t2346, ":Str"), Z.apush(_t2346, Z.dup(v_line)), Z.apush(_t2346, Z.dup(v_s)), _t2346);
  return null;
}
function f_Workspace_closures__var(v_line, v_n) {
  let _t2347 = null;
  Z.setLine(20);
  return ((_t2347 = Z.arrNew()), Z.apush(_t2347, ":Var"), Z.apush(_t2347, Z.dup(v_line)), Z.apush(_t2347, Z.dup(v_n)), _t2347);
  return null;
}
function f_Workspace_closures__intl(v_line, v_i) {
  let _t2348 = null;
  Z.setLine(21);
  return ((_t2348 = Z.arrNew()), Z.apush(_t2348, ":Int"), Z.apush(_t2348, Z.dup(v_line)), Z.apush(_t2348, Z.dup(v_i)), _t2348);
  return null;
}
function f_Workspace_closures__arg(v_e) {
  let _t2349 = null;
  Z.setLine(22);
  return ((_t2349 = Z.arrNew()), Z.apush(_t2349, ":Arg"), Z.apush(_t2349, 0), Z.apush(_t2349, null), Z.apush(_t2349, Z.dup(v_e)), Z.apush(_t2349, false), _t2349);
  return null;
}
function f_Workspace_closures__call(v_line, v_fn, v_args) {
  let v_as = null, v_a = null;
  let _t2350 = null, _t2351 = null;
  Z.setLine(24);
  (v_as = ((_t2350 = Z.arrNew()), _t2350));
  Z.setLine(25);
  {
    const _it244 = Z.foreachArr(Z.dup(v_args));
    L244: for (let _i244 = 0; _i244 < _it244.keys.length; _i244++) {
      v_a = _it244.vals[_i244];
      Z.setLine(25);
      Z.apush((v_as = Z.wr(v_as)), f_Workspace_closures__arg(Z.dup(v_a)));
    }
  }
  Z.setLine(26);
  return ((_t2351 = Z.arrNew()), Z.apush(_t2351, ":Call"), Z.apush(_t2351, Z.dup(v_line)), Z.apush(_t2351, f_Workspace_closures__nm(Z.dup(v_line), Z.dup(v_fn))), Z.apush(_t2351, Z.dup(v_as)), _t2351);
  return null;
}
function f_Workspace_closures__param(v_name) {
  let _t2352 = null, _t2353 = null;
  Z.setLine(28);
  return ((_t2352 = Z.arrNew()), Z.apush(_t2352, ":Param"), Z.apush(_t2352, 0), Z.apush(_t2352, Z.dup(v_name)), Z.apush(_t2352, ((_t2353 = Z.arrNew()), _t2353)), Z.apush(_t2352, null), Z.apush(_t2352, false), _t2352);
  return null;
}
function f_Workspace_closures__bindArgs(v_line, v_params, v_argsName, v_fname) {
  let v_out = null, v_i = null, v_p = null, v_a = null, v_d = null, v_byName = null;
  let _t2354 = null, _t2355 = null, _t2356 = null, _t2357 = null, _t2358 = null, _t2359 = null, _t2360 = null, _t2361 = null, _t2362 = null, _t2363 = null, _t2364 = null;
  Z.setLine(35);
  (v_out = ((_t2354 = Z.arrNew()), _t2354));
  Z.setLine(36);
  (v_i = 0);
  L245: for (; Z.truthy((Z.cmp(v_i, Z.B.count(v_params)) < 0)); ((_t2355 = v_i), (v_i = Z.add(_t2355, 1)), _t2355)) {
    Z.setLine(37);
    (v_p = Z.dup(Z.index(v_params, v_i)));
    Z.setLine(38);
    if (Z.truthy(Z.index(v_p, 5))) {
      Z.setLine(39);
      Z.apush((v_out = Z.wr(v_out)), ((_t2356 = Z.arrNew()), Z.apush(_t2356, ":Arg"), Z.apush(_t2356, 0), Z.apush(_t2356, null), Z.apush(_t2356, f_Workspace_closures__call(Z.dup(v_line), "array_slice", ((_t2357 = Z.arrNew()), Z.apush(_t2357, f_Workspace_closures__var(Z.dup(v_line), Z.dup(v_argsName))), Z.apush(_t2357, f_Workspace_closures__intl(Z.dup(v_line), Z.dup(v_i))), _t2357))), Z.apush(_t2356, true), _t2356));
      continue L245;
    }
    Z.setLine(42);
    (v_a = f_Workspace_closures__var(Z.dup(v_line), Z.dup(v_argsName)));
    Z.setLine(43);
    (v_d = (Z.truthy(!Z.ident(Z.index(v_p, 4), null)) ? Z.index(v_p, 4) : f_Workspace_closures__call(Z.dup(v_line), "zs_arg_missing", ((_t2358 = Z.arrNew()), Z.apush(_t2358, f_Workspace_closures__str(Z.dup(v_line), Z.dup(v_fname))), Z.apush(_t2358, f_Workspace_closures__str(Z.dup(v_line), Z.dup(Z.index(v_p, 2)))), _t2358))));
    Z.setLine(44);
    (v_byName = ((_t2359 = Z.arrNew()), Z.apush(_t2359, ":Ternary"), Z.apush(_t2359, Z.dup(v_line)), Z.apush(_t2359, f_Workspace_closures__call(Z.dup(v_line), "has_key", ((_t2360 = Z.arrNew()), Z.apush(_t2360, Z.dup(v_a)), Z.apush(_t2360, f_Workspace_closures__str(Z.dup(v_line), Z.dup(Z.index(v_p, 2)))), _t2360))), Z.apush(_t2359, ((_t2361 = Z.arrNew()), Z.apush(_t2361, ":Index"), Z.apush(_t2361, Z.dup(v_line)), Z.apush(_t2361, Z.dup(v_a)), Z.apush(_t2361, f_Workspace_closures__str(Z.dup(v_line), Z.dup(Z.index(v_p, 2)))), _t2361)), Z.apush(_t2359, Z.dup(v_d)), _t2359));
    Z.setLine(45);
    Z.apush((v_out = Z.wr(v_out)), f_Workspace_closures__arg(((_t2362 = Z.arrNew()), Z.apush(_t2362, ":Ternary"), Z.apush(_t2362, Z.dup(v_line)), Z.apush(_t2362, f_Workspace_closures__call(Z.dup(v_line), "has_key", ((_t2363 = Z.arrNew()), Z.apush(_t2363, Z.dup(v_a)), Z.apush(_t2363, f_Workspace_closures__intl(Z.dup(v_line), Z.dup(v_i))), _t2363))), Z.apush(_t2362, ((_t2364 = Z.arrNew()), Z.apush(_t2364, ":Index"), Z.apush(_t2364, Z.dup(v_line)), Z.apush(_t2364, Z.dup(v_a)), Z.apush(_t2364, f_Workspace_closures__intl(Z.dup(v_line), Z.dup(v_i))), _t2364)), Z.apush(_t2362, Z.dup(v_byName)), _t2362)));
  }
  Z.setLine(47);
  return Z.dup(v_out);
  return null;
}
function f_Workspace_closures__prepend(v_v, v_xs) {
  let v_o = null, v_x = null;
  let _t2365 = null;
  Z.setLine(272);
  (v_o = ((_t2365 = Z.arrNew()), Z.apush(_t2365, Z.dup(v_v)), _t2365));
  Z.setLine(273);
  {
    const _it246 = Z.foreachArr(Z.dup(v_xs));
    L246: for (let _i246 = 0; _i246 < _it246.keys.length; _i246++) {
      v_x = _it246.vals[_i246];
      Z.setLine(273);
      Z.apush((v_o = Z.wr(v_o)), Z.dup(v_x));
    }
  }
  Z.setLine(274);
  return Z.dup(v_o);
  return null;
}
function f_Workspace_closures__lift(v_ast) {
  let v_l = null, v_s = null, v___k219 = null, v___r220 = null, v___w221 = null, v_rest = null, v_topvis = null, v_out = null, v_f = null, v_vis = null, v_p = null;
  let _t2366 = null, _t2367 = null, _t2368 = null, _t2369 = null, _t2370 = null, _t2371 = null, _t2372 = null, _t2373 = null, _t2374 = null;
  Z.setLine(281);
  (v_l = f_Lifter__new());
  Z.setLine(282);
  {
    const _it247 = Z.foreachArr(Z.dup(v_ast));
    L247: for (let _i247 = 0; _i247 < _it247.keys.length; _i247++) {
      v_s = _it247.vals[_i247];
      Z.setLine(282);
      if (Z.truthy(Z.ident(Z.index(v_s, 0), ":FuncStmt"))) {
        Z.setLine(282);
        (v___k219 = Z.dup(Z.index(Z.index(v_s, 2), 2)));
        Z.setLine(282);
        (v___r220 = Z.dup(Z.index(Z.index(v_s, 2), 3)));
        Z.setLine(282);
        (v___w221 = Z.B.zs_obj_take(v_l, "fnp"));
        Z.setLine(282);
        Z.aset((v___w221 = Z.wr(v___w221)), v___k219, Z.dup(v___r220));
        Z.setLine(282);
        Z.B.zs_obj_put(v_l, "fnp", v___w221);
      }
    }
  }
  Z.setLine(283);
  (v_rest = ((_t2366 = Z.arrNew()), _t2366));
  Z.setLine(284);
  {
    const _it248 = Z.foreachArr(Z.dup(v_ast));
    L248: for (let _i248 = 0; _i248 < _it248.keys.length; _i248++) {
      v_s = _it248.vals[_i248];
      Z.setLine(284);
      if (Z.truthy(!Z.ident(Z.index(v_s, 0), ":FuncStmt"))) {
        Z.setLine(284);
        Z.apush((v_rest = Z.wr(v_rest)), Z.dup(v_s));
      }
    }
  }
  Z.setLine(285);
  (v_topvis = f_zs_invoke(Z.dup(v_l), "names", ((_t2367 = Z.arrNew()), Z.apush(_t2367, Z.dup(v_rest)), _t2367)));
  Z.setLine(286);
  (v_out = ((_t2368 = Z.arrNew()), _t2368));
  Z.setLine(287);
  {
    const _it249 = Z.foreachArr(Z.dup(v_ast));
    L249: for (let _i249 = 0; _i249 < _it249.keys.length; _i249++) {
      v_s = _it249.vals[_i249];
      Z.setLine(288);
      if (Z.truthy(Z.ident(Z.index(v_s, 0), ":FuncStmt"))) {
        Z.setLine(289);
        (v_f = Z.dup(Z.index(v_s, 2)));
        Z.setLine(290);
        (v_vis = f_zs_invoke(Z.dup(v_l), "names", ((_t2369 = Z.arrNew()), Z.apush(_t2369, Z.dup(Z.index(v_f, 5))), _t2369)));
        Z.setLine(291);
        {
          const _it250 = Z.foreachArr(Z.dup(Z.index(v_f, 3)));
          L250: for (let _i250 = 0; _i250 < _it250.keys.length; _i250++) {
            v_p = _it250.vals[_i250];
            Z.setLine(291);
            Z.aset((v_vis = Z.wr(v_vis)), Z.index(v_p, 2), true);
          }
        }
        Z.setLine(292);
        Z.aset((v_f = Z.wr(v_f)), 5, f_zs_invoke(Z.dup(v_l), "rw", ((_t2370 = Z.arrNew()), Z.apush(_t2370, Z.dup(Z.index(v_f, 5))), Z.apush(_t2370, Z.dup(v_vis)), _t2370)));
        Z.setLine(293);
        Z.aset((v_s = Z.wr(v_s)), 2, Z.dup(v_f));
        Z.setLine(294);
        Z.apush((v_out = Z.wr(v_out)), Z.dup(v_s));
      } else {
        Z.setLine(296);
        Z.apush((v_out = Z.wr(v_out)), f_zs_invoke(Z.dup(v_l), "rw", ((_t2371 = Z.arrNew()), Z.apush(_t2371, Z.dup(v_s)), Z.apush(_t2371, Z.dup(v_topvis)), _t2371)));
      }
    }
  }
  Z.setLine(299);
  if (Z.truthy((Z.truthy((Z.truthy((Z.truthy(Z.ident(Z.B.zs_obj_get(v_l, "n"), 0)) && Z.truthy(!Z.truthy(Z.B.zs_obj_get(v_l, "dyn"))))) && Z.truthy(!Z.truthy(Z.B.zs_obj_get(v_l, "usesSpread"))))) && Z.truthy(!Z.truthy(Z.B.zs_obj_get(v_l, "sawHelper")))))) {
    Z.setLine(299);
    return ((_t2372 = Z.arrNew()), Z.aset(_t2372, "ast", Z.dup(v_out)), Z.aset(_t2372, "errors", Z.B.zs_obj_get(v_l, "errors")), _t2372);
  }
  Z.setLine(300);
  {
    const _it251 = Z.foreachArr(Z.B.zs_obj_get(v_l, "out"));
    L251: for (let _i251 = 0; _i251 < _it251.keys.length; _i251++) {
      v_s = _it251.vals[_i251];
      Z.setLine(300);
      Z.apush((v_out = Z.wr(v_out)), Z.dup(v_s));
    }
  }
  Z.setLine(301);
  {
    const _it252 = Z.foreachArr(f_zs_invoke(Z.dup(v_l), "helpers", ((_t2373 = Z.arrNew()), _t2373)));
    L252: for (let _i252 = 0; _i252 < _it252.keys.length; _i252++) {
      v_s = _it252.vals[_i252];
      Z.setLine(301);
      Z.apush((v_out = Z.wr(v_out)), Z.dup(v_s));
    }
  }
  Z.setLine(302);
  return ((_t2374 = Z.arrNew()), Z.aset(_t2374, "ast", Z.dup(v_out)), Z.aset(_t2374, "errors", Z.B.zs_obj_get(v_l, "errors")), _t2374);
  return null;
}
function f_Workspace_classes__pseudo_exceptions() {
  Z.setLine(7);
  return f_Workspace_parser__parse("class Exception { public $message = \"\"; public $line = 0; func __construct($message = \"\") { $this->message = $message; } func getMessage() { return $this->message; } } class Error extends Exception { }");
  return null;
}
function f_Workspace_classes__array_reverse_names(v_xs) {
  let v_o = null, v_i = null;
  let _t2375 = null, _t2376 = null;
  Z.setLine(529);
  (v_o = ((_t2375 = Z.arrNew()), _t2375));
  Z.setLine(530);
  (v_i = Z.sub(Z.B.count(v_xs), 1));
  L253: for (; Z.truthy((Z.cmp(v_i, 0) >= 0)); ((_t2376 = v_i), (v_i = Z.sub(_t2376, 1)), _t2376)) {
    Z.setLine(530);
    Z.apush((v_o = Z.wr(v_o)), Z.dup(Z.index(v_xs, v_i)));
  }
  Z.setLine(531);
  return Z.dup(v_o);
  return null;
}
function f_Workspace_classes__prepend(v_v, v_xs) {
  let v_o = null, v_x = null;
  let _t2377 = null;
  Z.setLine(534);
  (v_o = ((_t2377 = Z.arrNew()), Z.apush(_t2377, Z.dup(v_v)), _t2377));
  Z.setLine(535);
  {
    const _it254 = Z.foreachArr(Z.dup(v_xs));
    L254: for (let _i254 = 0; _i254 < _it254.keys.length; _i254++) {
      v_x = _it254.vals[_i254];
      Z.setLine(535);
      Z.apush((v_o = Z.wr(v_o)), Z.dup(v_x));
    }
  }
  Z.setLine(536);
  return Z.dup(v_o);
  return null;
}
function f_Workspace_classes__desugar(v_ast) {
  let v_has = null, v_s = null, v_d = null, v_k = null, v_r = null, v_guard = null, v_n = null, v_pseudo = null, v_rest = null, v_statics = null, v_pn = null, v_pd = null, v_ln = null, v_dv = null, v_body = null, v_f = null, v_y = null, v_out = null;
  let _t2378 = null, _t2379 = null, _t2380 = null, _t2381 = null, _t2382 = null, _t2383 = null, _t2384 = null, _t2385 = null, _t2386 = null, _t2387 = null, _t2388 = null, _t2389 = null, _t2390 = null, _t2391 = null, _t2392 = null, _t2393 = null, _t2394 = null, _t2395 = null, _t2396 = null, _t2397 = null, _t2398 = null;
  Z.setLine(543);
  (v_has = false);
  Z.setLine(544);
  {
    const _it255 = Z.foreachArr(Z.dup(v_ast));
    L255: for (let _i255 = 0; _i255 < _it255.keys.length; _i255++) {
      v_s = _it255.vals[_i255];
      Z.setLine(544);
      if (Z.truthy(Z.ident(Z.index(v_s, 0), ":ClassStmt"))) {
        Z.setLine(544);
        (v_has = true);
      }
    }
  }
  Z.setLine(545);
  if (Z.truthy(!Z.truthy(v_has))) {
    Z.setLine(545);
    return ((_t2378 = Z.arrNew()), Z.aset(_t2378, "ast", Z.dup(v_ast)), Z.aset(_t2378, "errors", ((_t2379 = Z.arrNew()), _t2379)), _t2378);
  }
  Z.setLine(546);
  (v_d = f_Desugar__new());
  Z.setLine(547);
  f_zs_invoke(Z.dup(v_d), "collect", ((_t2380 = Z.arrNew()), Z.apush(_t2380, Z.dup(v_ast)), _t2380));
  Z.setLine(548);
  {
    const _it256 = Z.foreachArr(Z.B.zs_obj_get(v_d, "classes"));
    L256: for (let _i256 = 0; _i256 < _it256.keys.length; _i256++) {
      v_k = _it256.vals[_i256];
      Z.setLine(549);
      (v_r = Z.B.zs_obj_get(v_k, "name"));
      Z.setLine(550);
      (v_guard = 0);
      Z.setLine(551);
      (v_n = Z.B.zs_obj_get(v_k, "parent"));
      L257: while (true) {
        Z.setLine(552);
        if (!Z.truthy((Z.truthy((Z.truthy(!Z.ident(v_n, null)) && Z.truthy(Z.B.has_key(Z.B.zs_obj_get(v_d, "classes"), v_n)))) && Z.truthy((Z.cmp(v_guard, 64) < 0))))) break;
        Z.setLine(552);
        (v_n = Z.B.zs_obj_get(Z.index(Z.B.zs_obj_get(v_d, "classes"), v_n), "parent"));
        Z.setLine(552);
        ((_t2381 = v_guard), (v_guard = Z.add(_t2381, 1)), _t2381);
      }
      Z.setLine(553);
      if (Z.truthy((Z.truthy(Z.ident(v_n, "Exception")) || Z.truthy(Z.ident(v_n, "Error"))))) {
        Z.setLine(553);
        Z.B.zs_obj_set(v_d, "excMode", true);
      }
    }
  }
  Z.setLine(555);
  if (Z.truthy((Z.truthy((Z.truthy(Z.B.zs_obj_get(v_d, "excMode")) && Z.truthy(!Z.truthy(Z.B.has_key(Z.B.zs_obj_get(v_d, "classes"), "Exception"))))) && Z.truthy(!Z.truthy(Z.B.has_key(Z.B.zs_obj_get(v_d, "classes"), "Error")))))) {
    Z.setLine(556);
    (v_pseudo = f_Workspace_classes__pseudo_exceptions());
    Z.setLine(557);
    f_zs_invoke(Z.dup(v_d), "collect", ((_t2382 = Z.arrNew()), Z.apush(_t2382, Z.dup(v_pseudo)), _t2382));
    Z.setLine(558);
    (v_ast = Z.dup(v_ast));
    Z.setLine(559);
    {
      const _it258 = Z.foreachArr(Z.dup(v_pseudo));
      L258: for (let _i258 = 0; _i258 < _it258.keys.length; _i258++) {
        v_s = _it258.vals[_i258];
        Z.setLine(559);
        Z.apush((v_ast = Z.wr(v_ast)), Z.dup(v_s));
      }
    }
  }
  Z.setLine(561);
  (v_rest = ((_t2383 = Z.arrNew()), _t2383));
  Z.setLine(562);
  {
    const _it259 = Z.foreachArr(Z.dup(v_ast));
    L259: for (let _i259 = 0; _i259 < _it259.keys.length; _i259++) {
      v_s = _it259.vals[_i259];
      Z.setLine(562);
      if (Z.truthy(!Z.ident(Z.index(v_s, 0), ":ClassStmt"))) {
        Z.setLine(562);
        Z.apush((v_rest = Z.wr(v_rest)), Z.dup(v_s));
      }
    }
  }
  Z.setLine(563);
  {
    const _it260 = Z.foreachArr(Z.B.zs_obj_get(v_d, "classes"));
    L260: for (let _i260 = 0; _i260 < _it260.keys.length; _i260++) {
      v_k = _it260.vals[_i260];
      Z.setLine(563);
      f_zs_invoke(Z.dup(v_d), "genClass", ((_t2384 = Z.arrNew()), Z.apush(_t2384, Z.dup(v_k)), _t2384));
    }
  }
  Z.setLine(564);
  Z.B.zs_obj_set(v_d, "cur", null);
  Z.setLine(565);
  (v_statics = ((_t2385 = Z.arrNew()), _t2385));
  Z.setLine(566);
  {
    const _it261 = Z.foreachArr(Z.B.zs_obj_get(v_d, "classes"));
    L261: for (let _i261 = 0; _i261 < _it261.keys.length; _i261++) {
      v_k = _it261.vals[_i261];
      Z.setLine(567);
      Z.B.zs_obj_set(v_d, "cur", v_k);
      Z.setLine(568);
      {
        const _it262 = Z.foreachArr(Z.B.zs_obj_get(v_k, "props"));
        L262: for (let _i262 = 0; _i262 < _it262.keys.length; _i262++) {
          v_pd = _it262.vals[_i262];
          v_pn = _it262.keys[_i262];
          Z.setLine(569);
          if (Z.truthy(!Z.truthy(Z.index(v_pd, "static")))) {
            continue L262;
          }
          Z.setLine(570);
          (v_ln = Z.B.zs_obj_get(v_k, "line"));
          Z.setLine(571);
          (v_dv = (Z.truthy(Z.ident(Z.index(v_pd, "default"), null)) ? ((_t2386 = Z.arrNew()), Z.apush(_t2386, ":Null"), Z.apush(_t2386, Z.dup(v_ln)), _t2386) : f_zs_invoke(Z.dup(v_d), "rw", ((_t2387 = Z.arrNew()), Z.apush(_t2387, Z.dup(Z.index(v_pd, "default"))), _t2387))));
          Z.setLine(572);
          Z.apush((v_statics = Z.wr(v_statics)), ((_t2388 = Z.arrNew()), Z.apush(_t2388, ":Expr"), Z.apush(_t2388, Z.dup(v_ln)), Z.apush(_t2388, f_zs_invoke(Z.dup(v_d), "call", ((_t2389 = Z.arrNew()), Z.apush(_t2389, Z.dup(v_ln)), Z.apush(_t2389, "zs_sset"), Z.apush(_t2389, ((_t2390 = Z.arrNew()), Z.apush(_t2390, f_zs_invoke(Z.dup(v_d), "mkstr", ((_t2391 = Z.arrNew()), Z.apush(_t2391, Z.dup(v_ln)), Z.apush(_t2391, Z.concat(Z.concat(Z.B.zs_obj_get(v_k, "name"), "::"), v_pn)), _t2391))), Z.apush(_t2390, Z.dup(v_dv)), _t2390)), _t2389))), _t2388));
        }
      }
    }
  }
  Z.setLine(575);
  Z.B.zs_obj_set(v_d, "cur", null);
  Z.setLine(576);
  (v_body = ((_t2392 = Z.arrNew()), _t2392));
  Z.setLine(577);
  {
    const _it263 = Z.foreachArr(Z.dup(v_rest));
    L263: for (let _i263 = 0; _i263 < _it263.keys.length; _i263++) {
      v_s = _it263.vals[_i263];
      Z.setLine(578);
      if (Z.truthy(Z.ident(Z.index(v_s, 0), ":FuncStmt"))) {
        Z.setLine(579);
        (v_f = Z.dup(Z.index(v_s, 2)));
        Z.setLine(580);
        Z.aset((v_f = Z.wr(v_f)), 5, f_zs_invoke(Z.dup(v_d), "rwList", ((_t2393 = Z.arrNew()), Z.apush(_t2393, Z.dup(Z.index(v_f, 5))), _t2393)));
        Z.setLine(581);
        Z.aset((v_s = Z.wr(v_s)), 2, Z.dup(v_f));
        Z.setLine(582);
        Z.apush((v_body = Z.wr(v_body)), Z.dup(v_s));
      } else {
        Z.setLine(584);
        (v_r = (Z.truthy(Z.ident(Z.index(v_s, 0), ":Expr")) ? f_zs_invoke(Z.dup(v_d), "stmtExpr", ((_t2394 = Z.arrNew()), Z.apush(_t2394, Z.dup(v_s)), _t2394)) : null));
        Z.setLine(585);
        if (Z.truthy(!Z.ident(v_r, null))) {
          Z.setLine(585);
          {
            const _it264 = Z.foreachArr(Z.dup(v_r));
            L264: for (let _i264 = 0; _i264 < _it264.keys.length; _i264++) {
              v_y = _it264.vals[_i264];
              Z.setLine(585);
              Z.apush((v_body = Z.wr(v_body)), Z.dup(v_y));
            }
          }
        } else {
          Z.setLine(586);
          Z.apush((v_body = Z.wr(v_body)), f_zs_invoke(Z.dup(v_d), "rw", ((_t2395 = Z.arrNew()), Z.apush(_t2395, Z.dup(v_s)), _t2395)));
        }
      }
    }
  }
  Z.setLine(589);
  f_zs_invoke(Z.dup(v_d), "genDispatch", ((_t2396 = Z.arrNew()), _t2396));
  Z.setLine(590);
  (v_out = ((_t2397 = Z.arrNew()), _t2397));
  Z.setLine(591);
  {
    const _it265 = Z.foreachArr(Z.B.zs_obj_get(v_d, "extra"));
    L265: for (let _i265 = 0; _i265 < _it265.keys.length; _i265++) {
      v_s = _it265.vals[_i265];
      Z.setLine(591);
      Z.apush((v_out = Z.wr(v_out)), Z.dup(v_s));
    }
  }
  Z.setLine(592);
  {
    const _it266 = Z.foreachArr(Z.dup(v_statics));
    L266: for (let _i266 = 0; _i266 < _it266.keys.length; _i266++) {
      v_s = _it266.vals[_i266];
      Z.setLine(592);
      Z.apush((v_out = Z.wr(v_out)), Z.dup(v_s));
    }
  }
  Z.setLine(593);
  {
    const _it267 = Z.foreachArr(Z.dup(v_body));
    L267: for (let _i267 = 0; _i267 < _it267.keys.length; _i267++) {
      v_s = _it267.vals[_i267];
      Z.setLine(593);
      Z.apush((v_out = Z.wr(v_out)), Z.dup(v_s));
    }
  }
  Z.setLine(594);
  return ((_t2398 = Z.arrNew()), Z.aset(_t2398, "ast", Z.dup(v_out)), Z.aset(_t2398, "errors", Z.B.zs_obj_get(v_d, "errors")), _t2398);
  return null;
}
function f_Workspace_prelude__names() {
  let _t2399 = null;
  Z.setLine(10);
  return ((_t2399 = Z.arrNew()), Z.apush(_t2399, "map"), Z.apush(_t2399, "filter"), Z.apush(_t2399, "reduce"), Z.apush(_t2399, "each"), Z.apush(_t2399, "find"), Z.apush(_t2399, "any"), Z.apush(_t2399, "all"), Z.apush(_t2399, "usort"), Z.apush(_t2399, "sum"), _t2399);
  return null;
}
function f_Workspace_prelude__source() {
  let v_l = null;
  let _t2400 = null;
  Z.setLine(14);
  (v_l = ((_t2400 = Z.arrNew()), _t2400));
  Z.setLine(15);
  Z.apush((v_l = Z.wr(v_l)), "func map($a, $f) { $o = []; foreach ($a as $k => $v) { $o[$k] = $f($v); } return $o; }");
  Z.setLine(16);
  Z.apush((v_l = Z.wr(v_l)), "func filter($a, $f) { $o = []; foreach ($a as $k => $v) { if ($f($v)) { $o[$k] = $v; } } return $o; }");
  Z.setLine(17);
  Z.apush((v_l = Z.wr(v_l)), "func reduce($a, $f, $acc) { foreach ($a as $v) { $acc = $f($acc, $v); } return $acc; }");
  Z.setLine(18);
  Z.apush((v_l = Z.wr(v_l)), "func each($a, $f) { foreach ($a as $v) { $f($v); } return null; }");
  Z.setLine(19);
  Z.apush((v_l = Z.wr(v_l)), "func find($a, $f) { foreach ($a as $v) { if ($f($v)) { return $v; } } return null; }");
  Z.setLine(20);
  Z.apush((v_l = Z.wr(v_l)), "func any($a, $f) { foreach ($a as $v) { if ($f($v)) { return true; } } return false; }");
  Z.setLine(21);
  Z.apush((v_l = Z.wr(v_l)), "func all($a, $f) { foreach ($a as $v) { if (!$f($v)) { return false; } } return true; }");
  Z.setLine(22);
  Z.apush((v_l = Z.wr(v_l)), "func sum($a) { $t = 0; foreach ($a as $v) { $t = $t + $v; } return $t; }");
  Z.setLine(24);
  Z.apush((v_l = Z.wr(v_l)), "func usort($a, $f) { $v = values($a); return usort_rec($v, $f); }");
  Z.setLine(25);
  Z.apush((v_l = Z.wr(v_l)), "func usort_rec($v, $f) { $n = count($v); if ($n < 2) { return $v; } $m = intval($n / 2); $l = usort_rec(array_slice($v, 0, $m), $f); $r = usort_rec(array_slice($v, $m), $f); $o = []; $i = 0; $j = 0; $nl = count($l); $nr = count($r); while ($i < $nl && $j < $nr) { if ($f($l[$i], $r[$j]) <= 0) { $o[] = $l[$i]; $i++; } else { $o[] = $r[$j]; $j++; } } while ($i < $nl) { $o[] = $l[$i]; $i++; } while ($j < $nr) { $o[] = $r[$j]; $j++; } return $o; }");
  Z.setLine(26);
  return Z.B.join(v_l, " ");
  return null;
}
function f_Workspace_spreadlit__segment(v_line, v_items) {
  let _t2401 = null;
  Z.setLine(13);
  return ((_t2401 = Z.arrNew()), Z.apush(_t2401, ":Array"), Z.apush(_t2401, Z.dup(v_line)), Z.apush(_t2401, Z.dup(v_items)), _t2401);
  return null;
}
function f_Workspace_spreadlit__spreadCall(v_line, v_a, v_b) {
  let _t2402 = null, _t2403 = null, _t2404 = null, _t2405 = null, _t2406 = null;
  Z.setLine(16);
  return ((_t2402 = Z.arrNew()), Z.apush(_t2402, ":Call"), Z.apush(_t2402, Z.dup(v_line)), Z.apush(_t2402, ((_t2403 = Z.arrNew()), Z.apush(_t2403, ":Name"), Z.apush(_t2403, Z.dup(v_line)), Z.apush(_t2403, "zs_spread"), _t2403)), Z.apush(_t2402, ((_t2404 = Z.arrNew()), Z.apush(_t2404, ((_t2405 = Z.arrNew()), Z.apush(_t2405, ":Arg"), Z.apush(_t2405, 0), Z.apush(_t2405, null), Z.apush(_t2405, Z.dup(v_a)), Z.apush(_t2405, false), _t2405)), Z.apush(_t2404, ((_t2406 = Z.arrNew()), Z.apush(_t2406, ":Arg"), Z.apush(_t2406, 0), Z.apush(_t2406, null), Z.apush(_t2406, Z.dup(v_b)), Z.apush(_t2406, false), _t2406)), _t2404)), _t2402);
  return null;
}
function f_Workspace_spreadlit__rewriteArray(v_n) {
  let v_line = null, v_has = null, v_it = null, v_cur = null, v_items = null, v_v = null, v_seg = null;
  let _t2407 = null, _t2408 = null, _t2409 = null;
  Z.setLine(20);
  (v_line = Z.dup(Z.index(v_n, 1)));
  Z.setLine(21);
  (v_has = false);
  Z.setLine(22);
  {
    const _it268 = Z.foreachArr(Z.dup(Z.index(v_n, 2)));
    L268: for (let _i268 = 0; _i268 < _it268.keys.length; _i268++) {
      v_it = _it268.vals[_i268];
      Z.setLine(22);
      if (Z.truthy((Z.truthy(f_Workspace_parser__isNode(Z.dup(Z.index(v_it, 3)))) && Z.truthy(Z.ident(Z.index(Z.index(v_it, 3), 0), ":Spread"))))) {
        Z.setLine(22);
        (v_has = true);
      }
    }
  }
  Z.setLine(23);
  if (Z.truthy(!Z.truthy(v_has))) {
    Z.setLine(23);
    return null;
  }
  Z.setLine(24);
  (v_cur = null);
  Z.setLine(25);
  (v_items = ((_t2407 = Z.arrNew()), _t2407));
  Z.setLine(26);
  {
    const _it269 = Z.foreachArr(Z.dup(Z.index(v_n, 2)));
    L269: for (let _i269 = 0; _i269 < _it269.keys.length; _i269++) {
      v_it = _it269.vals[_i269];
      Z.setLine(27);
      (v_v = Z.dup(Z.index(v_it, 3)));
      Z.setLine(28);
      if (Z.truthy((Z.truthy(f_Workspace_parser__isNode(Z.dup(v_v))) && Z.truthy(Z.ident(Z.index(v_v, 0), ":Spread"))))) {
        Z.setLine(29);
        (v_seg = f_Workspace_spreadlit__segment(Z.dup(v_line), Z.dup(v_items)));
        Z.setLine(30);
        (v_cur = (Z.truthy(Z.ident(v_cur, null)) ? v_seg : f_Workspace_spreadlit__spreadCall(Z.dup(v_line), Z.dup(v_cur), Z.dup(v_seg))));
        Z.setLine(31);
        (v_cur = f_Workspace_spreadlit__spreadCall(Z.dup(v_line), Z.dup(v_cur), f_Workspace_spreadlit__rewrite(Z.dup(Z.index(v_v, 2)))));
        Z.setLine(32);
        (v_items = ((_t2408 = Z.arrNew()), _t2408));
      } else {
        Z.setLine(34);
        Z.apush((v_items = Z.wr(v_items)), ((_t2409 = Z.arrNew()), Z.apush(_t2409, ":Item"), Z.apush(_t2409, 0), Z.apush(_t2409, (Z.truthy(Z.ident(Z.index(v_it, 2), null)) ? null : f_Workspace_spreadlit__rewrite(Z.dup(Z.index(v_it, 2))))), Z.apush(_t2409, f_Workspace_spreadlit__rewrite(Z.dup(v_v))), _t2409));
      }
    }
  }
  Z.setLine(37);
  if (Z.truthy((Z.cmp(Z.B.count(v_items), 0) > 0))) {
    Z.setLine(37);
    (v_cur = f_Workspace_spreadlit__spreadCall(Z.dup(v_line), Z.dup(v_cur), f_Workspace_spreadlit__segment(Z.dup(v_line), Z.dup(v_items))));
  }
  Z.setLine(38);
  return Z.dup(v_cur);
  return null;
}
function f_Workspace_spreadlit__rewrite(v_x) {
  let v_r = null, v_o = null, v_i = null, v_k = null, v_v = null;
  let _t2410 = null, _t2411 = null, _t2412 = null;
  Z.setLine(42);
  if (Z.truthy(f_Workspace_parser__isNode(Z.dup(v_x)))) {
    Z.setLine(43);
    if (Z.truthy(Z.ident(Z.index(v_x, 0), ":Array"))) {
      Z.setLine(44);
      (v_r = f_Workspace_spreadlit__rewriteArray(Z.dup(v_x)));
      Z.setLine(45);
      if (Z.truthy(!Z.ident(v_r, null))) {
        Z.setLine(45);
        return Z.dup(v_r);
      }
    }
    Z.setLine(47);
    (v_o = ((_t2410 = Z.arrNew()), Z.apush(_t2410, Z.dup(Z.index(v_x, 0))), Z.apush(_t2410, Z.dup(Z.index(v_x, 1))), _t2410));
    Z.setLine(48);
    (v_i = 2);
    L270: for (; Z.truthy((Z.cmp(v_i, Z.B.count(v_x)) < 0)); ((_t2411 = v_i), (v_i = Z.add(_t2411, 1)), _t2411)) {
      Z.setLine(48);
      Z.apush((v_o = Z.wr(v_o)), f_Workspace_spreadlit__rewrite(Z.dup(Z.index(v_x, v_i))));
    }
    Z.setLine(49);
    return Z.dup(v_o);
  }
  Z.setLine(51);
  if (Z.truthy(Z.B.is_array(v_x))) {
    Z.setLine(52);
    (v_o = ((_t2412 = Z.arrNew()), _t2412));
    Z.setLine(53);
    {
      const _it271 = Z.foreachArr(Z.dup(v_x));
      L271: for (let _i271 = 0; _i271 < _it271.keys.length; _i271++) {
        v_v = _it271.vals[_i271];
        v_k = _it271.keys[_i271];
        Z.setLine(53);
        Z.aset((v_o = Z.wr(v_o)), v_k, f_Workspace_spreadlit__rewrite(Z.dup(v_v)));
      }
    }
    Z.setLine(54);
    return Z.dup(v_o);
  }
  Z.setLine(56);
  return Z.dup(v_x);
  return null;
}
function f_Workspace_spreadlit__desugar(v_ast) {
  Z.setLine(62);
  return f_Workspace_spreadlit__rewrite(Z.dup(v_ast));
  return null;
}
function f_Workspace_matchlit__eqTest(v_line, v_c) {
  let _t2413 = null, _t2414 = null;
  Z.setLine(13);
  return ((_t2413 = Z.arrNew()), Z.apush(_t2413, ":Binary"), Z.apush(_t2413, Z.dup(v_line)), Z.apush(_t2413, "Identical"), Z.apush(_t2413, ((_t2414 = Z.arrNew()), Z.apush(_t2414, ":Var"), Z.apush(_t2414, Z.dup(v_line)), Z.apush(_t2414, "__m"), _t2414)), Z.apush(_t2413, Z.dup(v_c)), _t2413);
  return null;
}
function f_Workspace_matchlit__rewriteMatch(v_n) {
  let v_line = null, v_body = null, v_hasDefault = null, v_arm = null, v_conds = null, v_val = null, v_c = null, v_x = null, v_t = null, v_params = null, v_fn = null;
  let _t2415 = null, _t2416 = null, _t2417 = null, _t2418 = null, _t2419 = null, _t2420 = null, _t2421 = null, _t2422 = null, _t2423 = null, _t2424 = null, _t2425 = null, _t2426 = null, _t2427 = null, _t2428 = null, _t2429 = null, _t2430 = null, _t2431 = null, _t2432 = null, _t2433 = null, _t2434 = null;
  Z.setLine(17);
  (v_line = Z.dup(Z.index(v_n, 1)));
  Z.setLine(18);
  (v_body = ((_t2415 = Z.arrNew()), _t2415));
  Z.setLine(19);
  (v_hasDefault = false);
  Z.setLine(20);
  {
    const _it272 = Z.foreachArr(Z.dup(Z.index(v_n, 3)));
    L272: for (let _i272 = 0; _i272 < _it272.keys.length; _i272++) {
      v_arm = _it272.vals[_i272];
      Z.setLine(21);
      (v_conds = Z.dup(Z.index(v_arm, 2)));
      Z.setLine(22);
      (v_val = f_Workspace_matchlit__rewrite(Z.dup(Z.index(v_arm, 3))));
      Z.setLine(23);
      if (Z.truthy(Z.ident(v_conds, null))) {
        Z.setLine(24);
        Z.apush((v_body = Z.wr(v_body)), ((_t2416 = Z.arrNew()), Z.apush(_t2416, ":Return"), Z.apush(_t2416, Z.dup(v_line)), Z.apush(_t2416, Z.dup(v_val)), _t2416));
        Z.setLine(25);
        (v_hasDefault = true);
        break L272;
      }
      Z.setLine(28);
      (v_c = null);
      Z.setLine(29);
      {
        const _it273 = Z.foreachArr(Z.dup(v_conds));
        L273: for (let _i273 = 0; _i273 < _it273.keys.length; _i273++) {
          v_x = _it273.vals[_i273];
          Z.setLine(30);
          (v_t = f_Workspace_matchlit__eqTest(Z.dup(v_line), f_Workspace_matchlit__rewrite(Z.dup(v_x))));
          Z.setLine(31);
          (v_c = (Z.truthy(Z.ident(v_c, null)) ? v_t : ((_t2417 = Z.arrNew()), Z.apush(_t2417, ":Binary"), Z.apush(_t2417, Z.dup(v_line)), Z.apush(_t2417, "Or"), Z.apush(_t2417, Z.dup(v_c)), Z.apush(_t2417, Z.dup(v_t)), _t2417)));
        }
      }
      Z.setLine(33);
      Z.apush((v_body = Z.wr(v_body)), ((_t2418 = Z.arrNew()), Z.apush(_t2418, ":If"), Z.apush(_t2418, Z.dup(v_line)), Z.apush(_t2418, Z.dup(v_c)), Z.apush(_t2418, ((_t2419 = Z.arrNew()), Z.apush(_t2419, ((_t2420 = Z.arrNew()), Z.apush(_t2420, ":Return"), Z.apush(_t2420, Z.dup(v_line)), Z.apush(_t2420, Z.dup(v_val)), _t2420)), _t2419)), Z.apush(_t2418, null), _t2418));
    }
  }
  Z.setLine(35);
  if (Z.truthy(!Z.truthy(v_hasDefault))) {
    Z.setLine(36);
    Z.apush((v_body = Z.wr(v_body)), ((_t2421 = Z.arrNew()), Z.apush(_t2421, ":Throw"), Z.apush(_t2421, Z.dup(v_line)), Z.apush(_t2421, ((_t2422 = Z.arrNew()), Z.apush(_t2422, ":New"), Z.apush(_t2422, Z.dup(v_line)), Z.apush(_t2422, "Exception"), Z.apush(_t2422, ((_t2423 = Z.arrNew()), Z.apush(_t2423, ((_t2424 = Z.arrNew()), Z.apush(_t2424, ":Arg"), Z.apush(_t2424, 0), Z.apush(_t2424, null), Z.apush(_t2424, ((_t2425 = Z.arrNew()), Z.apush(_t2425, ":Str"), Z.apush(_t2425, Z.dup(v_line)), Z.apush(_t2425, "brak dopasowania w match"), _t2425)), Z.apush(_t2424, false), _t2424)), _t2423)), _t2422)), _t2421));
  }
  Z.setLine(38);
  (v_params = ((_t2426 = Z.arrNew()), Z.apush(_t2426, ((_t2427 = Z.arrNew()), Z.apush(_t2427, ":Param"), Z.apush(_t2427, 0), Z.apush(_t2427, "__m"), Z.apush(_t2427, ((_t2428 = Z.arrNew()), _t2428)), Z.apush(_t2427, null), Z.apush(_t2427, false), _t2427)), _t2426));
  Z.setLine(39);
  (v_fn = ((_t2429 = Z.arrNew()), Z.apush(_t2429, ":Func"), Z.apush(_t2429, Z.dup(v_line)), Z.apush(_t2429, null), Z.apush(_t2429, Z.dup(v_params)), Z.apush(_t2429, ((_t2430 = Z.arrNew()), _t2430)), Z.apush(_t2429, Z.dup(v_body)), Z.apush(_t2429, false), _t2429));
  Z.setLine(40);
  return ((_t2431 = Z.arrNew()), Z.apush(_t2431, ":Call"), Z.apush(_t2431, Z.dup(v_line)), Z.apush(_t2431, ((_t2432 = Z.arrNew()), Z.apush(_t2432, ":Closure"), Z.apush(_t2432, Z.dup(v_line)), Z.apush(_t2432, Z.dup(v_fn)), _t2432)), Z.apush(_t2431, ((_t2433 = Z.arrNew()), Z.apush(_t2433, ((_t2434 = Z.arrNew()), Z.apush(_t2434, ":Arg"), Z.apush(_t2434, 0), Z.apush(_t2434, null), Z.apush(_t2434, f_Workspace_matchlit__rewrite(Z.dup(Z.index(v_n, 2)))), Z.apush(_t2434, false), _t2434)), _t2433)), _t2431);
  return null;
}
function f_Workspace_matchlit__rewrite(v_x) {
  let v_o = null, v_i = null, v_k = null, v_v = null;
  let _t2435 = null, _t2436 = null, _t2437 = null;
  Z.setLine(44);
  if (Z.truthy(f_Workspace_parser__isNode(Z.dup(v_x)))) {
    Z.setLine(45);
    if (Z.truthy(Z.ident(Z.index(v_x, 0), ":Match"))) {
      Z.setLine(45);
      return f_Workspace_matchlit__rewriteMatch(Z.dup(v_x));
    }
    Z.setLine(46);
    (v_o = ((_t2435 = Z.arrNew()), Z.apush(_t2435, Z.dup(Z.index(v_x, 0))), Z.apush(_t2435, Z.dup(Z.index(v_x, 1))), _t2435));
    Z.setLine(47);
    (v_i = 2);
    L274: for (; Z.truthy((Z.cmp(v_i, Z.B.count(v_x)) < 0)); ((_t2436 = v_i), (v_i = Z.add(_t2436, 1)), _t2436)) {
      Z.setLine(47);
      Z.apush((v_o = Z.wr(v_o)), f_Workspace_matchlit__rewrite(Z.dup(Z.index(v_x, v_i))));
    }
    Z.setLine(48);
    return Z.dup(v_o);
  }
  Z.setLine(50);
  if (Z.truthy(Z.B.is_array(v_x))) {
    Z.setLine(51);
    (v_o = ((_t2437 = Z.arrNew()), _t2437));
    Z.setLine(52);
    {
      const _it275 = Z.foreachArr(Z.dup(v_x));
      L275: for (let _i275 = 0; _i275 < _it275.keys.length; _i275++) {
        v_v = _it275.vals[_i275];
        v_k = _it275.keys[_i275];
        Z.setLine(52);
        Z.aset((v_o = Z.wr(v_o)), v_k, f_Workspace_matchlit__rewrite(Z.dup(v_v)));
      }
    }
    Z.setLine(53);
    return Z.dup(v_o);
  }
  Z.setLine(55);
  return Z.dup(v_x);
  return null;
}
function f_Workspace_matchlit__desugar(v_ast) {
  Z.setLine(58);
  return f_Workspace_matchlit__rewrite(Z.dup(v_ast));
  return null;
}
function f_Workspace_link__builtin_modules() {
  let _t2438 = null;
  Z.setLine(17);
  return ((_t2438 = Z.arrNew()), Z.apush(_t2438, "System"), Z.apush(_t2438, "Math"), Z.apush(_t2438, "File"), Z.apush(_t2438, "Directory"), Z.apush(_t2438, "Process"), _t2438);
  return null;
}
function f_Workspace_link__link(v_ast, v_file) {
  let v_lk = null, v_aliases = null, v_main = null, v_s = null, v_f = null, v_all = null, v_ds = null, v_e = null, v___r222 = null, v___w223 = null, v_cl = null, v___r224 = null, v___w225 = null, v_vr = null, v___r226 = null, v___w227 = null;
  let _t2439 = null, _t2440 = null, _t2441 = null, _t2442 = null, _t2443 = null, _t2444 = null, _t2445 = null, _t2446 = null, _t2447 = null, _t2448 = null, _t2449 = null;
  Z.setLine(113);
  (v_lk = f_Linker__new());
  Z.setLine(114);
  (v_aliases = f_zs_invoke(Z.dup(v_lk), "collectImports", ((_t2439 = Z.arrNew()), Z.apush(_t2439, Z.dup(v_ast)), Z.apush(_t2439, Z.dup(v_file)), _t2439)));
  Z.setLine(115);
  (v_main = ((_t2440 = Z.arrNew()), _t2440));
  Z.setLine(116);
  {
    const _it276 = Z.foreachArr(Z.dup(v_ast));
    L276: for (let _i276 = 0; _i276 < _it276.keys.length; _i276++) {
      v_s = _it276.vals[_i276];
      Z.setLine(117);
      if (Z.truthy((Z.truthy(Z.ident(Z.index(v_s, 0), ":Import")) && Z.truthy(!Z.truthy(Z.B.in_array(Z.index(Z.index(v_s, 2), 0), f_Workspace_link__builtin_modules())))))) {
        continue L276;
      }
      Z.setLine(118);
      if (Z.truthy(Z.ident(Z.index(v_s, 0), ":FuncStmt"))) {
        Z.setLine(119);
        (v_f = Z.dup(Z.index(v_s, 2)));
        Z.setLine(120);
        Z.aset((v_f = Z.wr(v_f)), 5, f_zs_invoke(Z.dup(v_lk), "rw", ((_t2441 = Z.arrNew()), Z.apush(_t2441, Z.dup(Z.index(v_f, 5))), Z.apush(_t2441, null), Z.apush(_t2441, ((_t2442 = Z.arrNew()), _t2442)), Z.apush(_t2441, Z.dup(v_aliases)), _t2441)));
        Z.setLine(121);
        Z.aset((v_s = Z.wr(v_s)), 2, Z.dup(v_f));
        Z.setLine(122);
        Z.apush((v_main = Z.wr(v_main)), Z.dup(v_s));
      } else {
        Z.setLine(124);
        Z.apush((v_main = Z.wr(v_main)), f_zs_invoke(Z.dup(v_lk), "rw", ((_t2443 = Z.arrNew()), Z.apush(_t2443, Z.dup(v_s)), Z.apush(_t2443, null), Z.apush(_t2443, ((_t2444 = Z.arrNew()), _t2444)), Z.apush(_t2443, Z.dup(v_aliases)), _t2443)));
      }
    }
  }
  Z.setLine(127);
  (v_all = ((_t2445 = Z.arrNew()), _t2445));
  Z.setLine(128);
  {
    const _it277 = Z.foreachArr(Z.B.zs_obj_get(v_lk, "out"));
    L277: for (let _i277 = 0; _i277 < _it277.keys.length; _i277++) {
      v_s = _it277.vals[_i277];
      Z.setLine(128);
      Z.apush((v_all = Z.wr(v_all)), Z.dup(v_s));
    }
  }
  Z.setLine(129);
  {
    const _it278 = Z.foreachArr(Z.dup(v_main));
    L278: for (let _i278 = 0; _i278 < _it278.keys.length; _i278++) {
      v_s = _it278.vals[_i278];
      Z.setLine(129);
      Z.apush((v_all = Z.wr(v_all)), Z.dup(v_s));
    }
  }
  Z.setLine(130);
  (v_all = f_Workspace_link__prelude_pass(Z.dup(v_all)));
  Z.setLine(131);
  (v_all = f_Workspace_spreadlit__desugar(Z.dup(v_all)));
  Z.setLine(132);
  (v_all = f_Workspace_matchlit__desugar(Z.dup(v_all)));
  Z.setLine(133);
  (v_ds = f_Workspace_classes__desugar(Z.dup(v_all)));
  Z.setLine(134);
  {
    const _it279 = Z.foreachArr(Z.dup(Z.index(v_ds, "errors")));
    L279: for (let _i279 = 0; _i279 < _it279.keys.length; _i279++) {
      v_e = _it279.vals[_i279];
      Z.setLine(134);
      (v___r222 = ((_t2446 = Z.arrNew()), Z.apush(_t2446, Z.dup(Z.index(v_e, 0))), Z.apush(_t2446, Z.dup(Z.index(v_e, 1))), Z.apush(_t2446, Z.dup(Z.index(v_e, 2))), Z.apush(_t2446, Z.dup(v_file)), _t2446));
      Z.setLine(134);
      (v___w223 = Z.B.zs_obj_take(v_lk, "errors"));
      Z.setLine(134);
      Z.apush((v___w223 = Z.wr(v___w223)), Z.dup(v___r222));
      Z.setLine(134);
      Z.B.zs_obj_put(v_lk, "errors", v___w223);
    }
  }
  Z.setLine(135);
  (v_cl = f_Workspace_closures__lift(Z.dup(Z.index(v_ds, "ast"))));
  Z.setLine(136);
  {
    const _it280 = Z.foreachArr(Z.dup(Z.index(v_cl, "errors")));
    L280: for (let _i280 = 0; _i280 < _it280.keys.length; _i280++) {
      v_e = _it280.vals[_i280];
      Z.setLine(136);
      (v___r224 = ((_t2447 = Z.arrNew()), Z.apush(_t2447, Z.dup(Z.index(v_e, 0))), Z.apush(_t2447, Z.dup(Z.index(v_e, 1))), Z.apush(_t2447, Z.dup(Z.index(v_e, 2))), Z.apush(_t2447, Z.dup(v_file)), _t2447));
      Z.setLine(136);
      (v___w225 = Z.B.zs_obj_take(v_lk, "errors"));
      Z.setLine(136);
      Z.apush((v___w225 = Z.wr(v___w225)), Z.dup(v___r224));
      Z.setLine(136);
      Z.B.zs_obj_put(v_lk, "errors", v___w225);
    }
  }
  Z.setLine(137);
  (v_vr = f_Workspace_link__variadic_pass(Z.dup(Z.index(v_cl, "ast"))));
  Z.setLine(138);
  {
    const _it281 = Z.foreachArr(Z.dup(Z.index(v_vr, "errors")));
    L281: for (let _i281 = 0; _i281 < _it281.keys.length; _i281++) {
      v_e = _it281.vals[_i281];
      Z.setLine(138);
      (v___r226 = ((_t2448 = Z.arrNew()), Z.apush(_t2448, Z.dup(Z.index(v_e, 0))), Z.apush(_t2448, Z.dup(Z.index(v_e, 1))), Z.apush(_t2448, Z.dup(Z.index(v_e, 2))), Z.apush(_t2448, Z.dup(v_file)), _t2448));
      Z.setLine(138);
      (v___w227 = Z.B.zs_obj_take(v_lk, "errors"));
      Z.setLine(138);
      Z.apush((v___w227 = Z.wr(v___w227)), Z.dup(v___r226));
      Z.setLine(138);
      Z.B.zs_obj_put(v_lk, "errors", v___w227);
    }
  }
  Z.setLine(139);
  return ((_t2449 = Z.arrNew()), Z.aset(_t2449, "ast", Z.dup(Z.index(v_vr, "ast"))), Z.aset(_t2449, "errors", Z.B.zs_obj_get(v_lk, "errors")), _t2449);
  return null;
}
function f_Workspace_link__variadic_pass(v_ast) {
  let v_vp = null, v_s = null, v_ps = null, v_n = null, v___k228 = null, v___r229 = null, v___w230 = null, v___k231 = null, v___r232 = null, v___w233 = null, v_out = null, v_f = null, v_p = null;
  let _t2450 = null, _t2451 = null, _t2452 = null, _t2453 = null, _t2454 = null;
  Z.setLine(193);
  (v_vp = f_VarPass__new());
  Z.setLine(194);
  {
    const _it282 = Z.foreachArr(Z.dup(v_ast));
    L282: for (let _i282 = 0; _i282 < _it282.keys.length; _i282++) {
      v_s = _it282.vals[_i282];
      Z.setLine(195);
      if (Z.truthy(!Z.ident(Z.index(v_s, 0), ":FuncStmt"))) {
        continue L282;
      }
      Z.setLine(196);
      (v_ps = Z.dup(Z.index(Z.index(v_s, 2), 3)));
      Z.setLine(197);
      (v_n = Z.B.count(v_ps));
      Z.setLine(198);
      if (Z.truthy((Z.truthy((Z.cmp(v_n, 0) > 0)) && Z.truthy(Z.index(Z.index(v_ps, Z.sub(v_n, 1)), 5))))) {
        Z.setLine(198);
        (v___k228 = Z.dup(Z.index(Z.index(v_s, 2), 2)));
        Z.setLine(198);
        (v___r229 = Z.sub(v_n, 1));
        Z.setLine(198);
        (v___w230 = Z.B.zs_obj_take(v_vp, "fixed"));
        Z.setLine(198);
        Z.aset((v___w230 = Z.wr(v___w230)), v___k228, Z.dup(v___r229));
        Z.setLine(198);
        Z.B.zs_obj_put(v_vp, "fixed", v___w230);
        Z.setLine(198);
        (v___k231 = Z.dup(Z.index(Z.index(v_s, 2), 2)));
        Z.setLine(198);
        (v___r232 = Z.dup(v_ps));
        Z.setLine(198);
        (v___w233 = Z.B.zs_obj_take(v_vp, "defs"));
        Z.setLine(198);
        Z.aset((v___w233 = Z.wr(v___w233)), v___k231, Z.dup(v___r232));
        Z.setLine(198);
        Z.B.zs_obj_put(v_vp, "defs", v___w233);
      }
    }
  }
  Z.setLine(200);
  if (Z.truthy(Z.ident(Z.B.count(Z.B.zs_obj_get(v_vp, "fixed")), 0))) {
    Z.setLine(200);
    return ((_t2450 = Z.arrNew()), Z.aset(_t2450, "ast", Z.dup(v_ast)), Z.aset(_t2450, "errors", ((_t2451 = Z.arrNew()), _t2451)), _t2450);
  }
  Z.setLine(201);
  (v_out = ((_t2452 = Z.arrNew()), _t2452));
  Z.setLine(202);
  {
    const _it283 = Z.foreachArr(Z.dup(v_ast));
    L283: for (let _i283 = 0; _i283 < _it283.keys.length; _i283++) {
      v_s = _it283.vals[_i283];
      Z.setLine(203);
      (v_s = f_zs_invoke(Z.dup(v_vp), "rw", ((_t2453 = Z.arrNew()), Z.apush(_t2453, Z.dup(v_s)), _t2453)));
      Z.setLine(204);
      if (Z.truthy(Z.ident(Z.index(v_s, 0), ":FuncStmt"))) {
        Z.setLine(205);
        (v_f = Z.dup(Z.index(v_s, 2)));
        Z.setLine(206);
        (v_ps = Z.dup(Z.index(v_f, 3)));
        Z.setLine(207);
        (v_n = Z.B.count(v_ps));
        Z.setLine(208);
        if (Z.truthy((Z.truthy((Z.cmp(v_n, 0) > 0)) && Z.truthy(Z.index(Z.index(v_ps, Z.sub(v_n, 1)), 5))))) {
          Z.setLine(208);
          (v_p = Z.dup(Z.index(v_ps, Z.sub(v_n, 1))));
          Z.setLine(208);
          Z.aset((v_p = Z.wr(v_p)), 5, false);
          Z.setLine(208);
          Z.aset((v_ps = Z.wr(v_ps)), Z.sub(v_n, 1), Z.dup(v_p));
          Z.setLine(208);
          Z.aset((v_f = Z.wr(v_f)), 3, Z.dup(v_ps));
          Z.setLine(208);
          Z.aset((v_s = Z.wr(v_s)), 2, Z.dup(v_f));
        }
      }
      Z.setLine(210);
      Z.apush((v_out = Z.wr(v_out)), Z.dup(v_s));
    }
  }
  Z.setLine(212);
  return ((_t2454 = Z.arrNew()), Z.aset(_t2454, "ast", Z.dup(v_out)), Z.aset(_t2454, "errors", Z.B.zs_obj_get(v_vp, "errors")), _t2454);
  return null;
}
function f_Workspace_link__calls_of(v_x, v_acc) {
  let v_v = null;
  Z.setLine(216);
  if (Z.truthy(!Z.truthy(Z.B.is_array(v_x)))) {
    Z.setLine(216);
    return Z.dup(v_acc);
  }
  Z.setLine(217);
  if (Z.truthy((Z.truthy((Z.truthy(f_Workspace_parser__isNode(Z.dup(v_x))) && Z.truthy(Z.ident(Z.index(v_x, 0), ":Call")))) && Z.truthy(Z.ident(Z.index(Z.index(v_x, 2), 0), ":Name"))))) {
    Z.setLine(217);
    Z.aset((v_acc = Z.wr(v_acc)), Z.index(Z.index(v_x, 2), 2), true);
  }
  Z.setLine(218);
  {
    const _it284 = Z.foreachArr(Z.dup(v_x));
    L284: for (let _i284 = 0; _i284 < _it284.keys.length; _i284++) {
      v_v = _it284.vals[_i284];
      Z.setLine(218);
      (v_acc = f_Workspace_link__calls_of(Z.dup(v_v), Z.dup(v_acc)));
    }
  }
  Z.setLine(219);
  return Z.dup(v_acc);
  return null;
}
function f_Workspace_link__prelude_pass(v_ast) {
  let v_defined = null, v_s = null, v_used = null, v_want = null, v_n = null, v_out = null, v_nm = null;
  let _t2455 = null, _t2456 = null, _t2457 = null, _t2458 = null;
  Z.setLine(226);
  (v_defined = ((_t2455 = Z.arrNew()), _t2455));
  Z.setLine(227);
  {
    const _it285 = Z.foreachArr(Z.dup(v_ast));
    L285: for (let _i285 = 0; _i285 < _it285.keys.length; _i285++) {
      v_s = _it285.vals[_i285];
      Z.setLine(227);
      if (Z.truthy(Z.ident(Z.index(v_s, 0), ":FuncStmt"))) {
        Z.setLine(227);
        Z.aset((v_defined = Z.wr(v_defined)), Z.index(Z.index(v_s, 2), 2), true);
      }
    }
  }
  Z.setLine(228);
  (v_used = f_Workspace_link__calls_of(Z.dup(v_ast), ((_t2456 = Z.arrNew()), _t2456)));
  Z.setLine(229);
  (v_want = ((_t2457 = Z.arrNew()), _t2457));
  Z.setLine(230);
  {
    const _it286 = Z.foreachArr(f_Workspace_prelude__names());
    L286: for (let _i286 = 0; _i286 < _it286.keys.length; _i286++) {
      v_n = _it286.vals[_i286];
      Z.setLine(230);
      if (Z.truthy((Z.truthy(Z.B.has_key(v_used, v_n)) && Z.truthy(!Z.truthy(Z.B.has_key(v_defined, v_n)))))) {
        Z.setLine(230);
        Z.aset((v_want = Z.wr(v_want)), v_n, true);
      }
    }
  }
  Z.setLine(231);
  if (Z.truthy(Z.ident(Z.B.count(v_want), 0))) {
    Z.setLine(231);
    return Z.dup(v_ast);
  }
  Z.setLine(232);
  (v_out = ((_t2458 = Z.arrNew()), _t2458));
  Z.setLine(233);
  {
    const _it287 = Z.foreachArr(f_Workspace_parser__parse(f_Workspace_prelude__source()));
    L287: for (let _i287 = 0; _i287 < _it287.keys.length; _i287++) {
      v_s = _it287.vals[_i287];
      Z.setLine(234);
      (v_nm = Z.dup(Z.index(Z.index(v_s, 2), 2)));
      Z.setLine(235);
      if (Z.truthy((Z.truthy(Z.B.has_key(v_want, v_nm)) || Z.truthy((Z.truthy(Z.ident(v_nm, "usort_rec")) && Z.truthy(Z.B.has_key(v_want, "usort"))))))) {
        Z.setLine(235);
        Z.apush((v_out = Z.wr(v_out)), Z.dup(v_s));
      }
    }
  }
  Z.setLine(237);
  {
    const _it288 = Z.foreachArr(Z.dup(v_ast));
    L288: for (let _i288 = 0; _i288 < _it288.keys.length; _i288++) {
      v_s = _it288.vals[_i288];
      Z.setLine(237);
      Z.apush((v_out = Z.wr(v_out)), Z.dup(v_s));
    }
  }
  Z.setLine(238);
  return Z.dup(v_out);
  return null;
}
function f_Workspace_regions__var_counts(v_n, v_acc) {
  let v_t = null, v_c = null;
  let _t2459 = null, _t2460 = null, _t2461 = null, _t2462 = null, _t2463 = null, _t2464 = null, _t2465 = null, _t2466 = null, _t2467 = null, _t2468 = null, _t2469 = null;
  Z.setLine(14);
  if (Z.truthy(!Z.truthy(Z.B.is_array(v_n)))) {
    Z.setLine(14);
    return Z.dup(v_acc);
  }
  Z.setLine(15);
  (v_t = (((_t2459 = Z.indexOpt(v_n, 0)) !== null) ? _t2459 : null));
  Z.setLine(16);
  if (Z.truthy((Z.truthy(Z.ident(v_t, ":Var")) && Z.truthy(Z.B.is_string((((_t2460 = Z.indexOpt(v_n, 2)) !== null) ? _t2460 : null)))))) {
    Z.setLine(16);
    Z.aset((v_acc = Z.wr(v_acc)), Z.index(v_n, 2), Z.add((((_t2461 = Z.indexOpt(v_acc, Z.index(v_n, 2))) !== null) ? _t2461 : 0), 1));
    Z.setLine(16);
    return Z.dup(v_acc);
  }
  Z.setLine(17);
  if (Z.truthy(Z.ident(v_t, ":Foreach"))) {
    Z.setLine(18);
    if (Z.truthy(Z.B.is_string((((_t2462 = Z.indexOpt(v_n, 3)) !== null) ? _t2462 : null)))) {
      Z.setLine(18);
      Z.aset((v_acc = Z.wr(v_acc)), Z.index(v_n, 3), Z.add((((_t2463 = Z.indexOpt(v_acc, Z.index(v_n, 3))) !== null) ? _t2463 : 0), 1));
    }
    Z.setLine(19);
    if (Z.truthy(Z.B.is_string((((_t2464 = Z.indexOpt(v_n, 4)) !== null) ? _t2464 : null)))) {
      Z.setLine(19);
      Z.aset((v_acc = Z.wr(v_acc)), Z.index(v_n, 4), Z.add((((_t2465 = Z.indexOpt(v_acc, Z.index(v_n, 4))) !== null) ? _t2465 : 0), 1));
    }
  }
  Z.setLine(21);
  if (Z.truthy(Z.ident(v_t, ":Try"))) {
    Z.setLine(22);
    {
      const _it289 = Z.foreachArr((((_t2466 = Z.indexOpt(v_n, 3)) !== null) ? _t2466 : ((_t2467 = Z.arrNew()), _t2467)));
      L289: for (let _i289 = 0; _i289 < _it289.keys.length; _i289++) {
        v_c = _it289.vals[_i289];
        Z.setLine(22);
        if (Z.truthy((Z.truthy(Z.B.is_array(v_c)) && Z.truthy(Z.B.is_string((((_t2468 = Z.indexOpt(v_c, 3)) !== null) ? _t2468 : null)))))) {
          Z.setLine(22);
          Z.aset((v_acc = Z.wr(v_acc)), Z.index(v_c, 3), Z.add((((_t2469 = Z.indexOpt(v_acc, Z.index(v_c, 3))) !== null) ? _t2469 : 0), 1));
        }
      }
    }
  }
  Z.setLine(24);
  {
    const _it290 = Z.foreachArr(Z.dup(v_n));
    L290: for (let _i290 = 0; _i290 < _it290.keys.length; _i290++) {
      v_c = _it290.vals[_i290];
      Z.setLine(24);
      if (Z.truthy(Z.B.is_array(v_c))) {
        Z.setLine(24);
        (v_acc = f_Workspace_regions__var_counts(Z.dup(v_c), Z.dup(v_acc)));
      }
    }
  }
  Z.setLine(25);
  return Z.dup(v_acc);
  return null;
}
function f_Workspace_regions__region_carry(v_loop, v_body, v_hdr, v_pre, v_fnCounts) {
  let v_cnt = null, v_e = null, v_v = null, v_defined = null, v_bad = null, v_n = null, v_c = null, v_st = null, v_simple = null, v_out = null, v_priv = null;
  let _t2470 = null, _t2471 = null, _t2472 = null, _t2473 = null, _t2474 = null, _t2475 = null, _t2476 = null, _t2477 = null, _t2478 = null, _t2479 = null, _t2480 = null, _t2481 = null, _t2482 = null, _t2483 = null, _t2484 = null, _t2485 = null;
  Z.setLine(36);
  (v_cnt = f_Workspace_regions__var_counts(Z.dup(v_body), ((_t2470 = Z.arrNew()), _t2470)));
  Z.setLine(37);
  {
    const _it291 = Z.foreachArr(Z.dup(v_hdr));
    L291: for (let _i291 = 0; _i291 < _it291.keys.length; _i291++) {
      v_e = _it291.vals[_i291];
      Z.setLine(37);
      (v_cnt = f_Workspace_regions__var_counts(Z.dup(v_e), Z.dup(v_cnt)));
    }
  }
  Z.setLine(38);
  {
    const _it292 = Z.foreachArr(Z.dup(v_pre));
    L292: for (let _i292 = 0; _i292 < _it292.keys.length; _i292++) {
      v_v = _it292.vals[_i292];
      Z.setLine(38);
      if (Z.truthy(Z.B.is_string(v_v))) {
        Z.setLine(38);
        Z.aset((v_cnt = Z.wr(v_cnt)), v_v, Z.add((((_t2471 = Z.indexOpt(v_cnt, v_v)) !== null) ? _t2471 : 0), 1));
      }
    }
  }
  Z.setLine(39);
  (v_defined = ((_t2472 = Z.arrNew()), _t2472));
  Z.setLine(40);
  {
    const _it293 = Z.foreachArr(Z.dup(v_pre));
    L293: for (let _i293 = 0; _i293 < _it293.keys.length; _i293++) {
      v_v = _it293.vals[_i293];
      Z.setLine(40);
      if (Z.truthy(Z.B.is_string(v_v))) {
        Z.setLine(40);
        Z.aset((v_defined = Z.wr(v_defined)), v_v, true);
      }
    }
  }
  Z.setLine(41);
  (v_bad = ((_t2473 = Z.arrNew()), _t2473));
  Z.setLine(42);
  {
    const _it294 = Z.foreachArr(Z.dup(v_hdr));
    L294: for (let _i294 = 0; _i294 < _it294.keys.length; _i294++) {
      v_e = _it294.vals[_i294];
      Z.setLine(42);
      {
        const _it295 = Z.foreachArr(f_Workspace_regions__var_counts(Z.dup(v_e), ((_t2474 = Z.arrNew()), _t2474)));
        L295: for (let _i295 = 0; _i295 < _it295.keys.length; _i295++) {
          v_c = _it295.vals[_i295];
          v_n = _it295.keys[_i295];
          Z.setLine(42);
          Z.aset((v_bad = Z.wr(v_bad)), v_n, true);
        }
      }
    }
  }
  Z.setLine(43);
  {
    const _it296 = Z.foreachArr(Z.dup(v_body));
    L296: for (let _i296 = 0; _i296 < _it296.keys.length; _i296++) {
      v_st = _it296.vals[_i296];
      Z.setLine(44);
      (v_simple = (Z.truthy((Z.truthy((Z.truthy((Z.truthy((Z.truthy(Z.B.is_array(v_st)) && Z.truthy(Z.ident((((_t2475 = Z.indexOpt(v_st, 0)) !== null) ? _t2475 : null), ":Expr")))) && Z.truthy(Z.B.is_array((((_t2476 = Z.indexOpt(v_st, 2)) !== null) ? _t2476 : null))))) && Z.truthy(Z.ident((((_t2477 = Z.indexOpt(Z.indexOpt(v_st, 2), 0)) !== null) ? _t2477 : null), ":Assign")))) && Z.truthy(Z.B.is_array((((_t2478 = Z.indexOpt(Z.indexOpt(v_st, 2), 2)) !== null) ? _t2478 : null))))) && Z.truthy(Z.ident((((_t2479 = Z.indexOpt(Z.indexOpt(Z.indexOpt(v_st, 2), 2), 0)) !== null) ? _t2479 : null), ":Var"))));
      Z.setLine(46);
      if (Z.truthy(v_simple)) {
        Z.setLine(47);
        {
          const _it297 = Z.foreachArr(f_Workspace_regions__var_counts(Z.dup(Z.index(Z.index(v_st, 2), 3)), ((_t2480 = Z.arrNew()), _t2480)));
          L297: for (let _i297 = 0; _i297 < _it297.keys.length; _i297++) {
            v_c = _it297.vals[_i297];
            v_n = _it297.keys[_i297];
            Z.setLine(47);
            if (Z.truthy(!Z.truthy(Z.B.has_key(v_defined, v_n)))) {
              Z.setLine(47);
              Z.aset((v_bad = Z.wr(v_bad)), v_n, true);
            }
          }
        }
        Z.setLine(48);
        Z.aset((v_defined = Z.wr(v_defined)), Z.index(Z.index(Z.index(v_st, 2), 2), 2), true);
      } else {
        Z.setLine(50);
        {
          const _it298 = Z.foreachArr(f_Workspace_regions__var_counts(Z.dup(v_st), ((_t2481 = Z.arrNew()), _t2481)));
          L298: for (let _i298 = 0; _i298 < _it298.keys.length; _i298++) {
            v_c = _it298.vals[_i298];
            v_n = _it298.keys[_i298];
            Z.setLine(50);
            if (Z.truthy(!Z.truthy(Z.B.has_key(v_defined, v_n)))) {
              Z.setLine(50);
              Z.aset((v_bad = Z.wr(v_bad)), v_n, true);
            }
          }
        }
      }
    }
  }
  Z.setLine(53);
  (v_out = ((_t2482 = Z.arrNew()), _t2482));
  Z.setLine(54);
  (v_priv = ((_t2483 = Z.arrNew()), _t2483));
  Z.setLine(55);
  {
    const _it299 = Z.foreachArr(Z.dup(v_cnt));
    L299: for (let _i299 = 0; _i299 < _it299.keys.length; _i299++) {
      v_c = _it299.vals[_i299];
      v_n = _it299.keys[_i299];
      Z.setLine(56);
      if (Z.truthy((Z.truthy(Z.B.has_key(v_bad, v_n)) || Z.truthy(!Z.ident((((_t2484 = Z.indexOpt(v_fnCounts, v_n)) !== null) ? _t2484 : 0), v_c))))) {
        Z.setLine(56);
        Z.apush((v_out = Z.wr(v_out)), Z.dup(v_n));
      } else {
        Z.setLine(56);
        Z.apush((v_priv = Z.wr(v_priv)), Z.dup(v_n));
      }
    }
  }
  Z.setLine(58);
  return ((_t2485 = Z.arrNew()), Z.apush(_t2485, Z.dup(v_out)), Z.apush(_t2485, Z.dup(v_priv)), _t2485);
  return null;
}
function f_Workspace_emit_llvm__hex2(v_n) {
  let v_h = null;
  Z.setLine(1185);
  (v_h = Z.B.to_hex(v_n));
  Z.setLine(1186);
  return (Z.truthy((Z.cmp(Z.B.strlen(v_h), 2) < 0)) ? Z.concat("0", v_h) : Z.B.upper(v_h));
  return null;
}
function f_Workspace_emit_llvm__generate(v_ir, v_triple) {
  let v_em = null;
  let _t2486 = null;
  Z.setLine(1193);
  (v_em = f_LlEmitter__new(Z.dup(v_ir)));
  Z.setLine(1194);
  return f_zs_invoke(Z.dup(v_em), "generate", ((_t2486 = Z.arrNew()), Z.apush(_t2486, Z.dup(v_triple)), _t2486));
  return null;
}
function f_native__basename(v_p) {
  let v_i = null;
  let _t2487 = null;
  Z.setLine(15);
  (v_i = Z.sub(Z.B.strlen(v_p), 1));
  L300: while (true) {
    Z.setLine(16);
    if (!Z.truthy((Z.truthy((Z.cmp(v_i, 0) >= 0)) && Z.truthy(!Z.ident(Z.B.substr(v_p, v_i, 1), "/"))))) break;
    Z.setLine(16);
    ((_t2487 = v_i), (v_i = Z.sub(_t2487, 1)), _t2487);
  }
  Z.setLine(17);
  return Z.B.substr(v_p, Z.add(v_i, 1));
  return null;
}
function f_native__stem(v_p) {
  let v_b = null, v_dot = null, v_i = null;
  let _t2488 = null;
  Z.setLine(21);
  (v_b = f_native__basename(Z.dup(v_p)));
  Z.setLine(22);
  (v_dot = Z.neg(1));
  Z.setLine(23);
  (v_i = 0);
  L301: for (; Z.truthy((Z.cmp(v_i, Z.B.strlen(v_b)) < 0)); ((_t2488 = v_i), (v_i = Z.add(_t2488, 1)), _t2488)) {
    Z.setLine(23);
    if (Z.truthy(Z.ident(Z.B.substr(v_b, v_i, 1), "."))) {
      Z.setLine(23);
      (v_dot = Z.dup(v_i));
    }
  }
  Z.setLine(24);
  return (Z.truthy((Z.cmp(v_dot, 0) > 0)) ? Z.B.substr(v_b, 0, v_dot) : v_b);
  return null;
}
function f_native__zs_root(v_scriptDir) {
  let v_env = null, v_d = null, v_c = null, v_f = null;
  let _t2489 = null, _t2490 = null, _t2491 = null;
  Z.setLine(32);
  (v_env = Z.M.System.env("ZS_HOME"));
  Z.setLine(33);
  if (Z.truthy((Z.truthy(!Z.ident(v_env, null)) && Z.truthy(!Z.ident(v_env, ""))))) {
    Z.setLine(33);
    return Z.dup(v_env);
  }
  Z.setLine(34);
  (v_d = Z.dup(v_scriptDir));
  Z.setLine(35);
  if (Z.truthy(!Z.truthy(Z.B.starts_with(v_d, "/")))) {
    Z.setLine(35);
    (v_d = Z.concat(Z.concat((((_t2489 = Z.M.System.env("PWD")) !== null) ? _t2489 : "."), "/"), v_d));
  }
  Z.setLine(36);
  {
    const _it302 = Z.foreachArr(((_t2490 = Z.arrNew()), Z.apush(_t2490, Z.concat(v_d, "/../share/z-sharp")), Z.apush(_t2490, Z.concat(v_d, "/share/z-sharp")), _t2490));
    L302: for (let _i302 = 0; _i302 < _it302.keys.length; _i302++) {
      v_c = _it302.vals[_i302];
      Z.setLine(37);
      if (Z.truthy(Z.M.File.exists(Z.concat(v_c, "/runtime/native/zs_rt.c")))) {
        Z.setLine(37);
        return Z.dup(v_c);
      }
    }
  }
  Z.setLine(39);
  (v_f = Z.M.System.resolveImport(((_t2491 = Z.arrNew()), Z.apush(_t2491, "Workspace"), Z.apush(_t2491, "cli"), _t2491), v_scriptDir));
  Z.setLine(40);
  if (Z.truthy(Z.ident(v_f, null))) {
    Z.setLine(40);
    return null;
  }
  Z.setLine(41);
  return Z.M.System.dirname(Z.M.System.dirname(v_f));
  return null;
}
function f_native__frontend(v_file, v_doLink) {
  let v_ast = null, v___ex234 = null, v_e = null, v_r = null, v_lk = null;
  let _t2492 = null, _t2493 = null, _t2494 = null;
  Z.setLine(49);
  if (Z.truthy(!Z.truthy(Z.M.File.exists(v_file)))) {
    Z.setLine(49);
    Z.raise(new Z.ZExc(0, Z.concat("zsc: nie znaleziono pliku ", v_file)));
  }
  try {
    Z.setLine(50);
    (v_ast = f_Workspace_parser__parse(Z.M.File.read(v_file)));
  } catch (_e) {
    _e = Z.toExc(_e);
    if (true) {
      v___ex234 = _e;
      Z.setLine(50);
      if (Z.truthy(f_zs_isa(Z.dup(v___ex234), "Exception"))) {
        Z.setLine(50);
        (v_e = Z.dup(v___ex234));
        Z.setLine(53);
        Z.raise(new Z.ZExc(0, Z.concat(Z.concat(v_file, ":"), f_zs_invoke(Z.dup(v_e), "getMessage", ((_t2492 = Z.arrNew()), _t2492)))));
      } else {
        Z.setLine(50);
        Z.throwV(v___ex234);
      }
    }
    else throw _e;
  }
  Z.setLine(55);
  (v_r = f_Workspace_sema__analyze(Z.dup(v_ast)));
  Z.setLine(56);
  if (Z.truthy(!Z.truthy(v_doLink))) {
    Z.setLine(56);
    return ((_t2493 = Z.arrNew()), Z.aset(_t2493, "ast", Z.dup(v_ast)), Z.aset(_t2493, "warnings", Z.dup(Z.index(v_r, "warnings"))), _t2493);
  }
  Z.setLine(57);
  (v_lk = f_Workspace_link__link(Z.dup(v_ast), Z.dup(v_file)));
  Z.setLine(58);
  if (Z.truthy((Z.cmp(Z.B.count(Z.index(v_lk, "errors")), 0) > 0))) {
    Z.setLine(59);
    {
      const _it303 = Z.foreachArr(Z.dup(Z.index(v_lk, "errors")));
      L303: for (let _i303 = 0; _i303 < _it303.keys.length; _i303++) {
        v_e = _it303.vals[_i303];
        Z.setLine(59);
        Z.eecho(Z.concat(Z.concat(Z.concat(Z.concat(Z.concat(Z.concat(Z.index(v_e, 3), ":"), Z.index(v_e, 0)), ": błąd ["), Z.index(v_e, 1)), "]: "), Z.index(v_e, 2)));
      }
    }
    Z.setLine(60);
    Z.raise(new Z.ZExc(0, Z.concat(Z.concat("zsc: ", Z.B.count(Z.index(v_lk, "errors"))), " błędów linkowania modułów")));
  }
  Z.setLine(62);
  return ((_t2494 = Z.arrNew()), Z.aset(_t2494, "ast", Z.dup(Z.index(v_lk, "ast"))), Z.aset(_t2494, "warnings", Z.dup(Z.index(v_r, "warnings"))), _t2494);
  return null;
}
function f_native__print_warnings(v_file, v_warnings) {
  let v_w = null;
  Z.setLine(66);
  {
    const _it304 = Z.foreachArr(Z.dup(v_warnings));
    L304: for (let _i304 = 0; _i304 < _it304.keys.length; _i304++) {
      v_w = _it304.vals[_i304];
      Z.setLine(66);
      Z.eecho(Z.concat(Z.concat(Z.concat(Z.concat(v_file, ":"), Z.index(v_w, 0)), ": ostrzeżenie: "), Z.index(v_w, 1)));
    }
  }
  return null;
}
function f_native__lower_or_report(v_file, v_ast) {
  let v_res = null, v_e = null;
  Z.setLine(74);
  (v_res = f_Workspace_ir__lower(Z.dup(v_ast)));
  Z.setLine(75);
  if (Z.truthy(Z.ident(Z.B.count(Z.index(v_res, "errors")), 0))) {
    Z.setLine(75);
    return Z.dup(v_res);
  }
  Z.setLine(76);
  {
    const _it305 = Z.foreachArr(Z.dup(Z.index(v_res, "errors")));
    L305: for (let _i305 = 0; _i305 < _it305.keys.length; _i305++) {
      v_e = _it305.vals[_i305];
      Z.setLine(76);
      Z.eecho(Z.concat(Z.concat(Z.concat(Z.concat(Z.concat(Z.concat(v_file, ":"), Z.index(v_e, 0)), ": błąd ["), Z.index(v_e, 1)), "]: "), Z.index(v_e, 2)));
    }
  }
  Z.setLine(77);
  Z.eecho(Z.concat(Z.concat("zsc: ", Z.B.count(Z.index(v_res, "errors"))), " błędów — pełny język działa przez `zsc build --emit zbc` (uruchamianie: zsi)"));
  Z.setLine(78);
  return null;
  return null;
}
function f_native__opt_level(v_opts) {
  let v_o = null;
  let _t2495 = null;
  Z.setLine(82);
  {
    const _it306 = Z.foreachArr(((_t2495 = Z.arrNew()), Z.apush(_t2495, "-O0"), Z.apush(_t2495, "-O1"), Z.apush(_t2495, "-O2"), Z.apush(_t2495, "-O3"), Z.apush(_t2495, "-Os"), Z.apush(_t2495, "-Oz"), _t2495));
    L306: for (let _i306 = 0; _i306 < _it306.keys.length; _i306++) {
      v_o = _it306.vals[_i306];
      Z.setLine(82);
      if (Z.truthy(Z.B.has_key(Z.index(v_opts, "flags"), v_o))) {
        Z.setLine(82);
        return Z.dup(v_o);
      }
    }
  }
  Z.setLine(83);
  return "-O2";
  return null;
}
function f_native__toolchain(v_opts) {
  let v_tc = null;
  Z.setLine(90);
  (v_tc = f_llvmtool__detect(Z.dup(v_opts)));
  Z.setLine(91);
  if (Z.truthy(!Z.truthy(Z.index(v_tc, "ok")))) {
    Z.setLine(91);
    Z.eecho(Z.index(v_tc, "err"));
    Z.setLine(91);
    return null;
  }
  Z.setLine(92);
  return Z.dup(v_tc);
  return null;
}
function f_native__make_ll(v_file, v_opts, v_tc) {
  let v_fe = null, v___ex235 = null, v_e = null, v_irr = null, v_target = null, v_explicit = null, v_triple = null, v_ll = null, v___ex236 = null;
  let _t2496 = null, _t2497 = null, _t2498 = null, _t2499 = null;
  try {
    Z.setLine(99);
    (v_fe = f_native__frontend(Z.dup(v_file), true));
  } catch (_e) {
    _e = Z.toExc(_e);
    if (true) {
      v___ex235 = _e;
      Z.setLine(99);
      if (Z.truthy(f_zs_isa(Z.dup(v___ex235), "Exception"))) {
        Z.setLine(99);
        (v_e = Z.dup(v___ex235));
        Z.setLine(100);
        Z.eecho(f_zs_invoke(Z.dup(v_e), "getMessage", ((_t2496 = Z.arrNew()), _t2496)));
        Z.setLine(100);
        return null;
      } else {
        Z.setLine(99);
        Z.throwV(v___ex235);
      }
    }
    else throw _e;
  }
  Z.setLine(101);
  f_native__print_warnings(Z.dup(v_file), Z.dup(Z.index(v_fe, "warnings")));
  Z.setLine(102);
  (v_irr = f_native__lower_or_report(Z.dup(v_file), Z.dup(Z.index(v_fe, "ast"))));
  Z.setLine(103);
  if (Z.truthy(Z.ident(v_irr, null))) {
    Z.setLine(103);
    return null;
  }
  Z.setLine(104);
  (v_target = (((_t2497 = Z.indexOpt(Z.indexOpt(v_opts, "options"), "target")) !== null) ? _t2497 : "host"));
  Z.setLine(105);
  (v_explicit = !Z.ident(v_target, "host"));
  Z.setLine(106);
  (v_triple = (Z.truthy(v_explicit) ? v_target : f_llvmtool__host_triple(Z.dup(v_tc))));
  try {
    Z.setLine(107);
    (v_ll = f_Workspace_emit_llvm__generate(Z.dup(v_irr), Z.dup(v_triple)));
  } catch (_e) {
    _e = Z.toExc(_e);
    if (true) {
      v___ex236 = _e;
      Z.setLine(107);
      if (Z.truthy(f_zs_isa(Z.dup(v___ex236), "Exception"))) {
        Z.setLine(107);
        (v_e = Z.dup(v___ex236));
        Z.setLine(108);
        Z.eecho(Z.concat("zsc: błąd wewnętrzny backendu LLVM: ", f_zs_invoke(Z.dup(v_e), "getMessage", ((_t2498 = Z.arrNew()), _t2498))));
        Z.setLine(108);
        return null;
      } else {
        Z.setLine(107);
        Z.throwV(v___ex236);
      }
    }
    else throw _e;
  }
  Z.setLine(109);
  return ((_t2499 = Z.arrNew()), Z.aset(_t2499, "ll", Z.dup(v_ll)), Z.aset(_t2499, "triple", Z.dup(v_triple)), Z.aset(_t2499, "explicit", Z.dup(v_explicit)), _t2499);
  return null;
}
function f_native__compile(v_file, v_kind, v_out, v_opts, v_scriptDir) {
  let v_tc = null, v_m = null, v_level = null, v_tmp = null, v_keep = null, v_ll = null, v_bc = null, v_bcOut = null, v_r = null, v_ft = null, v_o1 = null, v_root = null, v_rt = null;
  let _t2500 = null;
  Z.setLine(116);
  (v_tc = f_native__toolchain(Z.dup(v_opts)));
  Z.setLine(117);
  if (Z.truthy(Z.ident(v_tc, null))) {
    Z.setLine(117);
    return 3;
  }
  Z.setLine(118);
  (v_m = f_native__make_ll(Z.dup(v_file), Z.dup(v_opts), Z.dup(v_tc)));
  Z.setLine(119);
  if (Z.truthy(Z.ident(v_m, null))) {
    Z.setLine(119);
    return 1;
  }
  Z.setLine(120);
  if (Z.truthy(Z.ident(v_kind, "ll"))) {
    Z.setLine(120);
    Z.M.File.write(v_out, Z.index(v_m, "ll"));
    Z.setLine(120);
    return 0;
  }
  Z.setLine(121);
  (v_level = f_native__opt_level(Z.dup(v_opts)));
  Z.setLine(122);
  (v_tmp = f_llvmtool__tmp_dir());
  Z.setLine(123);
  (v_keep = Z.B.has_key(Z.index(v_opts, "flags"), "--keep-temps"));
  Z.setLine(124);
  (v_ll = Z.concat(v_tmp, "/prog.ll"));
  Z.setLine(125);
  (v_bc = Z.concat(v_tmp, "/prog.bc"));
  Z.setLine(126);
  Z.M.File.write(v_ll, Z.index(v_m, "ll"));
  Z.setLine(127);
  (v_bcOut = (Z.truthy(Z.ident(v_kind, "bc")) ? v_out : v_bc));
  Z.setLine(128);
  (v_r = f_llvmtool__optimize(Z.dup(v_tc), Z.dup(v_ll), Z.dup(v_bcOut), Z.dup(v_level), Z.dup(Z.index(v_m, "triple"))));
  Z.setLine(129);
  if (Z.truthy(!Z.truthy(Z.index(v_r, "ok")))) {
    Z.setLine(130);
    Z.eecho(Z.index(v_r, "err"));
    Z.setLine(131);
    Z.eecho(Z.concat(Z.concat("zsc: błąd wewnętrzny: wygenerowany LLVM IR nie przeszedł opt (zachowano ", v_tmp), ")"));
    Z.setLine(132);
    return 1;
  }
  Z.setLine(134);
  if (Z.truthy(Z.ident(v_kind, "bc"))) {
    Z.setLine(134);
    if (Z.truthy(!Z.truthy(v_keep))) {
      Z.setLine(134);
      f_llvmtool__cleanup(Z.dup(v_tmp));
    }
    Z.setLine(134);
    return 0;
  }
  Z.setLine(135);
  (v_ft = (Z.truthy(Z.ident(v_kind, "asm")) ? "asm" : "obj"));
  Z.setLine(136);
  (v_o1 = (Z.truthy((Z.truthy(Z.ident(v_kind, "asm")) || Z.truthy(Z.ident(v_kind, "obj")))) ? v_out : Z.concat(v_tmp, "/prog.o")));
  Z.setLine(137);
  (v_r = f_llvmtool__codegen(Z.dup(v_tc), Z.dup(v_bc), Z.dup(v_o1), Z.dup(v_level), Z.dup(Z.index(v_m, "triple")), Z.dup(v_ft), Z.dup(Z.index(v_m, "explicit"))));
  Z.setLine(138);
  if (Z.truthy(!Z.truthy(Z.index(v_r, "ok")))) {
    Z.setLine(138);
    Z.eecho(Z.index(v_r, "err"));
    Z.setLine(138);
    return 1;
  }
  Z.setLine(139);
  if (Z.truthy((Z.truthy(Z.ident(v_kind, "asm")) || Z.truthy(Z.ident(v_kind, "obj"))))) {
    Z.setLine(140);
    if (Z.truthy(!Z.truthy(v_keep))) {
      Z.setLine(140);
      f_llvmtool__cleanup(Z.dup(v_tmp));
    }
    Z.setLine(141);
    return 0;
  }
  Z.setLine(143);
  (v_root = f_native__zs_root(Z.dup(v_scriptDir)));
  Z.setLine(144);
  if (Z.truthy(Z.ident(v_root, null))) {
    Z.setLine(144);
    Z.eecho("zsc: nie znaleziono Z-Sharp — ustaw ZS_HOME");
    Z.setLine(144);
    return 1;
  }
  Z.setLine(145);
  (v_rt = f_llvmtool__runtime_obj(Z.dup(v_tc), Z.dup(v_root), Z.dup(Z.index(v_m, "triple")), Z.dup(v_opts), Z.dup(v_level)));
  Z.setLine(146);
  if (Z.truthy(!Z.truthy(Z.index(v_rt, "ok")))) {
    Z.setLine(146);
    Z.eecho(Z.index(v_rt, "err"));
    Z.setLine(146);
    return 1;
  }
  Z.setLine(147);
  (v_r = f_llvmtool__link(Z.dup(v_tc), ((_t2500 = Z.arrNew()), Z.apush(_t2500, Z.dup(v_o1)), Z.apush(_t2500, Z.dup(Z.index(v_rt, "path"))), _t2500), Z.dup(v_out), Z.dup(Z.index(v_m, "triple")), Z.dup(Z.index(v_m, "explicit")), Z.dup(v_opts)));
  Z.setLine(148);
  if (Z.truthy(!Z.truthy(Z.index(v_r, "ok")))) {
    Z.setLine(148);
    Z.eecho(Z.index(v_r, "err"));
    Z.setLine(148);
    return 1;
  }
  Z.setLine(149);
  if (Z.truthy(!Z.truthy(v_keep))) {
    Z.setLine(149);
    f_llvmtool__cleanup(Z.dup(v_tmp));
  }
  Z.setLine(150);
  return 0;
  return null;
}
function f_native__build_exe(v_file, v_out, v_opts, v_scriptDir) {
  Z.setLine(154);
  return f_native__compile(Z.dup(v_file), "exe", Z.dup(v_out), Z.dup(v_opts), Z.dup(v_scriptDir));
  return null;
}
function f_usage() {
  Z.setLine(13);
  Z.echo("zsc — kompilator Z# 0.0.1 (backend LLVM >= 21)");
  Z.setLine(14);
  Z.echo("użycie:");
  Z.setLine(15);
  Z.echo("  zsc build <plik.zs> [-o <wyjście>] [--emit exe|obj|asm|bc|ll|ir|zbc] [-O0|-O1|-O2|-O3|-Os|-Oz] [--target <triple>]");
  Z.setLine(16);
  Z.echo("      Z# -> AST -> sema -> IR -> LLVM IR -> opt -> llc -> linker (+ runtime). Domyślnie: plik wykonywalny.");
  Z.setLine(17);
  Z.echo("      -c = --emit obj, -S = --emit asm. --keep-temps zostawia pliki pośrednie.");
  Z.setLine(18);
  Z.echo("  zsc run <plik.zs> [-- argumenty...]    zbuduj i uruchom (kod wyjścia programu = kod wyjścia zsc)");
  Z.setLine(19);
  Z.echo("  zsc check [--strict] [--native] <plik.zs>   składnia + sema (--native: zgodność z backendem natywnym)");
  Z.setLine(20);
  Z.echo("  zsc analyze <plik.zs>                  analiza ucieczki: klasy pamięci ZAMM dla alokacji");
  Z.setLine(21);
  Z.echo("  zsc runtime [-o <plik.o>]              zbuduj obiekt runtime (zs_rt.c) i wypisz ścieżkę");
  Z.setLine(22);
  Z.echo("  zsc toolchain                          wykryte narzędzia LLVM i ich wersje");
  Z.setLine(23);
  Z.echo("  zsc stages | --tokens <plik> | --version | --help");
  Z.setLine(24);
  Z.echo("opcje toolchaina: --llvm-bin <katalog>  --linker <sterownik>  --runtime-obj <plik.o>  --ldflags \"...\"  --allow-older-llvm");
  Z.setLine(25);
  Z.echo("kody wyjścia: 0 ok, 1 błąd (składnia, konstrukcja spoza podzbioru, błąd narzędzia), 2 użycie, 3 brak/za stary toolchain LLVM");
  Z.setLine(26);
  Z.echo("zmienne: ZS_HOME, ZS_LLVM_BIN, ZS_LINKER, ZS_RUNTIME_OBJ, ZS_CACHE, ZS_ALLOW_OLD_LLVM");
  return null;
}
function f_check(v_file, v_strict, v_nativeMode) {
  let v_fe = null, v___ex237 = null, v_e = null;
  let _t2501 = null;
  v_file = Z.chk(v_file, "string", "argument $file funkcji check");
  v_strict = Z.chk(v_strict, "bool", "argument $strict funkcji check");
  v_nativeMode = Z.chk(v_nativeMode, "bool", "argument $nativeMode funkcji check");
  try {
    Z.setLine(30);
    (v_fe = f_native__frontend(Z.dup(v_file), Z.dup(v_nativeMode)));
  } catch (_e) {
    _e = Z.toExc(_e);
    if (true) {
      v___ex237 = _e;
      Z.setLine(30);
      if (Z.truthy(f_zs_isa(Z.dup(v___ex237), "Exception"))) {
        Z.setLine(30);
        (v_e = Z.dup(v___ex237));
        Z.setLine(31);
        Z.eecho(f_zs_invoke(Z.dup(v_e), "getMessage", ((_t2501 = Z.arrNew()), _t2501)));
        Z.setLine(31);
        return Z.chk(1, "int", "wartość zwracana funkcji check");
      } else {
        Z.setLine(30);
        Z.throwV(v___ex237);
      }
    }
    else throw _e;
  }
  Z.setLine(32);
  f_native__print_warnings(Z.dup(v_file), Z.dup(Z.index(v_fe, "warnings")));
  Z.setLine(33);
  if (Z.truthy((Z.truthy(v_strict) && Z.truthy((Z.cmp(Z.B.count(Z.index(v_fe, "warnings")), 0) > 0))))) {
    Z.setLine(33);
    return Z.chk(1, "int", "wartość zwracana funkcji check");
  }
  Z.setLine(34);
  if (Z.truthy((Z.truthy(v_nativeMode) && Z.truthy(Z.ident(f_native__lower_or_report(Z.dup(v_file), Z.dup(Z.index(v_fe, "ast"))), null))))) {
    Z.setLine(34);
    return Z.chk(1, "int", "wartość zwracana funkcji check");
  }
  Z.setLine(35);
  return Z.chk(0, "int", "wartość zwracana funkcji check");
  return null;
}
function f_analyze(v_file) {
  let v_fe = null, v___ex238 = null, v_e = null;
  let _t2502 = null;
  v_file = Z.chk(v_file, "string", "argument $file funkcji analyze");
  try {
    Z.setLine(39);
    (v_fe = f_native__frontend(Z.dup(v_file), false));
  } catch (_e) {
    _e = Z.toExc(_e);
    if (true) {
      v___ex238 = _e;
      Z.setLine(39);
      if (Z.truthy(f_zs_isa(Z.dup(v___ex238), "Exception"))) {
        Z.setLine(39);
        (v_e = Z.dup(v___ex238));
        Z.setLine(40);
        Z.eecho(f_zs_invoke(Z.dup(v_e), "getMessage", ((_t2502 = Z.arrNew()), _t2502)));
        Z.setLine(40);
        return Z.chk(1, "int", "wartość zwracana funkcji analyze");
      } else {
        Z.setLine(39);
        Z.throwV(v___ex238);
      }
    }
    else throw _e;
  }
  Z.setLine(41);
  Z.echo(f_Workspace_sema__report(f_Workspace_sema__analyze(Z.dup(Z.index(v_fe, "ast")))));
  Z.setLine(42);
  return Z.chk(0, "int", "wartość zwracana funkcji analyze");
  return null;
}
function f_build_zbc(v_file, v_out) {
  let v_data = null, v___ex239 = null, v_e = null;
  let _t2503 = null;
  v_file = Z.chk(v_file, "string", "argument $file funkcji build_zbc");
  v_out = Z.chk(v_out, "string", "argument $out funkcji build_zbc");
  Z.setLine(46);
  if (Z.truthy(!Z.ident(f_check(Z.dup(v_file), false, false), 0))) {
    Z.setLine(46);
    return Z.chk(1, "int", "wartość zwracana funkcji build_zbc");
  }
  try {
    Z.setLine(47);
    (v_data = f_Workspace_zbc__bundle(Z.dup(v_file)));
  } catch (_e) {
    _e = Z.toExc(_e);
    if (true) {
      v___ex239 = _e;
      Z.setLine(47);
      if (Z.truthy(f_zs_isa(Z.dup(v___ex239), "Exception"))) {
        Z.setLine(47);
        (v_e = Z.dup(v___ex239));
        Z.setLine(48);
        Z.eecho(Z.concat("zsc: ", f_zs_invoke(Z.dup(v_e), "getMessage", ((_t2503 = Z.arrNew()), _t2503))));
        Z.setLine(48);
        return Z.chk(1, "int", "wartość zwracana funkcji build_zbc");
      } else {
        Z.setLine(47);
        Z.throwV(v___ex239);
      }
    }
    else throw _e;
  }
  Z.setLine(49);
  Z.M.File.write(v_out, v_data);
  Z.setLine(50);
  Z.echo(Z.concat(Z.concat(Z.concat(Z.concat("zsc: ", v_out), " ("), Z.B.strlen(v_data)), " B)"));
  Z.setLine(51);
  return Z.chk(0, "int", "wartość zwracana funkcji build_zbc");
  return null;
}
function f_emit_kind(v_o, v_flags) {
  let v_emit = null;
  let _t2504 = null, _t2505 = null;
  Z.setLine(55);
  (v_emit = (((_t2504 = Z.indexOpt(v_o, "emit")) !== null) ? _t2504 : null));
  Z.setLine(56);
  if (Z.truthy((Z.truthy(Z.ident(v_emit, null)) && Z.truthy(Z.B.has_key(v_flags, "-c"))))) {
    Z.setLine(56);
    (v_emit = "obj");
  }
  Z.setLine(57);
  if (Z.truthy((Z.truthy(Z.ident(v_emit, null)) && Z.truthy(Z.B.has_key(v_flags, "-S"))))) {
    Z.setLine(57);
    (v_emit = "asm");
  }
  Z.setLine(58);
  return (((_t2505 = v_emit) !== null) ? _t2505 : "exe");
  return null;
}
function f_default_out(v_stem, v_kind) {
  Z.setLine(62);
  if (Z.truthy(Z.ident(v_kind, "ll"))) {
    Z.setLine(62);
    return Z.concat(v_stem, ".ll");
  }
  Z.setLine(63);
  if (Z.truthy(Z.ident(v_kind, "bc"))) {
    Z.setLine(63);
    return Z.concat(v_stem, ".bc");
  }
  Z.setLine(64);
  if (Z.truthy(Z.ident(v_kind, "obj"))) {
    Z.setLine(64);
    return Z.concat(v_stem, ".o");
  }
  Z.setLine(65);
  if (Z.truthy(Z.ident(v_kind, "asm"))) {
    Z.setLine(65);
    return Z.concat(v_stem, ".s");
  }
  Z.setLine(66);
  if (Z.truthy(Z.ident(v_kind, "zbc"))) {
    Z.setLine(66);
    return Z.concat(v_stem, ".zbc");
  }
  Z.setLine(67);
  return Z.dup(v_stem);
  return null;
}
function f_build(v_file, v_opts, v_scriptDir) {
  let v_o = null, v_kind = null, v_stem = null, v_fe = null, v___ex240 = null, v_e = null, v_res = null, v_out = null, v_rc = null;
  let _t2506 = null, _t2507 = null, _t2508 = null, _t2509 = null;
  v_file = Z.chk(v_file, "string", "argument $file funkcji build");
  Z.setLine(71);
  (v_o = Z.dup(Z.index(v_opts, "options")));
  Z.setLine(72);
  (v_kind = f_emit_kind(Z.dup(v_o), Z.dup(Z.index(v_opts, "flags"))));
  Z.setLine(73);
  if (Z.truthy(!Z.truthy(Z.B.in_array(v_kind, ((_t2506 = Z.arrNew()), Z.apush(_t2506, "exe"), Z.apush(_t2506, "obj"), Z.apush(_t2506, "asm"), Z.apush(_t2506, "bc"), Z.apush(_t2506, "ll"), Z.apush(_t2506, "ir"), Z.apush(_t2506, "zbc"), _t2506))))) {
    Z.setLine(73);
    Z.eecho(Z.concat(Z.concat("zsc: nieznany --emit ", v_kind), " (exe|obj|asm|bc|ll|ir|zbc)"));
    Z.setLine(73);
    return Z.chk(2, "int", "wartość zwracana funkcji build");
  }
  Z.setLine(74);
  if (Z.truthy((Z.truthy(Z.B.has_key(v_o, "backend")) && Z.truthy(!Z.ident(Z.index(v_o, "backend"), "llvm"))))) {
    Z.setLine(75);
    Z.eecho(Z.concat(Z.concat("zsc: jedynym backendem jest LLVM (--backend ", Z.index(v_o, "backend")), " nie istnieje; transpilacja do C: zst, frontend gcc: zzc)"));
    Z.setLine(76);
    return Z.chk(2, "int", "wartość zwracana funkcji build");
  }
  Z.setLine(78);
  (v_stem = f_native__stem(Z.dup(v_file)));
  Z.setLine(79);
  if (Z.truthy(Z.ident(v_kind, "zbc"))) {
    Z.setLine(79);
    return Z.chk(f_build_zbc(Z.dup(v_file), (((_t2507 = Z.indexOpt(v_o, "o")) !== null) ? _t2507 : f_default_out(Z.dup(v_stem), "zbc"))), "int", "wartość zwracana funkcji build");
  }
  Z.setLine(80);
  if (Z.truthy(Z.ident(v_kind, "ir"))) {
    try {
      Z.setLine(81);
      (v_fe = f_native__frontend(Z.dup(v_file), true));
    } catch (_e) {
      _e = Z.toExc(_e);
      if (true) {
        v___ex240 = _e;
        Z.setLine(81);
        if (Z.truthy(f_zs_isa(Z.dup(v___ex240), "Exception"))) {
          Z.setLine(81);
          (v_e = Z.dup(v___ex240));
          Z.setLine(82);
          Z.eecho(f_zs_invoke(Z.dup(v_e), "getMessage", ((_t2508 = Z.arrNew()), _t2508)));
          Z.setLine(82);
          return Z.chk(1, "int", "wartość zwracana funkcji build");
        } else {
          Z.setLine(81);
          Z.throwV(v___ex240);
        }
      }
      else throw _e;
    }
    Z.setLine(83);
    (v_res = f_Workspace_ir__lower(Z.dup(Z.index(v_fe, "ast"))));
    Z.setLine(84);
    Z.echo(f_Workspace_ir__report(Z.dup(v_res)));
    Z.setLine(85);
    {
      const _it307 = Z.foreachArr(Z.dup(Z.index(v_res, "errors")));
      L307: for (let _i307 = 0; _i307 < _it307.keys.length; _i307++) {
        v_e = _it307.vals[_i307];
        Z.setLine(85);
        Z.eecho(Z.concat(Z.concat(Z.concat(Z.concat(Z.concat(Z.concat(v_file, ":"), Z.index(v_e, 0)), ": błąd ["), Z.index(v_e, 1)), "]: "), Z.index(v_e, 2)));
      }
    }
    Z.setLine(86);
    return Z.chk((Z.truthy((Z.cmp(Z.B.count(Z.index(v_res, "errors")), 0) > 0)) ? 1 : 0), "int", "wartość zwracana funkcji build");
  }
  Z.setLine(88);
  (v_out = (((_t2509 = Z.indexOpt(v_o, "o")) !== null) ? _t2509 : f_default_out(Z.dup(v_stem), Z.dup(v_kind))));
  Z.setLine(89);
  (v_rc = f_native__compile(Z.dup(v_file), Z.dup(v_kind), Z.dup(v_out), Z.dup(v_opts), Z.dup(v_scriptDir)));
  Z.setLine(90);
  if (Z.truthy(Z.ident(v_rc, 0))) {
    Z.setLine(90);
    Z.echo(Z.concat("zsc: ", v_out));
  }
  Z.setLine(91);
  return Z.chk(Z.dup(v_rc), "int", "wartość zwracana funkcji build");
  return null;
}
function f_run(v_file, v_opts, v_extra, v_scriptDir) {
  let v_dir = null, v_tmp = null, v_exe = null, v_rc = null, v_status = null;
  let _t2510 = null;
  v_file = Z.chk(v_file, "string", "argument $file funkcji run");
  Z.setLine(95);
  (v_dir = (((_t2510 = Z.M.System.env("TMPDIR")) !== null) ? _t2510 : "/tmp"));
  Z.setLine(96);
  (v_tmp = Z.concat(Z.concat(Z.concat(Z.concat(v_dir, "/zsc-run-"), Z.M.System.pid()), "-"), Z.M.System.nowNanos()));
  Z.setLine(97);
  Z.M.Directory.create(v_tmp);
  Z.setLine(98);
  (v_exe = Z.concat(Z.concat(v_tmp, "/"), f_native__stem(Z.dup(v_file))));
  Z.setLine(99);
  (v_rc = f_native__compile(Z.dup(v_file), "exe", Z.dup(v_exe), Z.dup(v_opts), Z.dup(v_scriptDir)));
  Z.setLine(100);
  if (Z.truthy(!Z.ident(v_rc, 0))) {
    Z.setLine(100);
    f_llvmtool__cleanup(Z.dup(v_tmp));
    Z.setLine(100);
    return Z.chk(Z.dup(v_rc), "int", "wartość zwracana funkcji run");
  }
  Z.setLine(101);
  (v_status = Z.M.Process.exec(v_exe, v_extra));
  Z.setLine(102);
  f_llvmtool__cleanup(Z.dup(v_tmp));
  Z.setLine(103);
  return Z.chk(Z.dup(v_status), "int", "wartość zwracana funkcji run");
  return null;
}
function f_toolchain_cmd(v_opts) {
  let v_tc = null, v_l = null;
  Z.setLine(107);
  (v_tc = f_llvmtool__detect(Z.dup(v_opts)));
  Z.setLine(108);
  Z.echo(Z.concat("wymagany LLVM >= ", Z.index(v_tc, "min")));
  Z.setLine(109);
  {
    const _it308 = Z.foreachArr(Z.dup(Z.index(v_tc, "lines")));
    L308: for (let _i308 = 0; _i308 < _it308.keys.length; _i308++) {
      v_l = _it308.vals[_i308];
      Z.setLine(109);
      Z.echo(Z.concat("  ", v_l));
    }
  }
  Z.setLine(110);
  if (Z.truthy(!Z.truthy(Z.index(v_tc, "ok")))) {
    Z.setLine(110);
    Z.eecho(Z.index(v_tc, "err"));
    Z.setLine(110);
    return Z.chk(3, "int", "wartość zwracana funkcji toolchain_cmd");
  }
  Z.setLine(111);
  Z.echo(Z.concat("host: ", f_llvmtool__host_triple(Z.dup(v_tc))));
  Z.setLine(112);
  Z.echo(Z.concat("cache: ", f_llvmtool__cache_dir()));
  Z.setLine(113);
  return Z.chk(0, "int", "wartość zwracana funkcji toolchain_cmd");
  return null;
}
function f_runtime_cmd(v_opts, v_scriptDir) {
  let v_tc = null, v_root = null, v_target = null, v_triple = null, v_r = null, v_dest = null;
  let _t2511 = null, _t2512 = null;
  Z.setLine(117);
  (v_tc = f_native__toolchain(Z.dup(v_opts)));
  Z.setLine(118);
  if (Z.truthy(Z.ident(v_tc, null))) {
    Z.setLine(118);
    return Z.chk(3, "int", "wartość zwracana funkcji runtime_cmd");
  }
  Z.setLine(119);
  (v_root = f_native__zs_root(Z.dup(v_scriptDir)));
  Z.setLine(120);
  if (Z.truthy(Z.ident(v_root, null))) {
    Z.setLine(120);
    Z.eecho("zsc: nie znaleziono Z-Sharp — ustaw ZS_HOME");
    Z.setLine(120);
    return Z.chk(1, "int", "wartość zwracana funkcji runtime_cmd");
  }
  Z.setLine(121);
  (v_target = (((_t2511 = Z.indexOpt(Z.indexOpt(v_opts, "options"), "target")) !== null) ? _t2511 : "host"));
  Z.setLine(122);
  (v_triple = (Z.truthy(Z.ident(v_target, "host")) ? f_llvmtool__host_triple(Z.dup(v_tc)) : v_target));
  Z.setLine(123);
  (v_r = f_llvmtool__runtime_obj(Z.dup(v_tc), Z.dup(v_root), Z.dup(v_triple), Z.dup(v_opts), f_native__opt_level(Z.dup(v_opts))));
  Z.setLine(124);
  if (Z.truthy(!Z.truthy(Z.index(v_r, "ok")))) {
    Z.setLine(124);
    Z.eecho(Z.index(v_r, "err"));
    Z.setLine(124);
    return Z.chk(1, "int", "wartość zwracana funkcji runtime_cmd");
  }
  Z.setLine(125);
  (v_dest = (((_t2512 = Z.indexOpt(Z.indexOpt(v_opts, "options"), "o")) !== null) ? _t2512 : null));
  Z.setLine(126);
  if (Z.truthy(!Z.ident(v_dest, null))) {
    Z.setLine(126);
    Z.M.File.write(v_dest, Z.M.File.read(Z.index(v_r, "path")));
    Z.setLine(126);
    Z.echo(v_dest);
    Z.setLine(126);
    return Z.chk(0, "int", "wartość zwracana funkcji runtime_cmd");
  }
  Z.setLine(127);
  Z.echo(Z.index(v_r, "path"));
  Z.setLine(128);
  return Z.chk(0, "int", "wartość zwracana funkcji runtime_cmd");
  return null;
}
function f_main() {
  let v_argv = null, v_scriptDir = null, v_r = null, v_pos = null, v_flags = null, v_t = null, v_cmd = null, v_s = null;
  let _t2513 = null;
  Z.setLine(132);
  (v_argv = Z.M.System.args());
  Z.setLine(133);
  (v_scriptDir = Z.M.System.dirname(Z.index(v_argv, 0)));
  Z.setLine(134);
  (v_r = f_Workspace_cli__parse(Z.dup(v_argv), ((_t2513 = Z.arrNew()), Z.apush(_t2513, "o"), Z.apush(_t2513, "target"), Z.apush(_t2513, "emit"), Z.apush(_t2513, "backend"), Z.apush(_t2513, "llvm-bin"), Z.apush(_t2513, "linker"), Z.apush(_t2513, "runtime-obj"), Z.apush(_t2513, "ldflags"), _t2513)));
  Z.setLine(135);
  (v_pos = Z.dup(Z.index(v_r, "positional")));
  Z.setLine(136);
  (v_flags = Z.dup(Z.index(v_r, "flags")));
  Z.setLine(137);
  if (Z.truthy(Z.B.has_key(v_flags, "--version"))) {
    Z.setLine(137);
    Z.echo(Z.concat("zsc ", Z.M.System.version()));
    Z.setLine(137);
    return Z.chk(0, "int", "wartość zwracana funkcji main");
  }
  Z.setLine(138);
  if (Z.truthy((Z.truthy(Z.B.has_key(v_flags, "--help")) || Z.truthy(Z.B.has_key(v_flags, "-h"))))) {
    Z.setLine(138);
    f_usage();
    Z.setLine(138);
    return Z.chk(0, "int", "wartość zwracana funkcji main");
  }
  Z.setLine(139);
  if (Z.truthy((Z.truthy(Z.B.has_key(v_flags, "--tokens")) && Z.truthy(Z.ident(Z.B.count(v_pos), 1))))) {
    Z.setLine(140);
    {
      const _it309 = Z.foreachArr(f_Workspace_lexer__tokenize(Z.M.File.read(Z.index(v_pos, 0)), false));
      L309: for (let _i309 = 0; _i309 < _it309.keys.length; _i309++) {
        v_t = _it309.vals[_i309];
        Z.setLine(140);
        Z.echo(Z.concat(Z.concat(Z.concat(Z.concat(Z.concat(Z.concat(Z.index(v_t, "line"), ":"), Z.index(v_t, "col")), "\t"), Z.index(v_t, "kind")), "\t"), Z.index(v_t, "text")));
      }
    }
    Z.setLine(141);
    return Z.chk(0, "int", "wartość zwracana funkcji main");
  }
  Z.setLine(143);
  if (Z.truthy(Z.ident(Z.B.count(v_pos), 0))) {
    Z.setLine(143);
    f_usage();
    Z.setLine(143);
    return Z.chk(2, "int", "wartość zwracana funkcji main");
  }
  Z.setLine(144);
  (v_cmd = Z.dup(Z.index(v_pos, 0)));
  Z.setLine(145);
  if (Z.truthy(Z.ident(v_cmd, "stages"))) {
    Z.setLine(146);
    {
      const _it310 = Z.foreachArr(f_pipeline__stages());
      L310: for (let _i310 = 0; _i310 < _it310.keys.length; _i310++) {
        v_s = _it310.vals[_i310];
        Z.setLine(146);
        Z.echo(Z.concat(Z.concat(Z.B.pad_right(Z.index(v_s, "name"), 20), Z.B.pad_right(Z.index(v_s, "status"), 8)), Z.index(v_s, "impl")));
      }
    }
    Z.setLine(147);
    return Z.chk(0, "int", "wartość zwracana funkcji main");
  }
  Z.setLine(149);
  if (Z.truthy(Z.ident(v_cmd, "toolchain"))) {
    Z.setLine(149);
    return Z.chk(f_toolchain_cmd(Z.dup(v_r)), "int", "wartość zwracana funkcji main");
  }
  Z.setLine(150);
  if (Z.truthy(Z.ident(v_cmd, "runtime"))) {
    Z.setLine(150);
    return Z.chk(f_runtime_cmd(Z.dup(v_r), Z.dup(v_scriptDir)), "int", "wartość zwracana funkcji main");
  }
  Z.setLine(151);
  if (Z.truthy((Z.cmp(Z.B.count(v_pos), 2) < 0))) {
    Z.setLine(151);
    f_usage();
    Z.setLine(151);
    return Z.chk(2, "int", "wartość zwracana funkcji main");
  }
  Z.setLine(152);
  if (Z.truthy(Z.ident(v_cmd, "check"))) {
    Z.setLine(152);
    return Z.chk(f_check(Z.dup(Z.index(v_pos, 1)), Z.B.has_key(v_flags, "--strict"), Z.B.has_key(v_flags, "--native")), "int", "wartość zwracana funkcji main");
  }
  Z.setLine(153);
  if (Z.truthy(Z.ident(v_cmd, "analyze"))) {
    Z.setLine(153);
    return Z.chk(f_analyze(Z.dup(Z.index(v_pos, 1))), "int", "wartość zwracana funkcji main");
  }
  Z.setLine(154);
  if (Z.truthy(Z.ident(v_cmd, "build"))) {
    Z.setLine(154);
    return Z.chk(f_build(Z.dup(Z.index(v_pos, 1)), Z.dup(v_r), Z.dup(v_scriptDir)), "int", "wartość zwracana funkcji main");
  }
  Z.setLine(155);
  if (Z.truthy(Z.ident(v_cmd, "run"))) {
    Z.setLine(155);
    return Z.chk(f_run(Z.dup(Z.index(v_pos, 1)), Z.dup(v_r), Z.B.array_slice(v_pos, 2, Z.sub(Z.B.count(v_pos), 2)), Z.dup(v_scriptDir)), "int", "wartość zwracana funkcji main");
  }
  Z.setLine(156);
  Z.eecho(Z.concat("zsc: nieznane polecenie ", v_cmd));
  Z.setLine(157);
  f_usage();
  Z.setLine(158);
  return Z.chk(2, "int", "wartość zwracana funkcji main");
  return null;
}
function zs_top() {
  Z.setLine(161);
  Z.exit(f_main());
}
Z.run(zs_top, f_main, true);
